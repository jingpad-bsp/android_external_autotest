// Copyright 2009 Google Inc.  All Rights Reserved.

/**
 * @fileoverview Extension of talk.media.C3dMuteHandler to only work in
 * fullscreen mode and also handle a mute keyboard shortcut.
 *
 * @author perd@google.com (Per Danvind)
 */

goog.provide('talk.media.C3dFullscreenMuteHandler');

goog.require('goog.debug.Logger');
goog.require('goog.events.BrowserEvent');
goog.require('goog.events.EventHandler');
goog.require('goog.events.EventTarget');
goog.require('goog.events.EventType');
goog.require('talk.media.C3dMuteHandler');


/**
 * Adds keyboard shortcut handling for microphone mute and limits mute handling
 * to fullscreen mode.
 *
 * @extends {talk.media.C3dMuteHandler}
 * @constructor
 */
talk.media.C3dFullscreenMuteHandler = function() {
  talk.media.C3dMuteHandler.call(this);
};
goog.inherits(talk.media.C3dFullscreenMuteHandler, talk.media.C3dMuteHandler);


/**
 * The char code of the default mute shortcut to use in C3D fullscreen mode.
 *
 * @type {number}
 * @private
 */
talk.media.C3dFullscreenMuteHandler.DEFAULT_MUTE_SHORTCUT_ = 32;


/**
 * Logger.  Note that the name logger_ could not be used since it somehow
 * clashed with the logger_ field of the super class.
 *
 * @type {!goog.debug.Logger}
 * @private
 */
talk.media.C3dFullscreenMuteHandler.prototype.fsLogger_ =
    goog.debug.Logger.getLogger('talk.media.C3dFullscreenMuteHandler');


/**
 * Char code for mute shortcut.
 *
 * @type {?number}
 * @private
 */
talk.media.C3dFullscreenMuteHandler.prototype.muteCharCode_;


/**
 * Event handler for simple install/remove of shortcut listener.
 *
 * @type {goog.events.EventHandler}
 * @private
 */
talk.media.C3dFullscreenMuteHandler.prototype.eventHandler_;


/**
 * Sets up handling of a keyboard shortcut for microphone mute.
 *
 * @param {goog.events.EventTarget} shortcutSource An event target to
 *     listen to for keyboard shortcuts.
 * @param {number} opt_muteCharCode The char code of the mute keyboard
 *     shortcut. If not specified, a default is used.
 */
talk.media.C3dFullscreenMuteHandler.prototype.setupMuteShortcut =
    function(shortcutSource, opt_muteCharCode) {
  this.muteCharCode_ = opt_muteCharCode ||
      talk.media.C3dFullscreenMuteHandler.DEFAULT_MUTE_SHORTCUT_;
  this.fsLogger_.info('Setup mute shortcut in fullscreen mode for charCode: ' +
      this.muteCharCode_);
  this.eventHandler_ = new goog.events.EventHandler(this);
  this.eventHandler_.listen(shortcutSource,
      goog.events.EventType.KEYPRESS, this.onKeyPress_);
};


/**
 * Overridden to always disable the mute handler initially.  It will be enabled
 * later if/when fullscreen mode is entered.
 *
 * @override
 * @protected
 */
talk.media.C3dFullscreenMuteHandler.prototype.initInternal = function() {
  talk.media.C3dFullscreenMuteHandler.superClass_.initInternal.call(this,
      false);
};


/**
 * Overridden to only enable mute handling in fullscreen mode.
 *
 * @param {Object} e A C3D event.
 * @override
 * @protected
 */
talk.media.C3dFullscreenMuteHandler.prototype.onResize = function(e) {
  talk.media.C3dFullscreenMuteHandler.superClass_.onResize.call(this, e);
  this.setEnabled(!!e['fullscreen']);
};


/**
 * @override
 * @protected
 */
talk.media.C3dFullscreenMuteHandler.prototype.disposeInternal = function() {
  talk.media.C3dFullscreenMuteHandler.superClass_.disposeInternal.call(this);
  if (this.eventHandler_) {
    this.eventHandler_.dispose();
  }
};


/**
 * Handler for keypress events to support mute keyboard shortcut.
 *
 * @param {goog.events.BrowserEvent} e The event.
 * @private
 */
talk.media.C3dFullscreenMuteHandler.prototype.onKeyPress_ = function(e) {
  if (e.charCode == this.muteCharCode_ && this.isEnabled()) {
    // Toggle mute state of call.
    var callManager = this.getCallManager();
    if (callManager) {
      var wasMuted = callManager.getMicrophoneMute();
      callManager.setMicrophoneMute(!wasMuted);
    }
  }
};
