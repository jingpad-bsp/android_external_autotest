// Copyright 2009 Google Inc.  All Rights Reserved.

/**
 * @fileoverview A wrapper for C3D event system to fit the closure event
 * system.  It only supports 'keypress' events so far.
 *
 * @author perd@google.com (Per Danvind)
 */

goog.provide('talk.media.c3d.C3dEventTarget');

goog.require('goog.debug.Logger');
goog.require('goog.events.BrowserEvent');
goog.require('goog.events.EventTarget');
goog.require('talk.media.c3d.C3dObject');
goog.require('talk.media.c3d.helpers');

/**
 * Creates a {goog.events.EventTarget} wrapper for C3D plugin.
 *
 * @constructor
 * @extends {goog.events.EventTarget}
 */
talk.media.c3d.C3dEventTarget = function() {
  goog.events.EventTarget.call(this);

  /**
   * A goog.bind()'ed version of onKeyPress_, suitable for using as an event
   * callback.
   *
   * @type Function
   * @private
   */
  this.boundOnKeyPress_ = goog.bind(this.onKeyPress_, this);
};
goog.inherits(talk.media.c3d.C3dEventTarget, goog.events.EventTarget);


/**
 * Mapping of C3D event to suit {goog.events.BrowserEvent}.
 *
 * @param {Object} e A C3D event object.
 * @constructor
 * @extends {Event}
 * @private
 */
talk.media.c3d.C3dEventTarget.MappedEvent_ = function(e) {
  this.type = e['type'];
  this.keyCode = e['keyCode'];
  this.charCode = e['charCode'];
  this.which = e['charCode'] || e['keyCode'];
  this.ctrlKey = e['ctrlKey'];
  this.altKey = e['altKey'];
  this.shiftKey = e['shiftKey'];
  this.metaKey = e['metaKey'];
};


/**
 * The C3D plugin object.
 *
 * @type {talk.media.c3d.C3dObject}
 * @private
 */
talk.media.c3d.C3dEventTarget.prototype.c3dObject_;


/**
 * Logger for debugging.
 *
 * @type {!goog.debug.Logger}
 * @private
 */
talk.media.c3d.C3dEventTarget.prototype.logger_ =
    goog.debug.Logger.getLogger('talk.media.c3d.C3dEventTarget');


/**
 * Sets the C3D plugin object to be managed by the event target wrapper.
 *
 * @param {talk.media.c3d.C3dObject} c3dObject The Client3D plugin object.
 */
talk.media.c3d.C3dEventTarget.prototype.setC3d = function(c3dObject) {
  if (this.c3dObject_) {
    this.removeEventCallbacks_();
  }
  this.c3dObject_ = c3dObject;
  if (this.c3dObject_) {
    this.addEventCallbacks_();
  }
};


/**
 * @override
 * @protected
 */
talk.media.c3d.C3dEventTarget.prototype.disposeInternal = function() {
  talk.media.c3d.C3dEventTarget.superClass_.disposeInternal.call(this);
  if (this.c3dObject_) {
    this.removeEventCallbacks_();
  }
};


/**
 * Handles C3D keypress events by dispatching them as ordinary closure events to
 * any listeners on this object.
 *
 * @param {Object} e The C3D event.
 * @private
 */
talk.media.c3d.C3dEventTarget.prototype.onKeyPress_ = function(e) {
  this.dispatchEvent(new goog.events.BrowserEvent(
      new talk.media.c3d.C3dEventTarget.MappedEvent_(e)));
};


/**
 * Registers event callbacks on the C3D plugin object.
 *
 * @private
 */
talk.media.c3d.C3dEventTarget.prototype.addEventCallbacks_ = function() {
  talk.media.c3d.addEventCallback(this.c3dObject_.getPlugin(), 'keypress',
      this.boundOnKeyPress_);
  this.logger_.info('Added keypress event callback on C3D plugin.');
};


/**
 * Removes event callbacks from the C3D plugin object.
 *
 * @private
 */
talk.media.c3d.C3dEventTarget.prototype.removeEventCallbacks_ = function() {
  if (this.c3dObject_.isScriptable()) {  // Might not be during shutdown
    talk.media.c3d.removeEventCallback(this.c3dObject_.getPlugin(), 'keypress',
        this.boundOnKeyPress_);
    this.logger_.info('Removed keypress event callback from C3D plugin.');
  }
};
