// Copyright 2009 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview Base for classes that handle the layout of video feeds.
 * Provides a mechanism to create and manage a set of feeds and a mechanism to
 * respond to changing layout conditions.
 *
 * @author mikaeld@google.com (Mikael Drugge)
 * @author geer@google.com (Arthur van der Geer)
 */

goog.provide('talk.media.c3d.SceneBase');

goog.require('goog.Disposable');
goog.require('goog.debug.Logger');
goog.require('goog.structs.Map');


/**
 * Creates the SceneBase object with functionality common to video scenes.
 *
 * @param {talk.media.c3d.O3dBundle} o3dBundle The bundle of global resources
 *     for this O3D instance.
 * @extends {goog.Disposable}
 * @constructor
 */
talk.media.c3d.SceneBase = function(o3dBundle) {
  goog.Disposable.call(this);

  // TODO(geer): split this class in two, one interface for specialization and
  // one with common implementation for scenes 'owning' feeds.

  /**
   * The container for global O3D handles.
   *
   * @type {talk.media.c3d.O3dBundle}
   * @protected
   */
  this.o3dBundle = o3dBundle;

  /**
   * Map holding the remote user video scene feeds.
   *
   * @type {goog.structs.Map}
   * @private
   */
  this.feeds_ = new goog.structs.Map();
};
goog.inherits(talk.media.c3d.SceneBase, goog.Disposable);


/**
 * Logger for debugging.
 *
 * @type {goog.debug.Logger}
 * @private
 */
talk.media.c3d.SceneBase.logger_ =
    goog.debug.Logger.getLogger('talk.media.c3d.SceneBase');


/**
 * The x-coordinate of the origin (bottom-left corner) for the rectangle to
 * draw in.
 *
 * @type {number}
 * @protected
 */
talk.media.c3d.SceneBase.prototype.x_;


/**
 * The y-coordinate of the origin (bottom-left corner) for the rectangle to
 * draw in.
 *
 * @type {number}
 * @protected
 */
talk.media.c3d.SceneBase.prototype.y_;


/**
 * The width of the rectangle to draw in.
 *
 * @type {number}
 * @protected
 */
talk.media.c3d.SceneBase.prototype.width_;


/**
 * The height of the rectangle to draw in.
 *
 * @type {number}
 * @protected
 */
talk.media.c3d.SceneBase.prototype.height_;


/**
 * Sets the area of the O3D window in which to draw.
 *
 * @param {number} x The x-coord of origin of rect in which to draw.
 * @param {number} y The y-coord of origin of rect in which to draw.
 * @param {number} width Width of rect in which to draw.
 * @param {number} height Height of rect in which to draw.
 */
talk.media.c3d.SceneBase.prototype.setArea = function(x, y, width, height) {
  this.x_ = x;
  this.y_ = y;
  this.width_ = width;
  this.height_ = height;
  this.updatePositions();
};


/**
 * Updates the position of all video feeds on screen, e.g. after having added
 * or removed one or more feeds, or after a resize of the available area.
 *
 * @protected
 */
talk.media.c3d.SceneBase.prototype.updatePositions = goog.abstractMethod;


/**
 * Adds a new video feed to display a stream. Returns null if scene did not
 * create one.
 *
 * @param {talk.media.c3d.StreamEndpoint} stream The endpoint providing its
 *     texture.
 * @param {?string} streamId The stream id.
 * @param {string} label The text to label the feed.
 */
talk.media.c3d.SceneBase.prototype.addFeed =
    function(stream, streamId, label) {
  if (this.feeds_.containsKey(streamId)) {
    talk.media.c3d.SceneBase.logger_.warning(
        'Attempt to add feed for existing stream ' + streamId);
    return;
  }
  var feed = this.createFeed(stream, streamId, label);
  if (feed) {
    this.feeds_.set(streamId, feed);
    this.updatePositions();
    talk.media.c3d.SceneBase.logger_.info('Added feed for stream ' + streamId +
        ', now displaying ' + this.feeds_.getCount() + ' feeds.');
  } else {
    talk.media.c3d.SceneBase.logger_.info('No feed created for stream ' +
        streamId + '.');
  }
};


/**
 * Creates a new video feed to display a stream. Returns null if scene did not
 * create one.
 *
 * @param {talk.media.c3d.StreamEndpoint} stream The endpoint providing its
 *     texture.
 * @param {?string} streamId The stream id.
 * @param {string} label The text to label the feed.
 * @return {?talk.media.c3d.BaseFeed}
 * @protected
 */
talk.media.c3d.SceneBase.prototype.createFeed = goog.abstractMethod;


/**
 * Removes a video feed.
 *
 * @param {string} streamId The stream id.
 */
talk.media.c3d.SceneBase.prototype.removeFeed = function(streamId) {
  if (!this.feeds_.containsKey(streamId)) {
    talk.media.c3d.SceneBase.logger_.warning('Attempt to remove feed for ' +
        'non-existing stream ' + streamId);
    return;
  }
  this.removeFeedInternal_(streamId);
  this.updatePositions();
  talk.media.c3d.SceneBase.logger_.info('Removed feed for stream ' + streamId +
      ', now displaying ' + this.feeds_.getCount() + ' feeds.');
};


/**
 * Returns the video feed for the given stream.
 *
 * @param {?string} streamId The stream id.
 * @return {talk.media.c3d.BaseFeed} The video feed.
 */
talk.media.c3d.SceneBase.prototype.getFeed = function(streamId) {
  return /** @type {talk.media.c3d.BaseFeed} */(
      this.feeds_.get(streamId));
};


/**
 * Returns whether there exists a video feed for the given stream.
 *
 * @param {?string} streamId The stream id.
 * @return {boolean} Whether there exists a feed for the given stream.
 */
talk.media.c3d.SceneBase.prototype.hasFeed = function(streamId) {
  return this.feeds_.containsKey(streamId);
};


/**
 * Removes and disposes the video feed corresponding to the given stream.
 *
 * @param {?string} streamId The stream id.
 * @private
 */
talk.media.c3d.SceneBase.prototype.removeFeedInternal_ = function(streamId) {
  var feed = this.feeds_.get(streamId);
  this.feeds_.remove(streamId);
  feed.dispose();
};


/**
 * @return {number}
 */
talk.media.c3d.SceneBase.prototype.getFeedCount = function() {
  return this.feeds_.getCount();
};


/**
 * @return {!Array.<string>}
 */
talk.media.c3d.SceneBase.prototype.getStreamIds = function() {
  return this.feeds_.getKeys();
};


/**
 * Disposes all video feeds.
 */
talk.media.c3d.SceneBase.prototype.disposeAllFeeds = function() {
  var streams = this.feeds_.getKeys();
  for (var i = 0; i < streams.length; ++i) {
    this.removeFeedInternal_(streams[i]);
  }
};


/**
 * @override
 * @protected
 */
talk.media.c3d.SceneBase.prototype.disposeInternal = function() {
  talk.media.c3d.SceneBase.superClass_.disposeInternal.call(this);
  this.disposeAllFeeds();
  this.feeds_ = null;
};
