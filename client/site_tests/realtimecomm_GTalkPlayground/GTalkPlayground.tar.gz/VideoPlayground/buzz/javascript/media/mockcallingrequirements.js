// Copyright 2008 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview Defines a mock implementation of the CallingRequirements class.
 *
 * @author jessan@google.com (Jessan Hutchison-Quillian)
 */

goog.provide('talk.media.MockCallingRequirements');
goog.provide('talk.media.MockClient3DDetector');
goog.provide('talk.media.MockFlashDetector');
goog.provide('talk.media.MockRendererDetector');

goog.require('talk.media.CallingRequirements');
goog.require('talk.media.Client3DDetector');
goog.require('talk.media.FlashDetector');
goog.require('talk.media.RendererDetector');


/**
 * Mock of FlashDetector to keep independent of the user agent and test
 * behaviour for different states of Flash.
 *
 * @param {boolean} installed Whether flash is installed or not, default
 *     true.
 * @param {boolean} required Whether flash has required version or not,
 *     default true.
 * @constructor
 * @extends talk.media.FlashDetector
 */
talk.media.MockFlashDetector = function (installed, required) {
  talk.media.FlashDetector.call(this);
  this.hasFlash = installed || (installed == undefined);
  this.hasRequiredVersion = required || (required == undefined);
};
talk.media.MockFlashDetector.inherits(talk.media.FlashDetector);


talk.media.MockFlashDetector.prototype.hasFlashInstalled = function() {
  return this.hasFlash;
};


talk.media.MockFlashDetector.prototype.hasRequiredFlashVersion = function() {
  return this.hasRequiredVersion;
};


/**
 * Mock of Client3DDetector to remain independent of the user agent and test
 * behaviour for different states of Client3D.
 *
 * @param {boolean} installed Whether Client3D is installed or not, default
 *     true.
 * @constructor
 * @extends talk.media.Client3DDetector
 */
talk.media.MockClient3DDetector = function(installed) {
  talk.media.Client3DDetector.call(this);
  this.hasClient3D = installed || (installed == undefined);
  this.mockPluginVersion_ = '1.0';
};
talk.media.MockClient3DDetector.inherits(talk.media.Client3DDetector);


talk.media.MockClient3DDetector.prototype.isInstalled = function() {
  return this.hasClient3D;
};


/**
 * @param {string} version String representation of the current version of the
 *     plugin.
 */
talk.media.MockClient3DDetector.prototype.setVersion = function(version) {
  this.mockPluginVersion_ = version;
};


/**
 * @override
 * @return {?string} String representation of the current plugin version.
 */
talk.media.MockClient3DDetector.prototype.getVersion = function() {
  if (this.hasClient3D) {
    return this.mockPluginVersion_;
  }
  return null;
};


/**
 * Mock of RendererDetector to remain independent of different states of Flash
 * and Client3D and test behaviour for different configurations of Flash and
 * Client3D.
 *
 * @param {boolean} flashInstalled Whether flash is installed or not, default
 *     true.
 * @param {boolean} flashRequired Whether flash has required version or not,
 *     default true.
 * @param {boolean} client3DInstalled Whether Client3D is installed or not,
 *     default true.
 * @param {boolean} supportClient3D Whether Client3D should be used if
 *     available or not, default true.
 * @constructor
 * @extends talk.media.RendererDetector
 */
talk.media.MockRendererDetector = function(flashInstalled, flashRequired,
    client3DInstalled, supportClient3D) {
  talk.media.RendererDetector.call(this, supportClient3D);
  this.flash = new talk.media.MockFlashDetector(flashInstalled, flashRequired);
  this.client3d = new talk.media.MockClient3DDetector(client3DInstalled);
};
talk.media.MockRendererDetector.inherits(talk.media.RendererDetector);


talk.media.MockRendererDetector.prototype.getFlashDetector = function() {
  return this.flash;
};


talk.media.MockRendererDetector.prototype.getClient3DDetector = function() {
  return this.client3d;
};


/**
 * Mock of CallingRequirements to remain independent of different OS, Flash
 * and Client3D configurations.
 *
 * @param {boolean} supportClient3D Whether Client3D should be used if
 *     available or not, default true.
 * @constructor
 * @extends talk.media.CallingRequirements
 */
talk.media.MockCallingRequirements = function(supportClient3D) {
  talk.media.CallingRequirements.call(this, supportClient3D);
  this.isSupportedOs = true;
  this.rendererDetector = new talk.media.MockRendererDetector(true, true, false,
      supportClient3D);
};
talk.media.MockCallingRequirements.inherits(talk.media.CallingRequirements);

talk.media.MockCallingRequirements.prototype.isAvailableForOs = function() {
  return this.isSupportedOs;
};


talk.media.MockCallingRequirements.prototype.getRendererDetector = function() {
  return this.rendererDetector;
};
