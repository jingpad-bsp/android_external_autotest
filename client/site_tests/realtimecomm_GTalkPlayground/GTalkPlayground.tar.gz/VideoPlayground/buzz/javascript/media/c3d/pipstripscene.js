// Copyright 2009 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview Handles the layout of multiple video views in N:N calls in a
 *     strip at the bottom of the main video feed.
 *
 * @author mikaeld@google.com (Mikael Drugge)
 * @author geer@google.com (Arthur van der Geer)
 */

goog.provide('talk.media.c3d.PipStripScene');

goog.require('goog.debug.Logger');
goog.require('talk.media.c3d.PipScene');
goog.require('talk.media.c3d.StripScene');


/**
 * Creates the PipStripScene.
 *
 * @param {talk.media.c3d.O3dBundle} o3dBundle The bundle of global resources
 *     for this O3D instance.
 * @extends {talk.media.c3d.SceneBase}
 * @constructor
 */
talk.media.c3d.PipStripScene = function(o3dBundle) {
  talk.media.c3d.SceneBase.call(this, o3dBundle);

  this.main_ = new talk.media.c3d.PipScene(o3dBundle, true);
  this.strip_ = new talk.media.c3d.StripScene(o3dBundle);
};
goog.inherits(talk.media.c3d.PipStripScene, talk.media.c3d.SceneBase);


/**
 * Logger for debugging.
 *
 * @type {goog.debug.Logger}
 * @private
 */
talk.media.c3d.PipStripScene.logger_ =
    goog.debug.Logger.getLogger('talk.media.c3d.PipStripScene');


/**
 * @override
 */
talk.media.c3d.PipStripScene.prototype.addFeed =
    function(stream, streamId, label) {
  if (streamId == null || streamId == '0') {
    this.main_.addFeed(stream, streamId, label);
  } else {
    this.strip_.addFeed(stream, streamId, label);
  }
};


/**
 * @override
 */
talk.media.c3d.PipStripScene.prototype.removeFeed =
    function(streamId) {
  if (streamId == null || streamId == '0') {
    this.main_.removeFeed(streamId);
  } else {
    this.strip_.removeFeed(streamId);
  }
};


/**
 * @override
 */
talk.media.c3d.PipStripScene.prototype.hasFeed = function(streamId) {
  if (streamId == null || streamId == '0') {
    return this.main_.hasFeed(streamId);
  } else {
    return this.strip_.hasFeed(streamId);
  }
};


/**
 * @override
 * @protected
 */
talk.media.c3d.PipStripScene.prototype.createFeed =
    function(stream, streamId, label) {
  talk.media.c3d.PipStripScene.logger_.severe('Unexpected call to createFeed.');
  return null;
};


/**
 * @override
 * @protected
 */
talk.media.c3d.PipStripScene.prototype.updatePositions = function() {
  this.main_.setArea(this.x_, this.y_, this.width_, this.height_);
  this.strip_.setArea(this.x_, this.y_, this.width_, this.height_);
};


/**
 * @override
 */
talk.media.c3d.PipStripScene.prototype.disposeAllFeeds = function() {
  if (this.main_) {
    this.main_.disposeAllFeeds();
  }
  if (this.strip_) {
    this.strip_.disposeAllFeeds();
  }
};


/**
 * @override
 * @protected
 */
talk.media.c3d.PipStripScene.prototype.disposeInternal = function() {
  talk.media.c3d.PipStripScene.superClass_.disposeInternal.call(this);
  this.main_.dispose();
  this.main_ = null;
  this.strip_.dispose();
  this.strip_ = null;
};
