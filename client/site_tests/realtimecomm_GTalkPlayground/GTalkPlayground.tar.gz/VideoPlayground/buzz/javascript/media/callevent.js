
// Copyright 2008 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview Handles communi
 *
 * @author jessan@google.com (Jessan Hutchison-Quillian)
 */
goog.provide('talk.media.CallEvent');

goog.require('goog.debug.Logger');
goog.require('goog.events.Event');
goog.require('goog.json');

/**
 * An event indicating that we have received a Jingle message or a message from
 * the Google Talk Plugin
 *
 * @param {string} type The type of call event
 * @param {string} json The json message triggering the event
 * @constructor
 * @extends goog.events.Event
 */
talk.media.CallEvent = function(type, json) {
  goog.events.Event.call(this, type);

  /**
   * @type string
   */
  this.json = json

  /**
   * The type parameter of this message.
   * @type string
   */
  this.msgType = this.getMsgType_(json);
};
talk.media.CallEvent.inherits(goog.events.Event);

talk.media.CallEvent.logger_ =
    goog.debug.Logger.getLogger('talk.media.CallEvent');

/**
 * The parsed JSON message, lazily initialized.
 *
 * @type Array
 * @private
 */
talk.media.CallEvent.prototype.parsedMsg_;

talk.media.CallEvent.prototype.getParsedMsg = function() {
  if (!this.parsedMsg_) {
    this.parsedMsg_ = /** @type Array */ (this.json ?
        goog.json.parse(this.json) : null);
  }
  return this.parsedMsg_;
};


/**
 * Returns the first string (the type parameter) in the json array.
 * @private
 */
talk.media.CallEvent.prototype.getMsgType_ = function(json) {
  try {
    var type = json.match('".*?"')[0];
    return type.substring(1, type.length - 1);
  } catch (e) {
    talk.media.CallEvent.logger_.warning(
        'We received an empty message from the plugin');
    return '';
  }
};
