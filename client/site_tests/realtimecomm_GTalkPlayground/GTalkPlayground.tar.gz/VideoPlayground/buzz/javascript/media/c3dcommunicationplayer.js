// Copyright 2008 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview A Client3D UI object handling real time communication.
 *
 * @author tschmelcher@google.com (Tristan Schmelcher)
 */

goog.provide('talk.media.C3dCommunicationPlayer');
goog.provide('talk.media.C3dCommunicationPlayer.FatalErrorEvent');

goog.require('goog.Timer');
goog.require('goog.debug.Trace');
goog.require('goog.events');
goog.require('goog.events.EventHandler');
goog.require('goog.structs.Map');
goog.require('goog.style');
goog.require('talk.media.C3dMuteHandler');
goog.require('talk.media.C3dNotifier');
goog.require('talk.media.CallManager');
goog.require('talk.media.CallManager.Call');
goog.require('talk.media.CallType');
goog.require('talk.media.CommunicationPlayer');  // for constants
goog.require('talk.media.c3d.C3dEngine');
goog.require('talk.media.c3d.C3dEventTarget');
goog.require('talk.media.c3d.C3dObject');
goog.require('talk.media.c3d.CursorManager');
goog.require('talk.media.c3d.Image');
goog.require('talk.media.c3d.ImageOverlay');
goog.require('talk.media.c3d.NotificationRenderer');
goog.require('talk.media.c3d.O3dBundle');
goog.require('talk.media.c3d.PipScene');
goog.require('talk.media.c3d.StreamEndpoint');
goog.require('talk.media.c3d.PipStripScene');
goog.require('talk.media.c3d.View');
goog.require('talk.media.c3d.helpers');


/**
 * Creates a player that displays real time communication (voice/video calls)
 * via Client3D. Based on CommunicationPlayer and NativeCommunicationPlayer.
 *
 * <p>Ordinary browser events like 'keypress' originating from the Client3D
 * plugin can be subscribed to by listening to this player.
 *
 * @param {talk.media.CallManager} callManager The manager for voice/video
 *     calls.
 * @param {boolean} opt_multiView Whether to enable multiple video views.
 * @param {talk.media.C3dMuteHandler} opt_muteHandler A handler for mute
 *     indications.
 * @param {boolean} opt_enableNotifications Whether to enable notifications.
 * @param {boolean} opt_hidePip Whether to hide the local feed, default false.
 * @constructor
 * @extends goog.events.EventTarget
 */
talk.media.C3dCommunicationPlayer = function(callManager,
    opt_multiView, opt_muteHandler, opt_enableNotifications, opt_hidePip) {
  goog.events.EventTarget.call(this);

  /**
   * A trace of how long it takes us to start video from the time that we
   * are created.
   *
   * @type {?number}
   * @private
   */
  this.videoStartTrace_ = goog.debug.Trace.startTracer(
      'communicationPlayer.start');


  /**
   * The container for our global O3D handles that will be shared across
   * multiple classes.
   *
   * @type {talk.media.c3d.O3dBundle}
   * @private
   */
  this.o3dBundle_ = new talk.media.c3d.O3dBundle();

  this.o3dBundle_.c3dObject = new talk.media.c3d.C3dObject();
  this.o3dBundle_.c3dEngine = new talk.media.c3d.C3dEngine();
  this.o3dBundle_.cursorManager =
      new talk.media.c3d.CursorManager(this.o3dBundle_);


  /**
   * A wrapper to convert C3D events to closure events and allow ordinary
   * closure event listening.
   *
   * @type {!talk.media.c3d.C3dEventTarget}
   */
  this.c3dEventTarget_ = new talk.media.c3d.C3dEventTarget();
  this.c3dEventTarget_.setParentEventTarget(this);


  /**
   * The call manager handles communication with the server and the
   * TalkPlugin.
   *
   * @type talk.media.CallManager
   * @private
   */
  this.callManager_ = callManager;


  /**
   * The mute handler for mute state indication icons.
   *
   * @type {talk.media.C3dMuteHandler}
   * @private
   */
  this.muteHandler_ = opt_muteHandler || null;


  /**
   * The flag to enable/disable notifications in O3D..
   *
   * @type {boolean}
   * @private
   */

  this.enableNotifications_ = opt_enableNotifications || false;


  /**
   * EventHandler to simplify installing/removing event listeners.
   *
   * @type goog.events.EventHandler
   * @private
   */
  this.eventHandler_ = new goog.events.EventHandler(this);

  this.eventHandler_.listen(this.callManager_,
      talk.media.CallManager.Event.SHOW_VIDEO, this.handleShowVideo_);
  this.eventHandler_.listen(this.callManager_,
      talk.media.CallManager.Event.ADD_VIDEO, this.handleAddVideo_);
  this.eventHandler_.listen(this.callManager_,
      talk.media.CallManager.Event.REMOVE_VIDEO, this.handleRemoveVideo_);

  /**
   * A list of all our stream endpoints.
   *
   * @type Array
   * @private
   */
  this.streamEndpoints_ = [];


  /**
   * A map from texture ids to the StreamEndpoints that created them.
   *
   * @type Object
   * @private
   */
  this.textureIdToEndpoint_ = {};


  // TODO(geer): Pass an opt_scene to use.
  var scene;
  if (opt_multiView) {
    scene = new talk.media.c3d.PipStripScene(this.o3dBundle_);
  } else {
    scene = new talk.media.c3d.PipScene(this.o3dBundle_);
  }
  /**
   * Our scene showing our stream endpoints.
   *
   * @type {talk.media.c3d.SceneBase}
   * @private
   */
  this.scene_ = scene;


  /**
   * Whether or not to hide the local feed.
   *
   * @type {boolean}
   * @private
   */
  this.hidePip_ = opt_hidePip || false;


  /**
   * A goog.bind()'ed version of onResize_, suitable for using as an event
   * callback.
   *
   * @type Function
   * @private
   */
  this.boundOnResize_ = goog.bind(this.onResize_, this);


  /**
   * A goog.bind()'ed version of onMouseMove_, suitable for using as an event
   * callback.
   *
   * @type Function
   * @private
   */
  this.boundOnMouseMove_ = goog.bind(this.onMouseMove_, this);


  /**
   * A goog.bind()'ed version of onClick_, suitable for using as an event
   * callback.
   *
   * @type Function
   * @private
   */
  this.boundOnClick_ = goog.bind(this.onClick_, this);


  /**
   * @type {goog.structs.Map} Maps the jids of participants to avatar urls.
   * @private
   */
  this.jidAvatarMap_ = new goog.structs.Map();
};
goog.inherits(talk.media.C3dCommunicationPlayer, goog.events.EventTarget);


/**
 * List of events that we dispatch.
 *
 * @enum {string}
 */
talk.media.C3dCommunicationPlayer.Events = {

  /**
   * Denotes a fatal error that prevents playback.
   */
  FATAL_ERROR : 'c3dcp-error'
};


/**
 * Event class for the
 * {@code talk.media.C3dCommunicationPlayer.Events.FATAL_PLAYER_ERROR} event.
 *
 * @constructor
 * @extends {goog.events.Event}
 */
talk.media.C3dCommunicationPlayer.FatalErrorEvent = function() {
  goog.events.Event.call(this,
      talk.media.C3dCommunicationPlayer.Events.FATAL_ERROR);
};
goog.inherits(talk.media.C3dCommunicationPlayer.FatalErrorEvent,
    goog.events.Event);


/**
 * The string constant for our effect code, Cg version.
 *
 * @type {string}
 * @const
 * @private
 */
talk.media.C3dCommunicationPlayer.EFFECT_STRING_CG_ =
    // The texture sampler is used to access the texture bitmap in the
    // pixel shader.
    'sampler texSampler0;' +
    'float4x4 worldViewProj : WORLDVIEWPROJECTION;' +
    // Alpha scaling value for doing fade-in.
    'float alpha;' +
    // Input parameters for our vertex shader
    'struct a2v {' +
      'float4 pos : POSITION;' +
      'float2 tex : TEXCOORD0;' + // Texture coordinates
    '};' +
    // Input parameters for our pixel shader
    'struct v2f {' +
      'float4 pos : POSITION;' +
      'float2 tex : TEXCOORD0;' + // Texture coordinates
    '};' +
    // Our vertex shader transforms the vertices to the proper screen-relative
    // position.
    'v2f vsMain(a2v IN) {' +
      'v2f OUT;' +
      'OUT.pos = mul(IN.pos, worldViewProj);' +
      'OUT.tex = IN.tex;' +
      'return OUT;' +
    '}' +
    // Given the texture coordinates, our pixel shader grabs the corresponding
    // color from the texture, changing the brightness to the desired level.
    'float4 psMain(v2f IN) : COLOR {' +
      // The "alpha" component in the input is not for brightness, it's for
      // transparency, but we don't have that enabled so it's unused (but
      // Cg language rules still require a float4 everywhere). To change the
      // brightness, we just multiply the RGB components by our scaling factor.
      // This code actually says to multiply the fourth alpha component too, but
      // the effect compiler must be smart enough to optimize this case because
      // this is actually MORE performant than only multiplying the RGB
      // components (by about 7%, measured as fps in SwiftShader).
      'return tex2D(texSampler0, IN.tex) * alpha;' +
    '}\n' +
    '// #o3d VertexShaderEntryPoint vsMain\n' +
    '// #o3d PixelShaderEntryPoint psMain\n' +
    '// #o3d MatrixLoadOrder RowMajor\n';

/**
 * The string constant for our effect code, GLSL version.
 *
 * @type {string}
 * @const
 * @private
 */
talk.media.C3dCommunicationPlayer.EFFECT_STRING_GLSL_ =
    'uniform mat4 worldViewProjection;\n' +
    // Input parameters for our vertex shader
    'attribute vec4 position;\n' +
    'attribute vec2 texcoords0;\n' +
    // Interpolant
    'varying vec2 uvs;\n' +
    // Our vertex shader transforms the vertices to the proper screen-relative
    // position.
    'void main() {\n' +
    '  gl_Position = worldViewProjection * position;\n' +
    '  uvs = texcoords0;\n' +
    '}\n' +
    '// #o3d SplitMarker\n' +
    '// #o3d MatrixLoadOrder RowMajor\n' +
    // The texture sampler is used to access the texture bitmap in the
    // pixel shader.
    'uniform sampler2D texSampler0;\n' +
    // Alpha scaling value for doing fade-in.
    'uniform float alpha;\n' +
    // Interpolant
    'varying vec2 uvs;\n' +
    // Given the texture coordinates, our pixel shader grabs the corresponding
    // color from the texture, changing the brightness to the desired level.
    'void main() {\n' +
      // The "alpha" component in the input is not for brightness, it's for
      // transparency, but we don't have that enabled so it's unused (but
      // GLSL language rules still require a float4 everywhere). To change the
      // brightness, we just multiply the RGB components by our scaling factor.
    '  gl_FragColor = texture2D(texSampler0, uvs) * alpha;\n' +
    '}\n';


/**
 * The amount of time (in ms) to wait before retrying the initialize step of
 * player creation. We continue to retry until MAX_INITIALIZE_WAIT_.
 *
 * @type {number}
 * @const
 * @private
 */
talk.media.C3dCommunicationPlayer.RETRY_INITIALIZE_WAIT_ = 2 * 1000;


/**
 * The maximum amount of time in total(in ms) to wait for O3D to
 * initialize.
 *
 * @type {number}
 * @const
 * @private
 */
talk.media.C3dCommunicationPlayer.MAX_INITIALIZE_WAIT_ = 20 * 1000;


/**
 * Our logger.
 *
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.logger_ =
    goog.debug.Logger.getLogger('talk.media.C3dCommunicationPlayer');


/**
 * Count of the number of errors we've gotten from O3D.
 *
 * @type number
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.errorCount_ = 0;


/**
 * The JID we're calling.
 *
 * @type string
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.senderJid_;


/**
 * The ID of the call being displayed.
 *
 * @type string
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.sessionId_;


/**
 * The type of call we're displaying.
 *
 * @type talk.media.CallType
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.callType_;


/**
 * Transparent view for overlaying icons on top of video contents.
 *
 * @type {talk.media.c3d.View}
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.transparencyView_;


/**
 * Endpoint for local texture.
 *
 * @type talk.media.c3d.StreamEndpoint
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.local_;


/**
 * Endpoint for remote texture.
 *
 * @type talk.media.c3d.StreamEndpoint
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.remote_;


/**
 * The C3D Effect.
 *
 * @type Object
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.effect_;


/**
 * A button to go into fullscreen mode.
 *
 * @type {talk.media.c3d.Image}
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.fullscreenImg_;


/**
 * The C3D render graph to draw transparent 2d images.
 *
 * @type {talk.media.c3d.ImageOverlay}
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.imageOverlay_;


/**
 * The C3D notifier to handle notifications.
 *
 * @type {talk.media.C3dNotifier}
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.notifier_;


/**
 * The message queue address for our O3D instance.
 *
 * @type {string}
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.c3dAddress_;


/**
 * The amount of time the player has been waiting to initialize.
 *
 * @type {number}
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.initializeWait_ = 0;


/**
 * The list of participants in the call.
 * Index 0 is the local user.  User array elements are [{string} JID,
 * {boolean} isLocal, {string} avatarUrl].
 *
 * @type {Array.<Array>}
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.participants_;


/**
 * The Element to contain the video pane.
 *
 * @type {string|Element}
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.container_;


/**
 * Opaque reference to the fullscreen image's cursor setting.
 *
 * @type {talk.media.c3d.CursorManager.Registration_}
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.cursorRef_;


/**
 * Returns whether or not this call is in the accepted state or not.
 *
 * @return {boolean}
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.isAccepted_ = function() {
  return goog.isDefAndNotNull(this.callManager_) &&
      goog.isDefAndNotNull(this.callManager_.getActiveCall()) &&
      this.callManager_.getActiveCall().state ==
      talk.media.CallManager.Call.State.ACTIVE_CALL;
};


/**
 * Updates C3D's perspective matrix to match the dimensions of its window pane.
 *
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.updatePerspective_ =
    function() {
  if (!this.o3dBundle_.view || !this.o3dBundle_.view.drawContext) {
    return;
  }
  // Set up our orthographic projection matrix. This selects the dimensions of
  // the rectangular prism of 3D space to render (which renders with no 3D
  // perspective--i.e., as if we're infinitely far away and with infinite zoom).
  // It needs to have the same aspect ratio as the Client3D pane or else the
  // scene will get stretched when drawn to the screen.
  var client = this.o3dBundle_.c3dObject.getPlugin()['client'];
  // Save width and height for fast lookups when laying-out feeds.
  this.o3dBundle_.width = client['width'];
  this.o3dBundle_.height = client['height'];
  // Reset the projection to match client area. Origin is at the top-left.
  this.o3dBundle_.view.setProjectionMatrix(
      talk.media.c3d.createOrthographicMatrix(0 + 0.5,
          this.o3dBundle_.width + 0.5,
          this.o3dBundle_.height + 0.5,
          0 + 0.5,
          0.001,
          1000));
  this.transparencyView_.setProjectionMatrix(
      talk.media.c3d.createOrthographicMatrix(0 + 0.5,
          this.o3dBundle_.width + 0.5,
          this.o3dBundle_.height + 0.5,
          0 + 0.5,
          0.001,
          1000));
  this.scene_.setArea(0, 0, this.o3dBundle_.width, this.o3dBundle_.height);
};


/**
 * Makes a new stream endpoint for sending a video stream from flute to C3D.
 *
 * @param {boolean} mirror Whether or not to mirror this stream when displayed.
 * @return {talk.media.c3d.StreamEndpoint} A new stream
 *     endpoint.
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.createStreamEndpoint_ = function(
    mirror) {
  var material = this.o3dBundle_.pack['createObject']('Material');

  // Set the material's drawList
  material['drawList'] = this.o3dBundle_.view.drawList;

  // Apply our effect to this material. The effect tells the 3D hardware
  // which shader to use.
  material['effect'] = this.effect_;

  // This will create our quadColor parameter on the material.
  this.effect_['createUniformParameters'](material);

  // Create a Sampler object for this texture.
  var texSampler = this.o3dBundle_.pack['createObject']('Sampler');
  // (Creating and setting the texture that it samples will be the
  // StreamEndpoint's job.)

  // Set this as the material's sampler.
  material['getParam']('texSampler0')['value'] = texSampler;

  // Create a VertexBuffer to tell which coordinates of the texture maps to a
  // specific vertex.
  var texBuffer = this.o3dBundle_.pack['createObject']('VertexBuffer');
  var texCoordField = texBuffer['createField']('FloatField', 2);
  // Setting the actual values will be the StreamEndpoint's job, but we have to
  // initialize it to something or else C3D complains.
  texBuffer['set'](talk.media.c3d.computeTextureCoords(1, 1, 1, 1, false));

  var endpoint = new talk.media.c3d.StreamEndpoint(
      material,
      texBuffer,
      texCoordField,
      texSampler,
      mirror,
      this.o3dBundle_.pack,
      this.o3dBundle_.c3dObject);

  this.eventHandler_.listen(endpoint,
      talk.media.c3d.StreamEndpoint.Events.SEND_STREAM_ON,
      this.sendStreamOn_);
  this.eventHandler_.listen(endpoint,
      talk.media.c3d.StreamEndpoint.Events.SEND_STREAM_OFF,
      this.sendStreamOff_);

  this.streamEndpoints_.push(endpoint);

  return endpoint;
};


/**
 * Gets the stream endpoint that owns a given texture.
 *
 * @param {number} id The texture id.
 * @return {talk.media.c3d.StreamEndpoint} The
 * StreamEndpoint_ object.
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.getEndpointForTexture_ =
    function(id) {
  return this.textureIdToEndpoint_[id];
};


/**
 * Sets the stream endpoint that owns a given texture.
 *
 * @param {number} id The texture id.
 * @param {talk.media.c3d.StreamEndpoint} endpoint The
 * StreamEndpoint_ object.
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.setEndpointForTexture_ =
    function(id, endpoint) {
  this.textureIdToEndpoint_[id] = endpoint;
};


/**
 * Clears the stream endpoint that owns a given texture (i.e., the texture no
 * longer exists).
 *
 * @param {number} id The texture id.
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.clearEndpointForTexture_ =
    function(id) {
  delete this.textureIdToEndpoint_[id];
};


/**
 * Disposes of all existing stream endpoints.
 *
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.disposeAllStreamEndpoints_ =
    function() {
  for (var i = 0; i < this.streamEndpoints_.length; ++i) {
    this.streamEndpoints_[i].dispose();
  }
  this.streamEndpoints_.splice(0, this.streamEndpoints_.length);
};


/**
 * Initializes our scene in C3D.
 *
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.initPlayer_ = function() {
  var success = false;
  try {
    var initialErrorCount = this.errorCount_;

    var c3d = this.o3dBundle_.c3dObject.getPlugin();

    if (!c3d) {
      // Plugin was removed from DOM before we had a chance to initialize it.
      // This is odd, so log it.
      this.logger_.warning('O3D missing from DOM during initPlayer_');
      return;
    }

    if (!this.o3dBundle_.c3dObject.isScriptable() ||
        (c3d['client']['rendererInitStatus'] ==
            c3d['o3d']['Renderer']['UNINITIALIZED'])) {
      // Plugin hasn't loaded yet.
      if (this.initializeWait_ <
          talk.media.C3dCommunicationPlayer.MAX_INITIALIZE_WAIT_) {

        // Wait and retry.
        goog.Timer.callOnce(this.initPlayer_,
            talk.media.C3dCommunicationPlayer.RETRY_INITIALIZE_WAIT_, this);
        this.initializeWait_ +=
            talk.media.C3dCommunicationPlayer.RETRY_INITIALIZE_WAIT_;

        this.logger_.info('O3D not loaded yet, retrying in ' +
            talk.media.C3dCommunicationPlayer.RETRY_INITIALIZE_WAIT_ + ' ms');
        return;
      } else {
        // We will catch this below and unload the player.
        throw new Error('Hit max retries for initializing O3D, quitting.');
      }
    }

    c3d['client']['setErrorCallback'](goog.bind(this.handleC3dError_, this));

    this.o3dBundle_.c3dEngine.setC3d(this.o3dBundle_.c3dObject);
    this.c3dEventTarget_.setC3d(this.o3dBundle_.c3dObject);

    // Have to cache this because we need it during the !isSceneScriptable()
    // shutdown path and it won't be correct if we read it then.
    this.c3dAddress_ = c3d['client']['getMessageQueueAddress']();

    // Add resize handler to re-position everything upon resize.
    talk.media.c3d.addEventCallback(c3d, 'resize', this.boundOnResize_);

    // Create a pack to manage our resources/assets
    this.o3dBundle_.pack = c3d['client']['createPack']();

    var priority = 0;

    // Setup our render graph.
    this.o3dBundle_.view = new talk.media.c3d.View(c3d, this.o3dBundle_.pack,
        priority, false);

    // Again for transparent objects.
    this.transparencyView_ =
        new talk.media.c3d.View(c3d, this.o3dBundle_.pack, priority++, true);

    // Create the effect to use for 3D objects.
    this.effect_ = this.o3dBundle_.pack['createObject']('Effect');
    var effectString;
    if (c3d['client']['clientInfo']['glsl']) {
      // o3d expects GLSL shaders.
      effectString = talk.media.C3dCommunicationPlayer.EFFECT_STRING_GLSL_;
    } else {
      // o3d expects Cg shaders.
      effectString = talk.media.C3dCommunicationPlayer.EFFECT_STRING_CG_;
    }
    this.effect_['loadFromFXString'](effectString);

    // Create local.
    if (!this.hidePip_) {
      this.local_ = this.createStreamEndpoint_(true);
      this.scene_.addFeed(this.local_, null, '');
    }

    // Create remote.
    this.remote_ = this.createStreamEndpoint_(false);
    this.eventHandler_.listen(this.remote_,
        talk.media.c3d.StreamEndpoint.Events.TEXTURE_ACTIVATED,
        this.onRemoteActivated_);
    this.scene_.addFeed(this.remote_, '0', '');

    // Set up the dimensions of our camera's frustum.
    this.updatePerspective_();

    // Add a 2d view on top for images like full screen button.
    this.imageOverlay_ = new talk.media.c3d.ImageOverlay(
        this.o3dBundle_,
        this.effect_,
        this.transparencyView_);

    if (this.enableNotifications_) {
      var notifRenderer = new talk.media.c3d.NotificationRenderer(
          this.o3dBundle_.pack,
          this.o3dBundle_.c3dObject.getPlugin(),
          this.o3dBundle_.c3dObject.getWidth(),
          50);
      this.notifier_ = new talk.media.C3dNotifier(this.callManager_,
          this.o3dBundle_.pack, this.o3dBundle_.c3dEngine,
          this.o3dBundle_.c3dObject, this.imageOverlay_, notifRenderer);
    }

    if (this.callType_ == talk.media.CallType.VIDEO ||
        this.callType_ == talk.media.CallType.TEST) {
      // Turn on local.
      if (this.local_) {
        this.local_.requestStream(null);
      }

      if (this.isAccepted_()) {
        // Turn on remote.
        this.remote_.requestStream('0');
      }
    } else if (this.local_) {
      // N:N audio: show local avatar, other(s) will show on activity.
      var url = this.jidAvatarMap_.get(this.participants_[0][0]);
      this.local_.requestAvatar(/** @type {string} */ (url));
    }

    if (this.errorCount_ == initialErrorCount) {
      // No errors during initialization.
      success = true;
    }
  } catch (e) {
    this.callManager_.addToLog('Exception during O3D initialization',
        talk.media.CallManager.LogCommentSeverity.ERROR, e);
  }
  if (!success) {
    // Either there was an error callback or an exception. In either case,
    // fallback to Flash for safety (since it could be that O3D is unusable on
    // this machine for some reason).
    this.dispatchEvent(new talk.media.C3dCommunicationPlayer.FatalErrorEvent());
  }
};


/**
 * Adds a clickable area in the upper left corner of the video area.
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.addFullscreen_ = function() {
  var c3d = this.o3dBundle_.c3dObject.getPlugin();
  try {
    // Create an o3d image.
    this.fullscreenImg_ = this.imageOverlay_.createImage(
        10, 10, 'images/enter_fullscreen.png', goog.bind(function() {
      // Link image to fullscreen mode.
      c3d['client']['setFullscreenClickRegion'](
          this.fullscreenImg_.x(),
          this.fullscreenImg_.y(),
          this.fullscreenImg_.width(),
          this.fullscreenImg_.height(),
          c3d['o3d']['Renderer']['DISPLAY_MODE_DEFAULT']);
      // Add mousemove handler to change mouse pointer over image.
      talk.media.c3d.addEventCallback(c3d, 'mousemove', this.boundOnMouseMove_);
    }, this, c3d));
  } catch (e) {
    // Not defined, old version of o3d plugin.
    this.logger_.warning('Full screen not available ("' + e.name + '", "' +
                         e.message + '")');
  }
};


/**
 * Handles changes to microphone mute state of the active call.
 *
 * @param {talk.media.CallManager.MicMuteEvent} e The event.
 */
talk.media.C3dCommunicationPlayer.prototype.handleMicMuteNotification =
    function(e) {
  if (this.muteHandler_) {
    this.muteHandler_.handleMicMuteNotification(e);
  }

  if (this.notifier_) {
    if (e.muted) {
      this.callManager_.addToLog('Mic Mute show');
      this.notifier_.showNotification(this.micMuteNotification_);
    } else {
      this.callManager_.addToLog('Mic Unmute show');
      this.notifier_.showNotification(this.micUnmuteNotification_);
    }
  }
};


/**
 * Handles a resize event of the o3d client.
 *
 * @param {Object} e The event.
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.onResize_ = function(e) {
  var c3d = this.o3dBundle_.c3dObject.getPlugin();
  this.updatePerspective_();

  // Show bigger fullscreen image if in fullscreen mode.
  if (this.fullscreenImg_) {
    if (e['fullscreen']) {
      this.fullscreenImg_.resize(this.fullscreenImg_.textureWidth() * 2,
                                 this.fullscreenImg_.textureHeight() * 2);
      // Add click handler to respond to mouse clicks on image, now that the
      // o3d click region has done its job.
      // TODO(geer): replace with 'click' event asa o3d plugin is fixed.
      talk.media.c3d.addEventCallback(c3d, 'mousedown', this.boundOnClick_);
    } else {
      this.fullscreenImg_.resize(this.fullscreenImg_.textureWidth(),
                                 this.fullscreenImg_.textureHeight());
      talk.media.c3d.removeEventCallback(c3d, 'mousedown', this.boundOnClick_);
    }
  }
};


/**
 * Handles a mousemove event of the o3d client.
 *
 * @param {Object} e The event.
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.onMouseMove_ = function(e) {
  var c3d = this.o3dBundle_.c3dObject.getPlugin();
  if (this.fullscreenImg_.isVisible() &&
      this.fullscreenImg_.hitTest(e['x'], e['y'])) {
    if (!this.cursorRef_) {
      this.cursorRef_ = this.o3dBundle_.cursorManager.setCursor('POINTER', 0);
    }
  } else {
    if (this.cursorRef_) {
      this.o3dBundle_.cursorManager.unsetCursor(this.cursorRef_);
      this.cursorRef_ = null;
    }
  }
};


/**
 * Handles a click event of the o3d client.
 *
 * @param {Object} e The event.
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.onClick_ = function(e) {
  var c3d = this.o3dBundle_.c3dObject.getPlugin();
  if (c3d['client']['fullscreen'] &&
      this.fullscreenImg_.hitTest(e['x'], e['y'])) {
    c3d['client']['cancelFullscreenDisplay']();
  }
};


/**
 * Handles logging of errors from Client3D.
 *
 * @param {string} msg The error message.
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.handleC3dError_ = function(msg) {
  if (msg.substring(0, 16) == 'Texture with id ' &&
      msg.substring(msg.length - 10) == ' not found') {
    // This error is benign. It occurs after we delete a texture and before
    // flute has stopped updating it.
    // TODO(tschmelcher): Find a way to make this error not happen in the first
    // place.
    return;
  }
  // Anything else is a real error though.
  ++this.errorCount_;
  this.callManager_.addToLog('Error from O3D: ' + msg,
      talk.media.CallManager.LogCommentSeverity.ERROR);
};


/**
 * Adds controls when the remote texture gets activated.
 *
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.onRemoteActivated_ = function() {
  this.addFullscreen_();
  this.initMuteHandler_();
  this.initNotifier_();
};


/**
 * Initializes the mute handler with the C3D objects.
 *
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.initMuteHandler_ = function() {
  if (this.muteHandler_) {
    this.muteHandler_.init(this.callManager_, this.o3dBundle_.c3dEngine,
        this.o3dBundle_.c3dObject, this.imageOverlay_);
  }
};


/**
 * Initializes the notifier with the C3D objects and adds notifications.
 *
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.initNotifier_ = function() {
  if (this.notifier_) {

    this.micMuteNotification_ = this.notifier_.addNotification(
        'images/mic_fullscreen_muted.png',
        'Your mic is now Off!');

    this.micUnmuteNotification_ = this.notifier_.addNotification(
        'images/mic_fullscreen.png',
        'Your mic is now On!');
  }
};


/**
 * Handles messages from the server, flute, or Gmail actions.
 *
 * @param {string} msg the kind of message to send to the player.
 * @param {Array|string} args the arguments to be sent with the message.
 */
talk.media.C3dCommunicationPlayer.prototype.sendToPlayer =
    function(msg, args) {
  var argsArray = args;
  if (typeof args == 'string') {
    argsArray = goog.json.parse(args);
  }
  switch (msg) {
    case talk.media.CommunicationPlayer.SendMsg.UI_COMMAND:
      if (argsArray[0] == 'a') {
        // TODO(tschmelcher): Refactor callmanager to do this.
        var message = ['ja', this.senderJid_, this.sessionId_];
        this.callManager_.sendJingleMsg(message);
        this.callManager_.sendFluteMsg(goog.json.serialize(message));
        if (this.callType_ == talk.media.CallType.VIDEO) {
          this.remote_.requestStream('0');
        }
      }
      break;
    case talk.media.CommunicationPlayer.SendMsg.JINGLE:
      if (argsArray[0] == 'ja') {
        if (this.callType_ == talk.media.CallType.VIDEO) {
          this.remote_.requestStream('0');
        }
      }
      break;
    case talk.media.CommunicationPlayer.SendMsg.PLUGIN_DATA:
      if (argsArray[0] == 'streamready') {
        this.logger_.info('streamready message from plugin');
        this.stopTracer_();
        // Ignore messages for texture id's that are not ours, and
        // dispatch to the proper stream endpoint.
        var textureId = argsArray[4];
        var endpoint = this.getEndpointForTexture_(textureId);
        if (endpoint) {
          var stream = argsArray[5];
          var width = argsArray[6];
          var height = argsArray[7];
          var opt_renderedWidth = argsArray[8];
          var opt_renderedHeight = argsArray[9];
          var opt_pixelWidth = argsArray[10];
          var opt_pixelHeight = argsArray[11];
          endpoint.handleStreamReady(textureId, stream, width, height,
              opt_renderedWidth, opt_renderedHeight, opt_pixelWidth,
              opt_pixelHeight);
        }
      } else if (argsArray[0] == 'streamfailed') {
        // TODO(tschmelcher): This should probably be a method on the
        // StreamEndpoint.
        this.logger_.info('streamfailed message from plugin');
        this.stopTracer_();
        // Dispatch to the proper stream endpoint.
        var textureId = argsArray[4];
        var endpoint = this.getEndpointForTexture_(textureId);
        var url;
        if (endpoint == this.local_) {
          url = this.jidAvatarMap_.get(this.participants_[0][0]);
        } else if (endpoint == this.remote_) {
          url = this.jidAvatarMap_.get(this.participants_[1][0]);
        } else if (!endpoint) {
          this.logger_.info('No endpoint found for textureid: ' + textureId);
        } else {
          var call = this.callManager_.getActiveCall();
          if (goog.isDefAndNotNull(call)) {
            var stream = argsArray[5];
            var jid = call.getJidForVideoSsrc(stream);
            url = this.jidAvatarMap_.get(jid);
          }
        }
        if (url) {
          endpoint.requestAvatar(/** @type {string} */ (url));
        }
      }
      break;
    default:
      this.logger_.warning('sendToPlayer(): unhandled message type: ' + msg);
  }
};


/**
 * Shows the avatar for a given jid.
 *
 * @param {string} jid The jid whose avatar to show.
 */
talk.media.C3dCommunicationPlayer.prototype.showAvatar = function(jid) {
  var url = this.jidAvatarMap_.get(jid);
  this.remote_.requestAvatar(/** @type {string} */ (url));
};


/**
 * Handles a request to show a video stream.
 *
 * @param {talk.media.CallManager.ShowVideoEvent} e The event.
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.handleShowVideo_ = function(e) {
  if (e.sessionId == this.sessionId_) {
    this.remote_.requestStream(e.ssrc);
  }
};


/**
 * Handles a request to add a video stream.
 *
 * @param {talk.media.CallManager.AddVideoEvent} e The event.
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.handleAddVideo_ = function(e) {
  if (e.sessionId == this.sessionId_) {
    if (!this.scene_.hasFeed(e.ssrc)) {
      var endpoint = this.createStreamEndpoint_(false);
      endpoint.requestStream(e.ssrc);
      // Get the text to display for this feed.
      var call = this.callManager_.getActiveCall();
      var name;
      if (goog.isDefAndNotNull(call)) {
        var jid = call.getJidForVideoSsrc(e.ssrc);
        name = jid.split('@', 1)[0];
      }
      this.scene_.addFeed(endpoint, e.ssrc, name || '');
    }
  }
};


/**
 * Handles a request to remove a video stream.
 *
 * @param {talk.media.CallManager.RemoveVideoEvent} e The event.
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.handleRemoveVideo_ = function(e) {
  if (e.sessionId == this.sessionId_) {
    if (this.scene_.hasFeed(e.ssrc)) {
      this.scene_.removeFeed(e.ssrc);
    }
  }
};


/**
 * Handles a request from a StreamEndpoint for us to send a 'streamon'.
 *
 * @param {talk.media.c3d.StreamEndpoint.SendStreamOnEvent}
 *     e The event.
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.sendStreamOn_ = function(e) {
  var c3d = this.o3dBundle_.c3dObject.getPlugin();
  this.callManager_.sendFluteMsg(goog.json.serialize(
      ['streamon', this.senderJid_, this.sessionId_, this.c3dAddress_,
          e.textureId, e.stream, e.textureWidth, e.textureHeight]));
  this.setEndpointForTexture_(e.textureId, e.endpoint);
};


/**
 * Handles a request from a StreamEndpoint for us to send a 'streamoff'.
 *
 * @param {talk.media.c3d.StreamEndpoint.SendStreamOffEvent}
 *     e The event.
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.sendStreamOff_ = function(e) {
  var c3d = this.o3dBundle_.c3dObject.getPlugin();
  this.callManager_.sendFluteMsg(goog.json.serialize(
      ['streamoff', this.senderJid_, this.sessionId_, this.c3dAddress_,
          e.textureId]));
  this.clearEndpointForTexture_(e.textureId);
};


/**
 * Tears down the stream rendering mappings that we currently have registered
 * with flute.
 *
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.disposeStreams_ = function() {
  this.scene_.disposeAllFeeds();
  this.disposeAllStreamEndpoints_();
  this.local_ = null;
  this.remote_ = null;
};


/**
 * Removes the C3D player (if present). This is public for historical reasons
 * only.
 */
talk.media.C3dCommunicationPlayer.prototype.removePlayer = function() {
  this.o3dBundle_.c3dEngine.unregisterAllRenderCallbacks();
  this.o3dBundle_.c3dEngine.setC3d(null);
  this.c3dEventTarget_.setC3d(null);
  this.disposeStreams_();
  this.effect_ = null;
  this.fullscreenImg_ = null;
  if (this.imageOverlay_) {
    this.imageOverlay_.dispose();
  }
  this.imageOverlay_ = null;
  if (this.muteHandler_) {
    this.muteHandler_.disposeC3d();
  }
  if (this.notifier_) {
    this.notifier_.disposeC3d();
  }
  this.o3dBundle_.pack = null;
  this.o3dBundle_.view = null;
  this.transparencyView_ = null;
  // Might not be during shutdown.
  if (this.o3dBundle_.c3dObject.isScriptable()) {
    var c3d = this.o3dBundle_.c3dObject.getPlugin();
    talk.media.c3d.removeEventCallback(c3d, 'resize', this.boundOnResize_);
    talk.media.c3d.removeEventCallback(c3d, 'mousemove',
                                       this.boundOnMouseMove_);
    // TODO(geer): replace with 'click' event asa o3d plugin is fixed.
    talk.media.c3d.removeEventCallback(c3d, 'mousedown', this.boundOnClick_);
    if (c3d['client']['fullscreen']) {
      c3d['client']['cancelFullscreenDisplay']();
    }
    c3d['client']['clearErrorCallback']();
    c3d['client']['clearFullscreenClickRegion']();
  }
  this.o3dBundle_.c3dObject.removeHTML();
  delete this.c3dAddress_;
};


/**
 * Creates the C3D player (must not already be present).
 *
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.createPlayer_ = function() {
  this.o3dBundle_.c3dObject.writeHTML(this.container_);
  // All other set-up work must be deferred because the plugin loads
  // asynchronously.
  goog.Timer.callOnce(this.initPlayer_, 0, this);
};


/**
 * Begins displaying the call with the given parameters.
 *
 * @param {string} sessionId The id of the call session.
 * @param {Array.<Array>} participants The users in the call.
 * @param {talk.media.CallType} callType The type of call.
 * @param {boolean} isMultiUser Whether the call is a MUC call.
 */
talk.media.C3dCommunicationPlayer.prototype.displayCall_ = function(
    sessionId, participants, callType, isMultiUser) {
  this.updateParticipants(participants);
  this.senderJid_ = participants[1][0];
  this.sessionId_ = sessionId;
  this.callType_ = callType;
  this.removePlayer();
  if (this.callType_ != talk.media.CallType.VIDEO &&
      this.callType_ != talk.media.CallType.TEST) {
    this.stopTracer_();
    // Voice calls only have a player UI if they are multi-user calls.
    if (isMultiUser) {
      this.createPlayer_();
    }
  } else {
    this.createPlayer_();
  }
};


/**
 * Handles a new call.
 *
 * @param {boolean} isOutgoing If the call is placed by the local user or not.
 * @param {string} sessionId The id of the call session.
 * @param {Array.<Array>} participants The users in the call. Index 0
 *     is the local user.  User array elements are [{string} JID,
 *     {boolean} isLocal, {string} avatarUrl].
 * @param {talk.media.CallType} callType The type of call.
 * @param {boolean} isMultiUser Whether the call is a MUC call.
 */
talk.media.C3dCommunicationPlayer.prototype.onNewCall = function(isOutgoing,
    sessionId, participants, callType, isMultiUser) {
  this.displayCall_(sessionId, participants, callType, isMultiUser);

  // Copied from NativeCommunicationPlayer
  if (isOutgoing) {
    // For historical reasons, we have to send the 'jn' for outgoing calls.
    // Further, we can't safely send it right away because CallManager was
    // designed for the Flash version and assumes that there is a delay.
    // TODO(tschmelcher): Refactor callmanager to send the initiate.
    if (this.callType_ != talk.media.CallType.TEST) {
      goog.Timer.callOnce(this.sendInitiate_, 0, this);
    } else {
      // Test calls are an exception. CallManager is not involved and the jn
      // _must_ be sent immediately or else the micon will arrive first and be
      // ignored.
      this.sendInitiate_();
    }
  }
};


/**
 * Sends a jingle initiate.
 *
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.sendInitiate_ = function() {
  // Send a Jingle initiate to both the server and the plugin.
  var typeString;
  switch (this.callType_) {
    case talk.media.CallType.TEST:
      typeString = 't';
      break;
    case talk.media.CallType.VIDEO:
      typeString = 'v';
      break;
    default:
      typeString = 'a';
      break;
  }
  var message = ['jn', this.senderJid_, this.sessionId_, typeString];
  if (this.callType_ != talk.media.CallType.TEST) {
    this.callManager_.sendJingleMsg(message);
  }
  // We are the initiator, append 's'.
  message.push('s');
  this.callManager_.sendFluteMsg(goog.json.serialize(message));
};


/**
 * Begins displaying the already active call.
 *
 * @param {Array.<Array>} participants The users in the active call.
 * @param {boolean} isMultiUser Whether the call is a MUC call.
 */
talk.media.C3dCommunicationPlayer.prototype.displayActiveCall = function(
    participants, isMultiUser) {
  var activeCall = this.callManager_.getActiveCall();
  if (!activeCall) {
    this.logger_.warning('displayActiveCall called with no active call');
    return;
  }

  this.displayCall_(activeCall.sessionId, participants, activeCall.type,
      isMultiUser);
};


/**
 * Handles a jingle signaling or talk plugin message.
 *
 * @param {string} type The kind of msg.
 * @param {string} message The json message to handle.
 */
talk.media.C3dCommunicationPlayer.prototype.relayCallMessage = function(
    type, message) {
  this.sendToPlayer(type, message);
};


/**
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.stopTracer_ = function() {
  if (this.videoStartTrace_ != null) {
    goog.debug.Trace.stopTracer(this.videoStartTrace_, 0);
    delete this.videoStartTrace_;
    this.logger_.info(goog.debug.Trace.getFormattedTrace());
  }
};


/**
 * Updates the list of participants.
 *
 * @param {Array.<Array>} participants The list of participants in the call.
 *     Index 0 is the local user.  User array elements are [{string} JID,
 *     {boolean} isLocal, {string} avatarUrl].
 */
talk.media.C3dCommunicationPlayer.prototype.updateParticipants = function(
    participants) {
  this.logger_.info('updateParticipants : ' + participants);
  this.participants_ = participants;
  this.jidAvatarMap_.clear();
  var n = participants.length;
  for (var i = 0; i < n; ++i) {
    var p = participants[i];
    this.jidAvatarMap_.set(p[0], p[2]);
  }
};


/**
 * Sets the container.
 * @param {string|Element} container The Element to contain the video pane.
 */
talk.media.C3dCommunicationPlayer.prototype.setContainer = function(container) {
  this.container_ = container;
};


/**
 * @override
 * @protected
 */
talk.media.C3dCommunicationPlayer.prototype.disposeInternal = function() {
  this.dispatchEvent(talk.media.CommunicationPlayer.Events.DISPOSED);
  talk.media.C3dCommunicationPlayer.superClass_.disposeInternal.call(this);
  this.removePlayer();
  if (this.muteHandler_) {
    this.muteHandler_.dispose();
  }
  this.eventHandler_.dispose();
  this.eventHandler_ = null;
  this.callManager_ = null;
  this.c3dEventTarget_.dispose();
  this.scene_.dispose();
  this.scene_ = null;
};
