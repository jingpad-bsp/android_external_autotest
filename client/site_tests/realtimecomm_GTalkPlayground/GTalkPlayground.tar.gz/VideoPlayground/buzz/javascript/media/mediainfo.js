// Copyright 2008 Google Inc. All Rights Reserved.

/**
 * @fileoverview Contains classes representing Jingle media info messages.
 *
 * @author jessan@google.com (Jessan Hutchison-Quillian)
 */

goog.provide('talk.media.MediaInfo');
goog.provide('talk.media.MediaInfo.Stats');
goog.provide('talk.media.MediaQualityDatapoint');
goog.provide('talk.media.MediaInfoMessage');

goog.require('goog.string');

/**
 * A datapoint contained in a media info message about the quality of one media
 * type.
 *
 * @param {Array} info The array of media info
 * @param {Array} connection The array of connection data for this media type
 * @constructor
 */
talk.media.MediaQualityDatapoint = function(info, connection) {
  // See googleclient/talk/magicflute/voicesession.cc for parameter order
  this.fracLost = info[0];
  this.cumLost = info[1];
  this.jitter = info[3];
  this.packetsSent = info[6];
  this.packetsReceived = info[8];

  this.rtt = connection[1];
  this.sendBitrate = connection[3];
  this.recvBitrate = connection[5];
  this.localCandidate = connection[6];
  this.remoteCandidate = connection[7];
  this.localip = this.localCandidate[3];
  this.remoteip = this.remoteCandidate[3];
  this.conQuality = connection[8];
};


/**
 * Generates a two space indented English representation of the datapoint
 * @return {string} A pretty representation of the datapoint
 */
talk.media.MediaQualityDatapoint.prototype.toString = function() {
  var stringRep = [];
  var add = function(label, value) {
     stringRep.push('&nbsp;&nbsp;' + label + ' = ' + value);
  }

  add('Fraction lost', this.formatNum_(this.fracLost, 2) + '%');

  add('Jitter', this.formatNum_(this.jitter / 1000, 2));

  add('RTT', this.formatNum_(this.rtt, 3) + 'ms');

  // Bps -> kbps
  add('Bitrate', this.formatNum_(this.recvBitrate / 128, 4) + 'kbps');
  add('Local', this.localip);
  add('Remote', this.remoteip);
  add('Connection quality', this.formatNum_(this.conQuality, 3));

  return stringRep.join('<br>\n');
};


/**
 * Pads the given number to the given precision, if number is null, will return
 * "?".
 *
 * @param {number} number The number to be formatted
 * @param {number} precision The number of digits of precision to use
 * @return {string} A padded string representaton of the number
 * @private
 */
talk.media.MediaQualityDatapoint.prototype.formatNum_ = function(number,
                                                                 precision) {
    return goog.isDef(number) ?
        goog.string.padNumber(number, 0, precision) : '?';
};


/**
 * An object representation of a Jingle media info ("jmidata") message
 *
 * @param {Array} msg The Jingle media info message
 * @constructor
 */
talk.media.MediaInfoMessage = function(msg) {
  this.info = msg;

  this.mediaInfos = this.info[4];
  this.connectionInfos = this.info[5];

  if (this.connectionInfos) {
    if (this.mediaInfos[0] && this.connectionInfos[0]) {
      this.audioData = new talk.media.MediaQualityDatapoint(this.mediaInfos[0],
          this.connectionInfos[0])
    }

    if (this.mediaInfos[1] && this.connectionInfos[1]) {
      this.videoData = new talk.media.MediaQualityDatapoint(this.mediaInfos[1],
          this.connectionInfos[1])
    }
  }
};


/**
 * Generates a English string representation of the message.
 * @return {string} A pretty representation of the message.
 */
talk.media.MediaInfoMessage.prototype.toString = function() {
  // Start with a newline
  var networkDebugText = ['<br>'];

  if (!this.connectionInfos) {
    return '';
  }
  networkDebugText.push('Audio:');
  if (this.audioData) {
    networkDebugText.push(this.audioData.toString());
  }
  networkDebugText.push('<br>Video:');
  if (this.videoData) {
    networkDebugText.push(this.videoData.toString());
  }
  return networkDebugText.join('<br>\n');
};


/**
 * Stores aggregate statistics about media/connection quality for a call.
 *
 * @constructor
 */
talk.media.MediaInfo = function() {

  /**
   * Statistics about the video connection
   * @type talk.media.MediaInfo.Stats
   * @private
   */
  this.video_ = new talk.media.MediaInfo.Stats();

  /**
   * Statistics about the audio connection
   * @type talk.media.MediaInfo.Stats
   * @private
   */
  this.audio_ = new talk.media.MediaInfo.Stats();
};


/**
 * The last jmidata message received
 *
 * @type talk.media.MediaInfoMessage
 * @private
 */
talk.media.MediaInfo.prototype.lastMsg_;


/**
 * Stores aggregate statistics about connection quality for a given media type.
 *
 * @constructor
 */
talk.media.MediaInfo.Stats = function() {};


/**
 * The average packet loss for the call. Will be NaN until we have
 * received packets.
 *
 * @type number
 */
talk.media.MediaInfo.Stats.prototype.averagePacketLoss = NaN;

/**
 * The single highest packet loss datapoint received. Initiailized to -1.
 * @type number
 */
talk.media.MediaInfo.Stats.prototype.worstPacketLoss = -1;

/**
 * The number of datapoints accounted in these statistics.
 */
talk.media.MediaInfo.Stats.prototype.datapointCount = 0;

/**
 * The most recent data about fraction of packets lost. Initialized to 0
 * @type number
 */
talk.media.MediaInfo.Stats.prototype.currentPacketLoss = 0;


/**
 * Updates the statistics for this call based on the given datapoint
 *
 * @param {talk.media.MediaQualityDatapoint} datapoint The datapoint
 */
talk.media.MediaInfo.Stats.prototype.update = function(datapoint) {
  this.datapointCount++;
  this.currentPacketLoss = datapoint.fracLost;

  if (datapoint.fracLost > this.worstPacketLoss) {
    this.worstPacketLoss = datapoint.fracLost;
  }

  this.averagePacketLoss =
      datapoint.cumLost / (datapoint.cumLost + datapoint.packetsReceived);
};


/**
 * Adds a message to the aggregate media info and updates the statistics.
 *
 * @param {Array} jmiMsg A parsed 'jmidata' message
 */
talk.media.MediaInfo.prototype.add = function(jmiMsg) {
  this.lastMsg_ = new talk.media.MediaInfoMessage(jmiMsg);

  if (this.lastMsg_.audioData) {
    this.audio_.update(this.lastMsg_.audioData);
  }
  if (this.lastMsg_.videoData) {
    this.video_.update(this.lastMsg_.videoData);
  }
};


/**
 * Returns statistics about the quality of the video connection.
 *
 * @return {talk.media.MediaInfo.Stats} Quality stats for the video connection
 */
talk.media.MediaInfo.prototype.getVideoStats = function() {
  return this.video_;
};


/**
 * Returns statistics about the quality of the audio connection.
 *
 * @return {talk.media.MediaInfo.Stats} Quality stats for the audio connection
 */
talk.media.MediaInfo.prototype.getAudioStats = function() {
  return this.audio_;
};


/**
 * Returns an object with audioLocal, audioRemote, videoLocal and videoRemote
 * arrays, each representing a currently used candidate. If a candidate is
 * not being used, the array will be empty.
 *
 * @return {Object} The object representing the candidates
 */
talk.media.MediaInfo.prototype.getCandidates = function() {
  var candidates = {};
  var lastMsg = this.lastMsg_ ? this.lastMsg_ : {};
  candidates.audioLocal = lastMsg.audioData ? lastMsg.audioData.localCandidate
                                             : [];
  candidates.audioRemote = lastMsg.audioData ? lastMsg.audioData.remoteCandidate
                                             : [];
  candidates.videoLocal = lastMsg.videoData ? lastMsg.videoData.localCandidate
                                             : [];
  candidates.videoRemote = lastMsg.videoData ? lastMsg.videoData.remoteCandidate
                                             : [];
  return candidates;
};


/**
 * Returns an object with the most recent datapoints for each quality metric.
 *
 * @return {Object} The object containing graphable data.
 */
talk.media.MediaInfo.prototype.getMostRecentDatapoint = function() {
  if (!this.lastMsg_) {
    return {};
  }

  return {
    audioRecvKbps: this.lastMsg_.audioData ?
        Math.round(this.lastMsg_.audioData.recvBitrate / 128) : 0,
    videoRecvKbps: this.lastMsg_.videoData ?
        Math.round(this.lastMsg_.videoData.recvBitrate / 128) : 0,
    audioSendKbps: this.lastMsg_.audioData ?
        Math.round(this.lastMsg_.audioData.sendBitrate / 128) : 0,
    videoSendKbps: this.lastMsg_.videoData ?
        Math.round(this.lastMsg_.videoData.sendBitrate / 128) : 0,
    audioJitter: this.lastMsg_.audioData ?
        this.lastMsg_.audioData.jitter / 1000 : 0,
    videoJitter: this.lastMsg_.videoData ?
        this.lastMsg_.videoData.jitter / 1000 : 0,
    audioRtt: this.lastMsg_.audioData ?
        Math.round(this.lastMsg_.audioData.rtt) : 0,
    videoRtt: this.lastMsg_.videoData ?
        Math.round(this.lastMsg_.videoData.rtt) : 0,
    audioPacketLoss: this.lastMsg_.audioData ?
        Math.round(this.lastMsg_.audioData.fracLost) : 0,
    videoPacketLoss: this.lastMsg_.videoData ?
        Math.round(this.lastMsg_.videoData.fracLost) : 0
  };
}
