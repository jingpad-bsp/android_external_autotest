// Copyright 2009 Google Inc.  All Rights Reserved.

/**
 * @fileoverview Handles mouse input for the PIP(Picture In Picture) element.
 * The PIP element is movable by dragging and minimizable by pressing the
 * minimize icon.
 *
 * @author oja@google.com (Fredrik Oja)
 */

goog.provide('talk.media.c3d.PipHandler');

goog.require('goog.Disposable');
goog.require('goog.debug.Logger');
goog.require('talk.media.c3d.Attrs');
goog.require('talk.media.c3d.AttrsTween');
goog.require('talk.media.c3d.C3dEngine');
goog.require('talk.media.c3d.Image');
goog.require('talk.media.c3d.ImageOverlay');
goog.require('talk.media.c3d.O3dBundle');
goog.require('talk.media.c3d.View');


/**
 * Handles input events for the PIP video object.
 *
 * @param {talk.media.c3d.O3dBundle} o3dBundle The global O3D bundle.
 * @param {talk.media.c3d.ShrinkableFeed} pipObject The object representing
 *     the PIP.
 * @param {Object} effect The effect needed for creating our image overlay.
 * @constructor
 * @extends {goog.Disposable}
 */
talk.media.c3d.PipHandler = function(o3dBundle, pipObject, effect) {
  goog.Disposable.call(this);

  /**
   * The bundle of global resources for this O3D instance.
   *
   * @type {talk.media.c3d.O3dBundle}
   * @private
   */
  this.o3dBundle_ = o3dBundle;

  /**
   * The parent of the feed to handle.
   *
   * @type {talk.media.c3d.ShrinkableFeed}
   * @private
   */
  this.pipObject_ = pipObject;

  /**
   * The effect used to create the image overlay. The object is a wrapper
   * around a native O3D {@code Effect} object.
   *
   * @type {Object}
   * @private
   */
  this.effect_ = effect;

  /**
   * A bound version of onMouseMove, suitable for using as an event callback.
   *
   * @type {Function}
   * @private
   */
  this.boundOnMouseMove_ = goog.bind(this.onMouseMove, this);

  /**
   * A bound version of onMouseUp, suitable for using as an event callback.
   *
   * @type {Function}
   * @private
   */
  this.boundOnMouseUp_ = goog.bind(this.onMouseUp, this);

  /**
   * A bound version of onMouseDown, suitable for using as an event callback.
   *
   * @type {Function}
   * @private
   */
  this.boundOnMouseDown_ = goog.bind(this.onMouseDown, this);
};
goog.inherits(talk.media.c3d.PipHandler, goog.Disposable);


/**
 * Width of border around the PIP.
 *
 * @type {number}
 * @private
 */
talk.media.c3d.PipHandler.PIP_BORDER_WIDTH_ = 2;


/**
 * Treshold width for when to double the size of the icons.
 *
 * @type {number}
 * @private
 */
talk.media.c3d.PipHandler.RESIZE_THRESHOLD_WIDTH_ = 320;


/**
 * Treshold height for when to double the size of the icons.
 *
 * @type {number}
 * @private
 */
talk.media.c3d.PipHandler.RESIZE_THRESHOLD_HEIGHT_ = 200;


/**
 * Logger.
 *
 * @type {!goog.debug.Logger}
 * @private
 */
talk.media.c3d.PipHandler.prototype.logger_ =
    goog.debug.Logger.getLogger('talk.media.c3d.PipHandler');


/**
 * A clickable icon for minimizing the pip.
 *
 * @type {talk.media.c3d.Image}
 * @private
 */
talk.media.c3d.PipHandler.prototype.minimizeImg_;


/**
 * A rollover version of the minimize icon.
 *
 * @type {talk.media.c3d.Image}
 * @private
 */
talk.media.c3d.PipHandler.prototype.minimizeRolloverImg_;


/**
 * A clickable icon for maximizing the pip.
 *
 * @type {talk.media.c3d.Image}
 * @private
 */
talk.media.c3d.PipHandler.prototype.maximizeImg_;


/**
 * A rollover version of the maximize icon.
 *
 * @type {talk.media.c3d.Image}
 * @private
 */
talk.media.c3d.PipHandler.prototype.maximizeRolloverImg_;


/**
 * An image showing a four way arrow highlighting that the pip is movable.
 *
 * @type {talk.media.c3d.Image}
 * @private
 */
talk.media.c3d.PipHandler.prototype.fourwayArrowImg_;


/**
 * Saved copy of PIP objects attributes before being minimized.
 *
 * @type {talk.media.c3d.Attrs}
 * @private
 */
talk.media.c3d.PipHandler.prototype.savedAttrs_;


/**
 * Saved copy of the feeds attributes.
 *
 * @type {talk.media.c3d.Attrs}
 * @private
 */
talk.media.c3d.PipHandler.prototype.feedAttrs_;


/**
 * The actual video scene.
 *
 * @type {talk.media.c3d.SceneObject}
 * @private
 */
talk.media.c3d.PipHandler.prototype.feedObject_;


/**
 * View to hold images.
 *
 * @type {talk.media.c3d.View}
 * @private
 */
talk.media.c3d.PipHandler.prototype.imageView_;


/**
 * Tween that handles shrinking and growing animations.
 *
 * @type {talk.media.c3d.AttrsTween}
 * @private
 */
talk.media.c3d.PipHandler.prototype.tween_;


/**
 * Whether we are currently minimized.
 *
 * @type {boolean}
 * @private
 */
talk.media.c3d.PipHandler.prototype.isMinimized_ = false;


/**
 * Whether we are currently being dragged.
 *
 * @type {boolean}
 * @private
 */
talk.media.c3d.PipHandler.prototype.isDragging_ = false;


/**
 * Current global mouse x coordinate.
 *
 * @type {number}
 * @private
 */
talk.media.c3d.PipHandler.prototype.mouseX_ = 0;


/**
 * Current global mouse y coordinate.
 *
 * @type {number}
 * @private
 */
talk.media.c3d.PipHandler.prototype.mouseY_ = 0;


/**
 * Opaque reference to our current cursor setting, if any.
 *
 * @type {talk.media.c3d.CursorManager.Registration_}
 * @private
 */
talk.media.c3d.PipHandler.prototype.cursorRef_;


/**
 * Initializes images and requests callbacks for event handling.
 */
talk.media.c3d.PipHandler.prototype.init = function() {
  this.feedObject_ = this.pipObject_.feedObject;
  this.feedAttrs_ = this.pipObject_.getFeedAttrs();

  this.imageView_ = new talk.media.c3d.View(
      this.o3dBundle_.c3dObject.getPlugin(), this.o3dBundle_.pack, 2, true,
      this.feedObject_.getTransform());
  this.imageView_.setProjectionMatrix(
      talk.media.c3d.createOrthographicMatrix(0 + 0.5,
          this.o3dBundle_.width + 0.5,
          this.o3dBundle_.height + 0.5,
          0 + 0.5,
          0.001,
          1000));
  var imageOverlay = new talk.media.c3d.ImageOverlay(
      this.o3dBundle_,
      this.effect_,
      this.imageView_);

  // Initiate icon images.
  this.createImages_(imageOverlay);

  var c3d = this.o3dBundle_.c3dObject.getPlugin();

  // Add mousemove handler to change mouse pointer over icons and for moving
  // the PIP.
  talk.media.c3d.addEventCallback(c3d, 'mousemove', this.boundOnMouseMove_);

  // Add mouse up handler for triggering minimize/maximize.
  talk.media.c3d.addEventCallback(c3d, 'mouseup', this.boundOnMouseUp_);

  // Add mouse down handler for entering drag mode.
  talk.media.c3d.addEventCallback(c3d, 'mousedown', this.boundOnMouseDown_);

  this.updatePosition(this.pipObject_.getFeedAttrs(), true);
};


/**
 * Removes all references to C3D objects.
 */
talk.media.c3d.PipHandler.prototype.disposeC3d = function() {
  // Might not be scriptable during shutdown.
  if (this.o3dBundle_.c3dObject.isScriptable()) {
    var c3d = this.o3dBundle_.c3dObject.getPlugin();
    talk.media.c3d.removeEventCallback(c3d, 'mousemove',
        this.boundOnMouseMove_);
    talk.media.c3d.removeEventCallback(c3d, 'mouseup',
        this.boundOnMouseUp_);
    talk.media.c3d.removeEventCallback(c3d, 'mousedown',
        this.boundOnMouseDown_);
  }
  this.minimizeImg_ = null;
  this.minimizeRolloverImg_ = null;
  this.maximizeImg_ = null;
  this.maximizeRolloverImg_ = null;
  this.fourwayArrowImg_ = null;
};


/**
 * Updates bounds for the current state.
 *
 * @param {talk.media.c3d.Attrs} attrs The new attributes for the PIP.
 * @param {boolean} savePosition Whether to save the current position or not.
 */
talk.media.c3d.PipHandler.prototype.updatePosition = function(attrs,
    savePosition) {
  if (this.feedObject_) {
    // Decide if we need to double the size of images.
    var scale = attrs.w < talk.media.c3d.PipHandler.RESIZE_THRESHOLD_WIDTH_ ||
        attrs.h < talk.media.c3d.PipHandler.RESIZE_THRESHOLD_HEIGHT_ ? 1 : 2;
    this.resizeImage_(this.minimizeImg_, scale);
    this.resizeImage_(this.minimizeRolloverImg_, scale);
    this.resizeImage_(this.maximizeImg_, scale);
    this.resizeImage_(this.maximizeRolloverImg_, scale);
    this.resizeImage_(this.fourwayArrowImg_, scale);

    // Reset the projection matrix to our new size.
    // TODO(oja): Replace this with using one single global draw context.
    this.imageView_.setProjectionMatrix(
        talk.media.c3d.createOrthographicMatrix(0 + 0.5,
            this.o3dBundle_.width + 0.5,
            this.o3dBundle_.height + 0.5,
            0 + 0.5,
            0.001,
            1000));

    if (this.isMinimized_ && savePosition) {
      // We have been resized while minimzied. Update the minimized bounds and
      // also store our new width and height for when being unminimized.
      var newAttrs = new talk.media.c3d.Attrs(this.pipObject_.getX() +
          this.pipObject_.getWidth() - (this.maximizeImg_.width() +
              talk.media.c3d.PipHandler.PIP_BORDER_WIDTH_),
          this.pipObject_.getY() + this.pipObject_.getHeight() -
          (this.maximizeImg_.height() +
              talk.media.c3d.PipHandler.PIP_BORDER_WIDTH_), 0,
          this.maximizeImg_.width(),
          this.maximizeImg_.height(), 1);
      this.savedAttrs_.w = attrs.w;
      this.savedAttrs_.h = attrs.h;
      this.feedObject_.setAttrs(newAttrs);
    }
    this.feedAttrs_ = this.pipObject_.getFeedAttrs();
    if (this.isMinimized_) {
      this.maximizeImg_.moveImageWithEdgeWrapping(0, 0, this.feedAttrs_.w,
          this.feedAttrs_.h);
      this.maximizeRolloverImg_.moveImageWithEdgeWrapping(0, 0,
          this.feedAttrs_.w, this.feedAttrs_.h);
    } else {
      this.minimizeImg_.moveImageWithEdgeWrapping(-2, 2, this.feedAttrs_.w,
          this.feedAttrs_.h);
      this.minimizeRolloverImg_.moveImageWithEdgeWrapping(-2, 2,
          this.feedAttrs_.w, this.feedAttrs_.h);
      this.fourwayArrowImg_.moveImageWithEdgeWrapping(
          this.feedAttrs_.w / 2 - this.fourwayArrowImg_.width() / 2,
          this.feedAttrs_.h / 2 - this.fourwayArrowImg_.height() / 2,
          this.feedAttrs_.w, this.feedAttrs_.h);
    }
  }
};


/**
 * Scales the given image with the given factor.
 *
 * @param {talk.media.c3d.Image} image The image to scale.
 * @param {number} scale The factor to scale with.
 * @private
 */
talk.media.c3d.PipHandler.prototype.resizeImage_ = function(image, scale) {
  image.resize(image.textureWidth() * scale, image.textureHeight() * scale);
}


/**
 * Creates icons used for the minimize and maximize buttons.
 *
 * @param {talk.media.c3d.ImageOverlay} imageOverlay The overlay to display the
 *     images.
 * @private
 */
talk.media.c3d.PipHandler.prototype.createImages_ = function(imageOverlay) {
  this.minimizeImg_ = this.createImage_(imageOverlay, 'images/minimize.png',
      -talk.media.c3d.PipHandler.PIP_BORDER_WIDTH_,
      talk.media.c3d.PipHandler.PIP_BORDER_WIDTH_);
  this.minimizeRolloverImg_ = this.createImage_(imageOverlay,
      'images/minimize_rollover.png',
      -talk.media.c3d.PipHandler.PIP_BORDER_WIDTH_,
      talk.media.c3d.PipHandler.PIP_BORDER_WIDTH_);
  this.maximizeImg_ = this.createImage_(imageOverlay, 'images/maximize.png',
      -talk.media.c3d.PipHandler.PIP_BORDER_WIDTH_,
      -talk.media.c3d.PipHandler.PIP_BORDER_WIDTH_);
  this.maximizeRolloverImg_ = this.createImage_(imageOverlay,
      'images/maximize_rollover.png',
      -talk.media.c3d.PipHandler.PIP_BORDER_WIDTH_,
      -talk.media.c3d.PipHandler.PIP_BORDER_WIDTH_);
  this.fourwayArrowImg_ = this.createImage_(imageOverlay,
      'images/fourway_arrow.png', 0, 0);

  // Make the image a bit transparent.
  this.fourwayArrowImg_.setAlpha(0.9);

  // Don't show any images initially.
  this.minimizeImg_.setVisible(false);
  this.minimizeRolloverImg_.setVisible(false);
  this.maximizeImg_.setVisible(false);
  this.maximizeRolloverImg_.setVisible(false);
  this.fourwayArrowImg_.setVisible(false);
};


/**
 * Creates icons used for the minimize and maximize buttons.
 *
 * @param {talk.media.c3d.ImageOverlay} imageOverlay The overlay to display the
 *     image.
 * @param {string} url The url of the image.
 * @param {number} x The initial x coordinate for this image.
 * @param {number} y The initial y coordinate for this image.
 * @return {talk.media.c3d.Image} A new Image object.
 * @private
 */
talk.media.c3d.PipHandler.prototype.createImage_ = function(imageOverlay, url,
    x, y) {
  var image = imageOverlay.createImage(0, 0, url, goog.bind(function() {
    this.imageLoaded_(image, x, y);
  }, this));
  return image;
};


/**
 * Moves image to the given initial position. Called when an image has
 * completed loading.
 *
 * @param {talk.media.c3d.Image} image The image that loaded.
 * @param {number} x The new horizontal position.
 * @param {number} y The new vertical position.
 * @private
 */
talk.media.c3d.PipHandler.prototype.imageLoaded_ = function(image, x, y) {
  image.moveImageWithEdgeWrapping(x, y, this.feedAttrs_.w, this.feedAttrs_.h);
};


/**
 * Toggles the minimized state for the PIP and initiates a tween to move it to
 * the new location.
 *
 * @param {boolean} minimized Whether the PIP is minimized.
 * @private
 */
talk.media.c3d.PipHandler.prototype.setMinimized_ = function(minimized) {
  this.isMinimized_ = minimized;

  var newAttrs;
  if (minimized) {
    this.minimizeImg_.setVisible(false);
    this.minimizeRolloverImg_.setVisible(false);
    this.fourwayArrowImg_.setVisible(false);
    this.savedAttrs_ = this.feedAttrs_;
    newAttrs = new talk.media.c3d.Attrs(this.pipObject_.getX() +
        this.pipObject_.getWidth() - (this.maximizeImg_.width() +
            talk.media.c3d.PipHandler.PIP_BORDER_WIDTH_),
        this.pipObject_.getY() + this.pipObject_.getHeight() -
        (this.maximizeImg_.height() +
            talk.media.c3d.PipHandler.PIP_BORDER_WIDTH_), 0,
        this.maximizeImg_.width(),
        this.maximizeImg_.height(), 1);
  } else {
    this.maximizeImg_.setVisible(false);
    this.maximizeRolloverImg_.setVisible(false);
    newAttrs = this.savedAttrs_;

    // In case we have been resized while in minimized mode we need to make
    // sure we doesn't end up outside our parent area.
    this.checkBoundaries_(newAttrs);
  }
  this.tween_ = new talk.media.c3d.AttrsTween(
      this.feedObject_,
      this.feedAttrs_,
      newAttrs,
      0.8,
      talk.media.c3d.STRONG_EASE_IN_OUT,
      goog.bind(this.onTweenCompleted, this)
      );
  this.o3dBundle_.c3dEngine.registerRenderCallback(this.tween_);
};


/**
 * Checks if this coordinate is inside the PIP.
 *
 * @param {number} x The client global x coordinate.
 * @param {number} y The client global y coordinate.
 * @return {boolean} Wether this point is inside the pip.
 * @private
 */
talk.media.c3d.PipHandler.prototype.isInsidePip_ = function(x, y) {
  return (x >= this.feedAttrs_.x &&
      x <= this.feedAttrs_.x + this.feedAttrs_.w &&
      y >= this.feedAttrs_.y && y <= this.feedAttrs_.y + this.feedAttrs_.h);
};


/**
 * Checks if this x position is inside the client area.
 *
 * @param {number} x The client global x coordinate.
 * @return {boolean} Whether this x position is inside the client area.
 * @private
 */
talk.media.c3d.PipHandler.prototype.clientHitTestX_ = function(x) {
  return x >= 0 && x <= this.o3dBundle_.width;
};


/**
 * Checks if this y position is inside the client area.
 *
 * @param {number} y The client global y coordinate.
 * @return {boolean} Wether this y position is inside the client area.
 * @private
 */
talk.media.c3d.PipHandler.prototype.clientHitTestY_ = function(y) {
  return y >= 0 && y <= this.o3dBundle_.height;
};


/**
 * Translates world vector to pip local.
 *
 * @param {Array.<number>} vector The world vector to be translated.
 * @return {Array.<number>} The translated vector.
 * @private
 */
talk.media.c3d.PipHandler.prototype.translateToPipPoint_ = function(vector) {
  var inverseMatrix = talk.media.c3d.inverse4(
      this.feedObject_.getTransform()['localMatrix']);
  return talk.media.c3d.transformPoint(inverseMatrix, vector);
};


/**
 * Checks given attributes and makes sure that they are within our parent's
 * bounds. If not the check will fail and the attributes will be adjusted to
 * the closest valid bounds.
 *
 * @param {talk.media.c3d.Attrs} attrs The attributes to be checked.
 * @return {boolean} Whether the attributes are within our parent's bounds.
 * @private
 */
talk.media.c3d.PipHandler.prototype.checkBoundaries_ = function(attrs) {
  var result = true;
  if (attrs.x < 0) {
    attrs.x = 0;
    result = false;
  } else if (attrs.x + attrs.w > this.pipObject_.getX() +
      this.pipObject_.getWidth()) {
    attrs.x = this.pipObject_.getWidth() - attrs.w;
    result = false;
  }
  if (attrs.y < 0) {
    attrs.y = 0;
    result = false;
  } else if (attrs.y + attrs.h > this.pipObject_.getY() +
      this.pipObject_.getHeight()) {
    attrs.y = this.pipObject_.getHeight() - attrs.h;
    result = false;
  }
  return result;
};


/**
 * Updates the PIP to match the new state.
 *
 * @protected
 */
talk.media.c3d.PipHandler.prototype.onTweenCompleted = function() {
  this.tween_ = null;
  this.updatePosition(this.pipObject_.getAttrs(), false);
  if (this.isMinimized_) {
    this.maximizeImg_.setVisible(true);
  }
};


/**
 * Handles a global mousemove event.
 *
 * @param {Object} e The event.
 * @protected
 */
talk.media.c3d.PipHandler.prototype.onMouseMove = function(e) {
  if (this.tween_) {
    // Just ignore mouse move if we are in a tween.
    return;
  }
  if (this.isDragging_) {
    var x = e['x'];
    var y = e['y'];
    var dx = x - this.mouseX_;
    var dy = y - this.mouseY_;
    var attrs = this.feedAttrs_;

    // Simulates Flash behaviour when dragging outside the client area.
    if (this.clientHitTestX_(x)) {
      // Allow move only if inside the x range.
      attrs.x += dx;
    }
    if (this.clientHitTestY_(y)) {
      // Allow move only if inside the y range.
      attrs.y += dy;
    }
    this.mouseX_ = x;
    this.mouseY_ = y;
    this.checkBoundaries_(attrs);
    this.feedObject_.setAttrs(attrs);
  } else {
    // Not being dragged.
    if (this.isInsidePip_(e['x'], e['y'])) {
      // Inside the PIP, update icon states.
      this.changeCursor_('POINTER', 0);
      var vec = [e['x'], e['y'], 0];
      vec = this.translateToPipPoint_(vec);
      if (this.isMinimized_) {
        if (this.maximizeImg_.hitTest(vec[0], vec[1])) {
          this.maximizeImg_.setVisible(false);
          this.maximizeRolloverImg_.setVisible(true);
        } else {
          this.maximizeImg_.setVisible(true);
          this.maximizeRolloverImg_.setVisible(false);
        }
      } else {
        this.fourwayArrowImg_.moveImageWithEdgeWrapping(
            this.feedAttrs_.w / 2 - this.fourwayArrowImg_.width() / 2,
            this.feedAttrs_.h / 2 - this.fourwayArrowImg_.height() / 2,
            this.feedAttrs_.w, this.feedAttrs_.h);
        this.fourwayArrowImg_.setVisible(true);
        if (this.minimizeImg_.hitTest(vec[0], vec[1])) {
          this.minimizeImg_.setVisible(false);
          this.minimizeRolloverImg_.setVisible(true);
        } else {
          this.minimizeImg_.setVisible(true);
          this.minimizeRolloverImg_.setVisible(false);
        }
      }
    } else {
      // Mouse has left the pip, turn of highlight of maximize button and set
      // default cursor back.
      this.unsetCursor_();
      this.fourwayArrowImg_.setVisible(false);
      this.maximizeRolloverImg_.setVisible(false);
      this.minimizeImg_.setVisible(false);
      this.minimizeRolloverImg_.setVisible(false);
      if (this.isMinimized_) {
        this.maximizeImg_.setVisible(true);
      }
    }
  }
};


/**
 * Handles a global mouseup event.
 *
 * @param {Object} e The event.
 * @protected
 */
talk.media.c3d.PipHandler.prototype.onMouseUp = function(e) {
  this.isDragging_ = false;
  if (this.isInsidePip_(e['x'], e['y'])) {
    // Mouse released inside PIP, check if any icon was hit.
    var vec = [e['x'], e['y'], 0];
    vec = this.translateToPipPoint_(vec);
    if (this.isMinimized_) {
      if (this.maximizeImg_.hitTest(vec[0], vec[1])) {
        this.setMinimized_(false);
      }
    } else {
      if (this.minimizeImg_.hitTest(vec[0], vec[1])) {
        this.setMinimized_(true);
      }
    }
    this.changeCursor_('POINTER', 0);  // In case we were dragging
  } else {
    this.unsetCursor_();
  }
};


/**
 * Handles a global mousedown event.
 *
 * @param {Object} e The event.
 * @protected
 */
talk.media.c3d.PipHandler.prototype.onMouseDown = function(e) {
  if (!this.isMinimized_ && this.isInsidePip_(e['x'], e['y'])) {
    // Mouse pressed inside PIP, initiate dragging.
    this.isDragging_ = true;
    this.mouseX_ = e['x'];
    this.mouseY_ = e['y'];
    // Priority for the grab icon is higher than pointer, because even when over
    // other clickable things we still want to see the grab icon.
    this.changeCursor_('MOVE', 1);
  }
};


/**
 * Changes our cursor style to the given one.
 *
 * @param {string} styleName New cursor style.
 * @param {number} priority Priority for this style request.
 * @private
 */
talk.media.c3d.PipHandler.prototype.changeCursor_ = function(
    styleName,
    priority) {
  if (goog.isDefAndNotNull(this.cursorRef_)) {
    this.o3dBundle_.cursorManager.unsetCursor(this.cursorRef_);
  }
  this.cursorRef_ = this.o3dBundle_.cursorManager.setCursor(
    styleName,
    priority);
};


/**
 * Unsets our cursor style.
 * @private
 */
talk.media.c3d.PipHandler.prototype.unsetCursor_ = function() {
  this.o3dBundle_.cursorManager.unsetCursor(this.cursorRef_);
  this.cursorRef_ = null;
};


/** @inheritDoc */
talk.media.c3d.PipHandler.prototype.disposeInternal = function() {
  talk.media.c3d.PipHandler.superClass_.disposeInternal.call(this);
  this.disposeC3d();
};
