// Copyright 2008 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview UI component for a video recorder. Includes video area and
 * basic controls via talk.media.VideoRecorderControls.
 *
 * CSS classes to define are
 * <ul>
 * <li>CSS_VIDEO_RECORDER_SWF_DIV = The div holding only the swf
 * <li>CSS_VIDEO_RECORDER_CONTROLS_DIV = The div holding the control buttons
 * <li>CSS_VIDEO_RECORDER_CONTROLS_LEFT = The left-most control button
 * <li>CSS_VIDEO_RECORDER_CONTROLS_RIGHT = The right-most control button
 * </ul>
 *
 * @author kmd@google.com (Krista Davis)
 */

goog.provide('talk.media.VideoRecorder');
goog.provide('talk.media.VideoRecorderEvent');

goog.require('goog.debug.Logger');
goog.require('goog.dom');
goog.require('goog.dom.classes');
goog.require('goog.events.Event');
goog.require('goog.events.EventHandler');
goog.require('goog.ui.Component');
goog.require('goog.ui.Component.EventType');
goog.require('talk.media.FlashObject');
goog.require('talk.media.VideoRecorderControls');

/**
 * Class for loading a video recorder SWF and basic controls.
 * @param {goog.dom.DomHelper} opt_domHelper Otional DOM helper.
 * @constructor
 * @extends {goog.ui.Component}
 */
talk.media.VideoRecorder = function(opt_domHelper) {
  goog.ui.Component.call(this, opt_domHelper);

  /**
   * @type {goog.events.EventHandler}
   * @private
   */
  this.eventHandler_ = new goog.events.EventHandler(this);

  /**
   * @type {talk.media.VideoRecorderControls}
   * @private
   */
  this.controls_ = new talk.media.VideoRecorderControls(opt_domHelper);
  this.addChild(this.controls_);
};
talk.media.VideoRecorder.inherits(goog.ui.Component);


/**
 * Name used in the id of the HTML.
 * @type {string}
 */
talk.media.VideoRecorder.NAME = 'talk_media_VideoRecorder';


/**
 * Default max record duration.
 * @type {number}
 */
talk.media.VideoRecorder.DEFAULT_MAX_DURATION = 30 * 1000; // 30s


/**
 * Messages from the SWF.
 * @enum {string}
 */
talk.media.VideoRecorder.FromSwf = {
  /** Message from SWF with videocapture state. */
  VC_STATUS: 'VIDEO_CAPTURE_STATUS',
  /** Message from SWF with camera status. */
  CAMERA_STATUS: 'CAMERA_STATUS',
  /** Trace statement message from SWF. */
  TRACE: 'TRACE',
  /** SWF is fully loaded. */
  LOADED: 'loaded',
  /** Safe to close. */
  CLOSE: 'CLOSE'
};


/**
 * The states of the VideoCapture sent by the SWF. Arguments with
 * talk.media.VideoRecorder.FromSwf.VC_STATUS messages.
 * @enum {string}
 */
talk.media.VideoRecorder.VideoState = {
  /** The initial state when not recording or replaying and no recorded video */
  START: 'VideoCapture.Start',
  /** Audio and video is being captured and written to a stream */
  RECORDING: 'VideoCapture.Recording',
  /** A video has been recorded and not deleted,
   * but is not being replayed or written to */
  HAVE_RECORDED: 'VideoCapture.HaveRecorded',
  /** The most recently recorded (and not delete) stream is being replayed */
  REPLAYING: 'VideoCapture.Replaying',
  /** The most recently recorded stream is being buffered before replaying */
  BUFFERING: 'VideoCapture.Buffering',
  /** The most recently recorded stream is being saved */
  SAVING: 'VideoCapture.Saving',
  /** The most recently recorded stream has been saved */
  SAVED: 'VideoCapture.Saved',
  /** There is an error connecting to the Flash Server */
  CONNECT_ERROR: 'VideoCapture.ConnectError'
};


/**
 * The status codes for the camera sent by the SWF. Arguments with
 * talk.media.VideoRecorder.FromSwf.CAMERA_STATUS messages.
 * @enum {string}
 */
talk.media.VideoRecorder.CameraStatus = {
  /** Error message when another app has exclusive use of camera. */
  CAMERA_IN_USE: 'Camera.InUse',
  /** Status message when camera is ready. */
  CAMERA_READY: 'Camera.Ready',
  /** Error message when no camera is installed. */
  CAMERA_NOT_INSTALLED: 'Camera.NotInstalled',
  /** Status message when user denies access.
   * Convenience var for Flash status message. */
  CAMERA_MUTED: 'Camera.Muted',
  /** Status message when user allows access.
   * Convenience var for Flash status message. */
  CAMERA_UNMUTED: 'Camera.Unmuted'
};


/**
 * Commands sent to the SWF.
 * @enum {string}
 */
talk.media.VideoRecorder.Command = {
  /** Tell the SWF to set the rtmp server URL. */
  SERVER_URL: 'SERVER_URL',
  /** Tell the SWF this is a control, such as 'RECORD' or 'STOP'. */
  CONTROL: 'CONTROL',
  /** Tell the SWF to check the camera again. */
  VERIFY_CAMERA: 'VERIFY_CAMERA',
  /** Tell the SWF to open the Flash settings dialog. */
  FLASH_SETTINGS: 'FLASH_SETTINGS',
  /** Tell the SWF to enable or disable its control button. */
  ENABLE: 'ENABLE',
  MAX_DURATION: 'MAX_DURATION'
};


/**
 * Control messages understood by the SWF. Arguments with
 * talk.media.VideoRecorder.Command.CONTROL messages.
 * @enum {string}
 */
talk.media.VideoRecorder.VcControl = {
  RECORD: 'RECORD',
  STOP: 'STOP',
  REPLAY: 'REPLAY',
  DELETE: 'DELETE',
  SAVE: 'SAVE',
  CANCEL: 'CANCEL'
};


/**
 * Indicates an error connecting to the RTMP server.
 * @type {boolean}
 * @private
 */
talk.media.VideoRecorder.prototype.serverError_;


/**
 * Logger object
 * @type {goog.debug.Logger}
 * @private
 */
talk.media.VideoRecorder.prototype.logger_ =
    goog.debug.Logger.getLogger('talk.media.VideoRecorder');


/**
 * Max record duration in ms
 * @type {number}
 * @private
 */
talk.media.VideoRecorder.prototype.maxDuration_;


/**
 * {@inheritDoc}
 */
talk.media.VideoRecorder.prototype.enterDocument = function() {
  talk.media.VideoRecorder.superClass_.enterDocument.call(this);

  /**
   * @type {Element}
   * @private
   */
  this.swfDiv_ = this.dom_.$dom('div');
  goog.dom.classes.set(this.swfDiv_,
      goog.getCssName('CSS_VIDEO_RECORDER_SWF_DIV'));

  /**
   * @type {Element}
   * @private
   */
  this.controlDiv_ = this.dom_.$dom('div');
  goog.dom.classes.set(this.controlDiv_,
      goog.getCssName('CSS_VIDEO_RECORDER_CONTROLS_DIV'));

  var el = this.getElement();
  el.appendChild(this.swfDiv_);
  el.appendChild(this.controlDiv_);

  this.controls_.render(this.controlDiv_);

  // Set event listeners.
  this.eventHandler_.listen(this.controls_, goog.ui.Component.EventType.ACTION,
      this.onControlAction_);

  this.enableControls(false);
  this.controls_.setState(talk.media.VideoRecorderControls.State.START);
};


/**
 * {@inheritDoc}
 */
talk.media.VideoRecorder.prototype.exitDocument = function() {
  talk.media.VideoRecorder.superClass_.exitDocument.call(this);

  // Clear event listeners.
  this.eventHandler_.removeAll();
};


/**
 * {@inheritDoc}
 */
talk.media.VideoRecorder.prototype.dispose = function() {
  if (!this.isDisposed()) {
    talk.media.VideoRecorder.superClass_.dispose.call(this);

    if (this.eventHandler_) {
      this.eventHandler_.dispose();
      this.eventHandler_ = null;
    }

    if (this.recorder_) {
      this.recorder_.removeHTML();
    }
  }
};


/**
 * Inits the video recorder SWF.
 * @param {string} swf The path to the video recorder SWF.
 * @param {string} serverUrl The URL of the RTMP server.
 * @param {number} opt_maxDuration The max duration of a recording.  30 seconds
 *   by default.
 */
talk.media.VideoRecorder.prototype.initRecorder = function(swf, serverUrl,
    opt_maxDuration) {
  // Save the server URL so we can send it to the SWF when it's loaded.
  this.serverUrl_ = serverUrl;
  // Save the max duration too.
  if (opt_maxDuration) {
    this.maxDuration_ = opt_maxDuration;
  } else {
    this.maxDuration_ = talk.media.VideoRecorder.DEFAULT_MAX_DURATION;
  }
  this.recorder_ =
      new talk.media.FlashObject(talk.media.VideoRecorder.NAME, '');
  this.recorder_.writeHTML(this.swfDiv_, swf);
  this.recorder_.setRecv(goog.bind(this.onDataFromRecorder_, this));
};


/**
 * Handler for button clicks. Sends the control command to the SWF.
 *
 * @param {goog.events.Event} e The event object
 * @private
 */
talk.media.VideoRecorder.prototype.onControlAction_ = function(e) {
  switch (e.target.getValue()) {
    case talk.media.VideoRecorderControls.ButtonId.RECORD:
      this.send_(talk.media.VideoRecorder.Command.CONTROL,
          [talk.media.VideoRecorder.VcControl.RECORD]);
      break;
    case talk.media.VideoRecorderControls.ButtonId.STOP:
      this.send_(talk.media.VideoRecorder.Command.CONTROL,
          [talk.media.VideoRecorder.VcControl.STOP]);
      break;
    case talk.media.VideoRecorderControls.ButtonId.REPLAY:
      this.send_(talk.media.VideoRecorder.Command.CONTROL,
          [talk.media.VideoRecorder.VcControl.REPLAY]);
      break;
    case talk.media.VideoRecorderControls.ButtonId.START_OVER:
      this.send_(talk.media.VideoRecorder.Command.CONTROL,
          [talk.media.VideoRecorder.VcControl.DELETE]);
      break;
    case talk.media.VideoRecorderControls.ButtonId.SAVE:
      this.enableControls(false);
      // We do not save the video, its the parent's responsibility to call save.
      break;
    case talk.media.VideoRecorderControls.ButtonId.CANCEL:
      this.enableControls(false);
      this.send_(talk.media.VideoRecorder.Command.CONTROL,
          [talk.media.VideoRecorder.VcControl.CANCEL]);
      break;
  }
};

/**
 * Enables or disables the controls in js and Flash.
 *
 * @param {boolean} enable true to enable, false to disable
 */
talk.media.VideoRecorder.prototype.enableControls = function(enable) {
  this.controls_.setEnabled(enable);
  this.send_(talk.media.VideoRecorder.Command.ENABLE, [enable]);
}


/**
 * Sends a command to SWF to save the current video. Command does nothing if no
 * video is present.
 *
 * TODO (kmd): Add handling for additional metadata beyond owner and title.
 *
 * @param {string} owner The JID of the owner of this video
 * @param {string} title The title (caption) to give the video
 */
talk.media.VideoRecorder.prototype.save = function(owner, title) {
  this.send_(talk.media.VideoRecorder.Command.CONTROL,
      [talk.media.VideoRecorder.VcControl.SAVE, owner, title]);
};


/**
 * Sends a cancel command to SWF. The SWF will perform clean up tasks and
 * prepare for disposal. The SWF will send a close message when it is safe to
 * dispose.
 */
talk.media.VideoRecorder.prototype.cancel = function() {
  this.send_(talk.media.VideoRecorder.Command.CONTROL,
      [talk.media.VideoRecorder.VcControl.CANCEL]);
};


/**
 * Sends a verify command to the SWF. The SWF will check the camera and send
 * back a status.
 * @param {boolean} opt_getDefault True to get the default camera.
 */
talk.media.VideoRecorder.prototype.verify = function(opt_getDefault) {
  this.send_(talk.media.VideoRecorder.Command.VERIFY_CAMERA,
      [!!opt_getDefault]);
};


/**
 * Sends a Flash settings command to the SWF. The SWF will open the Flash
 * settings dialog to the specified tab.
 *
 * @param {number} tab The tab of the Flash settings dialog to start on
 */
talk.media.VideoRecorder.prototype.openFlashSettings = function (tab) {
  this.send_(talk.media.VideoRecorder.Command.FLASH_SETTINGS,
      [tab]);
};


/**
 * Sends a message to the SWF from this.
 * @param {string} message The message to send.
 * @param {Array.<string>} opt_args An array of additional arguments.
 * @private
 */
talk.media.VideoRecorder.prototype.send_ = function(message, opt_args) {
  if (this.recorder_) {
    opt_args = opt_args ? opt_args : [];
    this.recorder_.send(message, opt_args);
  }
};


/**
 * Receives data from flash widget.
 * @param {string} a ignored
 * @param {string} b ignored
 * @param {Array} message Message array passed from flash API.
 * @private
 */
talk.media.VideoRecorder.prototype.onDataFromRecorder_ =
    function(a, b, message) {
  switch (message[0]) {
    case talk.media.VideoRecorder.FromSwf.VC_STATUS:
      // message[1] = status, message[2] = info object
      this.handleVcStatus_(message[1], message[2]);
      break;
    case talk.media.VideoRecorder.FromSwf.CAMERA_STATUS:
      this.handleCameraStatus_(message[1]);
      break;
    case talk.media.VideoRecorder.FromSwf.TRACE:
      this.logger_.info('Flash Trace: ' + message[1]);
      break;
    case talk.media.VideoRecorder.FromSwf.LOADED:
      this.handleSwfLoaded_();
      break;
    case talk.media.VideoRecorder.FromSwf.CLOSE:
      this.handleClose_();
      break;
    default:
      this.logger_.info('Unknown message from SWF: ' + message[0]);
      break;
  }
};


/**
 * Handler for video status events from the SWF. Updates the UI to correspond
 * to the current status and dispatches event.
 * @param {string} status The video status
 * @param {Object} opt_infoObj An optional Object from the SWF with the current
 *     any information relevant to the status
 * @private
 */
talk.media.VideoRecorder.prototype.handleVcStatus_ =
    function(status, opt_infoObj) {
  this.logger_.info('Received video status: ' + status);
  switch (status) {
    case talk.media.VideoRecorder.VideoState.START:
      this.controls_.setState(talk.media.VideoRecorderControls.State.START);
      break;
    case talk.media.VideoRecorder.VideoState.RECORDING:
      this.controls_.setState(talk.media.VideoRecorderControls.State.RECORDING);
      break;
    case talk.media.VideoRecorder.VideoState.HAVE_RECORDED:
      this.controls_.setState(
        talk.media.VideoRecorderControls.State.HAVE_RECORDED);
      break;
    case talk.media.VideoRecorder.VideoState.BUFFERING:
    case talk.media.VideoRecorder.VideoState.REPLAYING:
      this.controls_.setState(talk.media.VideoRecorderControls.State.REPLAYING);
      break;
    case talk.media.VideoRecorder.VideoState.SAVING:
      break;
    case talk.media.VideoRecorder.VideoState.SAVED:
      this.dispatchUrlEvent_(opt_infoObj['link']);
      this.handleClose_();
      break;
    case talk.media.VideoRecorder.VideoState.CONNECT_ERROR:
      this.logger_.warning('Error connecting to RTMP server.');
      this.enableControls(false);
      this.serverError_ = true;
      break;
    default:
      this.logger_.info('Unknown VideoRecorder State: ' + status);
      break;
  }
  this.dispatchVideoStatus_(status);
};


/**
 * Handler for camera.onStatus messages, which indicate when the user selects
 * or changes the access permissions for the camera.
 *
 * @param {string} code The status code.
 * @private
 */
talk.media.VideoRecorder.prototype.handleCameraStatus_ = function(code) {
  this.logger_.info('Received Camera status ' + code);
  if (!this.serverError_) {
    switch (code) {
      case talk.media.VideoRecorder.CameraStatus.CAMERA_UNMUTED:
        this.verify();
        // Switch statement fallthrough is intentional. Do not break;
      case talk.media.VideoRecorder.CameraStatus.CAMERA_MUTED:
      case talk.media.VideoRecorder.CameraStatus.CAMERA_IN_USE:
      case talk.media.VideoRecorder.CameraStatus.CAMERA_NOT_INSTALLED:
        this.enableControls(false);
        break;
      case talk.media.VideoRecorder.CameraStatus.CAMERA_READY:
        this.enableControls(true);
        break;
    }
    this.dispatchCameraEvent_(code);
  }
};


/**
 * Called when the SWF is fully loaded. Sets the server URL.
 * @private
 */
talk.media.VideoRecorder.prototype.handleSwfLoaded_ = function() {
  this.logger_.info('Video Capture SWF loaded.');
  // Tell the SWF what RTMP Server to connect to.
  this.send_(talk.media.VideoRecorder.Command.SERVER_URL, [this.serverUrl_]);
  // Tell the SWF the maximum time to record.
  this.send_(talk.media.VideoRecorder.Command.MAX_DURATION,
             [this.maxDuration_]);
  this.dispatchVideoRecorderEvent_(talk.media.VideoRecorder.Event.SWF_LOADED);
};


/**
 * Dispatches close event when it is safe to dispose the SWF.
 * @private
 */
talk.media.VideoRecorder.prototype.handleClose_ = function() {
  this.dispatchVideoRecorderEvent_(talk.media.VideoRecorder.Event.CLOSE);
};


/**
 * Dispatches video status event.
 * @param {string} status The current status sent from the SWF.
 * @private
 */
talk.media.VideoRecorder.prototype.dispatchVideoStatus_ = function(status) {
  this.dispatchVideoRecorderEvent_(talk.media.VideoRecorder.Event.STATUS,
      { status: status });
};


/**
 * Dispatches URL event when the save command completes. Event object
 * includes URL to the saved video.
 * @param {string} url The link to the video.
 * @private
 */
talk.media.VideoRecorder.prototype.dispatchUrlEvent_ = function(url) {
  this.dispatchVideoRecorderEvent_(talk.media.VideoRecorder.Event.URL,
      { link: url });
};


/**
 * Dispatches camera event.
 * @param {string} code The camera event code.
 * @private
 */
talk.media.VideoRecorder.prototype.dispatchCameraEvent_ = function(code) {
  this.dispatchVideoRecorderEvent_(talk.media.VideoRecorder.Event.CAMERA,
      { code: code });
};


/**
 * Dispatches a talk.media.VideoRecorderEvent event.
 * @param {string} event The event name.
 * @param {Object} opt_info Extra info to send with the event.
 * @private
 */
talk.media.VideoRecorder.prototype.dispatchVideoRecorderEvent_ =
    function(event, opt_info) {
  this.dispatchEvent(new talk.media.VideoRecorderEvent(event, opt_info));
};



/**
 * Events generated by talk.media.VideoRecorder.
 * @param {string} type Event Type.
 * @param {Object} opt_info Additional info if relevant.
 * @constructor
 * @extends {goog.events.Event}
 */
talk.media.VideoRecorderEvent = function(type, opt_info) {
  goog.events.Event.call(this, type);

  /**
   * Info item for the event.
   *
   * @type {Object}
   */
  this.info = (opt_info ? opt_info : null);
};
goog.inherits(talk.media.VideoRecorderEvent, goog.events.Event);


/**
 * Constants for event type fired by talk.media.VideoRecorder.
 * @enum {string}
 */
talk.media.VideoRecorder.Event = {

  /** Id for url events. This event signals a completed save call. */
  URL : 'VIDEO_URL',

  /** Id for video status events. */
  STATUS : 'VIDEO_STATUS',

  /** Id for event when the recorder SWF has completed loading. */
  SWF_LOADED : 'SWF_LOADED',

  /** Id for close events. The parent needs to wait for this message before
   * disposing this component. */
  CLOSE : 'VIDEO_CLOSE',

  /** Id for camera events. */
  CAMERA : 'VIDEO_CAMERA'
};
