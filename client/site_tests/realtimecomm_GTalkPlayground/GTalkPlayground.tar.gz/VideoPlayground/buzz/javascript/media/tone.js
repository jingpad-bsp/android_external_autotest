// Copyright 2009 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview Calling related constants.
 *
 * @author Robin Schriebman (rschriebman@google.com)
 */

goog.provide('talk.media.Tone');

goog.require('goog.events.KeyCodes');


/**
 * DTMF tones that the user can send.
 * @enum {string}
 */
talk.media.Tone = {
  ONE: '1',
  TWO: '2',
  THREE: '3',
  FOUR: '4',
  FIVE: '5',
  SIX: '6',
  SEVEN: '7',
  EIGHT: '8',
  NINE: '9',
  STAR: '*',
  POUND: '#'
};

/**
 * Delay in milliseconds to show the button as being depressed when playing a
 * tone.
 * @type {number}
 */
talk.media.Tone.DELAY = 200;

/**
 * Takes a keypress and determines if a valid DTMF tone was pressed.
 * @param {number} keyCode The keycode that was pressed.
 * @param {boolean} isShift True if the shift key was depressed.
 * @return {talk.media.Tone?} The tone to play if a valid one was pressed.
 */
talk.media.Tone.getAndCheckDtmfTone = function(keyCode, isShift) {
  var value = null;
  if (!isShift) {
    if (keyCode >= goog.events.KeyCodes.ZERO &&
        keyCode <= goog.events.KeyCodes.NINE) {
      value = /** @type {talk.media.Tone} */
          ('' + (keyCode - goog.events.KeyCodes.ZERO));
    }
    if (keyCode >= goog.events.KeyCodes.NUM_ZERO &&
        keyCode <= goog.events.KeyCodes.NUM_NINE) {
      value = /** @type {talk.media.Tone} */
          ('' + (keyCode - goog.events.KeyCodes.NUM_ZERO));
    }
  }

  if (keyCode == goog.events.KeyCodes.EIGHT && isShift ||
      keyCode == goog.events.KeyCodes.NUM_MULTIPLY) {
    value = talk.media.Tone.STAR;
  } else if (keyCode == goog.events.KeyCodes.THREE && isShift) {
    value = talk.media.Tone.POUND;
  }
  if (goog.events.KeyCodes.A <= keyCode && keyCode <= goog.events.KeyCodes.Z) {
    value = /** @type {talk.media.Tone} */
        ("222333444555666777788899999".charAt(
            keyCode - goog.events.KeyCodes.A));
  }

  return value;
};

/**
 * Converts a potentially char infested string to a purely numerical one (ie.
 * 1800flowers becomes 18003569377.
 * @param {string} number The phone number.
 * @return {string} The phone number without characters.
 * TODO(rschriebman): move this somewhere more logical. Chris has a CL that
 * does this.
 * TODO(rschriebman): figure out in localization if we want this?
 */
talk.media.Tone.convertLettersToNumbers = function(number) {
  number = number.toLowerCase();
  number = number.replace(/[abc]/g, talk.media.Tone.TWO);
  number = number.replace(/[def]/g, talk.media.Tone.THREE);
  number = number.replace(/[ghi]/g, talk.media.Tone.FOUR);
  number = number.replace(/[jkl]/g, talk.media.Tone.FIVE);
  number = number.replace(/[mno]/g, talk.media.Tone.SIX);
  number = number.replace(/[pqrs]/g, talk.media.Tone.SEVEN);
  number = number.replace(/[tuv]/g, talk.media.Tone.EIGHT);
  number = number.replace(/[wxyz]/g, talk.media.Tone.NINE);
  return number;
};
