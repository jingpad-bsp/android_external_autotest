// Copyright 2008 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview A diagnostic tool to help log events from the plugin.
 *
 * @author jessan@google.com (Jessan Hutchison-Quillian)
 */

goog.provide('talk.media.TalkPluginSpy');

goog.require('goog.events.Event');
goog.require('goog.events.EventHandler');
goog.require('goog.events.EventType');
goog.require('goog.math.Size')
goog.require('goog.string');
goog.require('goog.structs.CircularBuffer');
goog.require('goog.ui.Component');
goog.require('goog.ui.SplitPane');
goog.require('goog.ui.SplitPane.Orientation');
goog.require('talk.media.CallDashboard');
goog.require('talk.media.CallManager');
goog.require('talk.media.GraphDashboard');
goog.require('talk.media.MediaInfoMessage');
goog.require('talk.media.MultiwayDashboard');
goog.require('talk.media.TalkPluginEvent');
goog.require('talk.media.TalkPluginSpyTemplate');

/**
 * Listens to and logs events from the TalkPlugin and CallManager, allowing
 * them to be displayed in a debug window.
 *
 * @param {talk.media.CallManager} opt_callManager The CallManager to spy.
 * @param {Array.<talk.media.CallEvent>} opt_events An initial set of events.
 * @param {boolean} opt_openWindow Whether or not to initially open the window.
 * @param {string} opt_windowTitle A title for the popup window.
 * @constructor
 */
talk.media.TalkPluginSpy = function(opt_callManager, opt_events,
    opt_openWindow, opt_windowTitle) {

  /**
   * @type {talk.media.CallManager|undefined}
   * @private
   */
  this.callManager_ = opt_callManager;

  /**
   * @type {null|string}
   * @private
   */
  this.windowTitle_ = 'Voice and Video Stats';

  if (goog.isDefAndNotNull(opt_windowTitle)) {
    this.windowTitle_ = opt_windowTitle;
  }

  /**
   * @type {goog.events.EventHandler}
   * @private
   */
  this.eventHandler_ = new goog.events.EventHandler(this);

  /**
   * An array of all events that have been fired
   * @type {goog.structs.CircularBuffer}
   * @private
   */
  this.events_ = new goog.structs.CircularBuffer(1000);

  var eventsToListen = [
    talk.media.TalkPluginEvent.MESSAGE,
    talk.media.TalkPluginEvent.OUTGOING_MESSAGE,
    talk.media.CallManager.Event.INCOMING_JINGLE,
    talk.media.CallManager.Event.OUTGOING_JINGLE
  ];
  if (this.callManager_) {
    this.eventHandler_.listen(this.callManager_, eventsToListen,
        this.handleEvent_);
  }

  if (opt_events) {
    for (var i = 0; i < opt_events.length; i++) {
      this.events_.add([opt_events[i], new Date(0)])
    }
  }

  if (opt_openWindow) {
    this.openWindow();
  }
};


/**
 * Debug window
 * @type {Window}
 * @private
 */
talk.media.TalkPluginSpy.prototype.debugWindow_;

/**
 * The call dashboard
 * @type {talk.media.CallDashboard}
 * @private
 */
talk.media.TalkPluginSpy.prototype.callDashboard_;

/**
 * The multiway dashboard
 * @type {talk.media.MultiwayDashboard}
 * @private
 */
talk.media.TalkPluginSpy.prototype.multiwayDashboard_;

/**
 * The graph dashboard
 * @type {talk.media.GraphDashboard}
 * @private
 */
talk.media.TalkPluginSpy.prototype.graphDashboard_;

/**
 * The document for the debug window
 * @type {goog.dom.DomHelper}
 * @private
 */
talk.media.TalkPluginSpy.prototype.dom_;

/**
 * The split pane for the window
 * @type {goog.ui.SplitPane}
 * @private
 */
talk.media.TalkPluginSpy.prototype.splitpane_;

/**
 * The padding between the split pane and window.
 * @type {number}
 * @private
 */
talk.media.TalkPluginSpy.SPLIT_PANE_PADDING_ = 18;

/**
 * The thickness of the split pane handle.
 * @type {number}
 * @private
 */
talk.media.TalkPluginSpy.SPLIT_PANE_HANDLE_SIZE_ = 3;

/**
 * The height of the popup window.
 * @type {number}
 * @private
 */
talk.media.TalkPluginSpy.WINDOW_HEIGHT_ = 600;

/**
 * The width of the popup window.
 * @type {number}
 * @private
 */
talk.media.TalkPluginSpy.WINDOW_WIDTH_ = 1000;

/**
 * Shows the voice and video debug window.
 *
 * @return {boolean} Whether the window was successfully opened (or already
 *     open). If the pop-up was blocked then returns false.
 */
talk.media.TalkPluginSpy.prototype.openWindow = function() {
  if (this.debugWindow_ && !this.debugWindow_.closed) {
    this.debugWindow_.focus();
    return true;
  }

  this.debugWindow_ = window.open('', '', 'menubar=no,toolbar=no,' +
      'resizable=yes,height=600, width=1000, scrollbars=no');

  if (!this.debugWindow_) {
    // Pop-up was blocked.
    return false;
  }

  // Set the title and body content
  this.debugWindow_.document.title = this.windowTitle_;
  this.debugWindow_.document.body.innerHTML =
      talk.media.TalkPluginSpyTemplate();

  this.dom_ = goog.dom.getDomHelper(this.debugWindow_.document);
  this.eventHandler_.listen(this.dom_.getElement('wmodes'),
      goog.events.EventType.CLICK, this.onWmodesClick_);

  this.eventHandler_.listen(this.dom_.getElement('uploadlog'),
      goog.events.EventType.CLICK, this.onUploadLogClick_);

  // Set up the split pane
  this.splitpane_ = new goog.ui.SplitPane(
      new goog.ui.Component(this.dom_), new goog.ui.Component(this.dom_),
      goog.ui.SplitPane.Orientation.VERTICAL, this.dom_);

  var width = talk.media.TalkPluginSpy.WINDOW_WIDTH_ -
      talk.media.TalkPluginSpy.SPLIT_PANE_PADDING_;
  var height = talk.media.TalkPluginSpy.WINDOW_HEIGHT_ -
      talk.media.TalkPluginSpy.SPLIT_PANE_PADDING_;

  this.splitpane_.setInitialSize(height / 2);
  this.splitpane_.setHandleSize(
      talk.media.TalkPluginSpy.SPLIT_PANE_HANDLE_SIZE_);
  this.splitpane_.decorate(this.dom_.getElement('splitter'));
  this.splitpane_.setSize(new goog.math.Size(width, height));

  // Set up the resize event listener
  this.eventHandler_.listen(this.debugWindow_, goog.events.EventType.RESIZE,
                            this.resizePane_, false, this);

  // Render plugin events that have happened prior to the window opening
  for (var i = 0; i < this.events_.getCount(); i++) {
    var events = (/** @type {Array} */ this.events_.get(i));
    this.renderEvent_(events[0], events[1]);
  }

  return true;
};


/**
 * Changes the wmode to use when creating our communication player SWFs.
 * @param {goog.events.Event} e The event passed.
 * @private
 */
talk.media.TalkPluginSpy.prototype.onWmodesClick_ = function(e) {
  this.write_('Change Wmode', new Date(), e.target.id);
  talk.media.CommunicationPlayer.setWmode(e.target.id);
};


/**
 * Records diagnostic text inline with the spy tracing.
 *
 * @param {string} text The diagnostic text to record.
 */
talk.media.TalkPluginSpy.prototype.recordDiagnostic = function(text) {
  var e = new goog.events.Event('diag');  // Must not be taken by CallManager
  e.text = text;
  this.handleEvent_(e);
};


/**
 * Triggers an uploadlog operation to start.
 * @param {goog.events.Event} e The event passed.
 * @private
 */
talk.media.TalkPluginSpy.prototype.onUploadLogClick_ = function(e) {
  var plugin = this.callManager_.getTalkPlugin();
  this.callManager_.doUploadLog(plugin.getLocalJid(), 'chat.crash@google.com');
};


/**
 * Records the given event and renders it if the debug window is open.
 *
 * @param {goog.events.Event} e The event passed.
 * @private
 */
talk.media.TalkPluginSpy.prototype.handleEvent_ = function(e) {
  var now = new Date();
  this.events_.add([e, now]);
  if (this.debugWindow_ && this.debugWindow_.document) {
    this.renderEvent_(e, now);
  }
};

/**
 * Resizes the split pane on a window resize.
 *
 * @param {goog.events.Event} e The event.
 * @private
 */
talk.media.TalkPluginSpy.prototype.resizePane_ = function(e) {
  // Calculate and set the new dimensions of the split pane.
  var width = this.debugWindow_.document.body.clientWidth -
      talk.media.TalkPluginSpy.SPLIT_PANE_PADDING_;
  var height = this.debugWindow_.document.body.clientHeight -
      talk.media.TalkPluginSpy.SPLIT_PANE_PADDING_;
  var firstComponentHeight = this.splitpane_.getFirstComponentSize();

  // check if initial size is less than height
  if (firstComponentHeight > height) {
    var componentHeight = height - talk.media.TalkPluginSpy.SPLIT_PANE_PADDING_;

    if (componentHeight < 0) {
      componentHeight = 0;
    }

    this.splitpane_.setFirstComponentSize(componentHeight);
  }

  this.splitpane_.setSize(new goog.math.Size(width, height));
};

/**
 * Adds a string representation of an event to the debug window. Additionally,
 * this method updates the dashboards.
 *
 * @param {goog.events.Event} e The event.
 * @param {Date} time The time.
 * @private
 */
talk.media.TalkPluginSpy.prototype.renderEvent_ = function(e, time) {
  // Check if the message is an initiate and if it is from the active call

  if (e.msgType == 'jn') {
    this.dom_.getElement('log').innerHTML += '<hr>New Call<hr>';
  }
  if (e.msgType == 'jmistart' && (!this.callManager_ ||
      e.getParsedMsg()[2] == this.callManager_.getActiveCall().sessionId)) {
    if (this.callDashboard_) {
      this.callDashboard_.dispose();
      this.callDashboard_ = null;
      this.dom_.getElement('dashboard').innerHTML = '';
    }
    if (this.multiwayDashboard_) {
      this.multiwayDashboard_.dispose();
      this.multiwayDashboard_ = null;
      this.dom_.getElement('multiwaydashboard').innerHTML = '';
    }
    if (this.graphDashboard_) {
      this.graphDashboard_.dispose();
      this.graphDashboard_ = null;
      this.dom_.getElement('graphdashboard').innerHTML = '';
    }
  }
  if (!this.callDashboard_) {
    this.callDashboard_ = new talk.media.CallDashboard(this.dom_);
    this.callDashboard_.decorate(this.dom_.getElement('dashboard'));
  }
  if (!this.multiwayDashboard_) {
    this.multiwayDashboard_ = new talk.media.MultiwayDashboard(
        this.callManager_, this.dom_);
    this.multiwayDashboard_.decorate(this.dom_.getElement('multiwaydashboard'));
  }
  if (!this.graphDashboard_) {
    this.graphDashboard_ = new talk.media.GraphDashboard(this.dom_);
    this.graphDashboard_.decorate(this.dom_.getElement('graphdashboard'));
  }

  if (e.type == 'diag') {
    this.write_('Diag', time, e.text);
  } else if (e.type == talk.media.TalkPluginEvent.OUTGOING_MESSAGE) {
    this.write_('F-out', time, e.json);
    this.multiwayDashboard_.onFluteMessage(e);
  } else if (e.type == talk.media.CallManager.Event.OUTGOING_JINGLE) {
    this.write_('J-out', time, e.json);
  } else if (e.type == talk.media.CallManager.Event.INCOMING_JINGLE) {
    this.write_('J-in', time, e.json);
  } else {
    if (e.msgType == 'jai') {
      // Not printing "jai" because they come so frequently
    } else if (e.msgType == 'jmidata') {
      var mediaInfoStr = this.generateMediaInfo_(e);
      this.write_('Media info', time, mediaInfoStr);
      this.dom_.getElement('jmi').innerHTML = mediaInfoStr;
      this.callDashboard_.onJmiMessage(e.getParsedMsg());
      this.graphDashboard_.onJmiMessage(e.getParsedMsg());
    } else if (e.msgType == 'streamready') {
      this.write_('F-in', time, e.json);
      this.callDashboard_.onStreamReadyMessage(e.getParsedMsg());
    } else {
      this.write_('F-in', time, e.json);
    }
  }

  if (e.msgType == 'jt') {
    this.dom_.getElement('log').innerHTML += '<hr>End Call<hr>';
  }
};


/**
 * Pretty prints a jingle media info message.
 *
 * @param {goog.events.Event} e The event containing a media info message.
 * @return {string} A pretty printed string representing the 'jmidata'  message.
 * @private
 */
talk.media.TalkPluginSpy.prototype.generateMediaInfo_ = function(e) {
  return new talk.media.MediaInfoMessage(e.getParsedMsg()).toString();
};


/**
 * Writes a line of debug output to the debug window.
 * @param {string} type Type of message.
 * @param {Date} time Time for the message.
 * @param {string} body Body of the message.
 * @private
 */
talk.media.TalkPluginSpy.prototype.write_ = function(type, time, body) {
  // pinto doesn't include goog.date.DateTime, so we'll just format the time
  var timeStr = time.getHours() + ':' +
              goog.string.padNumber(time.getMinutes(), 2) + '.' +
              goog.string.padNumber(time.getSeconds(), 2)
  this.dom_.getElement('log').innerHTML += '<b>' + type + '</b>[' + timeStr +
      ']: ' + body + '<br>\n';
};


/**
 * Disposes the plugin spy.
 */
talk.media.TalkPluginSpy.prototype.dispose = function() {
  if (this.eventHandler_) {
    this.eventHandler_.dispose()
    this.eventHandler_ = null;
  }
  this.debugWindow_ = null;
  this.callManager_ = null;
  if (this.callDashboard_) {
    this.callDashboard_.dispose();
    this.callDashboard_ = null;
  }
  if (this.multiwayDashboard_) {
    this.multiwayDashboard_.dispose();
    this.multiwayDashboard_ = null;
  }
  if (this.graphDashboard_) {
    this.graphDashboard_.dispose();
    this.graphDashboard_ = null;
  }

  this.dom_ = null;
};
