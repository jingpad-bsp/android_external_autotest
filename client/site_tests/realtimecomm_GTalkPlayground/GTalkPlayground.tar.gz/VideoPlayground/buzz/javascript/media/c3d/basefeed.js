// Copyright 2009 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview Abstract base class for video feeds.
 *
 * @author tschmelcher@google.com (Tristan Schmelcher)
 */

goog.provide('talk.media.c3d.BaseFeed');

goog.require('goog.Disposable');
goog.require('goog.events.EventHandler');
goog.require('talk.media.c3d.Attrs');
goog.require('talk.media.c3d.SceneObject');
goog.require('talk.media.c3d.StreamEndpoint');
goog.require('talk.media.c3d.helpers');


/**
 * An abstract container for the UI elements of a video feed and associated
 * positioning logic.
 *
 * @param {talk.media.c3d.O3dBundle} o3dBundle The bundle of global resources
 * for this O3D instance.
 * @param {talk.media.c3d.StreamEndpoint} endpoint The StreamEndpoint that
 * provides the video/avatar for this feed.
 * @param {number} depth The depth at which to display this feed.
 * @extends {goog.Disposable}
 * @constructor
 */
talk.media.c3d.BaseFeed = function(o3dBundle, endpoint, depth) {
  goog.Disposable.call(this);

  /**
   * The bundle of global resources for this O3D instance.
   *
   * @type {talk.media.c3d.O3dBundle}
   * @protected
   */
  this.o3dBundle = o3dBundle;


  /**
   * The StreamEndpoint that provides the video/avatar for this feed.
   *
   * @type {talk.media.c3d.StreamEndpoint}
   * @private
   */
  this.endpoint_ = endpoint;


  /**
   * The position and size of the feed. Filled in by subclass.
   *
   * @type {talk.media.c3d.Attrs}
   * @private
   */
  this.attrs_ = new talk.media.c3d.Attrs(0, 0, depth, 0, 0, 1);


  /**
   * EventHandler to simplify installing/removing event listeners.
   *
   * @type goog.events.EventHandler
   * @private
   */
  this.eventHandler_ = new goog.events.EventHandler(this);

  this.eventHandler_.listen(this.endpoint_,
      talk.media.c3d.StreamEndpoint.Events.ASPECT_CHANGED,
      this.onEndpointChange_);
  this.eventHandler_.listen(this.endpoint_,
      talk.media.c3d.StreamEndpoint.Events.AVATAR,
      this.onEndpointChange_);
  this.eventHandler_.listen(this.endpoint_,
      talk.media.c3d.StreamEndpoint.Events.TEXTURE_ACTIVATED,
      this.onTextureActivated);

};
goog.inherits(talk.media.c3d.BaseFeed, goog.Disposable);


/**
 * The scene object for the feed rectangle.
 *
 * @type {talk.media.c3d.SceneObject}
 */
talk.media.c3d.BaseFeed.prototype.feedObject;


/**
 * Returns a copy of this feed's current spatial attributes.
 *
 * @return {talk.media.c3d.Attrs} The current spatial attributes
 * renders.
 */
talk.media.c3d.BaseFeed.prototype.getAttrs = function() {
  return new talk.media.c3d.Attrs(this.attrs_.x,
                                  this.attrs_.y,
                                  this.attrs_.z,
                                  this.attrs_.w,
                                  this.attrs_.h,
                                  this.attrs_.d);
};


/**
 * Returns the current spatial attributes of the underlying sceneobject.
 *
 * @return {talk.media.c3d.Attrs} If feedObject exists its current attributes,
 *     else null.
 */
talk.media.c3d.BaseFeed.prototype.getFeedAttrs = function() {
  if (!this.feedObject) {
    return null;
  } else {
    return this.feedObject.getAttrs();
  }
};


/**
 * Returns the StreamEndpoint that this feed renders.
 *
 * @return {talk.media.c3d.StreamEndpoint} The StreamEndpoint that this feed
 * renders.
 */
talk.media.c3d.BaseFeed.prototype.getEndpoint = function() {
  return this.endpoint_;
};


/**
 * Handles a notification from our StreamEndpoint that its aspect ratio has
 * changed or it has displayed avatar. Both trigger a reposition.
 *
 * @param {talk.media.c3d.StreamEndpoint.AspectChangedEvent |
 *         talk.media.c3d.StreamEndpoint.AvatarEvent} e The event.
 * @private
 */
talk.media.c3d.BaseFeed.prototype.onEndpointChange_ = function(e) {
  this.reposition();
};


/**
 * Handles the event for our StreamEndpoint's texture being activated.
 *
 * @param {talk.media.c3d.StreamEndpoint.TextureActivatedEvent} e The event.
 * @protected
 */
talk.media.c3d.BaseFeed.prototype.onTextureActivated = function(e) {
};


/**
 * Updates this feed's on-screen position (and size) and creates it if
 * necessary.
 *
 * @protected
 */
talk.media.c3d.BaseFeed.prototype.reposition = function() {
  if (!this.feedObject) {
    // Haven't created the feed yet.
    if (!this.endpoint_.isOn()) {
      // Not ready to display it yet.
      return;
    }
    // Otherwise we can create the feed now.
    this.feedObject = this.createFeedObject();
  }
  this.fillAttributes(this.attrs_, this.endpoint_.getAspect());
  this.updatePosition(this.attrs_);
};


/**
 * Does the actual updating of the feed's position. May be overidden by
 * subclasses.
 *
 * @param {talk.media.c3d.Attrs} attrs The new position.
 * @protected
 */
talk.media.c3d.BaseFeed.prototype.updatePosition = function(attrs) {
  this.feedObject.setAttrs(attrs);
};


/**
 * Creates a default SceneObject for this feed with initial brightness of zero.
 * May be overridden by subclasses if they want to use a fancier feed UI.
 *
 * @return {talk.media.c3d.SceneObject} Our representation of the C3D object.
 * @protected
 */
talk.media.c3d.BaseFeed.prototype.createFeedObject = function() {
  var c3d = this.o3dBundle.c3dObject.getPlugin();

  var myTransform = this.o3dBundle.pack['createObject']('Transform');
  var myShape = talk.media.c3d.createPlane(c3d,
                                           this.o3dBundle.pack,
                                           this.endpoint_.material,
                                           this.endpoint_.texCoordField);
  // Attach our quad to the scene graph.
  myTransform['parent'] = this.o3dBundle.view.transform;

  return new talk.media.c3d.SceneObject(myTransform, this.o3dBundle.pack,
      myShape);
};


/**
 * Fills in the position (x, y) and size (w, h) in the given attributes object
 * with the values to use for displaying this feed on screen.
 *
 * @param {talk.media.c3d.Attrs} attrs The object in which to store the
 * attributes.
 * @param {number} aspect The aspect ratio of the feed.
 * @protected
 */
talk.media.c3d.BaseFeed.prototype.fillAttributes = goog.abstractMethod;


/**
 * @override
 * @protected
 */
talk.media.c3d.BaseFeed.prototype.disposeInternal = function() {
  talk.media.c3d.BaseFeed.superClass_.disposeInternal.call(this);
  // Some browsers (Chrome) don't unload the plugin immediately, and since we
  // dispose the streams right away they're going to switch to the error
  // texture, so we fade the feeds to black so that the error texture is
  // hidden. This also makes the Hang Up button appear more responsive.
  // However, we can only do this if the scene is scriptable, which it might not
  // be during shutdown cases where the plugin was already removed from the DOM.
  if (this.feedObject && this.o3dBundle.c3dObject.isSceneScriptable()) {
    this.feedObject.setAlpha(0);
    this.feedObject.dispose();
  }
  this.feedObject = null;
};
