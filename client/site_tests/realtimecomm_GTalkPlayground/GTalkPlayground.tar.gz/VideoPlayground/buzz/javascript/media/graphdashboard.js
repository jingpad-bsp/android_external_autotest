// Copyright 2009 Google Inc. All Rights Reserved.

/**
 * @fileoverview Defines talk.media.GraphDashboard
 *
 * @author mikaeld@google.com (Mikael Drugge)
 */

goog.provide('talk.media.GraphDashboard');

goog.require('goog.string.StringBuffer');
goog.require('goog.ui.Component');
goog.require('goog.ui.ServerChart');
goog.require('talk.media.GraphDashboardTemplate');
goog.require('talk.media.MediaInfo');
goog.require('talk.Jid');

/**
 * A component that displays graphs for the active call.
 *
 * @param {goog.dom.DomHelper} opt_domHelper The document for the component.
 * @extends goog.ui.Component
 * @constructor
 */
talk.media.GraphDashboard = function(opt_domHelper) {
  goog.ui.Component.call(this, opt_domHelper);

  /**
   * The statistics about the call.
   * @type {talk.media.MediaInfo}
   * @private
   */
  this.mediaInfo_ = new talk.media.MediaInfo();

  /**
   * The audio receive bitrates reported.
   * @type {Array.<number>}
   * @private
   */
  this.audioRecvBitrates_ = [];

  /**
   * The video receive bitrates reported.
   * @type {Array.<number>}
   * @private
   */
  this.videoRecvBitrates_ = [];

  /**
   * The audio send bitrates reported.
   * @type {Array.<number>}
   * @private
   */
  this.audioSendBitrates_ = [];

  /**
   * The video send bitrates reported.
   * @type {Array.<number>}
   * @private
   */
  this.videoSendBitrates_ = [];

  /**
   * The audio jitters reported.
   * @type {Array.<number>}
   * @private
   */
  this.audioJitters_ = [];

  /**
   * The video jitters reported.
   * @type {Array.<number>}
   * @private
   */
  this.videoJitters_ = [];

  /**
   * The audio RTTs reported.
   * @type {Array.<number>}
   * @private
   */
  this.audioRtts_ = [];

  /**
   * The video RTTs reported.
   * @type {Array.<number>}
   * @private
   */
  this.videoRtts_ = [];

  /**
   * The audio packet loss reported.
   * @type {Array.<number>}
   * @private
   */
  this.audioPacketLosses_ = [];

  /**
   * The video packet loss reported.
   * @type {Array.<number>}
   * @private
   */
  this.videoPacketLosses_ = [];
};
goog.inherits(talk.media.GraphDashboard, goog.ui.Component);


/**
 * The number of data points to store for graphs.
 *
 * @type {number}
 * @private
 */
talk.media.GraphDashboard.MAX_GRAPH_POINTS_ = 30;


talk.media.GraphDashboard.Id = {
  GRAPH_INFO : 'gi',
  AUDIO_BITRATE_CHART : 'abc',
  VIDEO_BITRATE_CHART : 'vbc',
  PACKET_LOSS_CHART : 'plc',
  RTT_CHART : 'rc',
  JITTER_CHART : 'jc'
};


/**
 * @override
 */
talk.media.GraphDashboard.prototype.createDom = function() {
  this.decorateInternal(this.dom_.createElement('div'));
};


/**
 * @override
 */
talk.media.GraphDashboard.prototype.decorateInternal = function(element) {
  /**
   * element_ is defined in the Component superclass.
   */
  this.element_ = element;

  this.element_.innerHTML = talk.media.GraphDashboardTemplate(
      this.createTemplateContext_());
};


/**
 * Returns the context for rendering our call dashboard soy template
 *
 * @returns {Object} The template context
 * @private
 */
talk.media.GraphDashboard.prototype.createTemplateContext_ = function() {
  return {
    graphInfoId : this.makeId(talk.media.GraphDashboard.Id.GRAPH_INFO),
    audioBitrateChart :
        this.makeId(talk.media.GraphDashboard.Id.AUDIO_BITRATE_CHART),
    videoBitrateChart :
        this.makeId(talk.media.GraphDashboard.Id.VIDEO_BITRATE_CHART),
    packetLossChart :
        this.makeId(talk.media.GraphDashboard.Id.PACKET_LOSS_CHART),
    rttChart :
        this.makeId(talk.media.GraphDashboard.Id.RTT_CHART),
    jitterChart :
        this.makeId(talk.media.GraphDashboard.Id.JITTER_CHART)
  };
};


/**
 * Updates the various pieces of the dashboard based on the information
 * in the message.
 *
 * @param {Array} msg The jmidata message.
 */
talk.media.GraphDashboard.prototype.onJmiMessage = function(msg) {
  this.mediaInfo_.add(msg);
  this.updateGraphData_(this.mediaInfo_.getMostRecentDatapoint());
  this.updateGraphDashboard_();
};


/**
 * Updates the graph data points based on the current media info.
 *
 * @param {Object} datapoint The object containing graphable data.
 * @private
 */
talk.media.GraphDashboard.prototype.updateGraphData_ = function(datapoint) {
  this.audioRecvBitrates_.push(datapoint.audioRecvKbps);
  if (this.audioRecvBitrates_.length >
      talk.media.GraphDashboard.MAX_GRAPH_POINTS_) {
    this.audioRecvBitrates_.shift();
  }
  this.videoRecvBitrates_.push(datapoint.videoRecvKbps);
  if (this.videoRecvBitrates_.length >
      talk.media.GraphDashboard.MAX_GRAPH_POINTS_) {
    this.videoRecvBitrates_.shift();
  }
  this.audioSendBitrates_.push(datapoint.audioSendKbps);
  if (this.audioSendBitrates_.length >
      talk.media.GraphDashboard.MAX_GRAPH_POINTS_) {
    this.audioSendBitrates_.shift();
  }
  this.videoSendBitrates_.push(datapoint.videoSendKbps);
  if (this.videoSendBitrates_.length >
      talk.media.GraphDashboard.MAX_GRAPH_POINTS_) {
    this.videoSendBitrates_.shift();
  }
  this.audioJitters_.push(datapoint.audioJitter);
  if (this.audioJitters_.length > talk.media.GraphDashboard.MAX_GRAPH_POINTS_) {
    this.audioJitters_.shift();
  }
  this.videoJitters_.push(datapoint.videoJitter);
  if (this.videoJitters_.length > talk.media.GraphDashboard.MAX_GRAPH_POINTS_) {
    this.videoJitters_.shift();
  }
  this.audioRtts_.push(datapoint.audioRtt);
  if (this.audioRtts_.length > talk.media.GraphDashboard.MAX_GRAPH_POINTS_) {
    this.audioRtts_.shift();
  }
  this.videoRtts_.push(datapoint.videoRtt);
  if (this.videoRtts_.length > talk.media.GraphDashboard.MAX_GRAPH_POINTS_) {
    this.videoRtts_.shift();
  }
  this.audioPacketLosses_.push(datapoint.audioPacketLoss);
  if (this.audioPacketLosses_.length >
      talk.media.GraphDashboard.MAX_GRAPH_POINTS_) {
    this.audioPacketLosses_.shift();
  }
  this.videoPacketLosses_.push(datapoint.videoPacketLoss);
  if (this.videoPacketLosses_.length >
      talk.media.GraphDashboard.MAX_GRAPH_POINTS_) {
    this.videoPacketLosses_.shift();
  }
}


/**
 * Updates the graphs displaying media info of the call.
 *
 * @private
 */
talk.media.GraphDashboard.prototype.updateGraphDashboard_ = function() {
  var chartWidth = 180;
  var chartHeight = 164;

  // Bitrate graph for audio.
  var audioBitrateChart = new goog.ui.ServerChart(
      goog.ui.ServerChart.ChartType.LINE, chartWidth, chartHeight);
  audioBitrateChart.setTitle('Audio bitrate (kbps)');
  audioBitrateChart.addDataSet(this.audioRecvBitrates_, '0000ff');
  audioBitrateChart.addDataSet(this.audioSendBitrates_, 'ccccff');
  audioBitrateChart.setMinValue(0);
  audioBitrateChart.setMaxValue(100);
  audioBitrateChart.setLeftLabels([0,20,40,60,80,100]);
  audioBitrateChart.setGridParameter('0,20,1,4');
  audioBitrateChart.decorate(this.getElementByFragment(
      talk.media.GraphDashboard.Id.AUDIO_BITRATE_CHART));

  // Bitrate graph for video.
  var videoBitrateChart = new goog.ui.ServerChart(
      goog.ui.ServerChart.ChartType.LINE, chartWidth, chartHeight);
  videoBitrateChart.setTitle('Video bitrate (kbps)');
  videoBitrateChart.addDataSet(this.videoRecvBitrates_, '007700');
  videoBitrateChart.addDataSet(this.videoSendBitrates_, '99ff99');
  videoBitrateChart.setMinValue(0);
  videoBitrateChart.setMaxValue(2000);
  videoBitrateChart.setLeftLabels([0,500,1000,1500,2000]);
  videoBitrateChart.setGridParameter('0,12.5,1,4');
  videoBitrateChart.decorate(this.getElementByFragment(
      talk.media.GraphDashboard.Id.VIDEO_BITRATE_CHART));

  // Packet loss.
  var packetLossChart = new goog.ui.ServerChart(
      goog.ui.ServerChart.ChartType.LINE, chartWidth, chartHeight);
  packetLossChart.setTitle('Packet loss (%)');
  packetLossChart.addDataSet(this.audioPacketLosses_, '0000ff');
  packetLossChart.addDataSet(this.videoPacketLosses_, '007700');
  packetLossChart.setMinValue(0);
  packetLossChart.setMaxValue(50);
  packetLossChart.setLeftLabels([0,10,20,30,40,50]);
  packetLossChart.setGridParameter('0,20,1,4');
  packetLossChart.decorate(this.getElementByFragment(
      talk.media.GraphDashboard.Id.PACKET_LOSS_CHART));

  // RTT graph.
  var rttChart = new goog.ui.ServerChart(
      goog.ui.ServerChart.ChartType.LINE, chartWidth, chartHeight);
  rttChart.setTitle('RTT (ms)');
  rttChart.addDataSet(this.audioRtts_, '0000ff');
  rttChart.addDataSet(this.videoRtts_, '007700');
  rttChart.setMinValue(0);
  rttChart.setMaxValue(500);
  rttChart.setLeftLabels([0,100,200,300,400,500]);
  rttChart.setGridParameter('0,20,1,4');
  rttChart.decorate(this.getElementByFragment(
      talk.media.GraphDashboard.Id.RTT_CHART));

  // Jitter graph, also including a legend applicable to the other graphs.
  var jitterChart = new goog.ui.ServerChart(goog.ui.ServerChart.ChartType.LINE,
      Math.round(chartWidth * 1.3), chartHeight);
  jitterChart.setTitle('Jitter');
  jitterChart.addDataSet(this.audioJitters_, '0000ff');
  jitterChart.addDataSet(this.videoJitters_, '007700');
  jitterChart.setMinValue(0);
  jitterChart.setMaxValue(1);
  jitterChart.setLeftLabels(['0.0','0.5','1.0']);
  jitterChart.setGridParameter('0,50,1,4');
  jitterChart.setLegend(['Audio', 'Video']);
  jitterChart.decorate(this.getElementByFragment(
      talk.media.GraphDashboard.Id.JITTER_CHART));
}
