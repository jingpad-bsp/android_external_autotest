// Copyright 2008 Google Inc. All Rights Reserved.

/**
 * @fileoverview Defines talk.media.CallDashboard
 *
 * @author jessan@google.com (Jessan Hutchison-Quillian)
 */

goog.provide('talk.media.CallDashboard');

goog.require('goog.ui.Component');
goog.require('talk.media.CallDashboardTemplate');
goog.require('talk.media.ConnectionInfoTemplate');
goog.require('talk.media.MediaInfo');
goog.require('talk.media.PacketLossTemplate');

/**
 * A component that displays technical information about a currently call.
 *
 * @param {goog.dom.DomHelper} opt_domHelper The document for the component.
 * @extends goog.ui.Component
 * @constructor
 */
talk.media.CallDashboard = function(opt_domHelper) {
  goog.ui.Component.call(this, opt_domHelper);

  /**
   * The statistics about the call.
   * @type {talk.media.MediaInfo}
   * @private
   */
  this.mediaInfo_ = new talk.media.MediaInfo();
};
goog.inherits(talk.media.CallDashboard, goog.ui.Component);


talk.media.CallDashboard.Id = {
  CALL_TIME : 'ct',
  PACKET_LOSS : 'pl',
  CONNECTION_INFO : 'ci',
  RENDERER_TYPE : 'rt',
  LOCAL_RESOLUTION : 'lr',
  REMOTE_RESOLUTION : 'rr'
};


/**
 * @override
 */
talk.media.CallDashboard.prototype.createDom = function() {
  this.decorateInternal(this.dom_.createElement('div'));
};


/**
 * @override
 */
talk.media.CallDashboard.prototype.decorateInternal = function(element) {
  /**
   * element_ is defined in the Component superclass.
   */
  this.element_ = element;

  this.element_.innerHTML = talk.media.CallDashboardTemplate(
      this.createTemplateContext_());
};


/**
 * Returns the context for rendering our call dashboard soy template
 *
 * @returns {Object} The template context
 * @private
 */
talk.media.CallDashboard.prototype.createTemplateContext_ = function() {
  return {
    callTimeId : this.makeId(talk.media.CallDashboard.Id.CALL_TIME),
    packetLossId : this.makeId(talk.media.CallDashboard.Id.PACKET_LOSS),
    connectionInfoId : this.makeId(talk.media.CallDashboard.Id.CONNECTION_INFO),
    rendererTypeId : this.makeId(talk.media.CallDashboard.Id.RENDERER_TYPE),
    localResId : this.makeId(talk.media.CallDashboard.Id.LOCAL_RESOLUTION),
    remoteResId : this.makeId(talk.media.CallDashboard.Id.REMOTE_RESOLUTION)
  };
};


/**
 * Updates the various pieces of the dashboard based on the information
 * in the message.
 *
 * @param {Array} msg The jmidata message.
 */
talk.media.CallDashboard.prototype.onJmiMessage = function(msg) {
  this.mediaInfo_.add(msg);

  this.getElementByFragment(talk.media.CallDashboard.Id.CALL_TIME
      ).innerHTML = msg[3];

  var packetLoss = talk.media.PacketLossTemplate({
        audio: this.mediaInfo_.getAudioStats(),
        video: this.mediaInfo_.getVideoStats()
      });
  this.getElementByFragment(talk.media.CallDashboard.Id.PACKET_LOSS
      ).innerHTML = packetLoss;

  var connectionInfo =
      talk.media.ConnectionInfoTemplate(this.mediaInfo_.getCandidates());
  this.getElementByFragment(talk.media.CallDashboard.Id.CONNECTION_INFO
      ).innerHTML = connectionInfo;
};


/**
 * Updates the resolution based on the information in the message.
 *
 * @param {Array} msg The streamready message.
 */
talk.media.CallDashboard.prototype.onStreamReadyMessage = function(msg) {
  if (msg.length > 7) {
    this.getElementByFragment(talk.media.CallDashboard.Id.RENDERER_TYPE
        ).innerHTML = 'O3D';
    var width = msg[6];
    var height = msg[7];
    // Old versions of the streamready format didn't have these. They specify
    // the actual resolution that was written to the texture, rather than the
    // resolution of the source, which in some cases can differ (but should
    // always eventually end up the same, unless there is some sort of error
    // such as insufficient video RAM).
    var opt_renderedWidth = msg[8];
    var opt_renderedHeight = msg[9];
    var context = {width: opt_renderedWidth || width,
                   height: opt_renderedHeight || height};
    if (goog.isDefAndNotNull(msg[5])) {
      context['endpoint'] = "remote";
      this.getElementByFragment(talk.media.CallDashboard.Id.REMOTE_RESOLUTION
          ).innerHTML = talk.media.ResolutionTemplate(context);
    } else {
      context['endpoint'] = "local";
      this.getElementByFragment(talk.media.CallDashboard.Id.LOCAL_RESOLUTION
          ).innerHTML = talk.media.ResolutionTemplate(context);
    }
  } else {
    this.getElementByFragment(talk.media.CallDashboard.Id.RENDERER_TYPE
        ).innerHTML = 'Flash';
  }
};
