// Copyright 2009 Google Inc.  All Rights Reserved.

/**
 * @fileoverview Definition of the CallRatings class.
 *
 * @author rln@google.com (Rolf Larsson)
 */

goog.provide('talk.media.CallRating');
goog.provide('talk.media.CallRating.EventType');
goog.provide('talk.media.CallRating.SubmitEvent')

goog.require('goog.debug.Logger');
goog.require('goog.events.Event');
goog.require('goog.events.EventHandler');
goog.require('goog.json');
goog.require('goog.ui.Component');
goog.require('goog.ui.Ratings');
goog.require('talk.media.callRatingTemplate');


/**
 * Handles CallRating events.
 *
 * @param {goog.dom.DomHelper} opt_domHelper The DOM helper object of the app
 *     context where the ratings will be rendered.
 * @constructor
 * @extends {goog.ui.Component}
 */
talk.media.CallRating = function(opt_domHelper) {
  goog.ui.Component.call(this, opt_domHelper);

  /**
   * @type {goog.events.EventHandler} Event handler to manage listeners.
   * @private
   */
  this.eventHandler_ = new goog.events.EventHandler(this);
};
goog.inherits(talk.media.CallRating, goog.ui.Component);


/**
 * The DOM element containing the ratings widget.
 * @type {Element}
 * @private
 */
talk.media.CallRating.prototype.ratingElement_;


/**
 * The unique call identifier.
 * @type {string}
 * @private
 */
talk.media.CallRating.prototype.sessionId_;


/**
 * The JID of the other end of the call.
 * @type {string}
 * @private
 */
talk.media.CallRating.prototype.chatJid_;


/**
 * The Rating UI handler.
 * @type {goog.ui.Ratings}
 * @private
 */
talk.media.CallRating.prototype.ratingUiHandler_;


/**
 * Enums for CallRating event type.
 * @enum {string}
 */
talk.media.CallRating.EventType = {
  SUBMIT: 'ratingsubmit'
};


/**
 * The Event dispatched when ratings are done.
 *
 * @param {string} chatJid The JID of the other end of the call.
 * @param {string} json The JSON message representing a ratings submission.
 * @constructor
 * @extends {goog.events.Event}
 */
talk.media.CallRating.SubmitEvent = function(chatJid, json) {
  goog.events.Event.call(this, talk.media.CallRating.EventType.SUBMIT);

  /**
   * The JID of the other end of the call.
   *
   * @type {string}
   */
  this.chatJid = chatJid;

  /**
   * The JSON message representing a ratings submission.
   *
   * @type {string}
   */
  this.json = json;
};
goog.inherits(talk.media.CallRating.SubmitEvent, goog.events.Event);


/**
 * The highest rating that is considered a low rating from users.
 *
 * @type {number}
 */
talk.media.CallRating.RATED_LOW = 2;


/**
 * Format of JSON message sent to server.
 *
 * @enum {number}
 */
talk.media.CallRating.JsonFormat = {
  IDENTIFIER: 0,
  SENDER_JID: 1,
  SESSION_ID: 2,
  RATING: 3,
  INCIDENT_ID: 4,
  UPLOAD_LOG_RESULT: 5,
  SURVEY_DATA_ELEMENTS: 6
};


/**
 * Logger.
 * @type {goog.debug.Logger}
 * @private
 */
talk.media.CallRating.prototype.logger_ =
    goog.debug.Logger.getLogger('talk.media.CallRating');


/**
 * Returns the rating container template.
 *
 * @param {string} id The Id of the rating container.
 * @return {string} The HTML element template.
 */
talk.media.CallRating.getRatingTemplate = function(id) {
  return talk.media.callRatingTemplate({id: id});
};


/**
 * Returns the rating 'thank you' template.
 * TODO(rln): Fix camelCaps here & in soy files.
 *
 * @return {string} The HTML element template.
 */
talk.media.CallRating.getRatingThankyouTemplate = function() {
  return talk.media.callRatingThankyouTemplate();
};


/**
 * Creates rating UI handler and hooks it up to the rating container.
 * Sets up an event handler waiting for user input.
 *
 * @param {string} containerId The identifier of the container to decorate.
 * @param {string} sessionId A unique call identifier.
 * @param {string} chatJid The JID of the other end of the call.
 */
talk.media.CallRating.prototype.addRatingListener = function(
    containerId, sessionId, chatJid) {
  var containerElement = this.getDomHelper().getElement(containerId);

  // Protect ourselves in case the chat is closed before we decorate.
  if (containerElement) {
    var ratingUiHandler = new goog.ui.Ratings();
    this.setUiHandler_(ratingUiHandler);

    // setRatingUiHandler should've cleaned up any previous visual elements,
    // so it's OK to just set these without checking for prior content.
    this.ratingElement_ = containerElement;
    this.sessionId_ = sessionId;
    this.chatJid_ = chatJid;

    ratingUiHandler.decorate(containerElement);

    // goog.ui.Ratings.decorate() sets the selected index to 0, causing star 1
    // to light up - resetting it to -1 to avoid this.
    ratingUiHandler.setSelectedIndex(-1);

    this.eventHandler_.listenOnce(ratingUiHandler,
        goog.ui.Ratings.EventType.CHANGE, this.onSetRating_);
  } else {
    this.logger_.warning('Did not find element ' + containerId +
        ' in document.');
  }
};


/**
 * Stores the rating UI handler associated with a specific rating container.
 *
 * @param {goog.ui.Ratings} uiHandler The rating UI handler.
 * @private
 */
talk.media.CallRating.prototype.setUiHandler_ = function(uiHandler) {
  // There can be only one active rating UI handler.
  if (this.ratingUiHandler_) {
    this.removeUiHandler_();
    // Also remove the rating container element of any previously unfinished
    // rating attempt to avoid confusion.
    this.removeRatingElement_();
  }
  this.ratingUiHandler_ = uiHandler;
};


/**
 * Removes the active rating UI handler.
 *
 * @private
 */
talk.media.CallRating.prototype.removeUiHandler_ = function() {
  this.ratingUiHandler_.dispose();
  this.ratingUiHandler_ = null;
};


/**
 * Removes any existing rating container element nodes to avoid confusion.
 *
 * @private
 */
talk.media.CallRating.prototype.removeRatingElement_ = function() {
  if (this.ratingElement_) {
    this.getDomHelper().removeNode(this.ratingElement_);
  }
  this.ratingElement_ = null;
};


/**
 * Handles ratings getting submitted by user.
 *
 * @param {goog.events.Event} e The event.
 * @private
 */
talk.media.CallRating.prototype.onSetRating_ = function(e) {
  var rating = this.ratingUiHandler_.getSelectedIndex() + 1;
  if (rating > 0) {
    var json = goog.json.serialize([
        'callsurvey',
        this.chatJid_,
        this.sessionId_,
        rating,
        '',
        '',
        {}
    ]);
    this.dispatchEvent(new talk.media.CallRating.SubmitEvent(
        this.chatJid_, json));
  }

  // Remove the UI handler, but leave rating on screen until mole is closed.
  this.removeUiHandler_();
};
