// Copyright 2009 Google Inc. All Rights Reserved.

/**
 * @fileoverview Defines talk.media.MultiwayDashboard
 *
 * @author mikaeld@google.com (Mikael Drugge)
 */

goog.provide('talk.media.MultiwayDashboard');

goog.require('goog.string.StringBuffer');
goog.require('goog.structs.Map');
goog.require('goog.structs.Set');
goog.require('goog.ui.Component');
goog.require('talk.media.MediaInfo');
goog.require('talk.media.MultiwayDashboardTemplate');
goog.require('talk.media.MultiwayHistoryTemplate');
goog.require('talk.media.MultiwayMappingContentTemplate');
goog.require('talk.media.MultiwayMappingFooterTemplate');
goog.require('talk.media.MultiwayMappingHeaderTemplate');
goog.require('talk.media.MultiwayStatsInfoTemplate');
goog.require('talk.Jid');

/**
 * A component that displays technical information about a currently call.
 *
 * @param {talk.media.CallManager|undefined} callManager The call manager.
 * @param {goog.dom.DomHelper} opt_domHelper The document for the component.
 * @extends goog.ui.Component
 * @constructor
 */
talk.media.MultiwayDashboard = function(callManager, opt_domHelper) {
  goog.ui.Component.call(this, opt_domHelper);

  /**
   * The statistics about the call.
   * @type {talk.media.MediaInfo}
   * @private
   */
  this.mediaInfo_ = new talk.media.MediaInfo();

  /**
   * The call manager.
   * @type {talk.media.CallManager|undefined}
   * @private
   */
  this.callManager_ = callManager;

  /**
   * The information about audio SSRCs in an N:N call.
   * @type {Object}
   * @private
   */
  this.audioSsrcInfo_ = {};

  /**
   * The information about video SSRCs in an N:N call.
   * @type {Object}
   * @private
   */
  this.videoSsrcInfo_ = {};

  /**
   * The set of all remote jids seen in the call.
   * @type {goog.structs.Set}
   * @private
   */
  this.remoteJids_ = new goog.structs.Set();

  /**
   * The set of all session IDs seen in the call.
   * @type {goog.structs.Set}
   * @private
   */
  this.sessionIds_ = new goog.structs.Set();

  /**
   * The set of all audio SSRCs seen added in an N:N call.
   * @type {goog.structs.Set}
   * @private
   */
  this.audioSsrcsAdded_ = new goog.structs.Set();

  /**
   * The set of all video SSRCs seen added in an N:N call.
   * @type {goog.structs.Set}
   * @private
   */
  this.videoSsrcsAdded_ = new goog.structs.Set();

  /**
   * The set of all audio SSRCs seen removed in an N:N call.
   * @type {goog.structs.Set}
   * @private
   */
  this.audioSsrcsRemoved_ = new goog.structs.Set();

  /**
   * The set of all video SSRCs seen removed in an N:N call.
   * @type {goog.structs.Set}
   * @private
   */
  this.videoSsrcsRemoved_ = new goog.structs.Set();

  /**
   * Local audio SSRC used by the Flute.
   * @type {string}
   * @private
   */
  this.localAudioSsrc_;

  /**
   * Local video SSRC used by the Flute.
   * @type {string}
   * @private
   */
  this.localVideoSsrc_;

  /**
   * Local audio codec used by the Flute.
   * @type {string}
   * @private
   */
  this.localAudioCodec_;

  /**
   * Local video codec used by the Flute.
   * @type {string}
   * @private
   */
  this.localVideoCodec_;

  /**
   * Video bandwidth limit in N:N calls.
   * @type {number}
   * @private
   */
  this.videoBandwidthLimit_;
};
goog.inherits(talk.media.MultiwayDashboard, goog.ui.Component);


talk.media.MultiwayDashboard.Id = {
  MULTIWAY_INFO : 'mi'
};


/**
 * @override
 */
talk.media.MultiwayDashboard.prototype.createDom = function() {
  this.decorateInternal(this.dom_.createElement('div'));
};


/**
 * @override
 */
talk.media.MultiwayDashboard.prototype.decorateInternal = function(element) {
  /**
   * element_ is defined in the Component superclass.
   */
  this.element_ = element;

  this.element_.innerHTML = talk.media.MultiwayDashboardTemplate(
      this.createTemplateContext_());
};


/**
 * Returns the context for rendering our call dashboard soy template
 *
 * @returns {Object} The template context
 * @private
 */
talk.media.MultiwayDashboard.prototype.createTemplateContext_ = function() {
  return {
    multiwayInfoId : this.makeId(talk.media.MultiwayDashboard.Id.MULTIWAY_INFO)
  };
};


/**
 * Updates the various pieces of the dashboard based on the information
 * in the message that was sent to the Flute.
 *
 * @param {goog.events.Event} e The event sent to the Flute.
 */
talk.media.MultiwayDashboard.prototype.onFluteMessage = function(e) {
  this.extractCallInfo_(e.getParsedMsg());
  this.extractSsrcInfo_(e.getParsedMsg());
  this.updateMultiwayDashboard_();
};


/**
 * Extracts and keeps track of call information from Flute messages.
 *
 * @param {Array} json The parsed message sent to the Flute.
 * @private
 */
talk.media.MultiwayDashboard.prototype.extractCallInfo_ = function(json) {
  if (!json) {
    return;
  }

  switch (json[0]) {
    // TODO(mikaeld): We should keep all possible messages in a map instead,
    // so that when e.g. adding a new message we won't need to update this piece
    // of code to be in sync.
    case 'ja':
    case 'jc':
    case 'jn':
    case 'jt':
    case 'jsa':
    case 'jsr':
    case 'jtr':
    case 'jrtp':
    case 'jshow':
    case 'streamon':
    case 'streamoff':
      if (json[1]) {
        this.remoteJids_.add(json[1]);
      }
      if (json[2]) {
        this.sessionIds_.add(json[2]);
      }
      break;
  }

  if (json[0] == 'jrtp') {
    var audioCodecs = json[3];
    var videoCodecs = json[4];
    if (audioCodecs && audioCodecs[0]) {
      this.localAudioCodec_ = audioCodecs[0];
    }
    if (videoCodecs && videoCodecs[0]) {
      this.localVideoCodec_ = videoCodecs[0];
    }
    var audioSsrc = json[5];
    var videoSsrc = json[6];
    if (audioSsrc && audioSsrc['s']) {
      this.localAudioSsrc_ = audioSsrc['s'];
    }
    if (videoSsrc && videoSsrc['s']) {
      this.localVideoSsrc_ = videoSsrc['s'];
    }
  } else if (json[0] == 'jshow') {
    var params = json[3];
    if (params && params['maxBandwidth']) {
      this.videoBandwidthLimit_ =
          Math.round(params['maxBandwidth'] / 1024);
    }
  }
}


/**
 * Extracts and keeps track of SSRC information from Flute messages.
 *
 * @param {Array} json The parsed message sent to the Flute.
 * @private
 */
talk.media.MultiwayDashboard.prototype.extractSsrcInfo_ = function(json) {
  if (!json) {
    return;
  }

  // Extract SSRCs from message.
  var audioSsrc;
  var videoSsrc;
  switch (json[0]) {
    case 'jsa':
    case 'jsr':
      audioSsrc = json[3];
      videoSsrc = json[4];

      // Ignore SSRC zero.
      if (audioSsrc == '0') {
        audioSsrc = null;
      }
      if (videoSsrc == '0') {
        videoSsrc = null;
      }

      // Keep track of the jsa/jsr actions associated with every SSRC.
      if (audioSsrc) {
        if (json[0] == 'jsa') {
          this.audioSsrcsAdded_.add(audioSsrc);
          this.audioSsrcsRemoved_.remove(audioSsrc);
        } else if (json[0] == 'jsr') {
          this.audioSsrcsRemoved_.add(audioSsrc);
          this.audioSsrcsAdded_.remove(audioSsrc);
        }
      }
      if (videoSsrc) {
        if (json[0] == 'jsa') {
          this.videoSsrcsAdded_.add(videoSsrc);
          this.videoSsrcsRemoved_.remove(videoSsrc);
        } else if (json[0] == 'jsr') {
          this.videoSsrcsRemoved_.add(videoSsrc);
          this.videoSsrcsAdded_.remove(videoSsrc);
        }
      }
      break;
    case 'streamon':
      videoSsrc = json[4];
      break;
    case 'streamoff':
      videoSsrc = json[3];
      break;
  }

  // Count the number of actions taken on the SSRCs.
  if (audioSsrc) {
    if (!this.audioSsrcInfo_[audioSsrc]) {
      this.audioSsrcInfo_[audioSsrc] = this.createEmptySsrcActions_();
    }
    this.audioSsrcInfo_[audioSsrc][json[0]]++;
  }
  if (videoSsrc) {
    if (!this.videoSsrcInfo_[videoSsrc]) {
      this.videoSsrcInfo_[videoSsrc] = this.createEmptySsrcActions_();
    }
    this.videoSsrcInfo_[videoSsrc][json[0]]++;
  }
}


/**
 * Updates the multiway information on the dashboard.
 *
 * @private
 */
talk.media.MultiwayDashboard.prototype.updateMultiwayDashboard_ = function() {
  if (!this.callManager_) {
    return;
  }
  var call = this.callManager_.getActiveCall();
  if (!call || !call.isMultiway()) {
    return;
  }

  var localTime = new Date();
  var mappings = this.getMultiwayMappings_(call);
  var sb = new goog.string.StringBuffer();

  sb.append('<h4>N:N call state</h4>');

  sb.append(talk.media.MultiwayStatsInfoTemplate({
      localTime: localTime,
      numberOfUsers: (mappings ? mappings.length : 'n/a'),
      numberOfAudioSenders: call.getNumberOfAudioSenders(),
      numberOfVideoSenders: call.getNumberOfVideoSenders(),
      localAudioSsrc: this.localAudioSsrc_,
      localVideoSsrc: this.localVideoSsrc_,
      localAudioCodec: this.localAudioCodec_,
      localVideoCodec: this.localVideoCodec_,
      videoBandwidthLimit: this.videoBandwidthLimit_}));

  if (mappings) {
    sb.append(talk.media.MultiwayMappingHeaderTemplate());
    for (var i = 0; i < mappings.length; i++) {
      sb.append(talk.media.MultiwayMappingContentTemplate(mappings[i]));
    }
    sb.append(talk.media.MultiwayMappingFooterTemplate());
  }

  sb.append(talk.media.MultiwayHistoryTemplate({
      allRemoteJids: this.remoteJids_.getValues().join(', '),
      allSessionIds: this.sessionIds_.getValues().join(', '),
      allAudioSsrcsAdded:
          this.audioSsrcsAdded_.getValues().sort().join(', '),
      allVideoSsrcsAdded:
          this.videoSsrcsAdded_.getValues().sort().join(', '),
      allAudioSsrcsRemoved:
          this.audioSsrcsRemoved_.getValues().sort().join(', '),
      allVideoSsrcsRemoved:
          this.videoSsrcsRemoved_.getValues().sort().join(', '),
      allRemoteJidsCount: this.remoteJids_.getValues().length,
      allSessionIdsCount: this.sessionIds_.getValues().length,
      allAudioSsrcsAddedCount:
          this.audioSsrcsAdded_.getValues().length,
      allVideoSsrcsAddedCount:
          this.videoSsrcsAdded_.getValues().length,
      allAudioSsrcsRemovedCount:
          this.audioSsrcsRemoved_.getValues().length,
      allVideoSsrcsRemovedCount:
          this.videoSsrcsRemoved_.getValues().length}));

  this.getElementByFragment(talk.media.MultiwayDashboard.Id.MULTIWAY_INFO).
      innerHTML = sb.toString();
};


/**
 * Returns information about the SSRC mappings for an N:N call.
 *
 * @param {talk.media.CallManager.Call} call The call.
 * @return {Array.<string>|null} HTML formatted rows with mapping information.
 * @private
 */
talk.media.MultiwayDashboard.prototype.getMultiwayMappings_ = function(call) {
  if (!call || !call.isMultiway()) {
    return null;
  }

  var rows = [];
  var jids = call.ssrcMap.getKeys();
  jids.sort();

  for (var i = 0; i < jids.length; i++) {
    var mapEntry = call.ssrcMap.get(jids[i]);

    // Create object containing information about user and SSRCs.
    var row = {};
    row.jid = talk.Jid.barePart(jids[i]);
    row.resource = talk.Jid.resource(jids[i]);
    row.audioSsrc = mapEntry.audioSsrc;
    row.audioSsrcActions = this.audioSsrcInfo_[mapEntry.audioSsrc] ?
        this.audioSsrcInfo_[mapEntry.audioSsrc] :
        this.createEmptySsrcActions_();
    row.videoSsrc = mapEntry.videoSsrc;
    row.videoSsrcActions = this.videoSsrcInfo_[mapEntry.videoSsrc] ?
        this.videoSsrcInfo_[mapEntry.videoSsrc] :
        this.createEmptySsrcActions_();

    // Do basic sanity checking and notify about potential issues.
    var sb = new goog.string.StringBuffer();
    if (!row.resource) {
      sb.append('Jid resource missing, ');
    }
    if (mapEntry.videoSsrc && !mapEntry.audioSsrc) {
      sb.append('Video without audio, ');
    }
    if (this.audioSsrcInfo_[mapEntry.audioSsrc]) {
      if (this.audioSsrcInfo_[mapEntry.audioSsrc].jsa > 1) {
        sb.append('Audio added more than once, ');
      }
      if (this.audioSsrcInfo_[mapEntry.audioSsrc].jsr >
          this.audioSsrcInfo_[mapEntry.audioSsrc].jsa) {
        sb.append('Audio jsr>jsa, ');
      }
    }
    if (this.videoSsrcInfo_[mapEntry.videoSsrc]) {
      if (this.videoSsrcInfo_[mapEntry.videoSsrc].jsa > 1) {
        sb.append('Video added more than once, ');
      }
      if (this.videoSsrcInfo_[mapEntry.videoSsrc].jsr >
          this.videoSsrcInfo_[mapEntry.videoSsrc].jsa) {
        sb.append('Video jsr>jsa, ');
      }
      if (this.videoSsrcInfo_[mapEntry.videoSsrc].jsa == 0 &&
          this.videoSsrcInfo_[mapEntry.videoSsrc].streamon > 0) {
        sb.append('Video streamon without jsa, ');
      }
    }
    row.notes = sb.toString();

    rows.push(row);
  }

  return rows;
}


/**
 * Creates an empty SSRC action object, used for counting actions associated
 * with an SSRC.
 *
 * @private
 */
talk.media.MultiwayDashboard.prototype.createEmptySsrcActions_ = function() {
  return {
    jsa: 0,
    jsr: 0,
    streamon: 0,
    streamoff: 0
  };
};
