// Copyright 2008 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview Handles communication with the Google Talk Plugin daemon.
 *
 * @author jessan@google.com (Jessan Hutchison-Quillian)
 */

goog.provide('talk.media.TalkPluginChannel');
goog.provide('talk.media.TalkPluginChannel.ImpressionEvent');

goog.require('goog.Timer');
goog.require('goog.debug.Logger');
goog.require('goog.dom');
goog.require('goog.events.EventTarget');
goog.require('goog.json');
goog.require('goog.object');
goog.require('goog.userAgent');
goog.require('talk.media.CallEvent');
goog.require('talk.media.RendererDetector');
goog.require('talk.media.TalkPluginEvent');

/**
 * Creates a channel to communicate with the Google Talk plugin using a browser
 * plugin. Note that the communication method may be overridden by subclasses.
 *
 * @param {string} bareJid Our user's bare JID.
 * @param {talk.media.RendererDetector} rendererDetector Our rendering
 *     capabilities.
 * @param {goog.dom.DomHelper} opt_domHelper A handle on the DOM.
 * @param {Object} opt_mfInfo Additional information to pass down to the Google
 * Talk Plugin in the 'mf' message exchange.
 * @constructor
 * @extends goog.events.EventTarget
 */
talk.media.TalkPluginChannel = function(bareJid, rendererDetector,
    opt_domHelper, opt_mfInfo) {
  goog.events.EventTarget.call(this);
  /**
   * The document
   * @type goog.dom.DomHelper
   * @private
   */
  this.dom_ = opt_domHelper || goog.dom.getDomHelper();


  /**
   * The amount of time the channel has been waiting to initialize.
   *
   * @type number
   * @private
   */
  this.initializeWait_ = 0;


  /**
   * Our user's bare JID.
   *
   * @type string
   * @private
   */
  this.bareJid_ = bareJid;


  /**
   * Our rendering capabilities.
   *
   * @type {talk.media.RendererDetector}
   * @private
   */
  this.rendererDetector_ = rendererDetector;

  /**
   * A map containing information to send to the Google Talk Plugin in the
   * 'mf' message
   *
   * @type {Object}
   * @private
   */
  this.mfInfo_ = opt_mfInfo || {};

  /**
   * The sequence of f-connect messages received from the plugin indicating
   * progress in establishing a connection to the magic flute executable.
   *
   * @type {Array.<string>}
   * @private
   */
  this.connectState_ = [];

};
goog.inherits(talk.media.TalkPluginChannel, goog.events.EventTarget);


/**
 * The amount of time (in ms) to wait before retrying the initialize step of
 * browser plugin creation. We continue to retry until MAX_INITIALIZE_WAIT_
 *
 * @type number
 * @private
 */
talk.media.TalkPluginChannel.RETRY_INITIALIZE_WAIT_ = 2 * 1000;


/**
 * The maximum amount of time in total(in ms) to wait for the plugin to
 * initialize
 *
 * @type number
 * @private
 */
talk.media.TalkPluginChannel.MAX_INITIALIZE_WAIT_ = 20 * 1000;


/**
 * The amount of time after which we assume the plugin was unable to connect
 * to the executable.
 *
 * @type number
 * @private
 */
talk.media.TalkPluginChannel.PLUGIN_CONNECTION_WAIT_ = 10 * 1000;


/**
 * Whether or not the plugin has finished initializing. Messages sent before
 * it's done initializing are dropped.
 *
 * @type boolean
 * @private
 */
talk.media.TalkPluginChannel.prototype.initialized_ = false;


/**
 * Whether or not the plugin is connected to a running instance of flute.
 * Messages sent while not connected (but after initialized) are queued by the
 * plugin.
 *
 * @type boolean
 * @private
 */
talk.media.TalkPluginChannel.prototype.ready_ = false;

talk.media.TalkPluginChannel.prototype.logger_ =
    goog.debug.Logger.getLogger('talk.media.TalkPluginChannel');

/**
 * The browser plugin we use to communicate with the Google Talk plugin daemon.
 *
 * @type {ActiveXObject|Element}
 */
talk.media.TalkPluginChannel.prototype.channel_;

/**
 * A function closure to be called when we receive a message from the plugin
 *
 * @type {Function}
 */
talk.media.TalkPluginChannel.prototype.onMessageClosure_;


/**
 * Whether to send jmidata messages or not.
 *
 * @type {boolean}
 */
talk.media.TalkPluginChannel.prototype.shouldSendJmiData_ = false;


/**
 * Event indicating the connection process has completed and
 * its end state should be interpreted and recorded.
 *
 * @param {Array.<Object>} messages The collected info about the connection
 * @constructor
 * @extends {goog.events.Event}
 */
talk.media.TalkPluginChannel.ImpressionEvent = function(messages) {
  goog.events.Event.call(this,
      talk.media.TalkPluginEvent.CONNECT_IMPRESSION);

  /**
  * @type {Array.<Object>}
  */
  this.messages = messages;
};
goog.inherits(talk.media.TalkPluginChannel.ImpressionEvent,
    goog.events.Event);


/**
 * Initializes the channel to the Google Talk plugin daemon.
 *
 * @return boolean Whether or not initialization succeeded
 */
talk.media.TalkPluginChannel.prototype.initialize = function() {

  // Attempt to instantiate the actual browser plugin object;
  if (goog.userAgent.IE) {
    // for IE, we try to create an activex object
    try {
      this.logger_.info('Attempting to load GTP activeX plugin');
      // IE's garbage collector can't handle circular references between a mix
      // of JavaScript and ActiveX, so we absolutely have to unset the channel_
      // property when the page unloads or else we will leak the browserplugin
      // instance. JS exceptions anywhere in Gmail might prevent proper
      // disposal, so we also do this as a last resort.
      window.attachEvent('onunload', goog.bind(this.disposeChannel_, this));
      this.channel_ = new ActiveXObject('GoogleTalk.Plugin');
    } catch(e) {
      this.logger_.info('GTP activeX plugin was not loaded');
      this.channel_ = null;
    }
  } else {
    // for all others, we see if the mimetype is registered and
    // create an object in the DOM if so
    if (goog.global['navigator']) {
      this.logger_.info('Attempting to load gtp Npapi plugin');
      if (navigator.mimeTypes['application/googletalk']) {
        var pluginDOM = this.dom_.getDocument().createElement('embed');
        pluginDOM.id = 'plugin';
        pluginDOM.name = 'plugin';
        // We need to give the plugin non-zero dimensions because otherwise
        // NPP_SetWindow won't be called, and that's the only way to get access
        // to the browser thread's event queue on Linux. Thankfully this seems
        // to *not* actually translate into anything on screen.
        pluginDOM.width = 1;
        pluginDOM.height = 1;
        pluginDOM.type = 'application/googletalk';
        this.dom_.getDocument().documentElement.appendChild(pluginDOM);
        this.channel_ = pluginDOM;
        // now, this isn't necessarily a good plugin -
        // we might just have a handle on a DOM node
        // that has nothing useful in it.  We can
        // check later by asking for its version
        // attribute.  However, checking for its
        // version attribute *now* may result in
        // a return of 'undefined', depending on
        // when you call this and thus when the
        // plugin is inserted into the DOM.
      } else {
        this.logger_.info('GTP mime type not registered.');
        this.channel_ = null;
      }
    } else {
      this.logger_.warning('Global navigator object not defined!');
      this.channel_ = null;
    }
  }

  if (this.channel_) {
    this.logger_.info('GTP plugin embedded, assigning callback.');
    this.finishInitialization_();
  } else {
    this.logger_.info('Failed to instantiate GTP plugin.');
  }
  return !!this.channel_;
};

/**
 * Must match what is in flash/.../PluginFluteConnection.as.
 *
 * @private
 */
talk.media.TalkPluginChannel.API_VERSION_LATEST_ = 2;

/**
 * Gives flute our version info (which makes it respond with its own).
 *
 * @private
 */
talk.media.TalkPluginChannel.prototype.exchangeVersion_ = function() {
  // TODO(jessan): can move bare jid and renderer out of this class
  goog.object.extend(this.mfInfo_, {
        'jid': this.bareJid_,
        'domain': document.domain,
        'useragent': goog.userAgent.getUserAgentString(),
        'pluginversion': this.channel_['version'],
        'renderer': this.rendererDetector_.getCapabilities()
    });

  // If C3D is available, add C3D version info to the mf message.
  var client3DDetector = this.rendererDetector_.getClient3DDetector();
  if (goog.isDefAndNotNull(client3DDetector) &&
      client3DDetector.isInstalled()) {
    goog.object.extend(this.mfInfo_, {
          'o3dVersion': client3DDetector.getVersion() });
  }
  this.send(goog.json.serialize(['mf',
    talk.media.TalkPluginChannel.API_VERSION_LATEST_, this.mfInfo_]));
};


/**
 * Tries to finish the initialization of the browser plugin by setting up its
 * onmessage function. Sometimes this fails and we need to retry because it
 * takes the plugin a bit of time to be fully loaded into the DOM. This behavior
 * was noticed in Firefox but not in IE. We will continue to retry until we
 * receive our first callback or MAX_INITIALIZE_WAIT_ is reached.
 *
 * @private
 */
talk.media.TalkPluginChannel.prototype.finishInitialization_ = function() {
  if (this.initialized_) {
    // We are set up, nothing to do.
    return;
  }

  // Set up the retry
  if (this.initializeWait_ <
      talk.media.TalkPluginChannel.MAX_INITIALIZE_WAIT_) {
    goog.Timer.callOnce(this.finishInitialization_,
        talk.media.TalkPluginChannel.RETRY_INITIALIZE_WAIT_, this);
    this.initializeWait_ +=
        talk.media.TalkPluginChannel.RETRY_INITIALIZE_WAIT_;
  } else {
      this.logger_.severe(
          'Hit max retries for initializing TalkPluginChannel, quitting.');
      this.notifyChannelDead_();
      return;
  }

  // Apply our callback to the onmessage property of the plugin, unfortunately
  // it might not 'stick' and our native code will not see the assignment, so
  // we don't assume it didn't work and retry until we get our first invocation.
  try {
    this.channel_['onmessage'] = goog.bind(this.handleDaemonMessage, this);
  } catch (e){
    this.logger_.info('GTP BP initialization failed, retrying in ' +
       talk.media.TalkPluginChannel.RETRY_INITIALIZE_WAIT_ + ' ms', e);
  }
};


/**
 * Tries to send a message to the Google Talk Plugin daemon.
 *
 * @param {string} message A JSON message for the Google Talk plugin daemon
 */
talk.media.TalkPluginChannel.prototype.send = function(message) {
  if (this.initialized_) {
    try {
      this.channel_['send'](message);
    } catch (e) {
      // NOTE(tschmelcher): See bug 1820495 for the history of this.
      this.logger_.warning('Exception while sending message ' + message +
          ' to plugin: ' + e);
      return;
    }
    this.dispatchEvent(new talk.media.CallEvent(
        talk.media.TalkPluginEvent.OUTGOING_MESSAGE,
        message));
  } else {
    this.logger_.warning('Unable to send message. Channel was not initialized');
  }
};


/**
 * Handles a message from the Google Talk Plugin daemon, dispatching an event.
 *
 * @protected
 * @param {string} message A JSON message from the Google Talk Plugin daemon
 * @param {string} opt_sender Not currently used.
 */
talk.media.TalkPluginChannel.prototype.handleDaemonMessage = function(
    message, opt_sender) {
  if (!this.initialized_) {
    this.logger_.info('GTP BP load complete.');
    this.initialized_ = true;
  }

  var event = new talk.media.CallEvent(
      talk.media.TalkPluginEvent.MESSAGE, message);

  if (event.msgType == talk.media.TalkPluginEvent.CONNECTING) {
    // We collate these messages here, and eventually report them by
    // firing a CONNECT_IMPRESSION event.
    this.handleConnectStatus_(event);
    return;
  }
  if (event.msgType == talk.media.TalkPluginEvent.READY) {
    this.ready_ = true;

    goog.Timer.clear(this.connectReportTimer_);
    this.connectReportTimer_ = null;
    this.connectState_.push({ok: true});
    this.sendConnectReport_();

    this.exchangeVersion_();
  } else if (event.msgType == talk.media.TalkPluginEvent.DEAD) {
    this.ready_ = false;
    this.notifyChannelDead_();
  } else if (!this.shouldSendJmiData_ && event.msgType == 'jmidata') {
    // The user has disabled this. Drop it.
    return;
  }
  this.dispatchEvent(event);
};


/**
 * Dispatches a version event without values to indicate that the flute is not
 * available.
 *
 * @private
 */
talk.media.TalkPluginChannel.prototype.notifyChannelDead_ = function() {
  var noVersion = ['mf', '', ''];
  this.dispatchEvent(new talk.media.CallEvent(
      talk.media.TalkPluginEvent.MESSAGE,
      goog.json.serialize(noVersion)));
};


/**
 * Sets whether or not to send detailed statistics to the server
 * (the jmidata message).
 *
 * @param {boolean} enable whether to enable it or not
 */
talk.media.TalkPluginChannel.prototype.enableDetailedStats =
    function(enable) {
  this.shouldSendJmiData_ = enable;
};


/**
 * Returns true if the plugin was successfully initialized.
 *
 * @return {boolean}
 */
talk.media.TalkPluginChannel.prototype.isInitialized = function() {
  return this.initialized_;
};


/**
 * Returns true if the plugin is connected to a running instance of flute.
 *
 * @return {boolean}
 */
talk.media.TalkPluginChannel.prototype.isReady = function() {
  return this.ready_;
};


/**
 * Releases our browserplugin instance.
 *
 * @private
 */
talk.media.TalkPluginChannel.prototype.disposeChannel_ = function() {
  this.channel_ = null;
};


/**
 * {@inheritDoc}
 */
talk.media.TalkPluginChannel.prototype.dispose = function() {
  if (!this.getDisposed()) {
    this.disposeChannel_();
    talk.media.TalkPluginChannel.superClass_.dispose.call(this)
  }
};


/**
 * Updates maintained information about the progress of the Browser Plugin in
 * establishing a connection with the Flute executable, including order of
 * steps and any errors encountered.
 *
 * @private
 * @param {talk.media.CallEvent} e the f-connect message
 */
talk.media.TalkPluginChannel.prototype.handleConnectStatus_ = function(e) {
  if (!this.connectReportTimer_) {
    this.connectReportTimer_ = goog.Timer.callOnce(this.sendConnectReport_,
        talk.media.TalkPluginChannel.PLUGIN_CONNECTION_WAIT_, this);
  }

  // Append the json object containing the relevant fields to our array
  var data = e.getParsedMsg().pop();
  this.connectState_.push(data);
};


/**
 * Formats our collected data from any connection status messages in to a report
 * that is posted to the google crash server, for later analysis.
 *
 * @private
 */
talk.media.TalkPluginChannel.prototype.sendConnectReport_ = function() {
  this.dispatchEvent(new talk.media.TalkPluginChannel.ImpressionEvent(
      this.connectState_));
};

