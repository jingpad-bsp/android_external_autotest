// Copyright 2007 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview Definition of the talk.media.MediaPlayer class and subclasses.
 * This class is a wrapper around a Flash media player allowing
 * YouTube, Google Video, Picasa and Flickr links to be viewed inline
 *
 * TODO(andyro) NOTE this file isn't done, "state" is not complete
 *
 * @author Jessan Hutchison-Quillian (jessan@google.com)
 */


goog.provide("talk.media.MediaPlayer");

goog.require("goog.json");
goog.require('goog.userAgent');
goog.require('talk.media.FlashPlayer');
goog.require('talk.media.FlashObject');

/**
 * Creates the SWF for playing inline media.
 *
 * @param {string|Element} swfContainer An Element into which we insert the SWF
 * @constructor
 * @extends talk.media.FlashPlayer
 */
talk.media.MediaPlayer = function(swfContainer) {
  talk.media.FlashPlayer.call(this, talk.media.MediaPlayer.NAME,
      talk.media.MediaPlayer.getSwfUrl());
  this.setContainer(swfContainer);

  /**
   * State callbacks
   * @type Array.<Function>
   * @private
   */
  this.onStateCallbacks_ = [];
};
talk.media.MediaPlayer.inherits(talk.media.FlashPlayer);


/**
 * Current known player state
 * @type Object
 * @private
 */
talk.media.MediaPlayer.prototype.playerState_;


/**
 * Enum for messages sent to flash
 * @enum {string}
 */
talk.media.MediaPlayer.SendMsg = {
  /**
    * request to play media
    */
  PLAY_MEDIA_MSG : 'PLAY_MEDIA',

  /**
    * request to return state
    */
  GET_STATE_MSG : 'GET_STATE',

  /**
   * request to set to state
   */
  SET_STATE_MSG : 'SET_STATE'
};


/**
 * Enum for messages received from flash
 * @enum {string}
 */
talk.media.MediaPlayer.RecvMsg = {
  /**
   * current player state update
   */
  STATE_MSG : 'STATE'
};


talk.media.MediaPlayer.NAME = 'yj_player';


talk.media.MediaPlayer.PLAYER_SWF = 'im/media-player.swf';


/**
 * By updating this version, we can force .swf files to be re-cached
 */
talk.media.MediaPlayer.PLAYER_VERSION = '1.1.10';


/**
 * Returns the relative URL to the SWF file.
 *
 * @return {string} The URL to the SWF.
 */
talk.media.MediaPlayer.getSwfUrl = function() {
 return talk.media.MediaPlayer.PLAYER_SWF + '?ver='
     + talk.media.MediaPlayer.PLAYER_VERSION;
};


/**
 * Returns the wmode parameter to use when writing the flash DOM object.
 *
 * @return {talk.media.FlashObject.Wmodes} The Wmode to use.
 */
talk.media.MediaPlayer.prototype.getWmode = function() {
  // There is a bug with our player in FF2.0 for Windows using wmode=opaque
  if (goog.userAgent.GECKO && goog.userAgent.WINDOWS) {
    return talk.media.FlashObject.Wmodes.WINDOW;
  }
  return talk.media.FlashObject.Wmodes.OPAQUE;
};


/**
 * Plays the URL passed in.
 *
 * @param {String|Array} playerData Data representing media to play. Must be
 *     a JSON representation of an array or an array itself.
 */
talk.media.MediaPlayer.prototype.play = function(playerData) {
  if (goog.isString(playerData)) {
    playerData = goog.json.parse(playerData);
  }
  this.sendToPlayer(talk.media.MediaPlayer.SendMsg.PLAY_MEDIA_MSG,
      /** @type {Array} */ (playerData));
};


/**
 * Gets the state of the player.
 *
 * @param {Function} callbackFn Callback function to be called when we receive
 *                   the state of the player
 * @private
 */
talk.media.MediaPlayer.prototype.getPlayerState_ = function(callbackFn) {
  this.onStateCallbacks_.push(callbackFn);
  // Check if we are already waiting for state callback
  // if so, we don't need to send another request
  if (this.onStateCallbacks_.length > 1) {
    return;
  }
  this.sendToPlayer(talk.media.MediaPlayer.SendMsg.GET_STATE_MSG, []);
};


/**
 * Sets the state of the player, updates current player
 *
 * @param {Object} state array representing the state of the player
 */
talk.media.MediaPlayer.prototype.setPlayerState = function(state) {
  this.playerState_ = state;
  this.sendToPlayer(talk.media.MediaPlayer.SendMsg.SET_STATE_MSG, [state]);
};


/**
 * Calls the callbacks with the current state.
 * TODO(andyro) we should just update the local state and/or raise event
 * @param {Array} state the current state of the player
 * @private
 */
talk.media.MediaPlayer.prototype.handleStateUpdate_ = function(state) {
  while (this.onStateCallbacks_.length > 0) {
    var callbackFn = this.onStateCallbacks_.pop();
    if (callbackFn) {
      callbackFn(state);
    }
  }
};


/**
 * Override.
 * @param {Array} msg The message to handle.
 */
talk.media.MediaPlayer.prototype.handleMessage = function(type, msg) {
  if (type == talk.media.MediaPlayer.RecvMsg.STATE_MSG) {
    this.handleStateUpdate_(msg[1]);
    return true;
  }
  return false;
};


/**
 * @return {Object} The current state of the player
 */
talk.media.MediaPlayer.prototype.getPlayerState = function() {
  return this.playerState_;
};
