// Copyright 2009 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview Concrete feed class showing a label with an identifier.
 * @author geer@google.com (Arthur van der Geer)
 */

goog.provide('talk.media.c3d.LabeledFeed');

goog.require('goog.Timer');
goog.require('goog.debug.Logger');
goog.require('talk.media.c3d.AlphaTween');
goog.require('talk.media.c3d.FixedAreaFeed');
goog.require('talk.media.c3d.Image');
goog.require('talk.media.c3d.helpers');


/**
 * Concrete feed class that shows a label with an identifier.
 *
 * @param {talk.media.c3d.O3dBundle} o3dBundle The bundle of global resources
 *     for this O3D instance.
 * @param {talk.media.c3d.StreamEndpoint} endpoint The StreamEndpoint that
 *     provides the video/avatar for this feed.
 * @param {number} depth The depth at which to display this feed.
 * @param {number} x The x-coordinate of the origin.
 * @param {number} y The y-coordinate of the origin.
 * @param {number} width The width of the rectangle to draw in.
 * @param {number} height The height of the rectangle to draw in.
 * @param {string} text The text to show on the label.
 * @extends {talk.media.c3d.FixedAreaFeed}
 * @constructor
 */
talk.media.c3d.LabeledFeed = function(o3dBundle, endpoint, depth,
    x, y, width, height, text) {

  /**
   * A goog.bind()'ed version of onMouseMove_, suitable for using as an event
   * callback.
   *
   * @type {!Function}
   * @private
   */
  this.boundOnMouseMove_ = goog.bind(this.onMouseMove_, this);


  /**
   * The text to show on the label.
   *
   * @type {string}
   * @private
   */
  this.text_ = text;

  talk.media.c3d.FixedAreaFeed.call(this, o3dBundle, endpoint, depth,
      x, y, width, height);
};
goog.inherits(talk.media.c3d.LabeledFeed, talk.media.c3d.FixedAreaFeed);


/**
 * The time to show the label when feed appeared.
 *
 * @type {number}
 * @const
 * @private
 */
talk.media.c3d.LabeledFeed.SHOW_ON_START_MS_ = 7 * 1000;


/**
 * The time to show the label when mouse hovered over the feed.
 *
 * @type {number}
 * @const
 * @private
 */
talk.media.c3d.LabeledFeed.SHOW_ON_MOUSE_MS_ = 3 * 1000;


/**
 * The ID of the timer that hides the label on timeout.
 *
 * @type {?number}
 * @private
 */
talk.media.c3d.LabeledFeed.prototype.hideTimerId_;


/**
 * A tween to hide the label by fading.
 *
 * @type {talk.media.c3d.AlphaTween}
 * @private
 */
talk.media.c3d.LabeledFeed.prototype.labelHider_;


/**
 * The label to show on the feed.
 *
 * @type {talk.media.c3d.Image}
 * @private
 */
talk.media.c3d.LabeledFeed.prototype.label_ = null;


/**
 * Our logger.
 *
 * @type {goog.debug.Logger}
 * @private
 */
talk.media.c3d.LabeledFeed.prototype.logger_ =
    goog.debug.Logger.getLogger('talk.media.c3d.LabeledFeed');


/**
 * @override
 * @protected
 */
talk.media.c3d.LabeledFeed.prototype.createFeedObject = function() {
  var feedObject =
      talk.media.c3d.LabeledFeed.superClass_.createFeedObject.call(this);

  this.createLocalView_(feedObject);

  this.label_ = this.createLabelImage_(this.text_);

  var c3d = this.o3dBundle.c3dObject.getPlugin();
  talk.media.c3d.addEventCallback(c3d, 'mousemove', this.boundOnMouseMove_);

  this.showLabel(talk.media.c3d.LabeledFeed.SHOW_ON_START_MS_);

  return feedObject;
};


/**
 * @override
 * @protected
 */
talk.media.c3d.LabeledFeed.prototype.updatePosition = function(attrs) {
  talk.media.c3d.LabeledFeed.superClass_.updatePosition.call(this, attrs);
  this.updateLocalView_();
  this.label_.moveTo((attrs.w - this.label_.width()) / 2,
                     attrs.h - this.label_.height());
};


/**
 * Setup a view for displaying images on top of the video feed.
 *
 * @param {talk.media.c3d.SceneObject} feedObject The object displaying the
 *     feed.
 * @private
 */
talk.media.c3d.LabeledFeed.prototype.createLocalView_ = function(feedObject) {
  var c3d = this.o3dBundle.c3dObject.getPlugin();

  this.imageView_ = new talk.media.c3d.View(c3d, this.o3dBundle.pack, 2, true,
      feedObject.getTransform());
  this.updateLocalView_();

  this.imageOverlay_ = new talk.media.c3d.ImageOverlay(this.o3dBundle,
      this.getEndpoint().material.effect, this.imageView_);
};


/**
 * Update the view to the size of the O3D client area.
 * @private
 */
talk.media.c3d.LabeledFeed.prototype.updateLocalView_ = function() {
  // TODO(geer): Refactor this to a shared projection matrix in the bundle.
  this.imageView_.setProjectionMatrix(
      talk.media.c3d.createOrthographicMatrix(0 + 0.5,
                                              this.o3dBundle.width + 0.5,
                                              this.o3dBundle.height + 0.5,
                                              0 + 0.5,
                                              0.001,
                                              1000));
};


/**
 * Create an image in the local view with the text rendered on it.
 *
 * @param {string} text The text to render on the image.
 * @return {talk.media.c3d.Image} Image with the text.
 * @private
 */
talk.media.c3d.LabeledFeed.prototype.createLabelImage_ = function(text) {
  var c3d = this.o3dBundle.c3dObject.getPlugin();

  // The C3D CanvasPaint object for storing text properties.
  var canvasPaint = this.o3dBundle.pack.createObject('CanvasPaint');
  canvasPaint.setOutline(1, [0, 0, 0, 1]);
  canvasPaint.textAlign = c3d.o3d.CanvasPaint.CENTER;
  canvasPaint.textSize = 12;
  canvasPaint.textTypeface = 'Arial';
  canvasPaint.color = [1, 1, 1, 1];

  // Get the bounds for rendering the text: [left, top, right, bottom].
  var bounds = canvasPaint.measureText(text);
  var width = bounds[2] - bounds[0] + 30;
  var height = bounds[3] - bounds[1] + 30;

  // The C3D Canvas object for drawing text.
  var canvas = this.o3dBundle.pack.createObject('Canvas');
  canvas.setSize(width, height);

  // Makes the canvas black with 50% transparency.
  canvas.clear([0, 0, 0, 0.5]);
  canvas.drawText(text, width / 2, height - 20, canvasPaint);

  var texture = this.o3dBundle.pack.createTexture2D(width, height,
      c3d.o3d.Texture.ARGB8,  // format
      1,  // mipmap levels
      false);
  canvas.copyToTexture(texture);

  return this.imageOverlay_.createImageFromTexture(0, 0, texture);
};


/**
 * Shows the label for a specified amount of time. After that the label will
 * fade out.
 *
 * @param {number} interval The number of milliseconds to show the label.
 */
talk.media.c3d.LabeledFeed.prototype.showLabel = function(interval) {
  if (!this.label_) {
    this.logger_.warning('No label to show.');
    return;
  }

  this.label_.setVisible(true);
  this.label_.setAlpha(1);

  this.clearHideTimer_();
  this.hideTimerId_ = goog.Timer.callOnce(this.hideLabel, interval, this);
};


/**
 * Hides the label.
 */
talk.media.c3d.LabeledFeed.prototype.hideLabel = function() {
  this.clearHideTimer_();
  if (this.label_) {
    this.labelHider_ = new talk.media.c3d.AlphaTween(this.label_,
        this.label_.getAlpha(), 0, 1, talk.media.c3d.REGULAR_EASE_IN,
        goog.bind(this.finishHideLabel_, this));
    this.o3dBundle.c3dEngine.registerRenderCallback(this.labelHider_);
  }
};


/**
 * Finalizes the hiding of the label. Cancels and removes the tween.
 * @private
 */
talk.media.c3d.LabeledFeed.prototype.finishHideLabel_ = function() {
  if (this.labelHider_) {
    this.o3dBundle.c3dEngine.unregisterRenderCallback(this.labelHider_);
    this.labelHider_ = null;
  }
  this.label_.setVisible(false);
};


/**
 * Clears the timer for hiding the label.
 * @private
 */
talk.media.c3d.LabeledFeed.prototype.clearHideTimer_ = function() {
  if (this.hideTimerId_) {
    goog.Timer.clear(this.hideTimerId_);
    this.hideTimerId_ = null;
  }
};


/**
 * Responds to mousemove events by showing the label.
 *
 * @param {Object} e The O3D Plugin event object which is generic for all types
 *     of O3D events.
 * @private
 */
talk.media.c3d.LabeledFeed.prototype.onMouseMove_ = function(e) {
  if (this.hitTest(e.x, e.y)) {
    this.showLabel(talk.media.c3d.LabeledFeed.SHOW_ON_MOUSE_MS_);
  }
};


/**
 * Returns whether the position is inside the feed area.
 *
 * @param {number} x Horizontal position.
 * @param {number} y Vertical position.
 * @return {boolean} True iff inside.
 */
talk.media.c3d.LabeledFeed.prototype.hitTest = function(x, y) {
  return x >= this.x && x <= this.x + this.width &&
         y >= this.y && y <= this.y + this.height;
};


/**
 * @override
 * @protected
 */
talk.media.c3d.LabeledFeed.prototype.disposeInternal = function() {
  talk.media.c3d.LabeledFeed.superClass_.disposeInternal.call(this);

  this.clearHideTimer_();
  if (this.o3dBundle.c3dObject.isScriptable()) {
    var c3d = this.o3dBundle.c3dObject.getPlugin();
    talk.media.c3d.removeEventCallback(c3d, 'mousemove',
        this.boundOnMouseMove_);
  }
  if (this.label_) {
    this.label_.disposeC3d();
    this.label_ = null;
  }
};
