// Copyright 2008 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview A generic Client3D UI object.
 *
 * @author tschmelcher@google.com (Tristan Schmelcher)
 */

goog.provide('talk.media.c3d.C3dObject');

goog.require('goog.dom');
goog.require('goog.style');


/**
 * Creates a dynamically addable/removable Client3D object. Very loosely based
 * on google3/buzz/javascript/media/flashobject.js.
 *
 * @constructor
 */
talk.media.c3d.C3dObject = function() {
};


/**
 * The actual plugin.
 *
 * @type Element
 * @private
 */
talk.media.c3d.C3dObject.prototype.c3d_;


/**
 * The document.
 *
 * @type goog.dom.DomHelper
 * @private
 */
talk.media.c3d.C3dObject.prototype.dom_;


/**
 * The element that the object is currently in.
 *
 * @type Element
 * @private
 */
talk.media.c3d.C3dObject.prototype.container_;


/**
 * The DOM id that we gave the object.
 *
 * @type string
 * @private
 */
talk.media.c3d.C3dObject.prototype.id_;


/**
 * Inserts a Client3D plugin instance into the DOM inside the given container.
 *
 * @param {string|Element} container The Element to contain the Client3D
 *     instance.
 * @param {string} opt_id Id for the element. Defaults to 'client3d'.
 */
talk.media.c3d.C3dObject.prototype.writeHTML = function(container, opt_id) {
  this.container_ = goog.dom.getElement(container);
  this.dom_ = goog.dom.getDomHelper(this.container_);
  this.id_ = opt_id || 'client3d';

  var html;
  if (goog.userAgent.IE) {
    html = '<object classid="CLSID:9666A772-407E-4F90-BC37-982E8160EB2D" ' +
               'width="100%" height="100%" id="%s">' +
             '<param name="o3d_features" value=""/>' +
           '</object>';
  } else {
    html = '<object type="application/vnd.o3d.auto" ' +
               'width="100%" height="100%" id="%s" o3d_features="">' +
           '</object>';
  }
  this.container_.innerHTML = goog.string.subs(html, this.id_);

  this.c3d_ = this.dom_.getElement(this.id_);
};


/**
 * Returns a pointer to the Client3D plugin instance's scriptable object.
 *
 * @return {Element} the plugin's scriptable object.
 */
talk.media.c3d.C3dObject.prototype.getPlugin = function() {
  return this.c3d_;
};


/**
 * Returns whether or not the plugin is in a state where we can perform
 * scripting on its NPObject handle (i.e., the object returned from
 * getPlugin()). Normally this is the case if it has been added to the DOM with
 * writeHTML(), has had time to initialize, and has not yet been removed by
 * calling removeHTML(), but there are exceptions:
 * (1) If it has been removed by removing its container or a parent of its
 * container from the DOM, then it will not be scriptable in Chrome or Safari.
 * (2) If its 'display' property has been set to 'none', then it will not be
 * scriptable in Chrome or Safari.
 * And (3) if it has been removed by closing a pop-out window, then it will not
 * be scriptable in IE.
 *
 * @return {boolean} Whether or not the plugin handle is currently scriptable.
 */
talk.media.c3d.C3dObject.prototype.isScriptable = function() {
  return goog.isDefAndNotNull(this.c3d_) &&
      goog.isDefAndNotNull(this.c3d_['client']);
};


/**
 * Returns whether or not the plugin is in a state where we can perform
 * scripting specifically related to the scene logic. Normally if it is
 * generally in a scriptable state as indicated by isScriptable() then scene
 * logic is scriptable too, but there is an exception. If it has been removed
 * from the DOM, then scene logic will not be in a scriptable state in IE or
 * FF (but only after a delay in FF), even though it will still be generally
 * scriptable in those browsers. This is because this causes the plugin to
 * partially shut-down, making the O3D methods for control of the scene
 * unusable.
 *
 * @return {boolean} Whether or not the plugin's scene logic is currently
 * scriptable.
 */
talk.media.c3d.C3dObject.prototype.isSceneScriptable = function() {
  return this.isScriptable() &&
      goog.isDefAndNotNull(this.dom_.getElement(this.id_));
};


/**
 * Removes the HTML in the Element containing this Client3D plugin instance
 * from the DOM.
 */
talk.media.c3d.C3dObject.prototype.removeHTML = function() {
  if (this.container_) {
    this.container_.innerHTML = '';
  }
  delete this.container_;
  delete this.dom_;
  delete this.id_;
  delete this.c3d_;
};


/**
 * Returns the Client3D pane's true width in pixels.
 *
 * @return {number} the width.
 */
talk.media.c3d.C3dObject.prototype.getWidth = function() {
  return goog.style.getSize(this.c3d_).width;
};


/**
 * Returns the Client3D pane's true height in pixels.
 *
 * @return {number} the height.
 */
talk.media.c3d.C3dObject.prototype.getHeight = function() {
  return goog.style.getSize(this.c3d_).height;
};
