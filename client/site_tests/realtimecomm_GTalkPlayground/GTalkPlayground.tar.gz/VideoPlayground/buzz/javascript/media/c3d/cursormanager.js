// Copyright 2010 Google Inc. All Rights Reserved.

/**
 * @fileoverview Manages reconciliation of potentially conflicting changes to
 * the cursor style by separate UI elements.
 *
 * @author tschmelcher@google.com (Tristan Schmelcher)
 */

goog.provide('talk.media.c3d.CursorManager');


/**
 * Creates a CursorManager to manage reconciliation of potentially conflicting
 * changes to the cursor style by separate UI elements. Each UI element may
 * register a request to set the cursor to a particular style, with an
 * associated priority. The active style is whichever active registration has
 * the highest priority, or the default style if there are no registrations.
 *
 * @param {talk.media.c3d.O3dBundle} o3dBundle The bundle of global resources
 *     for this O3D instance.
 * @constructor
 */
talk.media.c3d.CursorManager = function(o3dBundle) {

  /**
   * The bundle of global resources for this O3D instance.
   *
   * @type {talk.media.c3d.O3dBundle}
   * @private
   */
  this.o3dBundle_ = o3dBundle;


  /**
   * The list of registered cursor setting requests.
   *
   * @type {Array.<talk.media.c3d.CursorManager.Registration_>}
   * @private
   */
  this.registrations_ = [];
};


/**
 * Record of a registration.
 *
 * @param {Object} style The O3D style object.
 * @param {number} priority The priority for this setting.
 * @constructor
 * @private
 */
talk.media.c3d.CursorManager.Registration_ = function(style, priority) {

  /**
   * The O3D style object.
   *
   * @type {Object}
   */
  this.style = style;


  /**
   * The priority for this setting.
   *
   * @type {number}
   */
  this.priority = priority;
};


/**
 * Registers a request to set the cursor to the given style, with a particular
 * priority.
 *
 * @param {string} styleName The name of the style in the O3D Cursor enum.
 * @param {number} priority The priority for this setting.
 * @return {talk.media.c3d.CursorManager.Registration_} An opaque reference to
 *     this request for use in unsetCursor().
 */
talk.media.c3d.CursorManager.prototype.setCursor =
    function(styleName, priority) {
  var c3d = this.o3dBundle_.c3dObject.getPlugin();
  var registration = new talk.media.c3d.CursorManager.Registration_(
      c3d['o3d']['Cursor'][styleName],
      priority);
  this.registrations_.push(registration);
  this.chooseCursor_();
  return registration;
};


/**
 * Unregisters a previously-registered request to set the cursor.
 *
 * @param {talk.media.c3d.CursorManager.Registration_} ref The opaque reference
 *     returned from setCursor().
 * @return {boolean} true iff the request was found.
 */
talk.media.c3d.CursorManager.prototype.unsetCursor = function(ref) {
  for (var i = 0; i < this.registrations_.length; i++) {
    if (this.registrations_[i] == ref) {
      this.registrations_.splice(i, 1);
      this.chooseCursor_();
      return true;
    }
  }
  return false;
};


/**
 * Updates the cursor style to that of the highest-priority registration.
 */
talk.media.c3d.CursorManager.prototype.chooseCursor_ = function() {
  var c3d = this.o3dBundle_.c3dObject.getPlugin();
  if (this.registrations_.length == 0) {
    c3d['client']['cursor'] = c3d['o3d']['Cursor']['DEFAULT'];
    return;
  }
  var highest = this.registrations_[0];
  for (var i = 1; i < this.registrations_.length; i++) {
    if (this.registrations_[i].priority > highest.priority) {
      highest = this.registrations_[i];
    }
  }
  c3d['client']['cursor'] = highest.style;
};
