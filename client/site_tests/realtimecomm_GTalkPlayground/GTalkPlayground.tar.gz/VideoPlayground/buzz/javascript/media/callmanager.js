// Copyright 2007 Google Inc.  All Rights Reserved.

/**
 * @fileoverview Defines the CallManager class.
 *
 * @author jessan@google.com (Jessan Hutchison-Quillian)
 */

goog.provide('talk.media.CallManager');
goog.provide('talk.media.CallManager.ActiveCallEvent');
goog.provide('talk.media.CallManager.AddVideoEvent');
goog.provide('talk.media.CallManager.Call');
goog.provide('talk.media.CallManager.CallEndedEvent');
goog.provide('talk.media.CallManager.InstallNeededEvent');
goog.provide('talk.media.CallManager.MicMuteEvent');
goog.provide('talk.media.CallManager.NewCallEvent');
goog.provide('talk.media.CallManager.RemoveVideoEvent');
goog.provide('talk.media.CallManager.ShowAvatarEvent');
goog.provide('talk.media.CallManager.ShowVideoEvent');
goog.provide('talk.media.CallManager.SpeakerChangedEvent');
goog.provide('talk.media.CallManager.UploadLogCompleteEvent');

goog.require('goog.Timer');
goog.require('goog.debug.Logger');
goog.require('goog.events.EventHandler');
goog.require('goog.events.EventTarget');
goog.require('goog.json');
goog.require('goog.object');
goog.require('goog.structs.Map');
goog.require('goog.structs.Queue');
goog.require('talk.Jid');
goog.require('talk.media.CallEvent');
goog.require('talk.media.CallType');
goog.require('talk.media.TalkPlugin');
goog.require('talk.media.TalkPluginErrorCodes');
goog.require('talk.media.TalkPluginEvent');
goog.require('talk.media.Tone');

/**
 * Handles and abstracts communication with the server and the Google Talk
 * Plugin related to voice and video calling.
 *
 * @param {talk.media.CallingRequirements} callingRequirements The requirements
 *     for voice and video.
 * @constructor
 * @extends {goog.events.EventTarget}
 */
talk.media.CallManager = function(callingRequirements) {
  goog.events.EventTarget.call(this);

  /**
   * A detector to query for Flash state, whether Flash is installed and its
   * version etc.
   *
   * @type {talk.media.FlashDetector}
   * @private
   */
  this.flashDetector_ = callingRequirements.getFlashDetector();

  /**
   * The object that knows about the system requirements for using
   * voice and video.
   *
   * @type {talk.media.CallingRequirements}
   * @private
   */
  this.requirements_ = callingRequirements;

  /**
   * Calls for which we have received initiates but have not yet been started.
   * Map from session id to call object.
   *
   * @type {!goog.structs.Map}
   * @private
   */
  this.unstartedCalls_ = new goog.structs.Map();

  /**
   * The event handler.
   * @type {goog.events.EventHandler}
   * @private
   */
  this.eventHandler_ = new goog.events.EventHandler(this);

  // Set up the callStartTimer_
  this.setOutgoingCallTimeoutMs(this.outgoingCallTimeoutMs_);
};
goog.inherits(talk.media.CallManager, goog.events.EventTarget);


/**
 * Logger for debugging.
 *
 * @type {goog.debug.Logger}
 * @private
 */
talk.media.CallManager.logger_ =
    goog.debug.Logger.getLogger('talk.media.CallManager');


/**
 * The active call, if there is one.
 *
 * @type {talk.media.CallManager.Call}
 * @private
 */
talk.media.CallManager.prototype.activeCall_;


/**
 * Our connection to the Google Talk Plugin.
 *
 * @type {talk.media.TalkPlugin}
 * @private
 */
talk.media.CallManager.prototype.talkPlugin_;


/**
 * A timer set up to be used for timing out unanswered outgoing calls.
 * Invariant: Never null outside of the constructor and setOutgoingCallTimeoutMs
 *
 * We use this instead of the default goog.Timer methods due to an issue with
 * different global window objects when a call is popped out.
 *
 * @type {goog.Timer}
 */
talk.media.CallManager.prototype.callStartTimer_;


/**
 * The number of milliseconds to wait for the remote party to accept before
 * timing out an outgoing ringing call.
 *
 * @type {number}
 * @private
 */
talk.media.CallManager.prototype.outgoingCallTimeoutMs_ = 60 * 1000;


/**
 * The number of milliseconds to wait for flute to clean up a terminating call.
 *
 * @type {number}
 * @private
 */
talk.media.CallManager.prototype.pendingCleanupTimeout_ = 250;

/**
 * The number of milliseconds to wait after a VAD switch until we allow
 * another switch.
 *
 * @type {number}
 * @private
 */
talk.media.CallManager.VAD_SWITCH_TIMEOUT_ = 1000;


/**
 * The id for our VAD switching timeout function.
 *
 * @type {?number}
 * @private
 */
talk.media.CallManager.prototype.vadSwitchingTimeoutFn_;


/**
 * Events related to call handling.
 *
 * @enum {string}
 */
talk.media.CallManager.Event = {
  /**
   * Fired when we receive a call, but before the call is set as active call.
   */
  NEW_CALL: 'nc',

  /**
   * Fired when the call has had its state set to active.
   */
  ACTIVE_CALL: 'ac',

  /**
   * Fired when our current call is ending, but before active call is cleared.
   */
  CALL_ENDED: 'ec',

  /**
   * An incoming jingle message.
   */
  INCOMING_JINGLE: 'ij',

  /**
   * An outgoing jingle message.
   */
  OUTGOING_JINGLE: 'oj',

  /**
   * An event indicating that the user needs to install something in order to
   * place a call.
   */
  INSTALL_NEEDED: 'in',

  /**
   * An event indicating that the current speaker has changed.
   */
  SPEAKER_CHANGED: 'sc',

  /**
   * An event indicating that an avatar should be shown.
   */
  SHOW_AVATAR: 'sa',

  /**
   * An event indicating that a video stream should be shown.
   */
  SHOW_VIDEO: 'sv',

  /**
   * A log was successfully uploaded.
   */
  UPLOAD_LOG_RESPONSE: 'ulr',

  /**
   * An event indicating that a video stream should be added.
   */
  ADD_VIDEO: 'av',

  /**
   * An event indicating that a video stream should be removed.
   */
  REMOVE_VIDEO: 'rv',

  /**
   * An event indicating that microphone mute state changed.
   */
  MIC_MUTE: 'mm'
};


/**
 * Types of installs required.
 *
 * @enum {string}
 */
talk.media.CallManager.InstallNeededType = {

  /**
   * The user needs to install the Google Talk Plugin.
   */
  INSTALL_PLUGIN_NEEDED: 'tpi',

  /**
   * The user needs to install Flash.
   */
  INSTALL_FLASH_NEEDED: 'fi',

  /**
   * The user needs to upgrade Flash.
   */
  UPGRADE_FLASH_NEEDED: 'fu',

  /**
   * The user needs to upgrade Flash further to use fullscreen.
   */
  FULLSCREEN_UPGRADE_NEEDED: 'fs'
};


/**
 * The types of jingle messages sent or received.
 *
 * @enum {string}
 * @private
 */
talk.media.CallManager.JingleMessage_ = {
  /**
   * Initiation of a jingle session.
   */
  INITIATE: 'jn',

  /**
   * Indication from the server that we can start processing an incoming call.
   */
  START: 'jstart',

  /**
   * Termination of a jingle session.
   */
  TERMINATE: 'jt',

  /**
   * Jingle transport message -- sent back by the server after we send an init.
   */
  TRANSPORT: 'jtr',

  /**
   * Jingle accept message, sent when a user accepts a call.
   */
  ACCEPT: 'ja',

  /**
   * Jingle info message, sent by server in response to 'mf' to give us STUN
   * and relay server info.
   */
  INFO: 'jf',

  /**
   * Acknowledges that the client has received a message.
   */
  ACK: 'jack',

  /**
   * Jingle encoder configuration message, sent by server in response to 'mf'
   * to provide maximum encoding capacity.
   */
  ENC_CONFIG: 'jec',

  /**
   * Jingle sync message, sent by server to request that we resend our
   * capabilities to ensure that they are in sync.
   */
  SYNC_CAPABILITIES: 'jsync'
};

/**
 * A set containing the messages from the Google Talk Plugin that need to be
 * relayed to the server.
 *
 * @type {Object}
 * @private
 */
talk.media.CallManager.PluginServerMessage_ = {
  /**
   * Jingle candidates
   */
  'jc': 1,

  /**
   * Jingle media info
   */
  'jmidata': 1,

  /**
   * Jingle media info start
   */
  'jmistart': 1,

  /**
   * Jingle media info end
   */
  'jmiend': 1
};


/**
 * Documents the cause of a CALL_ENDED event.
 * Must be kept in sync with EndCause.java
 *
 * @enum {number}
 */
talk.media.CallManager.EndCause = {
  USER_ENDED: 0,
  DECLINE: 1,
  TIMEOUT: 2,
  ERROR: 3,
  FLUTE_ENDED: 4,
  BUSY: 5,
  UNKNOWN: 6,
  FLUTE_NOT_ENABLED: 7,
  CLIENT_GONE: 8,
  BLOCKED: 9,
  CONNECTIVITY_LOST: 10,
  RETRYING: 11,
  TIE_BREAK: 12,
  PLAYER_ERROR: 13,
  ADMIN_ENDED: 14,
  FATAL_RESPONSE: 15,
  INITIATE_FAILED: 16,
  UNKNOWN_SESSION: 17,

  // TODO(jessan): This end cause should show no UI.
  ANOTHER_CLIENT_ACCEPTED: 18
};


/**
 * Additional information that can be passed down with a jn message.
 * Must be kept in sync with FluteMessageGenerator.java.
 *
 * @enum {string}
 */
talk.media.CallManager.InitiateContent = {
  ALT_JID: 'altJid',
  NICK: 'nick'
}


/**
 * Returns whether or not a given end cause should be treated as an error
 * condition, for example when displaying a message to the user.
 *
 * @param {talk.media.CallManager.EndCause} cause The end cause.
 * @return {boolean} Whether it is an error condition or not.
 */
talk.media.CallManager.isErrorCause = function(cause) {
  switch (cause) {
    case talk.media.CallManager.EndCause.ERROR:
    case talk.media.CallManager.EndCause.CONNECTIVITY_LOST:
    case talk.media.CallManager.EndCause.PLAYER_ERROR:
    // These next two aren't actually flute errors, but rather server errors
    case talk.media.CallManager.EndCause.FATAL_RESPONSE:
    case talk.media.CallManager.EndCause.INITIATE_FAILED:
      return true;
    default:
      return false;
  }
};


/**
 * Severity values for use with addToLog().
 *
 * @enum {number}
 */
talk.media.CallManager.LogCommentSeverity = {
  COMMENT: 0,
  WARNING: 1,
  ERROR: 2
};


/**
 * A map used for converting an end cause integer code into an EndCause
 *
 * @type {Object}
 *
 * @private
 */
talk.media.CallManager.intCodeToEndCause_ =
    goog.object.transpose(talk.media.CallManager.EndCause);


/**
 * Event class for the talk.media.CallManager.Event.NEW_CALL event.
 *
 * @param {boolean} isOutgoing Whether or not the call is outgoing.
 * @param {string} jid The JID of the user who is calling us.
 * @param {string} sessionId The id of the call.
 * @param {talk.media.CallType} callType What type of call it is.
 * @constructor
 * @extends {goog.events.Event}
 */
talk.media.CallManager.NewCallEvent = function(isOutgoing,
                                               jid,
                                               sessionId,
                                               callType) {
  goog.events.Event.call(this, talk.media.CallManager.Event.NEW_CALL);

  /**
   * Whether the call is outgoing.
   *
   * @type {boolean}
   */
  this.isOutgoing = isOutgoing;

  /**
   * The JID of the user calling us.
   *
   * @type {string}
   */
  this.jid = jid;

  /**
   * The session id of the call.
   *
   * @type {string}
   */
  this.sessionId = sessionId;

  /**
   * The type of the call.
   *
   * @type {talk.media.CallType}
   */
  this.callType = callType;
};
goog.inherits(talk.media.CallManager.NewCallEvent, goog.events.Event);


/**
 * Event class for the talk.media.CallManager.Event.ACTIVE_CALL event.
 *
 * @constructor
 * @extends {goog.events.Event}
 */
talk.media.CallManager.ActiveCallEvent = function() {
  goog.events.Event.call(this, talk.media.CallManager.Event.ACTIVE_CALL);
};
goog.inherits(talk.media.CallManager.ActiveCallEvent, goog.events.Event);


/**
 * An event corresponding to the end of a call.
 *
 * @param {talk.media.CallManager.EndCause} cause What caused the call end.
 * @param {boolean} isRemote Whether or the end cause was on the remote side.
 * @param {string} sessionId The session ID of the call that is ending.
 * @constructor
 * @extends {goog.events.Event}
 */
talk.media.CallManager.CallEndedEvent = function(cause, isRemote, sessionId) {
  goog.events.Event.call(this, talk.media.CallManager.Event.CALL_ENDED);

  /**
   * What caused the call to end.
   *
   * @type {talk.media.CallManager.EndCause}
   */
  this.cause = cause;

  /**
   * @type boolean
   */
  this.isRemote = isRemote;

  /**
   * The session id of the call that is ending.
   *
   * @type {string}
   */
  this.sessionId = sessionId;
};
goog.inherits(talk.media.CallManager.CallEndedEvent, goog.events.Event);


/**
 * Event class for the
 * {@code talk.media.CallManager.Event.INSTALL_NEEDED} event.
 *
 * @param {talk.media.CallManager.InstallNeededType} installType The type of
 *     install needed.
 * @param {boolean} attemptedCall Whether a call was attempted when the event
 *     was triggered.
 * @param {string} jid The JID of the user we tried to call.
 * @param {boolean} isVideo Whether or not it was a video call.
 * @constructor
 * @extends {goog.events.Event}
 */
talk.media.CallManager.InstallNeededEvent = function(installType,
    attemptedCall, jid, isVideo) {
  goog.events.Event.call(this, talk.media.CallManager.Event.INSTALL_NEEDED);

  /**
   * The type of install needed.
   *
   * @type {talk.media.CallManager.InstallNeededType}
   */
  this.installType = installType;

  /**
   * Whether a call was attempted when the event was triggered.
   *
   * @type {boolean}
   */
  this.attemptedCall = attemptedCall;

  /**
   * The JID of the user we tried to call.
   *
   * @type {string}
   */
  this.jid = jid;

  /**
   * Whether or not the call was a video call.
   *
   * @type {boolean}
   */
  this.isVideo = isVideo;
};
goog.inherits(talk.media.CallManager.InstallNeededEvent, goog.events.Event);


/**
 * Event class for the
 * {@code talk.media.CallManager.Event.SPEAKER_CHANGED} event.
 *
 * @param {string} jid The jid of the current speaker.
 * @constructor
 * @extends {goog.events.Event}
 */
talk.media.CallManager.SpeakerChangedEvent = function(jid) {
  goog.events.Event.call(this, talk.media.CallManager.Event.SPEAKER_CHANGED);

  /**
   * The jid of the current speaker.
   *
   * @type {string}
   */
  this.jid = jid;
};
goog.inherits(talk.media.CallManager.SpeakerChangedEvent, goog.events.Event);


/**
 * Event class for the
 * {@code talk.media.CallManager.Event.UPLOAD_LOG_RESPONSE} event.
 *
 * @param {string} chatJid The jid of the chat that triggered the upload.
 * @param {string} id The session id of the call.
 * @param {number} status The status of the upload.
 * @param {string} incidentId The incident id for the uploaded log.
 * @constructor
 * @extends {goog.events.Event}
 */
talk.media.CallManager.UploadLogCompleteEvent = function(
    chatJid, id, status, incidentId) {
  goog.events.Event.call(this, talk.media.CallManager.Event.UPLOAD_LOG_RESPONSE);

  /**
   * The chat jid.
   *
   * @type {string}
   */
  this.chatJid = chatJid;

  /**
   * The session id of the call.
   *
   * @type {string}
   */
  this.id = id;

  /**
   * The status.
   *
   * @type {number}
   */
  this.status = status;

  /**
   * The message.
   *
   * @type {string}
   */
  this.incidentId = incidentId;
};
goog.inherits(talk.media.CallManager.UploadLogCompleteEvent, goog.events.Event);


/**
 * Event class for the {@code talk.media.CallManager.Event.MIC_MUTE} event.
 *
 * @param {boolean} muted True if the microphone is now muted, otherwise false.
 * @constructor
 * @extends {goog.events.Event}
 */
talk.media.CallManager.MicMuteEvent = function(muted) {
  goog.events.Event.call(this, talk.media.CallManager.Event.MIC_MUTE);

  /**
   * Whether the microphone is now muted or unmuted.
   *
   * @type {boolean}
   */
  this.muted = muted;
};
goog.inherits(talk.media.CallManager.MicMuteEvent, goog.events.Event);


/**
 * Event class for the
 * {@code talk.media.CallManager.Event.SHOW_AVATAR} event.
 *
 * TODO(perd): Collapse ShowAvatarEvent and ShowVideoEvent.
 *
 * @param {string} jid The bare jid of the avatar to show.
 * @constructor
 * @extends {goog.events.Event}
 */
talk.media.CallManager.ShowAvatarEvent = function(jid) {
  goog.events.Event.call(this, talk.media.CallManager.Event.SHOW_AVATAR);

  /**
   * The bare jid whose avatar should be shown.
   *
   * @type {string}
   */
  this.jid = jid;
};
goog.inherits(talk.media.CallManager.ShowAvatarEvent, goog.events.Event);


/**
 * Event class for the
 * {@code talk.media.CallManager.Event.SHOW_VIDEO} event.
 *
 * @param {string} ssrc The SSRC of the video stream to show.
 * @param {string} sessionId The session ID of the corresponding call.
 * @constructor
 * @extends {goog.events.Event}
 */
talk.media.CallManager.ShowVideoEvent = function(ssrc, sessionId) {
  goog.events.Event.call(this, talk.media.CallManager.Event.SHOW_VIDEO);

  /**
   * The SSRC of the video stream to show.
   *
   * @type {string}
   */
  this.ssrc = ssrc;

  /**
   * The session ID of the corresponding call.
   *
   * @type {string}
   */
  this.sessionId = sessionId;
};
goog.inherits(talk.media.CallManager.ShowVideoEvent, goog.events.Event);


/**
 * Event class for the
 * {@code talk.media.CallManager.Event.ADD_VIDEO} event.
 *
 * @param {string} ssrc The SSRC of the video stream to add.
 * @param {string} sessionId The session ID of the corresponding call.
 * @constructor
 * @extends {goog.events.Event}
 */
talk.media.CallManager.AddVideoEvent = function(ssrc, sessionId) {
  goog.events.Event.call(this, talk.media.CallManager.Event.ADD_VIDEO);

  /**
   * The SSRC of the video stream to add.
   *
   * @type {string}
   */
  this.ssrc = ssrc;

  /**
   * The session ID of the corresponding call.
   *
   * @type {string}
   */
  this.sessionId = sessionId;
};
goog.inherits(talk.media.CallManager.AddVideoEvent, goog.events.Event);


/**
 * Event class for the
 * {@code talk.media.CallManager.Event.REMOVE_VIDEO} event.
 *
 * @param {string} ssrc The SSRC of the video stream to remove.
 * @param {string} sessionId The session ID of the corresponding call.
 * @constructor
 * @extends {goog.events.Event}
 */
talk.media.CallManager.RemoveVideoEvent = function(ssrc, sessionId) {
  goog.events.Event.call(this, talk.media.CallManager.Event.REMOVE_VIDEO);

  /**
   * The SSRC of the video stream to remove.
   *
   * @type {string}
   */
  this.ssrc = ssrc;

  /**
   * The session ID of the corresponding call.
   *
   * @type {string}
   */
  this.sessionId = sessionId;
};
goog.inherits(talk.media.CallManager.RemoveVideoEvent, goog.events.Event);


/**
 * Adds a comment message to the Google Talk Plugin logfile for a call (and also
 * to the Closure logging mechanism).
 *
 * @param {Object|string} comment The string or object to log, converted to
 *     JSON.
 * @param {talk.media.CallManager.LogCommentSeverity} opt_sev Optional severity.
 *     Default is COMMENT.
 * @param {Error} opt_exception Optional exception. Currently only sent
 *     to the Closure logger.
 */
talk.media.CallManager.prototype.addToLog = function(comment, opt_sev,
    opt_exception) {
  var text = '';
  switch (opt_sev) {
    case talk.media.CallManager.LogCommentSeverity.ERROR:
      text = goog.json.serialize(['error', comment]);
      talk.media.CallManager.logger_.severe('Adding error to log: ' + text,
                                            opt_exception);
      break;
    case talk.media.CallManager.LogCommentSeverity.WARNING:
      text = goog.json.serialize(['warning', comment]);
      talk.media.CallManager.logger_.warning('Adding warning to log: ' + text,
                                             opt_exception);
      break;
    default:
      text = goog.json.serialize(['comment', comment]);
      talk.media.CallManager.logger_.info('Adding comment to log: ' + text,
                                          opt_exception);
      break;
  }
  this.talkPlugin_.sendMsg(text);
};


/**
 * Initiates an outgoing call and dispatches events to notify about
 * the result; A {@code talk.media.CallManager.NewCallEvent} if
 * successful, otherwise a {@code talk.media.CallManager.InstallNeededEvent}
 * if for example the plugin or a webcam is missing.
 *
 * @param {string} jid The JID.
 * @param {talk.media.CallType} callType The call type.
 * @return {boolean} false, if the call was not started
 */
talk.media.CallManager.prototype.startCall = function(jid, callType) {
  if (!this.checkCanMakeCall(jid, callType)) {
    return false;
  }

  var newCall = new talk.media.CallManager.Call([jid], callType);
  this.dispatchEvent(new talk.media.CallManager.NewCallEvent(true, jid,
      newCall.sessionId, callType));
  // We only need to start a timeout if this new call is becoming active. If
  // we already have an active call, we automatically terminate the new call.
  if (!this.hasActiveCall()) {
    this.callStartTimer_.start();
    this.activeCall_ = newCall;
  }
  // TODO(jessan): We currently rely on flash to send the actual initiate. Sane?
  return true;
};


/**
 * Returns the object that knows about the system requirements for using
 * voice and video.
 *
 * @return {talk.media.CallingRequirements} The requirements for voice and
 * video.
 */
talk.media.CallManager.prototype.getCallingRequirements = function() {
  return this.requirements_;
};


/**
 * Checks whether or not the user is allowed to make a call.  If not,
 * an appropriate event is dispatched indicating the problem, e.g. if
 * something needs to be installed first.
 *
 * @param {string} jid The jid of the user to call.
 * @param {talk.media.CallType} callType The kind of call such as
 *     voice or video.
 * @return {boolean} True if allowed, otherwise false.
 *
 */
talk.media.CallManager.prototype.checkCanMakeCall = function(jid, callType) {
  var isVideo = callType == talk.media.CallType.VIDEO;

  if (!this.useClient3D()) {
    if (!this.flashDetector_.hasFlashInstalled()) {
      this.dispatchEvent(new talk.media.CallManager.InstallNeededEvent(
          talk.media.CallManager.InstallNeededType.INSTALL_FLASH_NEEDED,
          true, jid, isVideo));
      return false;
    }


    if (!this.flashDetector_.hasRequiredFlashVersion()) {
      this.dispatchEvent(new talk.media.CallManager.InstallNeededEvent(
          talk.media.CallManager.InstallNeededType.UPGRADE_FLASH_NEEDED,
          true, jid, isVideo));
      return false;
    }
  }

  if (!this.isTalkPluginEnabled()) {
    this.dispatchEvent(new talk.media.CallManager.InstallNeededEvent(
        talk.media.CallManager.InstallNeededType.INSTALL_PLUGIN_NEEDED,
        true, jid, isVideo));
    return false;
  }

  // TODO(perd): Also check camera busy, already in a call etc.
  return true;
};


/**
 * Determines if there is a hardware camera installed.
 *
 * @return {boolean} True if a camera is installed, otherwise false.
 */
talk.media.CallManager.prototype.hasCameraInstalled = function() {
  return this.talkPlugin_ ? this.talkPlugin_.hasCameraInstalled() : false;
};


/**
 * Sends a DTMF tone to the remote party of the active call and echoes the tone
 * locally. If there isn't the correct active call, this method does nothing
 * and returns false. This will always play the sound on both ends, but is only
 * really useful if the remote user is a phone of some type.
 * @param {talk.media.Tone} tone The tone to send.
 * @param {string} jid The jid of the user to send the tone to.
 * @return {boolean} True if the tone is sent.
 */
talk.media.CallManager.prototype.sendDtmfTone = function(tone, jid) {
  if (this.hasActiveCallWith(jid)) {
    var msg = goog.json.serialize([
        talk.media.TalkPlugin.Command.PLAY_SOUND,
        jid,
        this.getActiveCall().sessionId,
        tone]);
    this.talkPlugin_.sendMsg(msg);
    return true;
  }
  return false;
};


/**
 * Called to either terminate the current call and inform the server, or
 * notify the server that a new incoming call could not be handled because
 * the client is already busy with an existing call.
 *
 * @param {talk.media.CallManager.EndCause} opt_cause The end cause.
 * @param {string} opt_remoteJid Remote User's Jid.
 * @param {string} opt_sessionId Session Id for the call.
 */
talk.media.CallManager.prototype.endCall = function(opt_cause, opt_remoteJid,
    opt_sessionId) {
  if (goog.isDefAndNotNull(opt_cause) &&
      opt_cause == talk.media.CallManager.EndCause.BUSY &&
      goog.isDefAndNotNull(opt_remoteJid) &&
      goog.isDefAndNotNull(opt_sessionId)) {
    var call = {remoteJids : [opt_remoteJid], sessionId : opt_sessionId};
    this.sendTerminate_(/** @type {talk.media.CallManager.Call} */ (call),
        opt_cause);
  } else {
    this.doEndCall_(opt_cause || talk.media.CallManager.EndCause.USER_ENDED);
  }
};


/**
 * Terminate the active call.
 *
 * @param {talk.media.CallManager.EndCause} cause Why the call is being ended.
 * @private
 */
talk.media.CallManager.prototype.doEndCall_ = function(cause) {
  if (this.activeCall_) {
    this.sendTerminate_(this.activeCall_, cause);
    this.handleTerminate_(this.activeCall_.sessionId, false, cause);
  } else {
    talk.media.CallManager.logger_.warning(
        'Trying to end call, but no active call');
  }
};


/**
 * Terminates a specified call.
 *
 * @param {talk.media.CallManager.Call} call The call to terminate.
 * @param {talk.media.CallManager.EndCause} cause The cause of the terminate.
 * @private
 */
talk.media.CallManager.prototype.sendTerminate_ = function(call, cause) {
  this.unstartedCalls_.remove(call.sessionId);

  var terminateMsg = [talk.media.CallManager.JingleMessage_.TERMINATE,
        call.remoteJids[0],
        call.sessionId,
        cause];
  this.sendJingleMsg(terminateMsg);
};


/**
 * Clears the function waiting for the outgoing call to time out, if there is
 * one.
 *
 * @private
 */
talk.media.CallManager.prototype.clearTimeout_ = function() {
  this.callStartTimer_.stop();
};


/**
 * Creates an event indicating a jingle message should be sent to the server.
 *
 * @param {Object|Array|string} jingleMsg The message to send to the server.
 */
talk.media.CallManager.prototype.sendJingleMsg = function(jingleMsg) {
  // TODO(jessan): Can remove unnecessary parsing here to improve perf

  if (typeof jingleMsg == 'string') {
    jingleMsg = goog.json.parse(jingleMsg);
  }

  // Initiate and accept currently come from flash, so we update our state
  // when we hear a request to send these messages to the server.
  if (this.activeCall_ && jingleMsg[2] == this.activeCall_.sessionId) {
    if (jingleMsg[0] == talk.media.CallManager.JingleMessage_.INITIATE) {
      this.activeCall_.state = talk.media.CallManager.Call.State.OUTGOING_RING;
    } else if (jingleMsg[0] == talk.media.CallManager.JingleMessage_.ACCEPT) {

      /*
       * For single user calls, the 'ja' comes from flash and thus does
       * not have the remote user's full JID. We update the message
       * to have the full JID as expected.
       */
      if (this.activeCall_.remoteJids.length == 1) {
        jingleMsg[1] = this.activeCall_.remoteJids[0];
      }
      this.activeCall_.state = talk.media.CallManager.Call.State.ACTIVE_CALL;
      this.dispatchEvent(new talk.media.CallManager.ActiveCallEvent());
    }
  }
  this.dispatchEvent(
      new talk.media.CallEvent(talk.media.CallManager.Event.OUTGOING_JINGLE,
      goog.json.serialize(jingleMsg)));
};


/**
 * Returns the last 'mf' message from flute.
 *
 * @return {string?} The version message.
 */
talk.media.CallManager.prototype.getFluteVersionInfo = function() {
  if (this.talkPlugin_) {
    return this.talkPlugin_.getFluteVersionInfoStr();
  }
  return null;
};


/**
 * Sends a message to the Google Talk Plugin.
 *
 * @param {string} fluteMsg Json message to be sent to flute.
 */
talk.media.CallManager.prototype.sendFluteMsg = function(fluteMsg) {
  if (this.isTalkPluginEnabled()) {
    this.talkPlugin_.sendMsg(fluteMsg);
  }
};


/**
 * Sets the number of milliseconds to wait for the remote party to accept before
 * timing out an outgoing ringing call.
 *
 * This will clear any currently active outgoing call timers.
 *
 * @param {number} time A positive number indicating number of ms to wait.
 */
talk.media.CallManager.prototype.setOutgoingCallTimeoutMs = function(time) {
  if (time > 0) {
    this.outgoingCallTimeoutMs_ = time;

    // Release the current timer if we have one
    if (this.callStartTimer_) {
      this.eventHandler_.unlisten(this.callStartTimer_, goog.Timer.TICK,
        this.onCallTimeout_);
      this.callStartTimer_.dispose();
    }

    // Prepare a timer with the new timeout interval constant
    this.callStartTimer_ = new goog.Timer(this.outgoingCallTimeoutMs_);
    this.eventHandler_.listen(this.callStartTimer_, goog.Timer.TICK,
        this.onCallTimeout_);
  }
};


/**
 * Determines whether or not this CallManager is handling an active call.
 *
 * @return {boolean} Whether or not there is an active call.
 */
talk.media.CallManager.prototype.hasActiveCall = function() {
  return !!this.activeCall_;
};


/**
 * Determines whether or not there is a current call anywhere on this computer
 * (any browser, tab, process, etc.).
 *
 * @return {boolean} Whether or not there is an active call.
 */
talk.media.CallManager.prototype.machineHasActiveCall = function() {
  return this.getMachineCallType() != talk.media.CallType.NONE;
};


/**
 * Tells the call manager to override the machinecall state reported by the talk
 * plugin.  This is necessary because jingle messages from the server queue up
 * and are all processed before the fs message coming up from flute acking a jt
 * is processed.  We do not want to reject those messages unnecesarily.  Also
 * sets a timeout so we do not ignore the flutestate forever.
 */
talk.media.CallManager.prototype.setPendingCallCleanup = function() {
  this.hasPendingCallCleanup_ = true;
  goog.Timer.callOnce(this.clearPendingCallCleanup_,
                      this.pendingCleanupTimeout_, this);
};


/**
 * Tells the call manager to no longer override the machinecall state reported
 * by the talk plugin.
 *
 * @private
 */
talk.media.CallManager.prototype.clearPendingCallCleanup_ = function() {
  this.hasPendingCallCleanup_ = false;
};


/**
 * The type of call currently going on this computer, or null if none.
 *
 * @return {talk.media.CallType} The call type.
 */
talk.media.CallManager.prototype.getMachineCallType = function() {
  if (this.hasPendingCallCleanup_ == true) {
    return talk.media.CallType.NONE;
  }
  if (this.hasActiveCall()) {
    return this.activeCall_.type;
  } else {
    return this.talkPlugin_ ?
        this.talkPlugin_.getMachineCallType() :
        talk.media.CallType.NONE;
  }
};


/**
 * Creates and returns a copy of the active call.
 *
 * @return {talk.media.CallManager.Call|undefined} A copy of the active call.
 */
talk.media.CallManager.prototype.getActiveCall = function() {
  if (this.activeCall_) {
    var theCall = new talk.media.CallManager.Call(this.activeCall_.remoteJids,
      this.activeCall_.type, this.activeCall_.sessionId);
    theCall.state = this.activeCall_.state;
    theCall.muted = this.activeCall_.muted;
    theCall.ssrcMap = this.activeCall_.ssrcMap;
    // active calls should have no queued messages.
  }
  return theCall;
};


/**
 * Checks if we are in call with the given user. Does a bare jid comparison.
 *
 * @param {string} jid The JID of the user we want to check.
 * @return {boolean} Whether or not we have an active call with that user.
 */
talk.media.CallManager.prototype.hasActiveCallWith = function(jid) {
  if (this.activeCall_ && talk.Jid.isValid(jid)) {
    jid = talk.Jid.barePart(jid);
    for (var i = 0; i < this.activeCall_.remoteJids.length; i++) {
      if (talk.Jid.barePart(this.activeCall_.remoteJids[i]) == jid) {
        return true;
      }
    }
  }
  return false;
};


/**
 * Checks to see if there is additional information to extract from the message.
 * @param {string} jingleJson The jingle message from the server.
 */
talk.media.CallManager.prototype.maybeExtractInfoFromJingleInitiate = function(
    jingleJson) {
  var jingle = new talk.media.CallEvent(
      talk.media.CallManager.Event.INCOMING_JINGLE,
      jingleJson);
  if (jingle.msgType == talk.media.CallManager.JingleMessage_.INITIATE) {
    return jingle.getParsedMsg()[5];
  }
  return null;
};


/**
 * Handles a jingle message from the server.
 *
 * @param {string} jingleJson The message from the server in json.
 */
talk.media.CallManager.prototype.handleJingleMsg = function(jingleJson) {
  var incomingJingle = new talk.media.CallEvent(
      talk.media.CallManager.Event.INCOMING_JINGLE, jingleJson);

  var jingleMsg = incomingJingle.getParsedMsg();
  var msgType = incomingJingle.msgType;
  talk.media.CallManager.logger_.info('Jingle message - receiving: ' +
      incomingJingle.msgType);

  // 'jf', 'jec', 'jsync' messages have no JID or sessionId in them
  if (msgType == talk.media.CallManager.JingleMessage_.INFO ||
      msgType == talk.media.CallManager.JingleMessage_.ENC_CONFIG) {
    this.sendFluteMsg(jingleJson);
  } else if (msgType ==
      talk.media.CallManager.JingleMessage_.SYNC_CAPABILITIES) {
     if (goog.isDefAndNotNull(this.getTalkPlugin())) {
      this.sendJingleMsg(this.getTalkPlugin().getFluteVersionInfo());
    }
  } else {
    // TODO(jessan): Make ack conform by including remote jid before sid
    var sessionId = msgType == talk.media.CallManager.JingleMessage_.ACK ?
        jingleMsg[1] : jingleMsg[2];
    this.maybeQueueJingleMessage_(sessionId, incomingJingle);
    if (this.activeCall_ && this.activeCall_.sessionId == sessionId) {
      this.processCallMessage_(sessionId, incomingJingle);
    }
  }
  this.dispatchEvent(incomingJingle);
};


/**
 * Processes a message from the server for a call that is either active or
 * becoming active.
 *
 * @param {string} sessionId The ID of the call.
 * @param {talk.media.CallEvent} message The jingle message.
 * @private
 */
talk.media.CallManager.prototype.processCallMessage_ = function(sessionId,
                                                                message) {
  var jingleMsg = message.getParsedMsg();
  var fromJid = jingleMsg[1];
  var jsonToFlute = message.json;
  switch (message.msgType) {
    case talk.media.CallManager.JingleMessage_.INITIATE:
      // We expect to have a pending call when handling an initiate
      var newCall = (/** @type talk.media.CallManager.Call */
          this.unstartedCalls_.get(sessionId));
      this.handleIncomingCall_(fromJid, newCall);
      break;
    case talk.media.CallManager.JingleMessage_.TERMINATE:
      this.handleTerminate_(sessionId, true, this.getEndCause_(jingleMsg[3]));
      break;
    case talk.media.CallManager.JingleMessage_.ACCEPT:
      if (this.activeCall_ && sessionId == this.activeCall_.sessionId) {
        this.clearTimeout_();
        this.activeCall_.state =
            talk.media.CallManager.Call.State.ACTIVE_CALL;
        this.dispatchEvent(new talk.media.CallManager.ActiveCallEvent());
        if (this.activeCall_.ssrcMap) {
          this.ssrcMapUpdated();
        }
      } else {
        talk.media.CallManager.logger_.warning(
            'Accept received for a non-active call');
      }
      break;
    case talk.media.CallManager.JingleMessage_.TRANSPORT:
      // For now, we might initiate an outgoing call not using call manager
      if (!this.activeCall_) {
        talk.media.CallManager.logger_.warning(
            'A call has been started not using CallManager');
      }
      break;
    case talk.media.CallManager.JingleMessage_.ACK:
      // We ack the 'jack' message so that the server can estimate the
      // latency in sending a message down to us
      this.sendJingleMsg(
          [talk.media.CallManager.JingleMessage_.ACK, sessionId]);
      // Extend the ack message with the current system time, so that the
      // latency from the browser to flute can be measured.
      jsonToFlute = goog.json.serialize(jingleMsg.concat([goog.now()]))
      break;
  }
  if (this.activeCall_ && this.activeCall_.sessionId == sessionId) {
    this.sendFluteMsg(jsonToFlute);
  }
};


/**
 * Processes a message from the server by queuing up messages for unstarted
 * calls.
 *
 * @param {string} sessionId The ID of the call.
 * @param {talk.media.CallEvent} message  The jingle message.
 * @return {boolean} Whether the message was queued.
 * @private
 */
talk.media.CallManager.prototype.maybeQueueJingleMessage_ =
    function(sessionId, message) {
  var jingleMsg = message.getParsedMsg();
  var fromJid = jingleMsg[1];
  var pendingCall = this.unstartedCalls_.get(sessionId);

  if (message.msgType == talk.media.CallManager.JingleMessage_.INITIATE) {

    if (pendingCall) {
      this.addToLog(
          'Received "jn" for an already pending call. This is not expected',
          talk.media.CallManager.LogCommentSeverity.WARNING);
    } else {
      var callType = ('v' == jingleMsg[3]) ?
          talk.media.CallType.VIDEO : talk.media.CallType.VOICE;
      pendingCall = new talk.media.CallManager.Call([fromJid], callType,
          sessionId);
      this.unstartedCalls_.set(sessionId, pendingCall);
    }
    this.sendJingleMsg([talk.media.CallManager.JingleMessage_.ACK, sessionId]);
  } else if (message.msgType == talk.media.CallManager.JingleMessage_.START) {
    if (pendingCall) {
      while (!pendingCall.queuedJingleMessages.isEmpty()) {
        this.processCallMessage_(pendingCall.sessionId,
            pendingCall.queuedJingleMessages.dequeue());
      }
      this.unstartedCalls_.remove(pendingCall.sessionId);
    } else {

      // If we see this in practice, we should send a terminate here.
      this.addToLog(
          'Received "jstart" message before initiate message. Call will fail',
          talk.media.CallManager.LogCommentSeverity.ERROR);
    }

    // The call is started now, and thus no longer pending.
    pendingCall = null;
  } else if (message.msgType ==
             talk.media.CallManager.JingleMessage_.TERMINATE) {
    this.unstartedCalls_.remove(sessionId);
  }

  if (pendingCall) {
    pendingCall.queuedJingleMessages.enqueue(message);
    return true;
  }
  return false;
};


/**
 * Converts an integer code for a call end cause into an EndCause.
 * @param {number} endCauseNumber The integer representation of the EndCause.
 * @return {talk.media.CallManager.EndCause} The EndCause.
 * @private
 */
talk.media.CallManager.prototype.getEndCause_ = function(endCauseNumber) {
  var endCauseStr = talk.media.CallManager.intCodeToEndCause_[endCauseNumber];
  if (goog.isDefAndNotNull(talk.media.CallManager.EndCause[endCauseStr])) {
    return talk.media.CallManager.EndCause[endCauseStr];
  }
  return talk.media.CallManager.EndCause.UNKNOWN;
};


/**
 * Handles our outgoing call hitting the max time we will wait for a response.
 *
 * @private
 */
talk.media.CallManager.prototype.onCallTimeout_ = function() {
  if (this.activeCall_ &&
      this.activeCall_.state != talk.media.CallManager.Call.State.ACTIVE_CALL) {
    this.doEndCall_(talk.media.CallManager.EndCause.TIMEOUT);
  } else {
    talk.media.CallManager.logger_.warning(
        'onCallTimeout_(): not in timed-out state');
  }
  this.clearTimeout_();
};


/**
 * Starts a new incoming call.
 *
 * @param {string} fromJid The jid initiating the call.
 * @param {talk.media.CallType} callType The type of call.
 * @param {string} opt_sessionId The ID of the call being initiated.
 * @param {boolean} opt_timeout Whether to use a timeout to close the player.
 * @return {boolean} Whether we were able to start the call.
 */
talk.media.CallManager.prototype.startIncomingCall = function(
    fromJid, callType, opt_sessionId, opt_timeout) {
  var newCall = new talk.media.CallManager.Call([fromJid], callType,
      opt_sessionId);
  return this.handleIncomingCall_(fromJid, newCall);
};


/**
 * Handles the start of an incoming call.
 *
 * @param {string} fromJid The jid initiating the call.
 * @param {talk.media.CallManager.Call} newCall The call that is starting.
 * @param {boolean} opt_timeout Whether to use a timeout to close the player.
 * @return {boolean} Whether we were able to start the call.
 * @private
 */
talk.media.CallManager.prototype.handleIncomingCall_ =
    function(fromJid, newCall, opt_timeout) {
  var sessionId = newCall.sessionId;
  var callType = newCall.type;
  // Show no UI if talk plugin is not enabled, immediate terminate.
  if (!this.isTalkPluginEnabled()) {
    this.sendTerminate_(newCall,
        talk.media.CallManager.EndCause.FLUTE_NOT_ENABLED);
    talk.media.CallManager.logger_.severe(
        'Terminating call, plugin is not enabled');
  } else {
    this.maybeHandleSimultaneousInvite_(fromJid, sessionId);

    this.dispatchEvent(new talk.media.CallManager.NewCallEvent(false,
        fromJid, sessionId, callType));
    if (!this.machineHasActiveCall()) {
      newCall.state = talk.media.CallManager.Call.State.INCOMING_RING;
      if (opt_timeout) {
        this.callStartTimer_.start();
      }
      this.activeCall_ = newCall;
      return true;
    } else {
      this.sendTerminate_(newCall, talk.media.CallManager.EndCause.BUSY);
    }
  }
  return false;
};


/**
 * Handles the scenario where both users send invites to each other together.
 * To avoid having both sides return busy, the jingle spec says the call with
 * the lower session id overrides the other.  So if the incoming invite has
 * lower id, kill our pending.
 *
 * @param {string} fromJid the JID of the remote participant.
 * @param {string} sessionId The ID of the incoming call.
 * @private
 */
talk.media.CallManager.prototype.maybeHandleSimultaneousInvite_ = function(
    fromJid, sessionId) {
  if (this.hasActiveCallWith(fromJid) &&
      this.activeCall_.state ==
          talk.media.CallManager.Call.State.OUTGOING_RING &&
      sessionId < this.activeCall_.sessionId) {
    this.handleTerminate_(this.activeCall_.sessionId, false,
                          talk.media.CallManager.EndCause.TIE_BREAK);
    this.setPendingCallCleanup();
  }
};


/**
 * Handles the end of a call.
 *
 * @param {string} sessionId The ID of the call being ended.
 * @param {boolean} isRemote Whether or not the terminate came from the remote
 *     party.
 * @param {talk.media.CallManager.EndCause} cause The cause of the terminate.
 * @private
 */
talk.media.CallManager.prototype.handleTerminate_ = function(sessionId,
    isRemote, cause) {
  this.unstartedCalls_.remove(sessionId);
  if (this.activeCall_ && this.activeCall_.sessionId == sessionId) {
    this.clearTimeout_();
    this.clearVadSwitchingTimeout_();
    if (this.activeCall_.ssrcMap) {
      // Update the entries in the SSRC map; they now need to be added again
      // to the Flute in case we start a new call within the same chat mole.
      var jids = this.activeCall_.ssrcMap.getKeys();
      for (var i = 0; i < jids.length; i++) {
        var mapEntry = this.activeCall_.ssrcMap.get(jids[i]);
        mapEntry.update = true;
        mapEntry.audioSsrc = null;
        mapEntry.videoSsrc = null;
        mapEntry.newAudioSsrc = null;
        mapEntry.newVideoSsrc = null;
      }
    }
    if (this.isTalkPluginEnabled() &&
        (isRemote || cause != talk.media.CallManager.EndCause.FLUTE_ENDED)) {

      this.talkPlugin_.terminateCall(this.activeCall_.remoteJids[0],
                                     this.activeCall_.sessionId,
                                     cause, isRemote);
    }
    this.dispatchEvent(
        new talk.media.CallManager.CallEndedEvent(cause, isRemote, sessionId));
    this.activeCall_ = null;
  } else {
    talk.media.CallManager.logger_.warning(
            'Received a terminate for a nonactive call');
  }
};


/**
 * Sets the Google Talk Plugin with which this CallManager will communicate.
 *
 * @param {talk.media.TalkPlugin} talkPlugin The Google Talk Plugin.
 */
talk.media.CallManager.prototype.setTalkPlugin = function(talkPlugin) {
  if (this.talkPlugin_) {
    this.eventHandler_.removeAll();
    this.talkPlugin_.setParentEventTarget(null);
  }
  this.talkPlugin_ = talkPlugin;
  this.eventHandler_.listen(this.talkPlugin_,
      talk.media.TalkPluginEvent.ERROR,
      this.handleTalkPluginErrorMsg_);
  this.eventHandler_.listen(this.talkPlugin_,
      talk.media.TalkPluginEvent.VERSION,
      this.handleTalkPluginVersionMsg_);
  this.eventHandler_.listen(this.talkPlugin_,
      talk.media.TalkPluginEvent.END_CALL,
      this.handleTalkPluginEndCallMsg_);
  this.eventHandler_.listen(this.talkPlugin_,
      talk.media.TalkPluginEvent.MESSAGE,
      this.handleTalkPluginMessage_);
  this.eventHandler_.listen(this.talkPlugin_,
      talk.media.TalkPluginEvent.FLUTESTATE_CHANGED,
      this.clearPendingCallCleanup_);
  this.talkPlugin_.setParentEventTarget(this);
};


/**
 * @return {talk.media.TalkPlugin} The Google Talk Plugin with which this
 *     CallManager is communicating.
 */
talk.media.CallManager.prototype.getTalkPlugin = function() {
  return this.talkPlugin_;
};


/**
 * Determines whether or not the Google Talk Plugin is installed.
 *
 * @return {boolean} Whether or not the Google Talk Plugin is installed.
 */
talk.media.CallManager.prototype.isTalkPluginInstalled = function() {
  return !!this.talkPlugin_ && this.talkPlugin_.isInstalled();
};


/**
 * Determines whether or not the Google Talk Plugin is enabled.
 *
 * @return {boolean} Whether or not the Google Talk Plugin is enabled.
 */
talk.media.CallManager.prototype.isTalkPluginEnabled = function() {
  return !!this.talkPlugin_ && this.talkPlugin_.isConnected();
};


/**
 * Determines whether or not the Google Talk Plugin is re-connecting (i.e.,
 * after a crash).
 *
 * @return {boolean} Whether or not the Google Talk Plugin is re-connecting.
 */
talk.media.CallManager.prototype.isTalkPluginRecovering = function() {
  return !!this.talkPlugin_ && this.talkPlugin_.isRecovering();
};


/**
 * Handles an mf version message from the Talk Plugin connection.
 *
 * @param {talk.media.TalkPlugin.VersionEvent} e Talk Plugin Version info.
 * @private
 */
talk.media.CallManager.prototype.handleTalkPluginVersionMsg_ = function(e) {
  this.sendJingleMsg(e.json);
};


/**
 * Handles an fe flute error message from the Talk Plugin connection.
 *
 * @param {talk.media.TalkPlugin.ErrorEvent} e Talk Plugin error data.
 * @private
 */
talk.media.CallManager.prototype.handleTalkPluginErrorMsg_ = function(e) {
  if (this.activeCall_ && e.errorData[2] == this.activeCall_.sessionId) {
    talk.media.CallManager.logger_.info('Received flute error of type ' +
        e.errorData[3] + '.');

    this.doEndCall_(
        e.errorData[3] == talk.media.TalkPluginErrorCodes.CONNECTIVITY_LOST ?
        talk.media.CallManager.EndCause.CONNECTIVITY_LOST :
        talk.media.CallManager.EndCause.ERROR);

  }
};


/**
 * Handles an end call flute message from the Talk Plugin connection.
 *
 * @private
 */
talk.media.CallManager.prototype.handleTalkPluginEndCallMsg_ = function() {
  if (this.activeCall_) {
    // Forward a 'jt' so the other side shuts down properly, and do js level
    // call cleanup.
    this.doEndCall_(talk.media.CallManager.EndCause.FLUTE_ENDED);
  }
};


/**
 * Handles other plugin messages.
 *
 * @param {talk.media.CallEvent} e The message event.
 * @private
 */
talk.media.CallManager.prototype.handleTalkPluginMessage_ = function(e) {
  if (e.msgType == talk.media.TalkPluginEvent.AUDIO_INFO) {
    this.handleTalkPluginAudioInfoMsg_(e);
  } else if (e.msgType == talk.media.TalkPluginEvent.DEAD) {
    if (this.activeCall_) {
      talk.media.CallManager.logger_.info('Flute crashed while in a call');
      this.doEndCall_(talk.media.CallManager.EndCause.ERROR);
    }
  } else if (e.msgType == talk.media.TalkPluginEvent.UPLOAD_LOG_RESPONSE) {
    this.dispatchUploadLogCompleted_(e);
  } else if (talk.media.CallManager.PluginServerMessage_[e.msgType]) {
    this.sendJingleMsg(e.json);
  }
};


/**
 * Gets the information from the event and dispatches the upload log
 * completed event with the extracted data.
 *
 * @param {talk.media.CallEvent} e The message event.
 * @private
 */
talk.media.CallManager.prototype.dispatchUploadLogCompleted_ = function(e) {
  var data = e.getParsedMsg();

  var jid = data[1];
  var id = data[2];
  var status = data[3];
  var incidentId = data[4];

  this.dispatchEvent(
      new talk.media.CallManager.UploadLogCompleteEvent(
         jid, id, status, incidentId));
};


/**
 * Handles a flute audio info message from the Talk Plugin connection.
 *
 * @param {talk.media.CallEvent} e Talk Plugin audio info.
 * @private
 */
talk.media.CallManager.prototype.handleTalkPluginAudioInfoMsg_ = function(e) {
  // We only care about this message when we are in a multi user call.
  if (this.activeCall_ && this.activeCall_.ssrcMap) {
    var userVolumes = e.getParsedMsg()[
        talk.media.AUDIO_INFO_SPEAKERS_PARAM][
        talk.media.AUDIO_INFO_SPEAKERS_VOLUMES];
    if (!userVolumes || userVolumes.length <= 0) {
      return;
    }
    // Get the array of users and volumes for this instant.
    this.activeCall_.userVolumes = userVolumes;
    // Handle VAD switching.
    this.doVadSwitching_();
  }
};


/**
 * Do VAD switching by finding the loudest speaker and switching to that
 * user's video stream. A grace period prevents switching too frequently.
 * This is only used for multi-user calls.
 *
 * @private
 */
talk.media.CallManager.prototype.doVadSwitching_ = function() {
  // Are we allowed to VAD switch right now?
  if (!this.activeCall_.vadSwitchingAllowed) {
    return;
  }

  // Find the loudest speaker, if one exists.
  var loudestJid = this.activeCall_.getLoudestSpeaker();

  // Did the loudest speaker change?
  if (loudestJid && (loudestJid != this.activeCall_.currentShownJid)) {
    this.dispatchEvent(new talk.media.CallManager.SpeakerChangedEvent(
        loudestJid));
    // Show the video stream for the loudest JID.
    this.showJid_(loudestJid);
    // Disallow VAD switching for a short period of time
    // to prevent switching video streams too frequently.
    this.activeCall_.vadSwitchingAllowed = false;
    this.vadSwitchingTimeoutFn_ =
        goog.Timer.callOnce(this.vadSwitchingTimeout_,
        talk.media.CallManager.VAD_SWITCH_TIMEOUT_, this);
  }
};


/**
 * Controls whether to record audio input on the active call.
 *
 * @param {boolean} mute True if the call should be muted.
 */
talk.media.CallManager.prototype.setMicrophoneMute = function(mute) {
  var call = this.activeCall_;
  if (call && mute != call.muted) {
    call.muted = mute;
    // NB: Currently flute just toggles the mute state of the call, but
    // we send the explicit true false value anyway.
    this.sendFluteMsg(goog.json.serialize(['mute', call.remoteJids[0],
        call.sessionId, call.muted]));
    this.dispatchEvent(new talk.media.CallManager.MicMuteEvent(call.muted));
  }
};


/**
 * Returns the current state of microphone mute for the active call.
 *
 * @return {boolean} True if the microphone is muted, otherwise false.
 */
talk.media.CallManager.prototype.getMicrophoneMute = function() {
  return goog.isDefAndNotNull(this.activeCall_) && this.activeCall_.muted;
};


/**
 * Allows the active video stream to be switched.
 *
 * @private
 */
talk.media.CallManager.prototype.vadSwitchingTimeout_ = function() {
  this.activeCall_.vadSwitchingAllowed = true;
  this.vadSwitchingTimeoutFn_ = null;
};


/**
 * Clears the function waiting for the VAD switching timeout to expire,
 * if there is one.
 *
 * @private
 */
talk.media.CallManager.prototype.clearVadSwitchingTimeout_ = function() {
  if (this.vadSwitchingTimeoutFn_) {
    goog.Timer.clear(this.vadSwitchingTimeoutFn_);
    this.vadSwitchingTimeoutFn_ = null;
  }
};


/**
 * Shows the video stream from the given JID.
 *
 * @param {string} jid The JID whose video to show.
 * @private
 */
talk.media.CallManager.prototype.showJid_ = function(jid) {
  var mapEntry = this.activeCall_.ssrcMap.get(jid);
  if (mapEntry.videoSsrc) {
    this.dispatchEvent(new talk.media.CallManager.ShowVideoEvent(
            mapEntry.videoSsrc, this.activeCall_.sessionId));
  } else {
    this.dispatchEvent(new talk.media.CallManager.ShowAvatarEvent(
                       talk.Jid.barePart(jid)));
    // TODO(mikaeld): For an N:N video call, there will still be a video SSRC
    // allocated for users not sending video (e.g. due to no camera), so this
    // statement will unfortunately not be reached in N:N video calls. We need
    // to fix this somehow in order for the avatars to work also in such calls.
  }
  this.activeCall_.currentShownJid = jid;
};


/**
 * Shows the video stream from any other JID than the given one,
 * provided there exists another JID with a valid video stream.
 *
 * @param {string} jid The JID not to show video from.
 * @private
 */
talk.media.CallManager.prototype.switchDisplayedStream_ = function(jid) {
  // TODO(mikaeld): We may want a better algorithm for this later,
  // but for now just pick the first valid video stream we find.
  var jids = this.activeCall_.ssrcMap.getKeys();
  // Sort the JIDs so that the stream chosen will be the same in every client.
  jids.sort();
  for (var i = 0; i < jids.length; i++) {
    if (jid != jids[i]) {
      var mapEntry = this.activeCall_.ssrcMap.get(jids[i]);
      if (mapEntry.videoSsrc) {
        this.showJid_(jids[i]);
        return;
      }
    }
  }
  this.activeCall_.currentShownJid = null;
};


/**
 * Adds media streams for given JID to the Flute.
 *
 * @param {string} jid The JID owning the streams.
 * @param {goog.structs.Map} ssrcMap The SSRC map.
 * @private
 */
talk.media.CallManager.prototype.fluteAddStreams_ = function(jid, ssrcMap) {
  var mapEntry = ssrcMap.get(jid);
  talk.media.CallManager.logger_.info('SSRC add ' +
      '{' + mapEntry.audioSsrc + ', ' + mapEntry.videoSsrc + '} for ' + jid);
  this.sendFluteMsg(goog.json.serialize([
      'jsa', this.activeCall_.remoteJids[0], this.activeCall_.sessionId,
      mapEntry.audioSsrc ? mapEntry.audioSsrc : '0',
      mapEntry.videoSsrc ? mapEntry.videoSsrc : '0'
      ]));

  // Could be a voice call.
  if (mapEntry.videoSsrc) {
    this.dispatchEvent(new talk.media.CallManager.AddVideoEvent(
            mapEntry.videoSsrc, this.activeCall_.sessionId));
  }
};


/**
 * Removes media streams for given JID from the Flute.
 *
 * @param {string} jid The JID owning the streams.
 * @param {goog.structs.Map} ssrcMap The SSRC map.
 * @private
 */
talk.media.CallManager.prototype.fluteRemoveStreams_ = function(jid, ssrcMap) {
  var mapEntry = ssrcMap.get(jid);
  talk.media.CallManager.logger_.info('SSRC remove ' +
      '{' + mapEntry.audioSsrc + ', ' + mapEntry.videoSsrc + '} for ' + jid);
  this.sendFluteMsg(goog.json.serialize([
      'jsr', this.activeCall_.remoteJids[0], this.activeCall_.sessionId,
      mapEntry.audioSsrc ? mapEntry.audioSsrc : '0',
      mapEntry.videoSsrc ? mapEntry.videoSsrc : '0'
      ]));
  this.dispatchEvent(new talk.media.CallManager.RemoveVideoEvent(
      mapEntry.videoSsrc, this.activeCall_.sessionId));
};


/**
 * Sets the SSRC map for the active call.
 *
 * @param {goog.structs.Map} ssrcMap The SSRC map.
 */
talk.media.CallManager.prototype.setSsrcMap = function(ssrcMap) {
  // Set a reference to the chat's SSRC map. We need to maintain it in
  // the Chat as it may be updated before we have a call going, but
  // once we have the call we also need access to it from CallManager.
  if (this.activeCall_) {
    this.activeCall_.ssrcMap = ssrcMap;
  }
};


/**
 * Updates the SSRC to JID mappings in the Flute, adding and removing media
 * streams appropriately. If no specific JID is given, all JIDs currently in
 * the map will be updated as needed.
 *
 * @param {string} opt_jid The JID owning the streams. If no JID is specified,
 *     all JIDs in the map will be updated as needed.
 */
talk.media.CallManager.prototype.ssrcMapUpdated = function(opt_jid) {
  if (!this.activeCall_ || !this.activeCall_.ssrcMap) {
    return;
  }

  // Create list of jids to process.
  var jids;
  if (opt_jid) {
    jids = [opt_jid];
  } else {
    jids = this.activeCall_.ssrcMap.getKeys();
  }

  // Get the number of video senders before the update.
  var numSenders = this.activeCall_.getNumberOfVideoSenders();

  // Process the SSRC map and add/remove media streams from Flute accordingly.
  for (var i = 0; i < jids.length; i++) {
    var jid = jids[i];
    var mapEntry = this.activeCall_.ssrcMap.get(jid);
    talk.media.CallManager.logger_.info('SSRC map update for ' + jid);
    if (mapEntry && mapEntry.update) {
      // Remove the old SSRCs?
      if ((mapEntry.audioSsrc && mapEntry.audioSsrc != mapEntry.newAudioSsrc) ||
          (mapEntry.videoSsrc && mapEntry.videoSsrc != mapEntry.newVideoSsrc)) {
        // Remove the old SSRCs.
        this.fluteRemoveStreams_(jid, this.activeCall_.ssrcMap);
        mapEntry.audioSsrc = null;
        mapEntry.videoSsrc = null;
        // If this JID's video stream is currently shown, we need to
        // turn on some other video stream to prevent frozen images.
        if (jid == this.activeCall_.currentShownJid) {
          this.switchDisplayedStream_(jid);
        }
      }
      // Add the new SSRCs?
      if (mapEntry.newAudioSsrc || mapEntry.newVideoSsrc) {
        // Add the new SSRCs.
        if (mapEntry.newAudioSsrc != mapEntry.audioSsrc ||
            mapEntry.newVideoSsrc != mapEntry.videoSsrc) {
          mapEntry.audioSsrc = mapEntry.newAudioSsrc;
          mapEntry.videoSsrc = mapEntry.newVideoSsrc;
          this.fluteAddStreams_(jid, this.activeCall_.ssrcMap);
          // Show the video stream just added.
          if (mapEntry.videoSsrc) {
            this.showJid_(jid);
          }
        }
      }
      // If entry has no SSRCs, we can remove the entire entry.
      if (!mapEntry.audioSsrc && !mapEntry.videoSsrc) {
        this.activeCall_.ssrcMap.remove(jid);
      } else {
        mapEntry.update = false;
      }
    }
  }

  if (this.activeCall_.useVideoBandwidthLimitation()) {
    // Get the number of video senders after the update, if they differ then
    // calculate and re-set the amount of bandwidth to use for sending video.
    var numSendersNow = this.activeCall_.getNumberOfVideoSenders();
    if (numSendersNow != numSenders) {
      var bw = this.activeCall_.calculateVideoSendBandwidth();
      if (bw) {
        this.setVideoSendBandwidth_(bw);
      }
    }
  }
};


/**
 * Sets the video bandwidth limits for the active call. This only applies to
 * N:N calls and is intended for experimental use, and this functionality will
 * eventually be superseded by the backend Conference Manager.
 *
 * @param {number} totalVideoBandwidthKbps The total video bandwidth in kbps
 *     allowed for the active call. Clients will reduce their own bandwidth when
 *     sending video to ensure the aggregated bandwidth does not exceed this.
 * @param {number} maxVideoSendBandwidthKbps The max video bandwidth in kbps.
 * @param {number} minVideoSendBandwidthKbps The min video bandwidth in kbps.
 * @return {boolean} Whether the video bandwidth limits were applied.
 */
talk.media.CallManager.prototype.setVideoBandwidthLimits = function(
    totalVideoBandwidthKbps, maxVideoSendBandwidthKbps,
    minVideoSendBandwidthKbps) {
  if (!this.activeCall_) {
    talk.media.CallManager.logger_.warning(
        'No active call, cannot set video bandwidth limits.');
    return false;
  }

  var wasSet = this.activeCall_.setVideoBandwidthLimits(
      totalVideoBandwidthKbps, maxVideoSendBandwidthKbps,
      minVideoSendBandwidthKbps);

  talk.media.CallManager.logger_.info('Video bandwidth limits (in kbps)' +
      ', total: ' + totalVideoBandwidthKbps +
      ', max: ' + maxVideoSendBandwidthKbps +
      ', min: ' + minVideoSendBandwidthKbps +
      ', ' + (wasSet ? 'applied.' : 'could not be applied.'));

  return wasSet;
};


/**
 * Determines if O3D should be used for rendering instead of Flash. (Which is
 * the case whenever we can use it.)
 *
 * @return {boolean} True iff both plugin and browser support O3D
 *     rendering.
 */
talk.media.CallManager.prototype.useClient3D = function() {
  return this.canUseClient3D();
};


/**
 * Determines if O3D can be used for rendering.
 *
 * @return {boolean} True iff both plugin and browser support O3D
 *     rendering.
 */
talk.media.CallManager.prototype.canUseClient3D = function() {
  return this.isTalkPluginEnabled() &&
         this.talkPlugin_.canUseClient3D() &&
         this.getCallingRequirements().canUseClient3D();
};


/**
 * Determines if Flash can be used for rendering.
 *
 * @return {boolean} True iff both plugin and browser support Flash
 *     rendering.
 */
talk.media.CallManager.prototype.canUseFlash = function() {
  return this.isTalkPluginEnabled() &&
         this.talkPlugin_.canUseFlash() &&
         this.getCallingRequirements().canUseFlash();
};


/**
 * Sets the maximum bandwidth to use when sending video.
 *
 * @param {number} bandwidthKbps The maximum bandwidth in kbps.
 * @private
 */
talk.media.CallManager.prototype.setVideoSendBandwidth_ = function(
    bandwidthKbps) {
  if (!this.activeCall_ || !bandwidthKbps) {
    return;
  }

  this.sendFluteMsg(goog.json.serialize([
      'jshow', this.activeCall_.remoteJids[0], this.activeCall_.sessionId,
      { 'maxBandwidth': bandwidthKbps * 1024 }]));
  talk.media.CallManager.logger_.info('Video sending bandwidth set to ' +
      bandwidthKbps + ' kbps.');
};


/**
 * Sends a message to the plugin to upload the error log of the call with the
 * specified session id.
 *
 * @param {string} sessionId The session id of the call.
 * @param {string} opt_chatJid The jid of the chat.
 */
talk.media.CallManager.prototype.doUploadLog = function(sessionId,
    opt_chatJid) {
  // TODO(dape): This fix is for the supermole team; we should contact them
  // to that they pass in the chatJid. Setting jid to 'unknown' will cause the
  // upload to succeed but avoid the chat from chat.crash@google.com.
  var jid = opt_chatJid || 'unknown';
  this.sendFluteMsg(goog.json.serialize(['uploadlog', jid, sessionId]));
};


/**
 * {@inheritDoc}
 */
talk.media.CallManager.prototype.dispose = function() {
  if (!this.getDisposed()) {
    this.doEndCall_(talk.media.CallManager.EndCause.USER_ENDED);
    talk.media.CallManager.superClass_.dispose.call(this);
    this.callStartTimer_.dispose();
    this.callStartTimer_ = null;
    this.eventHandler_.dispose();
    this.eventHandler_ = null;
  }
};


/**
 * An object representing a call.
 *
 * @param {Array.<string>} remoteJids The other users in the call.
 * @param {talk.media.CallType} type The kind of call.
 * @param {string} opt_sessionId The ID of the call. Generates a sessionId if
 *      not provided.
 * @constructor
 */
talk.media.CallManager.Call = function(remoteJids, type, opt_sessionId) {
   // Check that the JIDs supplied are valid.
  for (var i = 0; i < remoteJids.length; i++) {
    if (!talk.Jid.isValid(remoteJids[i])) {
      talk.media.CallManager.logger_.warning(
          'Invalid JID, ' + remoteJids[i] + ', in the array of remoteJids');
      return;
    }
  }

  /**
   * JIDs of other users in the call -- should just have one value for now.
   *
   * @type {Array.<string>}
   */
  this.remoteJids = remoteJids;

  /**
   * The session ID of the call.
   *
   * @type {string}
   */
  this.sessionId = opt_sessionId || talk.media.CallManager.Call.generateId_();

  /**
   * The state of the call.
   *
   * @type {talk.media.CallManager.Call.State}
   */
  this.state = talk.media.CallManager.Call.State.UNINITIALIZED;

  /**
   * The type of the call.
   *
   * @type {talk.media.CallType}
   */
  this.type = type;

  /**
   * @type {boolean}
   */
  this.muted = false;

  /**
   * @type {!goog.structs.Queue}
   */
  this.queuedJingleMessages = new goog.structs.Queue();

  // TODO(mikaeld): copy the values below in getActiveCall() once we use them

  /**
   * Volume levels of current speakers.
   *
   * @type {!Array}
   */
  this.userVolumes = [];

  /**
   * Flag allowing or disallowing VAD switching.
   *
   * @type {boolean}
   */
  this.vadSwitchingAllowed = true;
};

/**
 * The currently shown JID.
 *
 * @type {?string}
 */
talk.media.CallManager.Call.prototype.currentShownJid;

/**
 * Contains SSRC to JID mappings.
 *
 * @type {goog.structs.Map}
 */
talk.media.CallManager.Call.prototype.ssrcMap;


/**
 * The different states that a call can be in. Matches states in CallSession.as.
 *
 * @enum {number}
 */
talk.media.CallManager.Call.State = {
   /**
    * The state of the call has not yet been set. No communication between the
    * parties has yet happened.
    */
   UNINITIALIZED: 0,

   /**
    * The call is incoming from a remote user.
    */
   INCOMING_RING: 1,

   /**
    * The call is going to a remote user.
    */
   OUTGOING_RING: 2,

   /**
    * The call is active, both sides are sending data.
    */
   ACTIVE_CALL: 3,

   /**
    * The call is on hold. This is not currently used in Gmail.
    */
   CALL_ON_HOLD: 4
};


/**
 * Whether to impose a client side video bandwidth limitation.
 *
 * @type {boolean}
 * @private
 */
talk.media.CallManager.Call.prototype.useVideoBandwidthLimitation_ = false;


/**
 * The total bandwidth in kbps that should be allowed for all video streams in
 * an N:N call. Clients will reduce their own bandwidth when sending video to
 * ensure the aggregated bandwidth does not exceed this value.
 *
 * @type {?number}
 * @private
 */
talk.media.CallManager.Call.prototype.totalVideoBandwidthKbps_;


/**
 * The maximum bandwidth in kbps a single client should be allowed to use when
 * sending video in an N:N call.
 *
 * @type {?number}
 * @private
 */
talk.media.CallManager.Call.prototype.maxVideoSendBandwidthKbps_;


/**
 * The minimum bandwidth in kbps a single client should be allowed to use when
 * sending video in an N:N call.
 *
 * @type {?number}
 * @private
 */
talk.media.CallManager.Call.prototype.minVideoSendBandwidthKbps_;


/**
 * Generates a sessionId for a call.
 *
 * @return {string} A sessionId.
 * @private
 */
talk.media.CallManager.Call.generateId_ = function() {
  return 'c' + Math.round(Math.random() * 2147483648);
};


/**
 * Returns the loudest speaker in the call, or null if no one is speaking.
 *
 * @return {string?} The JID of the loudest speaker.
 */
talk.media.CallManager.Call.prototype.getLoudestSpeaker = function() {
  // TODO(mikaeld): Improve the VAD switching not to react on minor noises
  // originating from someone who is not really speaking. For now, we use
  // a treshold slightly larger than 0 as the loudest speaker, and assume
  // the real speaker will speak louder than this and thus trigger the VAD.
  var loudestVolume = 1;
  var loudestJid = null;

  // Find the loudest speaker.
  for (var i = 0; i < this.userVolumes.length; i++) {
    var jid = this.getJidForAudioSsrc(this.userVolumes[i][0]);
    if (jid) {
      var mapEntry = this.ssrcMap.get(jid);
      if (this.userVolumes[i][1] > loudestVolume) {
        loudestVolume = this.userVolumes[i][1];
        loudestJid = jid;
      }
    }
  }
  return loudestJid;
};


/**
 * Returns the JID corresponding to a given audio SSRC.
 *
 * @param {string} audioSsrc The audio SSRC.
 * @return {string?} The JID corresponding to the audio SSRC.
 */
talk.media.CallManager.Call.prototype.getJidForAudioSsrc = function(audioSsrc) {
  var jids = this.ssrcMap.getKeys();
  for (var i = 0; i < jids.length; i++) {
    if (this.ssrcMap.get(jids[i]).audioSsrc == audioSsrc) {
      return jids[i];
    }
  }
  return null;
};


/**
 * Returns the JID corresponding to a given video SSRC.
 * Note that this function really returns a JID whereas the above function
 * getJidForAudioSsrc currently returns a nickname when in mgc and a jid when
 * in caribou.
 *
 * @param {string} videoSsrc The video SSRC.
 * @return {string?} The JID corresponding to the video SSRC.
 */
talk.media.CallManager.Call.prototype.getJidForVideoSsrc = function(videoSsrc) {
  // TODO(geer): Resolve the different identifications of nicks and jids.
  var jids = this.ssrcMap.getKeys();
  for (var i = 0; i < jids.length; i++) {
    var mapEntry = this.ssrcMap.get(jids[i]);
    if (mapEntry.videoSsrc == videoSsrc) {
      if (goog.isDefAndNotNull(mapEntry.userJid)) {
        return mapEntry.userJid;
      } else {
        return jids[i];
      }
    }
  }
  return null;
};


/**
 * Returns the number of audio senders in an active N:N call.
 *
 * @return {?number} The number of audio senders in the active N:N call,
 *     or null if no N:N call is in progress.
 */
talk.media.CallManager.Call.prototype.getNumberOfAudioSenders = function() {
  if (!this.isMultiway()) {
    return null;
  }

  var jids = this.ssrcMap.getKeys();
  var numSenders = (this.type == talk.media.CallType.VOICE ||
      this.type == talk.media.CallType.VIDEO) ? 1 : 0;

  for (var i = 0; i < jids.length; i++) {
    var mapEntry = this.ssrcMap.get(jids[i]);
    if (mapEntry.audioSsrc) {
      numSenders++;
    }
  }
  return numSenders;
};


/**
 * Returns the number of video senders in an active N:N call.
 *
 * @return {?number} The number of video senders in the active N:N call,
 *     or null if no N:N call is in progress.
 */
talk.media.CallManager.Call.prototype.getNumberOfVideoSenders = function() {
  if (!this.isMultiway()) {
    return null;
  }

  var jids = this.ssrcMap.getKeys();
  var numSenders = (this.type == talk.media.CallType.VIDEO) ? 1 : 0;

  for (var i = 0; i < jids.length; i++) {
    var mapEntry = this.ssrcMap.get(jids[i]);
    if (mapEntry.videoSsrc) {
      numSenders++;
    }
  }
  return numSenders;
};


/**
 * Calculates and returns the maximum bandwidth to use when sending video in an
 * active N:N call. If no limits have been set, zero will be returned.
 *
 * @return {?number} The maximum bandwidth to use in kbps.
 */
talk.media.CallManager.Call.prototype.calculateVideoSendBandwidth = function() {
  var numSenders = this.getNumberOfVideoSenders();
  if (!numSenders) {
    return this.maxVideoSendBandwidthKbps_;
  }

  // Calculate bandwidth share.
  var bwPerSenderKbps = Math.round(this.totalVideoBandwidthKbps_ / numSenders);

  // Clip bandwidth into permitted range.
  if (bwPerSenderKbps > this.maxVideoSendBandwidthKbps_) {
    return this.maxVideoSendBandwidthKbps_;
  } else if (bwPerSenderKbps < this.minVideoSendBandwidthKbps_) {
    return this.minVideoSendBandwidthKbps_;
  }

  return bwPerSenderKbps;
};


/**
 * Returns whether to use client side video bandwidth limitations in N:N calls.
 *
 * @return {boolean} Whether to use client side video bandwidth limitation.
 */
talk.media.CallManager.Call.prototype.useVideoBandwidthLimitation = function() {
  return this.useVideoBandwidthLimitation_;
};


/**
 * Sets the sending video bandwidth limits for this call.
 *
 * @param {number} totalVideoBandwidthKbps The total video bandwidth in kbps
 *     allowed for this call. Clients will reduce their own bandwidth when
 *     sending video to ensure the aggregated bandwidth does not exceed this.
 * @param {number} maxVideoSendBandwidthKbps The max video bandwidth in kbps.
 * @param {number} minVideoSendBandwidthKbps The min video bandwidth in kbps.
 * @return {boolean} Whether the video bandwidth limits were applied.
 */
talk.media.CallManager.Call.prototype.setVideoBandwidthLimits = function(
    totalVideoBandwidthKbps, maxVideoSendBandwidthKbps,
    minVideoSendBandwidthKbps) {
  // Basic sanity checking.
  if (minVideoSendBandwidthKbps <= 0 ||
      maxVideoSendBandwidthKbps < minVideoSendBandwidthKbps ||
      totalVideoBandwidthKbps < maxVideoSendBandwidthKbps) {
    return false;
  }

  // Apply limits.
  this.totalVideoBandwidthKbps_ = totalVideoBandwidthKbps;
  this.maxVideoSendBandwidthKbps_ = maxVideoSendBandwidthKbps;
  this.minVideoSendBandwidthKbps_ = minVideoSendBandwidthKbps;
  this.useVideoBandwidthLimitation_ = true;

  return true;
};


/**
 * Returns whether the call is an N:N call.
 *
 * @return {boolean} Whether the call is an N:N call.
 */
talk.media.CallManager.Call.prototype.isMultiway = function() {
  return !!this.ssrcMap;
};
