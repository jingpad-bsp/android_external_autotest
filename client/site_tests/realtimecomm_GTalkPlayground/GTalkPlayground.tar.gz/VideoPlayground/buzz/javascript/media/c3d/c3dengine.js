// Copyright 2008 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview A generic engine for driving a Client3D plugin object and
 * adding some simple services.
 *
 * @author tschmelcher@google.com (Tristan Schmelcher)
 */

goog.provide('talk.media.c3d.C3dEngine');
goog.provide('talk.media.c3d.C3dEngine.RenderCallback');

goog.require('goog.Timer');
goog.require('talk.media.c3d.C3dObject');

/**
 * Creates a generic engine for driving a Client3D plugin object and
 * adding some simple services.
 *
 * @param {number} opt_renderFps The number of frames per second for O3D to
 *     render. Default 30 fps.
 * @constructor
 */
talk.media.c3d.C3dEngine = function(opt_renderFps) {

  /**
   * The list of render callbacks currently registered.
   *
   * @type {Array}
   * @private
   */
  this.renderCallbacks_ = [];


  /**
   * A goog.bind()'ed version of our renderCallback_, suitable for passing to
   * C3D.
   *
   * @type {Function}
   * @private
   */
  this.boundRenderCallback_ = goog.bind(this.renderCallback_, this)


  /**
   * The number of frames per second for O3D to render. Default 30 fps.
   *
   * @type {number}
   * @private
   */
  this.renderFps_ = goog.isDefAndNotNull(opt_renderFps) ? opt_renderFps : 30;

  /**
   * The timer that triggers a render call.
   *
   * @type {goog.Timer}
   * @private
   */
  this.renderClock_ = new goog.Timer(
      this.renderFps_ > 0 ? 1000 / this.renderFps_ : undefined);
  this.renderClock_.addEventListener(goog.Timer.TICK, this.render, false, this);
};


/**
 * The Client3D plugin object.
 *
 * @type {talk.media.c3d.C3dObject}
 * @private
 */
talk.media.c3d.C3dEngine.prototype.c3dObject_;


/**
 * Sets the C3D plugin object to be managed by the engine.
 *
 * @param {talk.media.c3d.C3dObject} c3dObject The Client3D plugin object.
 */
talk.media.c3d.C3dEngine.prototype.setC3d = function(c3dObject) {
  if (this.c3dObject_ == c3dObject) {
    return;
  }
  if (this.c3dObject_ && this.renderCallbacks_.length > 0) {
    this.disableRenderCallback_();
  }
  this.c3dObject_ = c3dObject;
  if (this.c3dObject_ && this.renderCallbacks_.length > 0) {
    this.enableRenderCallback_();
  }
  if (this.c3dObject_) {
    var c3d = this.c3dObject_.getPlugin();
    c3d['client']['renderMode'] = c3d['o3d']['Client']['RENDERMODE_ON_DEMAND'];
    this.renderClock_.start();
  } else {
    this.renderClock_.stop();
  }
};


/**
 * Returns the C3D plugin object reference managed by the engine.
 *
 * @return {talk.media.c3d.C3dObject} The Client3D plugin object.
 */
talk.media.c3d.C3dEngine.prototype.getC3d = function() {
  return this.c3dObject_;
};


/**
 * Virtual base class for all pre-render operations.
 *
 * @constructor
 */
talk.media.c3d.C3dEngine.RenderCallback = function() {
};


/**
 * Called before rendering each frame.
 *
 * @param {number} time The amount of time since the last pre-render callback.
 * @param {boolean} Whether or not to keep this callback installed.
 */
talk.media.c3d.C3dEngine.RenderCallback.prototype.onRender =
    goog.abstractMethod;


/**
 * Sets up the render callback to be called before each frame is rendered.
 *
 * @private
 */
talk.media.c3d.C3dEngine.prototype.enableRenderCallback_ =
    function() {
  var c3d = this.c3dObject_.getPlugin();
  c3d['client']['setRenderCallback'](this.boundRenderCallback_);
};


/**
 * Tears down the render callback so that it is no longer called.
 *
 * @private
 */
talk.media.c3d.C3dEngine.prototype.disableRenderCallback_ =
    function() {
  if (this.c3dObject_.isScriptable()) {  // Might not be during shutdown
    var c3d = this.c3dObject_.getPlugin();
    c3d['client']['clearRenderCallback']();
  }
};


/**
 * Called before each frame is rendered to execute render callbacks (when
 * enabled).
 *
 * @private
 */
talk.media.c3d.C3dEngine.prototype.renderCallback_ =
    function(renderEvent) {
  var i = 0;
  while (i < this.renderCallbacks_.length) {
    var callback = this.renderCallbacks_[i];
    if (!callback.onRender(renderEvent['elapsedTime'])) {
      // This callback is done.
      this.unregisterRenderCallback(callback);
    } else {
      i++;
    }
  }
};


/**
 * Registers a new pre-render callback.
 *
 * @param {talk.media.c3d.C3dEngine.RenderCallback} callback The render
 *     callback.
 */
talk.media.c3d.C3dEngine.prototype.registerRenderCallback =
    function(callback) {
  var empty = this.renderCallbacks_.length == 0;
  this.renderCallbacks_.push(callback);
  if (this.c3dObject_ && empty) {
    this.enableRenderCallback_();
  }
};


/**
 * Unregisters an existing pre-render callback.
 *
 * @param {talk.media.c3d.C3dEngine.RenderCallback} callback The render
 *     callback.
 * @return {boolean} Whether it was found or not.
 */
talk.media.c3d.C3dEngine.prototype.unregisterRenderCallback =
    function(callback) {
  for (var i in this.renderCallbacks_) {
    if (this.renderCallbacks_[i] == callback) {
      this.renderCallbacks_.splice(i, 1);
      if (this.c3dObject_ && this.renderCallbacks_.length == 0) {
        this.disableRenderCallback_();
      }
      return true;
    }
  }
  return false;
};


/**
 * Unregisters all pre-render callbacks.
 */
talk.media.c3d.C3dEngine.prototype.unregisterAllRenderCallbacks = function() {
  var empty = this.renderCallbacks_.length > 0;
  this.renderCallbacks_ = [];
  if (this.c3dObject_ && !empty) {
    this.disableRenderCallback_();
  }
};


/**
 * Forces the O3D plugin to render the scene.
 */
talk.media.c3d.C3dEngine.prototype.render = function() {
  if (this.c3dObject_) {
    var c3d = this.c3dObject_.getPlugin();
    c3d['client']['render']();
  }
};
