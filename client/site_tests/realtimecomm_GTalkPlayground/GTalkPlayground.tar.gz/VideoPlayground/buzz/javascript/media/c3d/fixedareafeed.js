// Copyright 2009 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview Concrete feed class that positions the feed within a fixed
 * rectangle of screen space, making it as large as possible without distorting
 * the aspect ratio.
 *
 * @author tschmelcher@google.com (Tristan Schmelcher)
 */

goog.provide('talk.media.c3d.FixedAreaFeed');

goog.require('talk.media.c3d.AlphaTween');
goog.require('talk.media.c3d.BaseFeed');
goog.require('talk.media.c3d.easing');


/**
 * Concrete feed class that positions the feed within a fixed rectangle of
 * screen space, making it as large as possible without distorting the aspect
 * ratio. Also supports fading-in the feed.
 *
 * @param {talk.media.c3d.O3dBundle} o3dBundle The bundle of global resources
 * for this O3D instance.
 * @param {talk.media.c3d.StreamEndpoint} endpoint The StreamEndpoint that
 * provides the video/avatar for this feed.
 * @param {number} depth The depth at which to display this feed.
 * @param {number} x The x-coordinate of the origin.
 * @param {number} y The y-coordinate of the origin.
 * @param {number} width The width of the rectangle to draw in.
 * @param {number} height The height of the rectangle to draw in.
 * @extends {talk.media.c3d.BaseFeed}
 * @constructor
 */
talk.media.c3d.FixedAreaFeed = function(o3dBundle, endpoint, depth,
    x, y, width, height) {
  talk.media.c3d.BaseFeed.call(this, o3dBundle, endpoint, depth);

  this.setArea(x, y, width, height);
};
goog.inherits(talk.media.c3d.FixedAreaFeed, talk.media.c3d.BaseFeed);


/**
 * The size for avatar images, as a fraction of the available area. We make
 * avatars smaller than the full area because they aren't as important.
 *
 * @type {number}
 * @private
 * @const
 */
talk.media.c3d.FixedAreaFeed.AVATAR_SIZE_FRACTION_ = 0.8;


/**
 * Duration of the fade-in animation, in seconds.
 *
 * @type {number}
 * @private
 * @const
 */
talk.media.c3d.FixedAreaFeed.FADE_IN_DURATION_ = 1.0;


/**
 * The x-coordinate of the origin (bottom-left corner) for the rectangle to
 * draw in.
 *
 * @type {number}
 * @protected
 */
talk.media.c3d.FixedAreaFeed.prototype.x;


/**
 * The y-coordinate of the origin (bottom-left corner) for the rectangle to
 * draw in.
 *
 * @type {number}
 * @protected
 */
talk.media.c3d.FixedAreaFeed.prototype.y;


/**
 * The width of the rectangle to draw in.
 *
 * @type {number}
 * @protected
 */
talk.media.c3d.FixedAreaFeed.prototype.width;


/**
 * The height of the rectangle to draw in.
 *
 * @type {number}
 * @protected
 */
talk.media.c3d.FixedAreaFeed.prototype.height;


/**
 * @return {number} Our current x-coordinate.
 */
talk.media.c3d.FixedAreaFeed.prototype.getX = function() {
  return this.x;
};


/**
 * @return {number} Our current y-coordinate.
 */
talk.media.c3d.FixedAreaFeed.prototype.getY = function() {
  return this.y;
};


/**
 * @return {number} Our current width.
 */
talk.media.c3d.FixedAreaFeed.prototype.getWidth = function() {
  return this.width;
};


/**
 * @return {number} Our current height.
 */
talk.media.c3d.FixedAreaFeed.prototype.getHeight = function() {
  return this.height;
};


/**
 * Sets the area of the O3D pane in which to draw the feed.
 *
 * @param {number} x The x-coordinate of the origin.
 * @param {number} y The y-coordinate of the origin.
 * @param {number} width The width of the rectangle to draw in.
 * @param {number} height The height of the rectangle to draw in.
 */
talk.media.c3d.FixedAreaFeed.prototype.setArea = function(x, y, width, height) {
  this.x = x;
  this.y = y;
  this.width = width;
  this.height = height;
  this.reposition();
};


/**
 * Fades-in the feed.
 */
talk.media.c3d.FixedAreaFeed.prototype.fadeIn = function() {
  // C3dCommunicationPlayer calls fadeIn() from an avatar ready handler, but
  // its handler executes before ours so the feed object may not be created yet.
  // Hence we need to call reposition() to handle any possible position changes
  // now.
  this.reposition();
  // Do the tween.
  this.o3dBundle.c3dEngine.registerRenderCallback(
      new talk.media.c3d.AlphaTween(
          this.feedObject,
          0.0,
          1.0,
          talk.media.c3d.FixedAreaFeed.FADE_IN_DURATION_,
          talk.media.c3d.REGULAR_EASE_IN
          ));
};


/**
 * @override
 * @protected
 */
talk.media.c3d.FixedAreaFeed.prototype.fillAttributes =
    function(attrs, aspect) {
  // Compute attributes for taking up the largest area possible while
  // maintaining aspect ratio. Based on getFullAttributes() from
  // //flash/actionscript/com/google/talk/session/VideoCallWindowManager.as.
  var fw = this.width;
  var fh = this.height;
  if (this.getEndpoint().isAvatar()) {
    fw *= talk.media.c3d.FixedAreaFeed.AVATAR_SIZE_FRACTION_;
    fh *= talk.media.c3d.FixedAreaFeed.AVATAR_SIZE_FRACTION_;
  }
  if (fw / fh < aspect) {  // letterbox
    fh = fw / aspect;
  } else {  // pillarbox
    fw = fh * aspect;
  }
  attrs.x = this.x + (this.width - fw) / 2;
  attrs.y = this.y + (this.height - fh) / 2;
  attrs.w = fw;
  attrs.h = fh;
};


/**
 * @override
 * @protected
 */
talk.media.c3d.FixedAreaFeed.prototype.onTextureActivated = function(e) {
  this.fadeIn();
};
