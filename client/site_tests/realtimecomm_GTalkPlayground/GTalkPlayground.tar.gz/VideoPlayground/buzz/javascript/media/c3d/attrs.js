// Copyright 2008 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview Simple JS container for spatial attributes.
 *
 * @author tschmelcher@google.com (Tristan Schmelcher)
 */

goog.provide('talk.media.c3d.Attrs');


/**
 * Holds a set of spatial attributes.
 *
 * @param {number} x The x-coord.
 * @param {number} y The y-coord.
 * @param {number} z The z-coord.
 * @param {number} w The width scale.
 * @param {number} h The height scale.
 * @param {number} d The depth scale.
 * @constructor
 */
talk.media.c3d.Attrs = function(x, y, z, w, h, d) {

  /**
   * The x-coord.
   *
   * @type number
   */
  this.x = x;


  /**
   * The y-coord.
   *
   * @type number
   */
  this.y = y;


  /**
   * The z-coord.
   *
   * @type number
   */
  this.z = z;


  /**
   * The width scale.
   *
   * @type number
   */
  this.w = w;


  /**
   * The height scale.
   *
   * @type number
   */
  this.h = h;


  /**
   * The depth scale.
   *
   * @type number
   */
  this.d = d;

};
