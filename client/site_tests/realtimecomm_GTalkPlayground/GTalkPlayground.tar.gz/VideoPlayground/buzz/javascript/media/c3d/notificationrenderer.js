// Copyright 2009 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview A NotificationRenderer object
 *     which converts a given text to texture.
 *
 * @author chaitali@google.com (Chaitali Lawande)
 */

goog.provide('talk.media.c3d.NotificationRenderer');

goog.require('goog.debug.Logger');


/**
 * Creates a NotificationRenderer object with canvas and canvas paint.
 * @param {Object} pack The C3D Pack object to use.
 * @param {Object} c3d The C3D Plugin instance.
 * @param {number} width The width of the text texture.
 * @param {number} height The height of the text texture.
 * @constructor
 */
talk.media.c3d.NotificationRenderer = function(pack, c3d, width, height) {

  this.pack_ = pack;
  this.width_ = width;
  this.height_ = height;
  this.c3d_ = c3d;

  /**
   * The C3D Canvas object for drawing text.
   *
   * @type {Object}
   * @private
   */
  this.canvas_ = this.pack_['createObject']('Canvas');
  this.canvas_['setSize'](width, height);

  /**
   * The C3D CanvasPaint object for storing text properties.
   *
   * @type {Object}
   * @private
   */
  this.canvasPaint_ = this.pack_['createObject']('CanvasPaint');
  this.canvasPaint_['setOutline'](1, [0, 0, 0, 1]);
  this.canvasPaint_.textAlign = c3d['o3d']['CanvasPaint']['LEFT'];
  this.canvasPaint_.textSize = 12;
  this.canvasPaint_.textTypeface = 'Arial';
  this.canvasPaint_.color = [1, 1, 1, 1];
};


/**
 * Our logger.
 *
 * @type {goog.debug.Logger}
 * @private
 */
talk.media.c3d.NotificationRenderer.prototype.logger_ =
    goog.debug.Logger.getLogger('talk.media.c3d.NotificationRenderer');


/**
 * The C3D Pack object to use.
 *
 * @type {Object}
 * @private
 */
talk.media.c3d.NotificationRenderer.prototype.pack_;


/**
 * The C3D Plugin instance to use.
 *
 * @type {Object}
 * @private
 */
talk.media.c3d.NotificationRenderer.prototype.c3d_;


/**
 * Draws the given text and image on the canvas.
 * @param {string} imgUrl The url of image to be drawn.
 * @param {string} text The text to be drawn.
 * @param {function(Object) : void} onResult Callback
 *     for passing result. Must accept the rendered texture as argument.
 */
talk.media.c3d.NotificationRenderer.prototype.renderTexture = function(
    imgUrl, text, onResult) {

  var request = this.pack_['createFileRequest']('TEXTURE');
  request['open']('GET', imgUrl, true);
  request['onreadystatechange'] = goog.bind(function() {
    if (request['done']) {
      if (request['success']) {
        this.canvas_['saveMatrix']();
        this.clearCanvas_();

        // Vertically center the image on the canvas.
        var heightCalc = (this.height_ - request['texture']['height']) / 2;
        heightCalc += request['texture']['height'];

        this.canvas_['drawBitmap'](request['texture'], 10, heightCalc);
        this.canvas_['drawText'](text, (request['texture']['width'] + 30),
                                 this.height_ / 2, this.canvasPaint_);

        this.canvas_['restoreMatrix']();

        var texture = this.pack_['createTexture2D'](
            this.width_, this.height_,
            this.c3d_['o3d']['Texture']['ARGB8'],  // format
            1,  // mipmap levels
            false);
        this.canvas_['copyToTexture'](texture);

        onResult(texture);
      } else {
        var msg = request['error'] || 'Unknown error';
        this.logger_.severe('Texture failed to load, url="' +
                            imgUrl + '", msg="' +
                            msg + '"');
        onResult(null); // pass null if we failed to render texture
      }
      this.pack_['removeObject'](request);
    }
  }, this);
  request.send();
};


/**
 * Clears the internal canvas and sets its background color.
 * @private
 */
talk.media.c3d.NotificationRenderer.prototype.clearCanvas_ = function() {

  // Makes the canvas black with 50% transparency.
  this.canvas_['clear']([0, 0, 0, 0.5]);
};

