// Copyright 2009 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview Handles the layout of multiple video views in N:N calls in a
 *     horizontal strip.
 *
 * @author mikaeld@google.com (Mikael Drugge)
 * @author geer@google.com (Arthur van der Geer)
 */

goog.provide('talk.media.c3d.StripScene');

goog.require('talk.media.c3d.LabeledFeed');
goog.require('talk.media.c3d.SceneBase');


/**
 * Creates the StripScene.
 *
 * @param {talk.media.c3d.O3dBundle} o3dBundle The bundle of global resources
 *     for this O3D instance.
 * @extends {talk.media.c3d.SceneBase}
 * @constructor
 */
talk.media.c3d.StripScene = function(o3dBundle) {
  talk.media.c3d.SceneBase.call(this, o3dBundle);
};
goog.inherits(talk.media.c3d.StripScene, talk.media.c3d.SceneBase);


/**
 * The height of the strip of small participant feeds in multi-view mode, as
 * a fraction of the O3D window's height.
 *
 * @type {number}
 * @const
 * @private
 */
talk.media.c3d.StripScene.STRIP_HEIGHT_ = 0.20;


/**
 * The default number of user feeds to fit on screen initially.
 *
 * @type {number}
 * @const
 * @private
 */
talk.media.c3d.StripScene.USER_FEEDS_ = 5;


/**
 * @override
 * @protected
 */
talk.media.c3d.StripScene.prototype.createFeed =
    function(stream, streamId, label) {
  return new talk.media.c3d.LabeledFeed(
        this.o3dBundle, stream, 0.2, 0, 0, 0, 0, label);
};


/**
 * @override
 * @protected
 */
talk.media.c3d.StripScene.prototype.updatePositions = function() {
  var count = this.getFeedCount();

  // We allocate each feed screen real estate for a 16:10 aspect. If the feed is
  // not 16:10 then the sizing logic in FixedAreaFeed will either pillarbox or
  // letterbox it within its area of the screen.
  var feedAspect = 1.6;

  var width = this.width_ /
      Math.max(talk.media.c3d.StripScene.USER_FEEDS_, count);
  var height = width / feedAspect;
  if (height > this.height_) {
    // If we make our feeds take up the whole horizontal area then they'll be
    // too high. Must instead limit to the whole vertical area and leave some
    // horizontal area unused.
    height = this.height_;
    width = height * feedAspect;
  }
  var scale = 0.92;  // For spacing in between the video feeds.
  var spacing = (1 - scale) / 2;

  // Loop through all video feeds and (re)position them on screen.
  var streams = this.getStreamIds();
  for (var i = 0; i < streams.length; ++i) {
    var feed = this.getFeed(streams[i]);
    feed.setArea(this.x_ + (i * width) + spacing * width,
                 this.y_ + this.height_ - spacing * height - height * scale,
                 width * scale,
                 height * scale);
  }
};
