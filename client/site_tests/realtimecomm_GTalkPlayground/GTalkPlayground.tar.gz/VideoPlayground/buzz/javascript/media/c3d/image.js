// Copyright 2009 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview An Image object which is a transform and a child
 * scaleTransform scaled to match a texture.
 * Rewritten from //depot/googleclient/client3d/samples/fullscreen.html.
 *
 * @author geer@google.com (Arthur van der Geer)
 */

goog.provide('talk.media.c3d.Image');

goog.require('goog.debug.Logger');
goog.require('talk.media.c3d.Dimmable');
goog.require('talk.media.c3d.O3dBundle');


/**
 * Creates an Image object scaled to match a texture.
 *
 * @param {talk.media.c3d.O3dBundle} o3dBundle The bundle of global resources
 *     for this O3D instance.
 * @param {Object} parent The C3D Transform parent object.
 * @param {Object} shape The C3D Shape object.
 * @param {number} x The horizontal position in plugin client pixels.
 * @param {number} y The vertical position in plugin client pixels.
 * @extends {talk.media.c3d.Dimmable}
 * @constructor
 */
talk.media.c3d.Image = function(o3dBundle, parent, shape, x, y) {

  /**
   * The bundle of global resources for this O3D instance.
   *
   * @type {talk.media.c3d.O3dBundle}
   * @private
   */
  this.o3dBundle_ = o3dBundle;

  var c3d = this.o3dBundle_.c3dObject.getPlugin();

  // Create a transform for positioning.
  this.transform_ = this.o3dBundle_.pack['createObject']('Transform');
  this.transform_['parent'] = parent;
  this.moveTo(x, y);

  // Create a transform for scaling to the size of the image just so
  // we don't have to manage that manually in the transform above.
  this.scaleTransform_ = this.o3dBundle_.pack['createObject']('Transform');
  this.scaleTransform_['parent'] = this.transform_;

  // Setup the sampler for the texture.
  this.sampler_ = this.o3dBundle_.pack['createObject']('Sampler');
  this.sampler_['addressModeU'] = c3d['o3d']['Sampler']['CLAMP'];
  this.sampler_['addressModeV'] = c3d['o3d']['Sampler']['CLAMP'];
  this.paramSampler_ = this.scaleTransform_['createParam']('texSampler0',
                                                           'ParamSampler');
  this.paramSampler_['value'] = this.sampler_;

  // Set the shape
  this.scaleTransform_['addShape'](shape);

  // Setup our UV offsets and color multiplier.
  this.alpha_ = this.scaleTransform_['createParam']('alpha', 'o3d.ParamFloat');
  this.setAlpha(1);
};
goog.inherits(talk.media.c3d.Image, talk.media.c3d.Dimmable);


/**
 * Our logger.
 *
 * @type {goog.debug.Logger}
 * @private
 */
talk.media.c3d.Image.prototype.logger_ =
    goog.debug.Logger.getLogger('talk.media.c3d.Image');


/**
 * The alpha value.
 *
 * @type {Object}
 * @private
 */
talk.media.c3d.Image.prototype.alpha_;


/**
 * The C3D ParamSampler object.
 *
 * @type {Object}
 * @private
 */
talk.media.c3d.Image.prototype.paramSampler_;


/**
 * The C3D Sampler object for the texture.
 *
 * @type {Object}
 * @private
 */
talk.media.c3d.Image.prototype.sampler_;


/**
 * The C3D Transform object for scaling to the size of the texture.
 *
 * @type {Object}
 * @private
 */
talk.media.c3d.Image.prototype.scaleTransform_;


/**
 * The C3D Transform object for positioning.
 *
 * @type {Object}
 * @private
 */
talk.media.c3d.Image.prototype.transform_;


/**
 * The horizontal position.
 *
 * @type {number}
 * @private
 */
talk.media.c3d.Image.prototype.x_;


/**
 * The vertical position.
 *
 * @type {number}
 * @private
 */
talk.media.c3d.Image.prototype.y_;


/**
 * The width.
 *
 * @type {number}
 * @private
 */
talk.media.c3d.Image.prototype.width_;


/**
 * The height.
 *
 * @type {number}
 * @private
 */
talk.media.c3d.Image.prototype.height_;


/**
 * Set the texture of the sampler and adjust transform to the size of the
 * texture.
 * @param {Object} texture The texture to display.
 * @private
 */
talk.media.c3d.Image.prototype.setTexture_ = function(texture) {
  this.sampler_['texture'] = texture;
  this.resize(texture.width, texture.height);
};


/**
 * Loads a texture from a url.
 * @param {string} url The url to load the texture from.
 * @param {function()} opt_onSuccess Optional callback for successful load.
 */
talk.media.c3d.Image.prototype.loadTexture = function(url, opt_onSuccess) {
  var request = this.o3dBundle_.pack['createFileRequest']('TEXTURE');
  request['open']('GET', url, true);
  request['onreadystatechange'] = goog.bind(function() {
    if (request['done']) {
      if (request['success']) {
        this.setTexture_(request['texture']);
        if (opt_onSuccess) {
          opt_onSuccess();
        }
      } else {
        var msg = request['error'];
        if (!msg) {
          msg = 'Unknown error';
        }
        this.logger_.severe('Texture failed to load, url="' + url + '", msg="' +
            msg + '"');
      }
      this.o3dBundle_.pack['removeObject'](request);
    }
  }, this);
  request.send();
};


/**
 * Sets a given texture. Useful for displaying text.
 * @param {Object} texture The texture to load.
 * @param {function()} opt_onSuccess Optional callback for successful load.
 */
talk.media.c3d.Image.prototype.setTexture = function(texture, opt_onSuccess) {
  this.setTexture_(texture);
  if (opt_onSuccess) {
    opt_onSuccess();
  }
};


/**
 * Sets the alpha value for the image.
 * @param {number} a Alpha component value between 0 and 1.
 * @override
 */
talk.media.c3d.Image.prototype.setAlpha = function(a) {
  this.alpha_['value'] = a;
};


/**
 * Returns the alpha value for the image.
 * @return {number} The value of the image's alpha component, between 0 and 1.
 */
talk.media.c3d.Image.prototype.getAlpha = function() {
  return this.alpha_['value'];
};


/**
 * Shows or hides the image.
 * @param {boolean} visible The visibility.
 */
talk.media.c3d.Image.prototype.setVisible = function(visible) {
  this.transform_['visible'] = visible;
};


/**
 * @return {boolean} Returns whether the image is visible or not.
 */
talk.media.c3d.Image.prototype.isVisible = function() {
  return !!this.transform_['visible'];
};


/**
 * @return {number} Horizontal position.
 */
talk.media.c3d.Image.prototype.x = function() {
  return this.x_;
};


/**
 * @return {number} Vertical position.
 */
talk.media.c3d.Image.prototype.y = function() {
  return this.y_;
};


/**
 * @return {number} Width.
 */
talk.media.c3d.Image.prototype.width = function() {
  return this.width_;
};


/**
 * @return {number} Height.
 */
talk.media.c3d.Image.prototype.height = function() {
  return this.height_;
};


/**
 * @return {number} Width of the loaded texture, or 0 if not loaded.
 */
talk.media.c3d.Image.prototype.textureWidth = function() {
  var texture = this.sampler_['texture'];
  if (texture) {
    return texture['width'];
  } else {
    // Not loaded yet.
    return 0;
  }
};


/**
 * @return {number} Height of the loaded texture, or 0 if not loaded.
 */
talk.media.c3d.Image.prototype.textureHeight = function() {
  var texture = this.sampler_['texture'];
  if (texture) {
    return texture['height'];
  } else {
    // Not loaded yet.
    return 0;
  }
};


/**
 * Moves the image to the specified location in plugin client pixels.
 *
 * @param {number} x The horizontal position.
 * @param {number} y The vertical position.
 */
talk.media.c3d.Image.prototype.moveTo = function(x, y) {
  this.transform_['identity']();
  this.transform_['translate'](x, y, -2);
  this.x_ = x;
  this.y_ = y;
};


/**
 * Moves an image to a new location.  If a negative value is specified, the
 * image will be moved that far from the far edge.  For example, if -2 is
 * passed as x, the image's right border will end up 2 pixels from the right
 * edge of the video area.
 *
 * @param {number} x The new horizontal position.
 * @param {number} y The new vertical position.
 * @param {number} w The width of the parent.
 * @param {number} h The height of the parent.
 */
talk.media.c3d.Image.prototype.moveImageWithEdgeWrapping =
    function(x, y, w, h) {
  if (x < 0) {
    x = w - this.width() + x;
  }
  if (y < 0) {
    y = h - this.height() + y;
  }
  this.moveTo(x, y);
};


/**
 * Resizes the image to the specified size in client pixels.
 *
 * @param {number} width The image width.
 * @param {number} height The image height .
 */
talk.media.c3d.Image.prototype.resize = function(width, height) {
  this.width_ = width;
  this.height_ = height;
  this.scaleTransform_['identity']();
  this.scaleTransform_['scale'](width, height, 1);
};


/**
 * Returns whether the position is in the image area.
 * @param {number} x Horizontal position.
 * @param {number} y Vertical position.
 * @return {boolean} True iff inside.
 */
talk.media.c3d.Image.prototype.hitTest = function(x, y) {
  return (x >= this.x_ && x <= this.x_ + this.width() &&
          y >= this.y_ && y <= this.y_ + this.height());
};


/**
 * Removes this from the O3D scene graph.
 */
talk.media.c3d.Image.prototype.disposeC3d = function() {
  if (this.o3dBundle_.c3dObject.isSceneScriptable()) {
    this.transform_['parent'] = null;
  }
};
