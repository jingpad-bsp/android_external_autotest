// Copyright 2007 Google Inc.
// All Rights Reserved

/**
 * @fileoverview Wrapper on a Flash object embedded in the HTML page.
 * This class contains routines for writing the HTML to create the Flash object
 * and to send and receive messages with the Flash object. Should work in both
 * IE and Firefox
 *
 * This class does not perform any batching or throttling of messages.  We
 * tested the former but found the effect to not be as significant (20%) as
 * other possible optimizations.  The latter we also avoided because it
 * introduces yet more complication and potentiality for bugs and because we
 * already have throttling on the server side.
 *
 * To use this object, create an instance, call writeHTML to generate the HTML
 * while the page is being written, and register a function  to handle
 * any messages it sends.  For example:
 *
 *     flash = new talk.media.FlashObject('test', prefix);
 *     flash.setRecv(function(src, dest, msg) { handleMe(src, dest, msg); });
 *     flash.writeHTML('test', 'test.swf');
 *
 * Reserved flashVars (do not use): dbg, ap, nm, cb, os
 *
 * This class is made to communicate with
 * google3/flash/actionscript/com/google/talk/BrowserInterface.as
 *
 * Based on java/com/google/buzz/webconnection/external/flashobject.js
 * by kevinz (Kevin Zatloukal)
 *
 * @author jessan (Jessan Hutchison-Quillian)
 */

goog.provide('talk.media.FlashObject');
goog.provide('talk.media.FlashObject.Wmodes');

goog.require('goog.dom');
goog.require('goog.json');
goog.require('goog.style');
goog.require('goog.userAgent');
goog.require('goog.userAgent.flash');
goog.require('goog.Timer');

/**
 * Wrapper for a SWF file. The name param should not contain dot (.) in order
 * to work correctly in IE.
 *
 * @param {string} name Used for the id in HTML, so it should be unique.
 * @param {string} addrPrefix Prepended to addresses of incoming and outgoing
 *     messages. In essesnce, it creates a namespace for the messages
 * @constructor
 */
talk.media.FlashObject = function(name, addrPrefix) {

  /**
   * Our logger.
   * @type {goog.debug.Logger}
   */
  this.logger_ = goog.debug.Logger.getLogger('talk.media.FlashObject');

  /**
   * The name of the flash object; the ID of the embed tag. The ID needs
   * to be unique or the messages can get misdirected
   * @type string
   * @private
   */
  this.name_ = name + talk.media.FlashObject.flID_++;

  /**
   * A string to prepend to all addresses
   * @type string
   * @private
   */
  this.addrPrefix_ = addrPrefix;

  /**
   * Functions to be called when the SWF has been loaded,
   *
   * @type Array.Function
   * @private
   */
  this.actions_ = [];

  // Compute os type once to pass to flashvars for each flash widget.
  if (goog.userAgent.WINDOWS) {
    this.osType_ = 'windows';
  } else if (goog.userAgent.MAC) {
    this.osType_ = 'macintosh';
  } else if (goog.userAgent.LINUX) {
    this.osType_ = 'linux';
  } else {
    this.osType_ = '';
  }
};

/**
 * Provides a unique ID for each instance
 * @type number
 * @private
 */
talk.media.FlashObject.flID_ = 0;

/**
 * The different states in which a the flash object can be
 * @enum {number}
 */
talk.media.FlashObject.States = {

  /** 
   * The initial state of a flash object. 
   */
  FLASH_STATE_INIT : 0,

  /** 
   * The state of a flash object once we have tested sending a message out. 
   */
  FLASH_STATE_LOADED : 1,

  /** 
   * The state of a flash object once we have tested sending both in and out. 
   */
  FLASH_STATE_READY : 2,

  /**
   * SWF has been reloaded need to reset 
   */
  FLASH_STATE_RESET : 3,

  /** 
   * A new-enough version of flash is not installed. 
   */
  FLASH_NOT_FOUND : 4
};

/**
 * The different modes for displaying a SWF. Note that different wmodes
 * can result in different bugs in different browsers and also that
 * both OPAQUE and TRANSPARENT will result in a performance hit.
 *
 * @enum {string}
 */
talk.media.FlashObject.Wmodes = {
  /**
   * Allows for z-ordering of the SWF.
   */
  OPAQUE : 'opaque',

  /**
   * Allows for z-ordering of the SWF and plays the swf with a transparent BG.
   */
  TRANSPARENT : 'transparent',

  /**
   * The default wmode. Does not allow for z-ordering of the SWF.
   */
  WINDOW : 'window'
};

/**
 * The state of the FlashObject
 * @type number
 * @private
 */
talk.media.FlashObject.prototype.state_ =
    talk.media.FlashObject.States.FLASH_STATE_INIT;

/**
 * The SWF itself
 * @type Element 
 * @private
 */
talk.media.FlashObject.prototype.flash_;

/**
 * Whether or not the SWF has been loaded
 * @type boolean
 * @private
 */
talk.media.FlashObject.prototype.loaded_;

/**
 * @type boolean
 * @private
 */
talk.media.FlashObject.prototype.fixLayoutDone_;

/**
 * Function to call when messages are received
 * @type Function
 * @private
 */
talk.media.FlashObject.prototype.recvFn_;

/**
 * Function to call when the state changes
 * @type Function
 * @private
 */
talk.media.FlashObject.prototype.stateChange_;

/**
 * The OS of the user
 * @type string
 * @private
 */
talk.media.FlashObject.prototype.osType_;

////
//These variables are not defined until writeHtml is called
////

/**
 * The document
 * @type goog.dom.DomHelper
 * @private
 */
talk.media.FlashObject.prototype.dom_;

/**
 *
 * @type Element
 * @private
 */
talk.media.FlashObject.prototype.container_;

/**
 * Whether or not the Element containing the SWF can be moved
 * @type boolean
 * @private
 */
talk.media.FlashObject.prototype.movable_;

/**
 * Whether or not the SWF has been placed visibly
 * @type boolean
 * @private
 */
talk.media.FlashObject.prototype.visible_;

/**
 * Width of the embedded SWF
 * @type number
 * @private
 */
talk.media.FlashObject.prototype.width_;

/**
 * Height of the embedded SWF
 * @type number
 * @private
 */
talk.media.FlashObject.prototype.height_;


/**
 * @return {string} the full address of this flash object.
 */
talk.media.FlashObject.prototype.getAddress = function() {
  return this.addrPrefix_ + this.name_;
};


/**
 *  @return {number} the state of this flash object.
 */
talk.media.FlashObject.prototype.getState = function() {
  return this.state_;
};


/**
 * Template for the object tag for IE.
 *
 * @type string
 * @private 
 */
talk.media.FlashObject.IE_HTML_ =
    '<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000"' +
           ' id="%s"' +
           ' name="%s"' +
           ' width="%s"' +
           ' height="%s"' +
           ' style="%s">' +
      '<param name="SCALE" value="exactfit">' +
      '<param name="movie" value="%s"/>' +
      '<param name="quality" value="high"/>' +
      '<param name="FlashVars" value="%s"/>' +
      '<param name="bgcolor" value="%s"/>' +
      '<param name="AllowScriptAccess" value="sameDomain"/>' +
      '<param name="allowFullScreen" value="true"/>' +
      '<param name="SeamlessTabbing" value="false"/>' +
      '%s' +
    '</object>';

/**
 * Template for the wmode param for IE.
 *
 * @type string
 * @private
 */
talk.media.FlashObject.IE_WMODE_PARAMS_ = '<param name="wmode" value="%s"/>';

/**
 * Template for the embed tag for FF.
 *
 * @type string
 * @private
 */
talk.media.FlashObject.FF_HTML_ =
    '<embed quality="high"' +
          ' id="%s"' +
          ' name="%s"' +
          ' style="width: %s; height: %s; %s"' +
          ' src="%s"' +
          ' FlashVars="%s"' +
          ' bgcolor="%s"' +
          ' AllowScriptAccess="sameDomain"' +
          ' allowFullScreen="true"' +
          ' SeamlessTabbing="false"' +
          ' type="application/x-shockwave-flash"' +
          ' pluginspage="http://www.macromedia.com/go/getflashplayer"' +
          ' %s>' +
    '</embed>';

/**
 * Template for the wmode param for Firefox.
 *
 * @type string
 * @private
 */
talk.media.FlashObject.FF_WMODE_PARAMS_ = 'wmode=%s';

/**
 * FlashVars string passed to the created object.  The final '%s' allows for
 * additional arguments to be added.
 *
 * @type string
 * @private
 */
talk.media.FlashObject.FLASH_VARS_ = 'dbg=%s&ap=%s&nm=%s&cb=%s&os=%s&%s';


/**
 * Writes the embed/object tag into the Element, overwriting its previous 
 * contents.
 *
 * @param {string|Element} swfContainer The Element into which we embed the SWF
       The SWF will overwrite the contents of the Element.
 * @param {string} swf the path to the SWF file to embed
 * @param {string} opt_flashVars Parameters to be passed to the SWF.
 *     The string should be in URL parameter format: var1=A&var2=B...
 * @param {boolean} opt_debug Whether or not the SWF should be in debug mode
 * @param {talk.media.FlashObject.Wmodes} opt_wmode The wmode to use in the
 *     embed/object tag. The default is WINDOW.
 * @param {goog.dom.DomHelper} opt_domHelper The document for this FlashObject
 * @param {Function} opt_innerHtmlWriterFn A function to call to write the
 *     innerHTML of the container
 * @param {string?} opt_bgcolor Background color for the swf
 */
talk.media.FlashObject.prototype.writeHTML = function(swfContainer,
                                                      swf,
                                                      opt_flashVars,
                                                      opt_debug,
                                                      opt_wmode,
                                                      opt_domHelper,
                                                      opt_innerHtmlWriterFn,
                                                      opt_bgcolor) {
  this.movable_ = false;
  this.visible_ = true;

  this.container_ = opt_domHelper ? opt_domHelper.getElement(swfContainer)
                                  : goog.dom.getElement(swfContainer);
  this.width_ = parseInt(goog.style.getStyle(this.container_, 'width'), 10);
  this.height_ = parseInt(goog.style.getStyle(this.container_, 'height'), 10);

  // Set the domHelper appropriately for this flash object.
  this.dom_ = opt_domHelper || goog.dom.getDomHelper(this.container_);

  // this was called via timer at one point because of a FF2 JS issue
  this.doWriteHTML_(true, swf, opt_flashVars, opt_debug, opt_wmode,
      opt_innerHtmlWriterFn, opt_bgcolor);
};


/**
 * Writes the HTML to embed the flash object and receive messages it sends.
 * The SWF loads in an element located at (x,y) then moves the element 
 * offscreen after loading finishes.
 *
 * @param {string} swf The relative URL to the SWF
 * @param {string|number} x The left offset for the element while the SWF loads
 * @param {string|number} y The top offset for the element while the SWF loads
 * @param {string} opt_flashVars Parameters to be passed to the SWF.
 *     The string should be in URL parameter format: var1=A&var2=B...
 * @param {boolean} opt_debug Whether or not the SWF should be in debug mode
 * @param {talk.media.FlashObject.Wmodes} opt_wmode The wmode to use in the
 *     embed/object tag. The default is WINDOW.
 * @param {string?} opt_bgcolor Background color for the swf
 */
talk.media.FlashObject.prototype.writeHiddenSwf = function(swf,
                                                           x,
                                                           y,
                                                           opt_flashVars,
                                                           opt_debug,
                                                           opt_wmode,
                                                           opt_bgcolor) {
  // Need to create a container to hold embed/object tag
  this.movable_ = true;
  this.visible_ = false;
  this.width_ = 0;
  this.height_ = 0;

  this.dom_ = goog.dom.getDomHelper();
  this.container_ = this.dom_.createElement('div');
  goog.style.setStyle(this.container_, 'position', 'absolute');
  goog.style.setStyle(this.container_, 'top', y + 'px');
  goog.style.setStyle(this.container_, 'left', x + 'px');
  goog.style.setStyle(this.container_, 'overflow', 'hidden');

  var initialWidth = 1;
  var initialHeight = 1;
  goog.style.setStyle(this.container_, 'width', initialWidth + 'px');
  goog.style.setStyle(this.container_, 'height', initialHeight + 'px');
  this.doWriteHTML_(false, swf, opt_flashVars, opt_debug, opt_wmode,
      null, opt_bgcolor);
};


/**
 * Determines the required version of flash
 * @return {string} a string representing the required version of Flash
 */
talk.media.FlashObject.prototype.getRequiredVersion = function() {
  // We need version 8 on win/mac and 9 on linux.
  return goog.userAgent.LINUX ? '9.0.0' : '8.0.0';
};


/**
 * Inserts the HTML for the flash embed into the page.
 *
 * @param {boolean} inPlace Whether this.container_ is already in the DOM
 * @param {string} swf The relative URL to the SWF file
 * @param {string?} opt_flashVars Additional variables to pass in to the SWF
 * @param {boolean?} opt_debug Whether the SWF should be in debug mode
 * @param {talk.media.FlashObject.Wmodes?} opt_wmode The wmode for the SWF
 * @param {Function} opt_innerHtmlWriterFn A function to call to write the
 *     innerHTML of the container
 * @param {string?} opt_bgcolor Background color for the swf
 * @private
 */
talk.media.FlashObject.prototype.doWriteHTML_ = function(inPlace,
                                                         swf,
                                                         opt_flashVars,
                                                         opt_debug,
                                                         opt_wmode,
                                                         opt_innerHtmlWriterFn,
                                                         opt_bgcolor) {
  var flashVars = opt_flashVars ? opt_flashVars : '';
  var wmode = opt_wmode ? opt_wmode : talk.media.FlashObject.Wmodes.WINDOW;
  var bgcolor = opt_bgcolor ? opt_bgcolor : "#000000";
  var minFlashVer = this.getRequiredVersion();

  if (goog.userAgent.flash.isVersion(minFlashVer)) {
    this.writeCommunicationHandlers_();
    var html = this.generateSwfTag_(swf, '100%', '100%', flashVars,
        wmode, bgcolor, opt_debug);
    if (opt_innerHtmlWriterFn) {
      opt_innerHtmlWriterFn(this.container_, html);
    } else {
      this.container_.innerHTML = html;
    }
  } else {
    // ERROR STATE
    this.setState(talk.media.FlashObject.States.FLASH_NOT_FOUND);
    this.logger_.warning('Flash not found.');
  }

  // If the element is not already in place, we need to add it into the DOM.
  if (!inPlace) {
    this.dom_.appendChild(this.dom_.getDocument().body, this.container_);
  }

  // Find the Flash object that should now exist.
  this.flash_ = this.dom_.getElement('flash_' + this.name_);
};


/**
 * Adds functions to handle messages coming from the SWF.
 *
 * @private
 */
talk.media.FlashObject.prototype.writeCommunicationHandlers_ = function() {
  // Function assignments of the form myObj[ x + y ] = function()...
  // Hit a JSCompiler bug when the --rename_anonymous_functions flag is used.
  // Therefore creating functions prior to assignment.
  var recvFunction = goog.bind(this.onRecv_, this);
  var doFSCommandFunction = goog.bind(this.onFSCommand_, this);

  // Find the appropriate window for this flash object. Flash needs
  // to have the function receiving its messages in the same window
  var divWindow = goog.dom.getWindow(this.dom_.getDocument());

  // Register functions that need to be present before the HTML is written.
  // (When pages are cached, these could get called immediately.)
  divWindow['Recv_' + this.name_] = recvFunction;
  divWindow[this.name_ + '_DoFSCommand'] = doFSCommandFunction;

  // On IE, DoFSCommand must be defined with a special script tag (or VBScript)
  if (goog.userAgent.IE) {
    var script = this.dom_.createElement('script');
    script.event = 'FSCommand(command,args)';
    script.htmlFor = 'flash_' + this.name_;
    script.text = this.name_ + '_DoFSCommand(command, args)';
    this.dom_.appendChild(this.dom_.getDocument().body, script);
  }
};


/**
 * Writes the HTML to embed the flash object and receive messages it sends.
 *
 * @param {string} swf The relative URL to the SWF file
 * @param {string} width The width of the SWF (can be fixed or percentage)
 * @param {string} height The height of the SWF (can be fixed or percentage)
 * @param {string} flashVars The variables to be passed in to the SWF
 * @param {talk.media.FlashObject.Wmodes} wmode The wmode for the SWF
 * @param {string} bgcolor Background color for the swf
 * @param {boolean?} opt_debug Whether the SWF should be in debug mode
 * @return {string} Browser appropriate HTML to add the SWF to the DOM.
 * @private 
 */
talk.media.FlashObject.prototype.generateSwfTag_ = function(swf,
                                                            width,
                                                            height,
                                                            flashVars,
                                                            wmode,
                                                            bgcolor,
                                                            opt_debug) {
  var debugStr = opt_debug ? 'true' : 'false';
  var template = goog.userAgent.IE ? talk.media.FlashObject.IE_HTML_
                                   : talk.media.FlashObject.FF_HTML_;
  var fvars = goog.string.subs(talk.media.FlashObject.FLASH_VARS_,
                               encodeURIComponent(debugStr),
                               encodeURIComponent(this.addrPrefix_),
                               encodeURIComponent(this.name_),
                               encodeURIComponent('Recv_' + this.name_),
                               encodeURIComponent(this.osType_),
                               flashVars + '&');
  var style = '';
  var params = goog.userAgent.IE ? talk.media.FlashObject.IE_WMODE_PARAMS_ :
                                   talk.media.FlashObject.FF_WMODE_PARAMS_;
  params = goog.string.subs(params, wmode);

  return goog.string.subs(template, 'flash_' + this.name_, this.name_, width,
                          height, style, swf, fvars, bgcolor, params);
};


/**
 * Removes the HTML in the Element containing this SWF from the DOM.
 */
talk.media.FlashObject.prototype.removeHTML = function () {
  this.container_.innerHTML = '';
  this.container_ = null;
  this.flash_ = null;
};


/**
 * Repositions and re-sizes the object after it has successfully loaded.
 * We start non-in-place objects on-screen (size 1x1) so that they will
 * initialize correctly on Windows.  Once they load, we move them off-screen
 * (once they are loaded).
 *
 * @private
 */
talk.media.FlashObject.prototype.fixLayout_ = function () {
  if (this.movable_ && !this.fixLayoutDone_) {
    this.fixLayoutDone_ = true;
    goog.style.setStyle(this.container_, 'left', '-10000px');
    goog.style.setStyle(this.container_, 'top', '0px');
    goog.style.setStyle(this.container_, 'width', this.width_ + 'px');
    goog.style.setStyle(this.container_, 'height', this.height_ + 'px');
  }
};


/**
 *  @return {boolean} the visibility state of this flash object.
 */
talk.media.FlashObject.prototype.isVisible = function() {
  return this.visible_;
};


/**
 * Updates the visibility bit of this flash object.
 *
 * @param {boolean} visible whether or not the SWF should be visible.
 */
talk.media.FlashObject.prototype.setVisible = function(visible) {
  // assert: this.movable_, cannot change the visibility of an in-place object
  if (this.actions_) {
    this.actions_.push(goog.bind(this.setVisible, this, visible));
  } else {
    this.visible_ = visible;
    if (!visible) {
      this.moveTo(-10000, 0);
      goog.style.setStyle(this.container_, 'width', this.width_ + 'px');
      goog.style.setStyle(this.container_, 'height', this.height_ + 'px');
    }
  }
};


/**
 * Updates the focus of this flash object.
 */
talk.media.FlashObject.prototype.focus = function() {
  if (this.actions_) {
    this.actions_.push(goog.bind(this.focus(), this));
  } else {
    if(!this.visible_) {
      throw Error('Cannot focus an invisible flash object');
    }
    // assert: this.visible_, cannot focus an invisible object
    this.flash_['focus']();
    // send an additional focus call. This is necessary for FF on OSX
    // and has no side effects on other browsers/platforms.
    goog.Timer.callOnce(function() { this.flash_['focus'](); }, 0, this);
  }
};


/**
 * @return {Element} the element, usually a DIV, containing the SWF
 */
talk.media.FlashObject.prototype.getHtmlElement = function() {
  return this.container_;
};


/**
 * @return {number} the width of this object.
 */
talk.media.FlashObject.prototype.getWidth = function() {
  if (this.actions_) {
    return this.width_;
  } else {
    return parseInt(goog.style.getStyle(this.container_, 'width'), 10);
  }
};


/**
 * @return {number} the height of this object.
 */ 
talk.media.FlashObject.prototype.getHeight = function() {
  if (this.actions_) {
    return this.height_;
  } else {
    return parseInt(goog.style.getStyle(this.container_, 'height'), 10);
  }
};


/**
 * Changes the (x,y) position of the object. Undefined for x or y is used
 * in the componentManager when scrolling fixed objects in y direction.
 * @param {number?} x the offset from the left
 * @param {number?} y the offset from the top
 */
talk.media.FlashObject.prototype.moveTo = function(x, y) {
  if (this.actions_) {
    this.actions_.push(goog.bind(this.moveTo, this, x, y));
  } else {
    if (x != null) {
      goog.style.setStyle(this.container_, 'left', x + 'px');
    }
    if (y != null) {
      goog.style.setStyle(this.container_, 'top', y + 'px');
    }
  }
};


/**
 * Sends a message into the flash object.
 * @param {string} src A string representing the source of the msg
 * @param {Array} array An array of arguments to pass down to the SWF.
 *                [0] = message type 
 */
talk.media.FlashObject.prototype.send = function(src, array) {
  if (this.actions_) {
    this.actions_.push(goog.bind(this.send, this, src, array));
  } else {
    this.sendInternal_(src, array);
  }
};


/**
 * Sends a message to the SWF using SetVariable
 * @param {string} src a string representing the source of the msg
 * @param {Array} array an array of arguments to pass down to the SWF
 *                [0] = message type
 */
talk.media.FlashObject.prototype.sendInternal_ = function(src, array) {
  try {
    this.flash_['SetVariable']('msg', goog.json.serialize(
        [src, this.getAddress(),array]));
  } catch(e) {
    this.logger_.warning('SetVariable failed: ' + e);
  }
};


/**
 * Function for handling FSCommand messages from SWF
 * wiki.corp.google.com/twiki/bin/view/Main/FlashJavaScriptIntegrationHowTo
 * For information about FSCommand
 * @param {string} cmd identifier for kind of message
 * @param {string} arg expected to be a JSON msg
 */
talk.media.FlashObject.prototype.onFSCommand_ = function(cmd, arg) {
  // The flash player sends fscommands for some other actions.  We want to
  // ignore all but our own messages.
  if ((cmd == 'msg') || (cmd == 'FSCommand:msg')) {
    this.onRecv_(arg);
  }
};


/**
 * Sets the function that will receive data from the flash object.
 * @param {Function} recv function to call when we receive a msg from the SWF
 */
talk.media.FlashObject.prototype.setRecv = function(recv) {
  this.recvFn_ = recv;
};


/**
 * Called with each message sent by the flash object.
 * @param {string} str a JSON array
 *     <ul>
 *     <li>[0] = source of the message</li>
 *     <li>[1] = destination for the message</li>
 *     <li>[2] = array, with first item in it being
 *           a string representing the message type</li>
 *     </ul>
 * @private
 */
talk.media.FlashObject.prototype.onRecv_ = function(str) {
  // assert: 'string' == typeof str, encoded message should be a string
  var msg = goog.json.parse(decodeURIComponent(str));
  // assert: msg instanceof Array, message should be an array
  // assert: msg.length == 3, message should have 3 parts

  var src = msg[0];
  var dest = msg[1];
  var array = msg[2];
  // assert: src == this.getAddress(), source should be this address
  // assert: array instanceof Array, message body should be an array

  // We specially handle messages for setup and focus handling.  Any other
  // message is delivered to the client for further processing.
  if (dest == this.addrPrefix_ + '.') {
    if (array[0] == 'f') {
      // assert: array.length == 1, focus message has no arguments
      this.focus();
    } else if (array[0] == 'b') {
      // assert: array.length == 1, blur message has no arguments
      this.flash_['blur']();
    } else if (array[0] == 'loaded') {
      this.onRecvLoaded_();
    } else if (array[0] == 'pong') {
      this.setState(talk.media.FlashObject.States.FLASH_STATE_READY);
      this.fixLayout_();
      this.onReady_();
    }
  }

  if (this.recvFn_) {
    this.recvFn_(src, dest, array);
  }
};


/**
 * Sets the state change function the flash calls back to indicate state has
 * changed.
 * @param {Function} stateChange callback for when state has changed
 */
talk.media.FlashObject.prototype.setStateChange = function(stateChange) {
  this.stateChange_ = stateChange;
};


/**
 * Set the state of the flash object
 * @param {number} state the state of the object
 */
talk.media.FlashObject.prototype.setState = function(state) {
  this.state_ = state;
  if (this.stateChange_) {
    this.stateChange_(this);
  }
};


/**
 * Resets the state back to the initial state and resets variables so that the
 * SWF behaves as if it has not been loaded.
 * There is no apparent indication when a SWF becomes unloaded. This needs to
 * be called explicitly before the SWF is reloaded.
 */
talk.media.FlashObject.prototype.resetState = function() {
  this.setState(talk.media.FlashObject.States.FLASH_STATE_INIT);
  this.loaded_ = false;
  this.actions_ = [];
};


/**
 * How frequently (in milliseconds?) to check if SWF has loaded
 * @type number
 * @private
 */
talk.media.FlashObject.LOADED_RECHECK_INTERVAL_ = 2000;

/**
 * Called to see if the flash has been loaded yet,
 * executes onLoaded_ when it has been.
 * @private
 */
talk.media.FlashObject.prototype.onRecvLoaded_ = function() {
  if (this.isLoaded()) {
    this.onLoaded_();
  } else {
    goog.Timer.callOnce(this.onRecvLoaded_,
        talk.media.FlashObject.LOADED_RECHECK_INTERVAL_, this);
  }
};


/**
 * Different states of loaded-ness in which the SWF itself can be
 *
 * Talked about at:
 * http://kb.adobe.com/selfservice/viewContent.do?externalId=tn_12059&sliceId=1
 *
 * @enum {number}
 * @private
 */
talk.media.FlashObject.SwfReadyStates_ = {

  LOADING : 0,

  UNINITIALIZED : 1,

  LOADED : 2,

  INTERACTIVE : 3,

  COMPLETE : 4 
};

/**
 * @return {boolean} whether the SWF has finished loading or not
 */
talk.media.FlashObject.prototype.isLoaded = function() {
  if (this.loaded_) {
    return true;
  }

  var fObj = this.flash_;
  if (!fObj) {
    return false;
  }

  this.loaded_ = ((typeof fObj.readyState != 'undefined' &&
                  fObj.readyState == 
                      talk.media.FlashObject.SwfReadyStates_.COMPLETE) ||
                 (typeof fObj.PercentLoaded != 'undefined' &&
                  fObj.PercentLoaded() == 100));
  return this.loaded_;
};


/**
 * Called when the SWF has finished loading, updates state appropriately
 * @private
 */
talk.media.FlashObject.prototype.onLoaded_ = function() {
  // If our state is transitioning downwards from READY then the swf was
  // reloaded.  Set the state to RESET so the BrowserChannel is reset.
  if (this.getState() == talk.media.FlashObject.States.FLASH_STATE_READY) {
    // Our state went down swf was re-created.
    this.setState(talk.media.FlashObject.States.FLASH_STATE_RESET);
  } else {
    this.setState(talk.media.FlashObject.States.FLASH_STATE_LOADED);
    var addr = this.getAddress();
    this.sendInternal_(addr, [ 'ping' ]);
  }
};


/**
 * Delivers all of the waiting messages for this object.
 * Called when the SWF has sent us the ready msg
 * @private
 */
talk.media.FlashObject.prototype.onReady_ = function() {
  if (this.actions_) {
    var actions = this.actions_;
    this.actions_ = null;
    for (var i = 0; i < actions.length; ++i) {
      actions[i]();
    }
  }
};
