// Copyright 2008 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview Defines the CallingRequirements class.
 *
 * @author jessan@google.com (Jessan Hutchison-Quillian)
 */

goog.provide('talk.media.CallingRequirements');

goog.require('goog.userAgent');
goog.require('talk.media.RendererDetector');

/**
 * Unified place for knowledge about the system capabilities required to use
 * Gmail Voice and Video.
 *
 * @param {boolean} supportClient3D Use Client3D instead of Flash if possible.
 * @constructor
 */
talk.media.CallingRequirements = function(supportClient3D) {

  /**
   * @type talk.media.RendererDetector
   * @private
   */
  this.rendererDetector_ = new talk.media.RendererDetector(supportClient3D);
};


/**
 * Returns the object used to determine which renderer is installed.
 *
 * @return {talk.media.RendererDetector} The object used to detect a renderer
 */
talk.media.CallingRequirements.prototype.getRendererDetector = function() {
  return this.rendererDetector_;
};


/**
 * Returns the object used to verify Flash availability and version.
 * Only needed for InstallNeededType determination in Callmanager.
 * TODO(geer): Move install requirement logic from CallManager to
 *             CallingRequirements.
 * @return {talk.media.FlashDetector} The object used to detect flash.
 */
talk.media.CallingRequirements.prototype.getFlashDetector = function() {
  return this.getRendererDetector().getFlashDetector();
};


/**
 * Determines whether or not the voice and video feature is available for the
 * user's operating system.
 *
 * @return {boolean} Whether or not the Google Talk Plugin is available
 */
talk.media.CallingRequirements.prototype.isAvailableForOs = function() {
  var intel = goog.userAgent.PLATFORM.indexOf('Intel') != -1;
  return goog.userAgent.WINDOWS || (goog.userAgent.MAC && intel) ||
        (goog.userAgent.LINUX && this.getRendererDetector().isO3dSupported());
};


/**
 * Determines whether or not the browser side supports Client3D rendering.
 *
 * @return {boolean} True iff Client3D is available.
 */
talk.media.CallingRequirements.prototype.canUseClient3D = function() {
  return !!(this.getRendererDetector().getCapabilities() &
      talk.media.RendererDetector.RENDER_CLIENT3D_CAPABILITY);
};


/**
 * Determines whether or not the browser side supports Flash rendering.
 *
 * @return {boolean} True iff Flash is available.
 */
talk.media.CallingRequirements.prototype.canUseFlash = function() {
  return !!(this.getRendererDetector().getCapabilities() &
      talk.media.RendererDetector.RENDER_MAGICCAM_CAPABILITY);
};


/**
 * Cleans up this object.
 */
talk.media.CallingRequirements.prototype.dispose = function() {
  this.rendererDetector_ = null;
};
