// Protocol Buffer 2 Copyright 2008 Google Inc
// All other code copyright its respective owners(s).

/**
 * @fileoverview Generated Protocol Buffer code for file
 * proto2/package_test.proto.
 */

goog.provide('someprotopackage.TestPackageTypes');

goog.require('goog.proto2.Message');
goog.require('proto2.TestAllTypes');

/**
 * Message TestPackageTypes.
 * @constructor
 * @extends {goog.proto2.Message}
 */
someprotopackage.TestPackageTypes = function() {
  goog.proto2.Message.apply(this);
};
goog.inherits(someprotopackage.TestPackageTypes, goog.proto2.Message);

/**
 * Gets the value of the optional_int32 field.
 * @return {number} The value.
 */
someprotopackage.TestPackageTypes.prototype.getOptionalInt32 = function() {
  return /** @type {number} */ (this.get$Value(1));
};


/**
 * Sets the value of the optional_int32 field.
 * @param {number} value The value.
 */
someprotopackage.TestPackageTypes.prototype.setOptionalInt32 = function(value) {
  this.set$Value(1, /** @type {Object} */ (value));
};


/**
 * Returns whether the optional_int32 field has a value.
 * @return {boolean} true if the field has a value.
 */
someprotopackage.TestPackageTypes.prototype.hasOptionalInt32 = function() {
  return this.has$Value(1);
};


/**
 * Gets the number of values in the optional_int32 field.
 * @return {number}
 */
someprotopackage.TestPackageTypes.prototype.optionalInt32Count = function() {
  return this.count$Values(1);
};


/**
 * Clears the values in the optional_int32 field.
 */
someprotopackage.TestPackageTypes.prototype.clearOptionalInt32 = function() {
  this.clear$Field(1);
};


/**
 * Gets the value of the other_all field.
 * @return {proto2.TestAllTypes} The value.
 */
someprotopackage.TestPackageTypes.prototype.getOtherAll = function() {
  return /** @type {proto2.TestAllTypes} */ (this.get$Value(2));
};


/**
 * Sets the value of the other_all field.
 * @param {proto2.TestAllTypes} value The value.
 */
someprotopackage.TestPackageTypes.prototype.setOtherAll = function(value) {
  this.set$Value(2, /** @type {Object} */ (value));
};


/**
 * Returns whether the other_all field has a value.
 * @return {boolean} true if the field has a value.
 */
someprotopackage.TestPackageTypes.prototype.hasOtherAll = function() {
  return this.has$Value(2);
};


/**
 * Gets the number of values in the other_all field.
 * @return {number}
 */
someprotopackage.TestPackageTypes.prototype.otherAllCount = function() {
  return this.count$Values(2);
};


/**
 * Clears the values in the other_all field.
 */
someprotopackage.TestPackageTypes.prototype.clearOtherAll = function() {
  this.clear$Field(2);
};




goog.proto2.Message.set$Metadata(someprotopackage.TestPackageTypes, {
  0 : {
    name: 'TestPackageTypes',
    fullName: 'someprotopackage.TestPackageTypes'
  },
  '1' : {
    name: 'optional_int32',
    fieldType: goog.proto2.Message.FieldType.INT32,
    type: Number
  },
  '2' : {
    name: 'other_all',
    fieldType: goog.proto2.Message.FieldType.MESSAGE,
    type: proto2.TestAllTypes
  }});

