// Copyright 2007 Google Inc. All Rights Reserved.

/**
 * @fileoverview An enum that contains the possible status type's of the Gears
 * feature of an application.
 *
 * @author Steven Saviano (ssaviano@google.com)
 */

goog.provide('goog.gears.StatusType');


/**
 * The possible status type's for Gears.
 * @enum {string}
 */
goog.gears.StatusType = {
  NOT_INSTALLED: 'ni',
  INSTALLED: 'i',
  PAUSED: 'p',
  OFFLINE: 'off',
  ONLINE: 'on',
  SYNCING: 's',
  CAPTURING: 'c',
  ERROR: 'e'
};
