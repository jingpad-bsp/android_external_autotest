// Copyright 2008 Google Inc. All Rights Reserved.

/**
 * @fileoverview A toolbar separator control.
 *
 * @author attila@google.com (Attila Bodis)
 * @author ssaviano@google.com (Steven Saviano)
 */

goog.provide('goog.ui.ToolbarSeparator');

goog.require('goog.ui.Separator');
goog.require('goog.ui.ToolbarSeparatorRenderer');
goog.require('goog.ui.registry');


/**
 * A separator control for a toolbar.
 *
 * @param {goog.ui.ToolbarSeparatorRenderer=} opt_renderer Renderer to render or
 *    decorate the separator; defaults to
 *     {@link goog.ui.ToolbarSeparatorRenderer}.
 * @param {goog.dom.DomHelper=} opt_domHelper Optional DOM helper, used for
 *    document interaction.
 * @constructor
 * @extends {goog.ui.Separator}
 */
goog.ui.ToolbarSeparator = function(opt_renderer, opt_domHelper) {
  goog.ui.Separator.call(this, opt_renderer ||
      goog.ui.ToolbarSeparatorRenderer.getInstance(), opt_domHelper);
};
goog.inherits(goog.ui.ToolbarSeparator, goog.ui.Separator);


// Registers a decorator factory function for toolbar separators.
goog.ui.registry.setDecoratorByClassName(
    goog.ui.ToolbarSeparatorRenderer.CSS_CLASS,
    function() {
      return new goog.ui.ToolbarSeparator();
    });
