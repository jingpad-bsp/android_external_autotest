// Copyright 2007 Google Inc. All Rights Reserved.

/**
 * @fileoverview Emoji implementation.
 *
 * @author dalewis@google.com (Darren Lewis)
 */

goog.provide('goog.ui.emoji.Emoji');


/**
 * Creates an emoji.
 *
 * A simple wrapper for an emoji.
 *
 * @param {string} url URL pointing to the source image for the emoji.
 * @param {string} id The id of the emoji, e.g., 'std.1'.
 * @constructor
 */
goog.ui.emoji.Emoji = function(url, id) {
  /**
   * The URL pointing to the source image for the emoji
   *
   * @type {string}
   * @private
   */
  this.url_ = url;

  /**
   * The id of the emoji
   *
   * @type {string}
   * @private
   */
  this.id_ = id;
};


/**
 * @return {string} The URL for this emoji.
 */
goog.ui.emoji.Emoji.prototype.getUrl = function() {
  return this.url_;
};


/**
 * @return {string} The id of this emoji.
 */
goog.ui.emoji.Emoji.prototype.getId = function() {
  return this.id_;
};
