// Copyright 2007 Google Inc. All Rights Reserved.

/**
 * @fileoverview Definition of goog.ui.MockActivityMonitor.
 * @author jonp@google.com (Jon Perlow)
 */

goog.provide('goog.ui.MockActivityMonitor');

goog.require('goog.events.EventType');
goog.require('goog.ui.ActivityMonitor');

/**
 * A mock implementation of goog.ui.ActivityMonitor for unit testing. Clients
 * of this class should override goog.now to return a synthetic time from
 * the unit test.
 * @constructor
 * @extends {goog.ui.ActivityMonitor}
 */
goog.ui.MockActivityMonitor = function() {
  goog.ui.ActivityMonitor.call(this);
};
goog.inherits(goog.ui.MockActivityMonitor, goog.ui.ActivityMonitor);


/**
 * Simulates an event that updates the user to being non-idle.
 * @param {goog.events.EventType=} opt_type The type of event that made the user
 *     not idle. If not specified, defaults to MOUSEMOVE.
 */
goog.ui.MockActivityMonitor.prototype.simulateEvent = function(opt_type) {
  var type = opt_type || goog.events.EventType.MOUSEMOVE;
  var eventTime = goog.now();

  // update internal state noting whether the user was idle
  this.lastEventTime_ = eventTime;
  this.lastEventType_ = type;

  // dispatch event
  this.dispatchEvent(goog.ui.ActivityMonitor.Event.ACTIVITY);
};
