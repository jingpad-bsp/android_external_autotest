// Copyright 2009 Google Inc. All Rights Reserved.

/**
 * @fileoverview Type declaration for control content.
 *
 * @author nicksantos@google.com (Nick Santos)
 */
goog.provide('goog.ui.ControlContent');



/**
 * Type declaration for text caption or DOM structure to be used as the content
 * of {@link goog.ui.Control}s.
 * @type {string|Node|Array.<Node>|NodeList}
 */
goog.ui.ControlContent = goog.typedef;
