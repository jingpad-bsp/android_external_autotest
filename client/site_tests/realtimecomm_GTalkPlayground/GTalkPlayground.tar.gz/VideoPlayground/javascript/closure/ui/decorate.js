// Copyright 2008 Google Inc. All Rights Reserved.

/**
 * @fileoverview Provides a function that decorates an element based on its CSS
 * class name.
 * @author attila@google.com (Attila Bodis)
 */

goog.provide('goog.ui.decorate');

goog.require('goog.ui.registry');



/**
 * Decorates the element with a suitable {@link goog.ui.Component} instance, if
 * a matching decorator is found.
 * @param {Element} element Element to decorate.
 * @return {goog.ui.Component?} New component instance, decorating the element.
 */
goog.ui.decorate = function(element) {
  var decorator = goog.ui.registry.getDecorator(element);
  if (decorator) {
    decorator.decorate(element);
  }
  return decorator;
};
