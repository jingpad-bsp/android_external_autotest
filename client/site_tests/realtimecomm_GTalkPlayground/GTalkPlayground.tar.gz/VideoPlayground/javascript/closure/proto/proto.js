// Copyright 2007 Google Inc. All Rights Reserved.

/**
 * @fileoverview Protocol buffer serializer.
 * @author arv@google.com (Erik Arvidsson)
 */

goog.provide('goog.proto');


goog.require('goog.proto.Serializer');


/**
 * Instance of the serializer object.
 * @type {goog.proto.Serializer}
 * @private
 */
goog.proto.serializer_ = null;


/**
 * Serializes an object or a value to a protocol buffer string.
 * @param {Object} object The object to serialize.
 * @return {string} The serialized protocol buffer string.
 */
goog.proto.serialize = function(object) {
  if (!goog.proto.serializer_) {
    goog.proto.serializer_ = new goog.proto.Serializer;
  }
  return goog.proto.serializer_.serialize(object);
};
