// Copyright 2007 Google Inc. All Rights Reserved.

/**
 * @fileoverview DOM pattern to match a text node.
 *
 * @author robbyw@google.com (Robby Walker)
 */

goog.provide('goog.dom.pattern.Text');

goog.require('goog.dom.NodeType');
goog.require('goog.dom.pattern');
goog.require('goog.dom.pattern.AbstractPattern');
goog.require('goog.dom.pattern.MatchType');

/**
 * Pattern object that matches text by exact matching or regular expressions.
 *
 * @param {string|RegExp} match String or regular expression to match against.
 * @constructor
 * @extends {goog.dom.pattern.AbstractPattern}
 */
goog.dom.pattern.Text = function(match) {
  this.match_ = match;
};
goog.inherits(goog.dom.pattern.Text, goog.dom.pattern.AbstractPattern);


/**
 * The text or regular expression to match.
 *
 * @type {string|RegExp}
 * @private
 */
goog.dom.pattern.Text.prototype.match_;

/**
 * Test whether the given token is a text token which matches the string or
 * regular expression provided in the constructor.
 *
 * @param {Node} token Token to match against.
 * @param {goog.dom.TagWalkType} type The type of token.
 * @return {goog.dom.pattern.MatchType} <code>MATCH</code> if the pattern
 *     matches, <code>NO_MATCH</code> otherwise.
 */
goog.dom.pattern.Text.prototype.matchToken = function(token, type) {
  if (token.nodeType == goog.dom.NodeType.TEXT &&
      goog.dom.pattern.matchStringOrRegex(this.match_, token.nodeValue)) {
    this.matchedNode = token;
    return goog.dom.pattern.MatchType.MATCH;
  }

  return goog.dom.pattern.MatchType.NO_MATCH;
};
