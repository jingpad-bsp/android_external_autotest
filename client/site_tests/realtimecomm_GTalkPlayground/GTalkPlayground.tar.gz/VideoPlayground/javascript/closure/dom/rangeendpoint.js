// Copyright 2007 Google Inc. All Rights Reserved.

/**
 * @fileoverview Simple struct for endpoints of a range.
 *
 * @author robbyw@google.com (Robby Walker)
 */


goog.provide('goog.dom.RangeEndpoint');


/**
 * Constants for selection endpoints.
 * @enum {number}
 */
goog.dom.RangeEndpoint = {
  START: 1,
  END: 0
};
