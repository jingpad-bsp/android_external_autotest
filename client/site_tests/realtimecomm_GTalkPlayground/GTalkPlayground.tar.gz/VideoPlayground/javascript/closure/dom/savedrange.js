// Copyright 2007 Google Inc. All Rights Reserved.

/**
 * @fileoverview A generic interface for saving and restoring ranges.
 *
 * @author robbyw@google.com (Robby Walker)
 */


goog.provide('goog.dom.SavedRange');

goog.require('goog.Disposable');
goog.require('goog.debug.Logger');


/**
 * Abstract interface for a saved range.
 * @constructor
 * @extends {goog.Disposable}
 */
goog.dom.SavedRange = function() {
  goog.Disposable.call(this);
};
goog.inherits(goog.dom.SavedRange, goog.Disposable);


/**
 * Logging object.
 * @type {goog.debug.Logger}
 * @private
 */
goog.dom.SavedRange.logger_ =
    goog.debug.Logger.getLogger('goog.dom.SavedRange');


/**
 * Restores the range and by default disposes of the saved copy.  Take note:
 * this means the by default SavedRange objects are single use objects.
 * @param {boolean=} opt_stayAlive Whether this SavedRange should stay alive
 *     (not be disposed) after restoring the range. Defaults to false (dispose).
 * @return {goog.dom.AbstractRange} The restored range.
 */
goog.dom.SavedRange.prototype.restore = function(opt_stayAlive) {
  if (this.isDisposed()) {
    goog.dom.SavedRange.logger_.severe(
        'Disposed SavedRange objects cannot be restored.');
  }

  var range = this.restoreInternal();
  if (!opt_stayAlive) {
    this.dispose();
  }
  return range;
};


/**
 * Internal method to restore the saved range.
 * @return {goog.dom.AbstractRange} The restored range.
 */
goog.dom.SavedRange.prototype.restoreInternal = goog.abstractMethod;
