// Copyright 2009 Google Inc. All Rights Reserved.

/**
 * @fileoverview Mock matchers for event related arguments.
 * @author benkomalo@google.com (Ben Komalo)
 */

goog.provide('goog.testing.events.EventMatcher');

goog.require('goog.events.Event');
goog.require('goog.testing.mockmatchers.ArgumentMatcher');


/**
 * A matcher that verifies that an argument is a {@code goog.events.Event} of a
 * particular type.
 * @param {string} type The single type the event argument must be of.
 * @constructor
 * @extends {goog.testing.mockmatchers.ArgumentMatcher}
 */
goog.testing.events.EventMatcher = function(type) {
  goog.testing.mockmatchers.ArgumentMatcher.call(this,
      function(obj) {
        return obj instanceof goog.events.Event &&
            obj.type == type;
      }, 'isEventOfType(' + type + ')');
};
goog.inherits(goog.testing.events.EventMatcher,
    goog.testing.mockmatchers.ArgumentMatcher);
