// Copyright 2009 Google Inc. All Rights Reserved.

/**
 * @fileoverview A table for showing the results of performance testing.
 * @author attila@google.com (Attila Bodis)
 * @author nicksantos@google.com (Nick Santos)
 */

goog.provide('goog.testing.PerformanceTable');

goog.require('goog.dom');
goog.require('goog.testing.PerformanceTimer');

/**
 * A UI widget that runs performance tests and displays the results.
 * @param {Element} root The element where the table should be attached.
 * @param {goog.testing.PerformanceTimer=} opt_timer A timer to use for
 *     executing functions and profiling them.
 * @constructor
 */
goog.testing.PerformanceTable = function(root, opt_timer) {
  /**
   * Where the table should be attached.
   * @type {Element}
   * @private
   */
  this.root_ = root;

  var timer = opt_timer;
  if (!timer) {
    timer = new goog.testing.PerformanceTimer();
    timer.setNumSamples(5);
    timer.setDiscardOutliers(true);
  }

  /**
   * A timer for running the tests.
   * @type {goog.testing.PerformanceTimer}
   * @private
   */
  this.timer_ = timer;

  this.initRoot_();
};


/**
 * @return {goog.testing.PerformanceTimer} The timer being used.
 */
goog.testing.PerformanceTable.prototype.getTimer = function() {
  return this.timer_;
};


/**
 * Render the initial table.
 * @private
 */
goog.testing.PerformanceTable.prototype.initRoot_ = function() {
  this.root_.innerHTML =
      '<table class="test-results" cellspacing="1">' +
      '  <thead>' +
      '    <tr>' +
      '      <th rowspan="2">Test Description</th>' +
      '      <th rowspan="2">Runs</th>' +
      '      <th colspan="4">Results (ms)</th>' +
      '    </tr>' +
      '    <tr>' +
      '      <th>Average</th>' +
      '      <th>Std Dev</th>' +
      '      <th>Minimum</th>' +
      '      <th>Maximum</th>' +
      '    </tr>' +
      '  </thead>' +
      '  <tbody>' +
      '  </tbody>' +
      '</table>';
};


/**
 * @return {Element} The body of the table.
 * @private
 */
goog.testing.PerformanceTable.prototype.getTableBody_ = function() {
  return goog.dom.$$('tbody', null, this.root_)[0];
};


/**
 * Run the given function with the performance timer, and show the results.
 * @param {Function} fn The function to run.
 * @param {string=} opt_desc A description to associate with this run.
 */
goog.testing.PerformanceTable.prototype.run = function(fn, opt_desc) {
  var results = this.timer_.run(fn);
  var average = results['average'];
  var standardDeviation = results['standardDeviation'];
  var isSuspicious = average < 0 || standardDeviation > average * .5;
  var resultsRow = goog.dom.createDom('tr', null,
      goog.dom.createDom('td', 'test-description',
          opt_desc || 'No description'),
      goog.dom.createDom('td', 'test-count', String(results['count'])),
      goog.dom.createDom('td', 'test-average', String(Math.round(average))),
      goog.dom.createDom('td', 'test-standard-deviation',
          String(Math.round(standardDeviation))),
      goog.dom.createDom('td', 'test-minimum', String(results['minimum'])),
      goog.dom.createDom('td', 'test-maximum', String(results['maximum'])));
  if (isSuspicious) {
    resultsRow.className = 'test-suspicious';
  }
  this.getTableBody_().appendChild(resultsRow);
};


/**
 * Report an error in the table.
 * @param {*} reason The reason for the error.
 */
goog.testing.PerformanceTable.prototype.reportError = function(reason) {
  this.getTableBody_().appendChild(
      goog.dom.createDom('tr', null,
          goog.dom.createDom('td', {'class': 'test-error', 'colSpan': 5},
              String(reason))));
};
