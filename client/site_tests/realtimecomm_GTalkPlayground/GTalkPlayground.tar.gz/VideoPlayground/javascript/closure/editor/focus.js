// Copyright 2009 Google, Inc. All Rights Reserved.

/**
 * @fileoverview Utilties to handle focusing related to rich text editing.
 *
 * @author marcosalmeida@google.com (Marcos Almeida)
 */

goog.provide('goog.editor.focus');

goog.require('goog.dom.selection');


/**
 * Change focus to the given input field and set cursor to end of current text.
 * @param {Element} inputElem Input DOM element.
 */
goog.editor.focus.focusInputField = function(inputElem) {
  inputElem.focus();
  goog.dom.selection.setCursorPosition(inputElem, inputElem.value.length);
};
