// Copyright 2007 Google Inc. All Rights Reserved.


/**
 * @fileoverview Represents a fill goog.graphics.
 * @author arv@google.com (Erik Arvidsson)
 */


goog.provide('goog.graphics.Fill');


/**
 * Creates a fill object
 * @constructor
 */
goog.graphics.Fill = function() {};
