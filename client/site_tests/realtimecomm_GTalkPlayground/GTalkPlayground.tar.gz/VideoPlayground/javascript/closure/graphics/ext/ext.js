// Copyright 2007 Google Inc. All Rights Reserved.


/**
 * @fileoverview Extended graphics namespace.
 * @author robby@google.com (Robby Walker)
 */


goog.provide('goog.graphics.ext');

goog.require('goog.graphics.ext.Ellipse');
goog.require('goog.graphics.ext.Graphics');
goog.require('goog.graphics.ext.Group');
goog.require('goog.graphics.ext.Image');
goog.require('goog.graphics.ext.Rectangle');
goog.require('goog.graphics.ext.Shape');
goog.require('goog.graphics.ext.coordinates');
