// Copyright 2007 Google Inc. All Rights Reserved.


/**
 * @fileoverview Represents a solid color fill goog.graphics.
 * @author arv@google.com (Erik Arvidsson)
 */


goog.provide('goog.graphics.SolidFill');


goog.require('goog.graphics.Fill');


/**
 * Creates an immutable solid color fill object.
 *
 * @param {string} color The color of the background.
 * @param {number=} opt_opacity The opacity of the background fill. The value
 *    must be greater than zero (transparent) and less than or equal to 1
 *    (opaque).
 * @constructor
 * @extends {goog.graphics.Fill}
 */
goog.graphics.SolidFill = function(color, opt_opacity) {
  /**
   * The color with which to fill.
   * @type {string}
   * @private
   */
  this.color_ = color;


  /**
   * The opacity of the fill.
   * @type {number}
   * @private
   */
  this.opacity_ = opt_opacity || 1.0;
};
goog.inherits(goog.graphics.SolidFill, goog.graphics.Fill);


/**
 * @return {string} The color of this fill.
 */
goog.graphics.SolidFill.prototype.getColor = function() {
  return this.color_;
};


/**
 * @return {number} The opacity of this fill.
 */
goog.graphics.SolidFill.prototype.getOpacity = function() {
  return this.opacity_;
};
