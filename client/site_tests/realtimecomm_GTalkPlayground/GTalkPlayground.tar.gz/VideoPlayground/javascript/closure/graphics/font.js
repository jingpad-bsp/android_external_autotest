// Copyright 2007 Google Inc. All Rights Reserved.


/**
 * @fileoverview Represents a font to be used with a Renderer.
 * @author arv@google.com (Erik Arvidsson)
 * @see ../demos/graphics/basicelements.html
 */


goog.provide('goog.graphics.Font');


/**
 * This class represents a font to be used with a renderer.
 * @param {number} size  The font size.
 * @param {string} family  The font family.
 * @constructor
 */
goog.graphics.Font = function(size, family) {
  /**
   * Font size.
   * @type {number}
   */
  this.size = size;
  // TODO(arv): Is this in pixels or drawing units based on the coord size?

  /**
   * The name of the font family to use, can be a comma separated string.
   * @type {string}
   */
  this.family = family;
};


/**
 * Indication if text should be bolded
 * @type {boolean}
 */
goog.graphics.Font.prototype.bold = false;


/**
 * Indication if text should be in italics
 * @type {boolean}
 */
goog.graphics.Font.prototype.italic = false;
