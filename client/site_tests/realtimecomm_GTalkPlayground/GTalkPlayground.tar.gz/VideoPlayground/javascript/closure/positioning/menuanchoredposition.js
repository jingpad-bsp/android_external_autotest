// Copyright 2006 Google Inc. All Rights Reserved.

/**
 * @fileoverview Anchored viewport positioning class with both adjust and
 *     resize options for the popup.
 *
 * @author eae@google.com (Emil A Eklund)
 * @author tildahl@google.com (Michael Tildahl)
 */

goog.provide('goog.positioning.MenuAnchoredPosition');

goog.require('goog.math.Box');
goog.require('goog.math.Size');
goog.require('goog.positioning');
goog.require('goog.positioning.AnchoredViewportPosition');
goog.require('goog.positioning.Corner');
goog.require('goog.positioning.Overflow');


/**
 * Encapsulates a popup position where the popup is anchored at a corner of
 * an element.  The positioning behavior changes based on the values of
 * opt_adjust and opt_resize.
 *
 * When using this positioning object it's recommended that the movable element
 * be absolutely positioned.
 *
 * @param {Element} anchorElement Element the movable element should be
 *     anchored against.
 * @param {goog.positioning.Corner} corner Corner of anchored element the
 *     movable element should be positioned at.
 * @param {boolean=} opt_adjust Whether the positioning should be adjusted until
 *     the element fits inside the viewport even if that means that the anchored
 *     corners are ignored.
 * @param {boolean=} opt_resize Whether the positioning should be adjusted until
 *     the element fits inside the viewport on the X axis and its height is
 *     resized so if fits in the viewport. This take precedence over opt_adjust.
 * @constructor
 * @extends {goog.positioning.AnchoredViewportPosition}
 */
goog.positioning.MenuAnchoredPosition = function(anchorElement,
                                                 corner,
                                                 opt_adjust,
                                                 opt_resize) {
  goog.positioning.AnchoredViewportPosition.call(this, anchorElement, corner,
                                                 opt_adjust);
  /**
   * Whether the positioning should be adjusted until the element fits inside
   * the viewport even if that means that the anchored corners are ignored.
   * @type {boolean|undefined}
   * @private
   */
  this.resize_ = opt_resize;
};
goog.inherits(goog.positioning.MenuAnchoredPosition,
              goog.positioning.AnchoredViewportPosition);


/**
 * Repositions the movable element.
 *
 * @param {Element} movableElement Element to position.
 * @param {goog.positioning.Corner} movableCorner Corner of the movable element
 *     that should be positioned adjacent to the anchored element.
 * @param {goog.math.Box=} opt_margin A margin specifin pixels.
 * @param {goog.math.Size=} opt_preferredSize Preferred size of the
 *     moveableElement.
 */
goog.positioning.MenuAnchoredPosition.prototype.reposition =
    function(movableElement, movableCorner, opt_margin, opt_preferredSize) {

  if (this.resize_) {
    goog.positioning.positionAtAnchor(this.element, this.corner,
        movableElement, movableCorner, null, opt_margin,
        goog.positioning.Overflow.ADJUST_X |
        goog.positioning.Overflow.RESIZE_HEIGHT, opt_preferredSize);
  } else {
    goog.positioning.MenuAnchoredPosition.superClass_.reposition.call(
        this,
        movableElement,
        movableCorner,
        opt_margin,
        opt_preferredSize);
  }
};
