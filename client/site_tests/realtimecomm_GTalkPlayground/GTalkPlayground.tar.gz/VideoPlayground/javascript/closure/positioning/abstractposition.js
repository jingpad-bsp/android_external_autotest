// Copyright 2006 Google Inc. All Rights Reserved.

/**
 * @fileoverview Abstract base class for positioning implementations.
 *
 * @author eae@google.com (Emil A Eklund)
 */

goog.provide('goog.positioning.AbstractPosition');

goog.require('goog.math.Box');
goog.require('goog.math.Size');
goog.require('goog.positioning.Corner');



/**
 * Abstract position object. Encapsulates position and overflow handling.
 *
 * @constructor
 */
goog.positioning.AbstractPosition = function() {};


/**
 * Repositions the element. Abstract method, should be overloaded.
 *
 * @param {Element} movableElement Element to position.
 * @param {goog.positioning.Corner} corner Corner of the movable element that
 *     should be positioned adjacent to the anchored element.
 * @param {goog.math.Box=} opt_margin A margin specified in pixels.
 * @param {goog.math.Size=} opt_preferredSize PreferredSize of the
 *     movableElement.
 */
goog.positioning.AbstractPosition.prototype.reposition =
    function(movableElement, corner, opt_margin, opt_preferredSize) { };
