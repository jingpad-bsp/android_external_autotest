// Copyright 2007 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview Definition of the talk.Jid class.
 *
 * @author Jon Perlow (jonp@google.com)
 * @author Robin Schriebman (rschriebman@google.com)
 */

goog.provide('talk.Jid');

/**
 * Represents a JID (see also java/com/google/buzz/core/JID.java).
 * @param {string|null} domain  domain part of JID
 * @param {string|undefined|null} node  node part of JID
 * @param {string|undefined|null} resource  resource part of JID
 * @constructor
 */
talk.Jid = function(domain, node, resource) {
  this.domain_ = domain;
  this.node_ = talk.Jid.normalizeJidCharacters_(node);
  this.resource_ = resource;
};

/**
 * Pattern for an email address.
 * Originally stolen from google3/urchin/javascript/formverify.js.
 *
 * Per XMPP standards only these characters are not valid in the node part
 * of a jid: space "&'/:<>@.
 *
 * Updated to include apostrophe (') and backslash (\). We are allowing
 * apostrophe because it's a common character in names and allowed by dasher.
 * We are allowing backslash for our partial implementation of XEP 0106. This
 * is not guarded by an experiment because a bad JID accepted here will be
 * rejected by the server or simply fail. See com.google.buzz.core.JID for
 * more info.
 *
 * Caveat: we pass jids around as strings. The only way to ensure that
 * apostrophes are properly encoded is to pass it through either new talk.Jid,
 * a function that invokes new talk.Jid like talk.Jid.FromString or
 * talk.Jid.normalizedBarePart. The intent is that jids that are sent from the
 * server as jids are jids but when we use an email address as a jid, that
 * needs to be normalized.
 *
 * Since ()[],; aren't legal in unquoted email address, we're leaving those
 * excluded for now. It's pretty unlikely anyone other than a tester has those
 * characters in a jid and Gaia won't let you use them when creating an account.
 *
 * This requires the TLD to be 2-6 characters which supports all present and
 * proposed TLDs. To support international TLDs add
 *     [xX][nN]--[a-zA-Z0-9-]{3,}
 * as an alternative to [...]{2,6}.
 */
talk.Jid.EMAIL_REGEXP = new RegExp(
    '^([a-zA-Z0-9!#$%*?|^{}+=_.\'\\\\-])+' +
    '\\@(([a-zA-Z0-9\\-])+\\.)+[a-zA-Z0-9]{2,6}$');

/**
 * Pattern that identifies whether this is a group chat.
 * Tied to the regexp in RoomManager.java.
 */
talk.Jid.PMUC_PATTERN_REGEXP = new RegExp(
    'private-chat-[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}'
    );

/**
 * Pattern that identifies whether this is a voice only chat.
 */
talk.Jid.VOICE_PATTERN_REGEXP = new RegExp(
    '^([0-9]+\\.)?voice\\.google\\.com$');

/**
 * Domain for public profile invites.
 */
talk.Jid.PUBLICPROFILE_DOMAIN = 'public.talk.google.com';

/**
 * Pattern that identifies whether this is a group chat.
 * Tied to the regexp in RoomManager.java.
 */
talk.Jid.FC_PMUC_PATTERN_REGEXP = new RegExp(
    'fc-chat-.*'
    );

/**
 * Pattern that matches an apostrophe that needs to be encoded.
 */
talk.Jid.PATTERN_APOSTROPHE = new RegExp('\'', 'g');

/**
 * Pattern that matches an encoded apostrophe (\27) in a jid.
 */
talk.Jid.PATTERN_ENCODED_APOSTROPHE = new RegExp('\\\\27', 'g');

/**
 * String that encodes an apostrophe in a jid for string.replace.
 */
talk.Jid.REPLACEMENT_APOSTROPHE = '\'';

/**
 * String that encodes an apostrophe in a jid for string.replace.
 */
talk.Jid.REPLACEMENT_ENCODED_APOSTROPHE = '\\27';

/**
 * @param {string} str Potential email.
 * @return {boolean} Is valid email address.
 */
talk.Jid.IsValidEmail = function(str) {
  return talk.Jid.EMAIL_REGEXP.test(str);
};

/**
 * Is this a group chat room jid?
 * @param jidStr A string encoding of a JID as described above.
 * @return {boolean} Is valid room jid.
 */
talk.Jid.IsRoomJid = function(jidStr) {
  var jid = talk.Jid.FromString(jidStr);
  return (jid.getDomain() == 'groupchat.google.com' &&
          talk.Jid.PMUC_PATTERN_REGEXP.test(jid.getNode())) ||
         (jid.getDomain() == 'friendconnectchat.google.com' &&
          talk.Jid.FC_PMUC_PATTERN_REGEXP.test(jid.getNode()));
};

/**
 * Is this a Voice only jid.
 * @param {string} jidStr A string encoding of the jid
 */
talk.Jid.IsVoiceOnlyJid = function(jidStr) {
  var jid = talk.Jid.FromString(jidStr);
  return talk.Jid.VOICE_PATTERN_REGEXP.test(jid.getDomain());
};

/**
 * Is this a public profile jid.
 * @param {string|talk.Jid} jid The JID to check.
 * @return {boolean} True if the JID provided is a public profile JID.
 */
talk.Jid.IsPublicProfileJid = function(jid) {
  if (goog.isString(jid)) {
    jid = talk.Jid.FromString(jid);
  }
  return jid.getDomain() == talk.Jid.PUBLICPROFILE_DOMAIN;
};

/**
 * Returns user jid extracted from a full room jid.
 * @param {string} roomJid The full room jid.
 * @return {string?} The user@domain.com or null.
 */
talk.Jid.getMucUserJid = function(roomJid) {
  var nick = talk.Jid.resource(roomJid);
  if (nick) {
    var at = nick.lastIndexOf('_');
    if (at > 0) {
      return [nick.substr(0, at), nick.substr(at + 1)].join('@');
    }
  }
  return null;
};

/**
 * Is this a gaia jid [ngid]?
 * @param {string} jidStr A string that represents a potential ngid jid.
 * @return {boolean} True if ngid.
 */
talk.Jid.IsGaiaJid = function(jidStr) {
  var jid = talk.Jid.FromString(jidStr);
  return goog.isDefAndNotNull(jid.getNode()) &&
         jid.getDomain() == 'id.talk.google.com';
};

/**
 * Is this a bot jid? This closely parallels the same test in
 * buzz.core.JID.
 * @param {string} jidStr A string that represents a potential bot jid.
 * @return {boolean} True if it is a bot jid.
 */
talk.Jid.isBotJid = function(jidStr) {
  var jid = talk.Jid.FromString(jidStr);
  return goog.isDefAndNotNull(jid.getNode()) &&
         (jid.getDomain() == 'bot.talk.google.com' ||
          jid.getDomain() == 'prom.corp.google.com' ||
          jid.getDomain() == 'appspot.com' ||
          /promchat\.corp\.google\.com$/.test(jid.getDomain()) ||
          /appspotchat\.com$/.test(jid.getDomain()));
};

/**
 * Returns whether the given jid is well-formed. We assume that the resource
 * is always well formed.
 * @param {string} jid The jid to check
 * @return {boolean} True if the jid is valid, otherwise false
 */
talk.Jid.isValid = function(jid) {
  return talk.Jid.IsValidEmail(talk.Jid.unparsedBarePart(jid));
};


/**
 * Returns whether the given JID is bare.
 * @param {string} jid The jid to check
 * @return {boolean} True if the jid is valid, otherwise false
 */
talk.Jid.isBare = function(jid) {
  return talk.Jid.FromString(jid).getResource() == null;
};


/**
 * Returns the bare jid of a jid. You should replace calls to this function with
 * talk.Jid.normalizedBarePart or talk.Jid.unparsedBarePart.
 *
 * @param {string} fullJid The jid
 * @return {string} The bare jid
 * @deprecated Use talk.Jid.normalizedBarePart or talk.Jid.unparsedBarePart.
 */
talk.Jid.barePart = function(fullJid) {
  return talk.Jid.unparsedBarePart(fullJid);
};


/**
 * Returns the bare jid for an unparsed jid by slicing off the part after the
 * first "/". This should only be used if you know the string you have is a
 * valid jid or as part of parsing or validating a jid. This function does not
 * normalize the jid so if the string has uppercase letters or apostrophes or
 * invalid syntax, the result will not be valid.
 *
 * @param {string} fullJid The jid
 * @return {string} The bare jid
 */
talk.Jid.unparsedBarePart = function(fullJid) {
  var slashIndex = fullJid.indexOf('/');
  if (slashIndex == -1) {
    return fullJid;
  } else {
    return fullJid.substring(0, slashIndex);
  }
};


/**
 * Convert a bare jid to normalized form. Parses the jid and then converts it
 * back into a string.
 *
 * @param {string} str A string encoding of a JID as described above.
 * @return {string} Normalized bare jid.
 */
talk.Jid.normalizedBarePart = function(str) {
  return talk.Jid.FromString(str).makeBare().toString().toLowerCase();
};


/**
 * Returns the node part of the given jid, or null if none.
 * @param {string} jid The jid
 * @return {string} The node of the jid
 */
talk.Jid.node = function(jid) {
  return talk.Jid.FromString(jid).getNode();
};


/**
 * Returns the domain part of the given jid.
 * @param {string} jid The jid
 * @return {string} The domain of the jid
 */
talk.Jid.domain = function(jid) {
  return talk.Jid.FromString(jid).getDomain();
};


/**
 * Returns the resource name part of the given jid, or null if none.
 * @param {string} jid The jid
 * @return {string} The resource of the jid
 */
talk.Jid.resource = function(jid) {
  return talk.Jid.FromString(jid).getResource();
};


/**
 * Returns an object with a node, domain, and resource
 * property corresponding to the three parsed parts of
 * the JID.
 */
talk.Jid.FromString = function(str) {
  var slIndex = str.indexOf('/');
  var atIndex = str.indexOf('@');

  var resource = null;
  if (slIndex < 0) {
    slIndex = str.length;
  } else {
    if (slIndex + 1 < str.length) {
      resource = str.substring(slIndex + 1);
    }
  }

  var node = null;
  if (atIndex >= 0) {
    if (atIndex < slIndex) {
      if (atIndex > 0) {
        node = str.substring(0, atIndex);
      }
    } else {
      atIndex = -1;
    }
  }

  // now grab the domain
  var domain = str.substring(atIndex + 1, slIndex);
  return new talk.Jid(domain, node, resource);
};


/**
 * Normalizes apostrophes to \27.
 * @param {string|undefined|null} jidStr A jid or the node part of a jid as a string.
 * @return {string|undefined|null} A string with apostrophes replaced by \27.
 * @private
 */
talk.Jid.normalizeJidCharacters_ = function(jidStr) {
  return jidStr ?
         jidStr.replace(talk.Jid.PATTERN_APOSTROPHE,
             talk.Jid.REPLACEMENT_ENCODED_APOSTROPHE) :
         jidStr;
};


/**
 * Unnormalizes a jid for display.
 * @param {string} jidStr A jid in string representation.
 * @return {string} A jid in string representation with apostrophes
 *     unnormalized.
 */
talk.Jid.unnormalizeJidStringForDisplay = function(jidStr) {
  return jidStr.replace(talk.Jid.PATTERN_ENCODED_APOSTROPHE,
      talk.Jid.REPLACEMENT_APOSTROPHE);
};


/** Returns the domain part of the JID. */
talk.Jid.prototype.getDomain = function() {
  return this.domain_;
};


/** Returns the node part of the JID or null if it has none. */
talk.Jid.prototype.getNode = function() {
  return this.node_;
};


/** Returns the resource part of the JID or null if it has none. */
talk.Jid.prototype.getResource = function() {
  return this.resource_;
};


/** Returns group chat nick based on jid. */
talk.Jid.prototype.getNickName = function() {
  return [this.node_, "_", this.domain_].join("");
};


/** Determines whether this JID is bare, i.e., has no resource. */
talk.Jid.prototype.isBareJid = function() {
  return this.resource_ == null;
};


/** Returns a bare version of this JID. */
talk.Jid.prototype.makeBare = function() {
  return this.isBareJid()
      ? this : new talk.Jid(this.domain_, this.node_, null);
};


/** Determines whether the given JID is identical to this one.
  * @param that  The JID to which to compare.
  */
talk.Jid.prototype.equals = function(that) {
  return (this.domain_ == that.domain_) &&
         (this.node_ == that.node_) &&
         (this.resource_ == that.resource_);
};

/**
 * Determines whether the given JID equals a given another jid or string,
 * ignoring non-bare parts.
 *
 * NOTE: for new code we are encouraging the use of talk.Jid objects over raw
 * strings, but we'll include the ability to compare with strings here for
 * convenience.
 *
 * @param {string|talk.Jid} otherJid The JID to which to compare.
 */
talk.Jid.prototype.equalsBare = function(otherJid) {
  if (goog.isString(otherJid)) {
    otherJid = talk.Jid.FromString(otherJid);
  }
  return this.node_ == otherJid.node_ && this.domain_ == otherJid.domain_;
};

/** Converts this JID to its string encoded version. */
talk.Jid.prototype.toString = function() {
  var A = new Array();
  if (this.node_ != null) {
    A.push(this.node_);
    A.push('@');
  }
  A.push(this.domain_);
  if (this.resource_ != null) {
    A.push('/');
    A.push(this.resource_);
  }
  return A.join("");
};

