// Copyright 2008 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview A bunch of tweening classes.
 *
 * @author tschmelcher@google.com (Tristan Schmelcher)
 */

goog.provide('talk.media.c3d.AlphaTween');
goog.provide('talk.media.c3d.AttrsTween');
goog.provide('talk.media.c3d.tweens');
goog.provide('talk.media.c3d.Tween');

goog.require('talk.media.c3d.easing');
goog.require('talk.media.c3d.Attrs');
goog.require('talk.media.c3d.C3dEngine');
goog.require('talk.media.c3d.SceneObject');


/**
 * Virtual base class for all tween-like operations.
 *
 * @param {number} duration The duration of the tween.
 * @param {Function} opt_doneFn A function to be called when tween finishes.
 * @constructor
 * @extends talk.media.c3d.C3dEngine.RenderCallback
 */
talk.media.c3d.Tween = function(duration, opt_doneFn) {
  talk.media.c3d.C3dEngine.RenderCallback.call(this);

  /**
   * The duration of the tween.
   *
   * @type number
   * @private
   */
  this.duration_ = duration;


  /**
   * A function to be called when the tween is finished.
   *
   * @type {Function}
   * @private
   */
  this.doneFn_ = opt_doneFn || null;
};
goog.inherits(talk.media.c3d.Tween,
    talk.media.c3d.C3dEngine.RenderCallback);


/**
 * The amount of time elapsed so far.
 *
 * @type number
 * @private
 */
talk.media.c3d.Tween.prototype.elapsed_ = 0;


/**
 * @return {number} The amount of time elapsed so far.
 */
talk.media.c3d.Tween.prototype.getElapsed = function() {
  return this.elapsed_;
};


/**
 * @return {number} The amount of time still remaining.
 */
talk.media.c3d.Tween.prototype.getRemaining = function() {
  return this.duration_ - this.elapsed_;
};


/**
 * {@inheritDoc}
 */
talk.media.c3d.Tween.prototype.onRender =
    function(time) {
  this.elapsed_ += time;
  var fraction = this.elapsed_ / this.duration_;
  var moreWork = fraction < 1.0;
  if (fraction > 1.0) {
    fraction = 1.0;
  }
  this.doTween_(fraction);
  if (!moreWork && this.doneFn_) {
    this.doneFn_();
  }
  return moreWork;
};


/**
 * Updates the 3D scene with the new state of the tween.
 *
 * @param {number} fraction The fraction of the tween that has completed.
 * @protected
 */
talk.media.c3d.Tween.prototype.doTween_ =
    goog.abstractMethod;


/**
 * A tween that adjusts the attrs of a SceneObject_.
 *
 * @param {talk.media.c3d.SceneObject} sceneObj The scene
 * object to tween.
 * @param {talk.media.c3d.Attrs} start The initial
 * attributes.
 * @param {talk.media.c3d.Attrs} end The final
 * attributes.
 * @param {number} duration The duration of the tween.
 * @param {talk.media.c3d.EasingMethod} easeMethod The easing method.
 * @param {Function} opt_doneFn A function to be called when tween finishes.
 * @constructor
 * @extends talk.media.c3d.Tween
 */
talk.media.c3d.AttrsTween = function(sceneObj, start, end,
    duration, easeMethod, opt_doneFn) {
  talk.media.c3d.Tween.call(this, duration, opt_doneFn);

  /**
   * The scene object to tween.
   *
   * @type talk.media.c3d.SceneObject
   * @private
   */
  this.sceneObj_ = sceneObj;


  /**
   * The initial attributes.
   *
   * @type talk.media.c3d.Attrs
   * @private
   */
  this.start_ = start;


  /**
   * The final attributes.
   *
   * @type talk.media.c3d.Attrs
   * @private
   */
  this.end_ = end;


  /**
   * The easing method.
   *
   * @type talk.media.c3d.EasingMethod
   * @private
   */
  this.easeMethod_ = easeMethod;

};
goog.inherits(talk.media.c3d.AttrsTween,
    talk.media.c3d.Tween);


/**
 * {@inheritDoc}
 */
talk.media.c3d.AttrsTween.prototype.doTween_ =
    function(fraction) {
  this.sceneObj_.setAttrs(new talk.media.c3d.Attrs(
      this.easeMethod_.doEase(this.start_.x, this.end_.x, fraction),
      this.easeMethod_.doEase(this.start_.y, this.end_.y, fraction),
      this.easeMethod_.doEase(this.start_.z, this.end_.z, fraction),
      this.easeMethod_.doEase(this.start_.w, this.end_.w, fraction),
      this.easeMethod_.doEase(this.start_.h, this.end_.h, fraction),
      this.easeMethod_.doEase(this.start_.d, this.end_.d, fraction)));
};


/**
 * @return {talk.media.c3d.EasingMethod} The easing method.
 */
talk.media.c3d.AttrsTween.prototype.getEaseMethod = function() {
  return this.easeMethod_;
};


/**
 * A tween that adjusts the alpha component of a Dimmable object.
 *
 * @param {talk.media.c3d.Dimmable} target The object to tween.
 * @param {number} start The initial alpha.
 * @param {number} end The final alpha.
 * @param {number} duration The duration of the tween.
 * @param {talk.media.c3d.EasingMethod} easeMethod The easing method.
 * @param {Function} opt_doneFn A function to be called when tween finishes.
 * @constructor
 * @extends talk.media.c3d.Tween
 */
talk.media.c3d.AlphaTween = function(target, start, end,
    duration, easeMethod, opt_doneFn) {
  talk.media.c3d.Tween.call(this, duration, opt_doneFn);

  /**
   * The object to tween.
   *
   * @type {talk.media.c3d.Dimmable}
   * @private
   */
  this.target_ = target;


  /**
   * The initial alpha.
   *
   * @type number
   * @private
   */
  this.start_ = start;


  /**
   * The final alpha.
   *
   * @type number
   * @private
   */
  this.end_ = end;


  /**
   * The easing method.
   *
   * @type talk.media.c3d.EasingMethod
   * @private
   */
  this.easeMethod_ = easeMethod;

};
goog.inherits(talk.media.c3d.AlphaTween,
    talk.media.c3d.Tween);


/**
 * {@inheritDoc}
 */
talk.media.c3d.AlphaTween.prototype.doTween_ =
    function(fraction) {
  this.target_.setAlpha(
      this.easeMethod_.doEase(this.start_, this.end_, fraction));
};
