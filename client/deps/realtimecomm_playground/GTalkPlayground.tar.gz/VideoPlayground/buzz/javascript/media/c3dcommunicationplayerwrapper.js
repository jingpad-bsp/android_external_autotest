// Copyright 2009 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview A wrapper for C3dCommunicationPlayer that handles falling back
 * to Flash.
 *
 * @author tschmelcher@google.com (Tristan Schmelcher)
 */

goog.provide('talk.media.C3dCommunicationPlayerWrapper');

goog.require('goog.events.EventHandler');
goog.require('goog.events.EventTarget');
goog.require('talk.media.C3dCommunicationPlayer');
goog.require('talk.media.C3dMuteHandler');
goog.require('talk.media.C3dNotifier');
goog.require('talk.media.CallManager');
goog.require('talk.media.CommunicationPlayer');
goog.require('talk.media.UiMode');

/**
 * Creates a wrapper for C3dCommunicationPlayer that handles falling back to
 * Flash in the event of a fatal error in O3D.
 *
 * @param {talk.media.CallManager} callManager The manager for voice/video
 *     calls.
 * @param {talk.media.PlayerOptions} options Options for player features.
 * @param {boolean} opt_multiView Whether to enable multiple video views.
 * @param {string} opt_flashVars Parameters to be passed to the SWF when falling
 *     back to Flash.
 * @param {string} opt_swfUrl The URL that points to the media-player.swf when
 *     falling back to Flash.
 * @param {talk.media.C3dMuteHandler} opt_muteHandler A handler for mute
 *     indications.
 * @param {boolean} opt_enableNotifications Whether to enable notifications.
 * @constructor
 * @extends goog.events.EventTarget
 */
talk.media.C3dCommunicationPlayerWrapper = function(callManager, options,
    opt_multiView, opt_flashVars, opt_swfUrl, opt_muteHandler,
    opt_enableNotifications) {
  goog.events.EventTarget.call(this);

  /**
   * The manager for voice/video calls.
   *
   * @type {talk.media.CallManager}
   * @private
   */
  this.callManager_ = callManager;


  /**
   * Parameters to be passed to the SWF when falling back to Flash.
   *
   * @type {string|undefined}
   * @private
   */
  this.flashVars_ = opt_flashVars;


  /**
   * The URL that points to the media-player.swf when falling back to Flash.
   *
   * @type {string|undefined}
   * @private
   */
  this.swfUrl_ = opt_swfUrl;


  /**
   * The UI mode for this player.
   *
   * @type {talk.media.UiMode}
   * @private
   */
  this.uiMode_ = talk.media.UiMode.NORMAL;


  /**
   * The real player.
   *
   * @type {talk.media.CommunicationPlayer|talk.media.C3dCommunicationPlayer}
   * @private
   */
  this.communicationPlayer_ = new talk.media.C3dCommunicationPlayer(
      callManager, options, opt_multiView, opt_muteHandler,
      opt_enableNotifications);

  this.communicationPlayer_.setParentEventTarget(this);

  /**
   * EventHandler to simplify installing/removing event listeners.
   *
   * @type goog.events.EventHandler
   * @private
   */
  this.eventHandler_ = new goog.events.EventHandler(this);

  this.eventHandler_.listen(this.communicationPlayer_,
      talk.media.C3dCommunicationPlayer.Events.FATAL_ERROR,
      this.onFatalO3dError_);
};
goog.inherits(talk.media.C3dCommunicationPlayerWrapper,
    goog.events.EventTarget);


/**
 * Our logger.
 *
 * @private
 */
talk.media.C3dCommunicationPlayerWrapper.prototype.logger_ =
    goog.debug.Logger.getLogger('talk.media.C3dCommunicationPlayerWrapper');


/**
 * Whether or not our call is outgoing or not. (Only set by onNewCall()).
 *
 * @type {?boolean}
 * @private
 */
talk.media.C3dCommunicationPlayerWrapper.prototype.isOutgoing_;


/**
 * The session ID of our call.
 *
 * @type {string}
 * @private
 */
talk.media.C3dCommunicationPlayerWrapper.prototype.sessionId_;


/**
 * The call participants.
 *
 * @type {Array.<Array>}
 * @private
 */
talk.media.C3dCommunicationPlayerWrapper.prototype.participants_;


/**
 * The type of call we're displaying.
 *
 * @type {talk.media.CallType}
 * @private
 */
talk.media.C3dCommunicationPlayerWrapper.prototype.callType_;


/**
 * Whether the call is multiuser or not.
 *
 * @type boolean
 * @private
 */
talk.media.C3dCommunicationPlayerWrapper.prototype.isMultiUser_;


/**
 * The Element to contain the video pane.
 *
 * @type {string|Element}
 * @private
 */
talk.media.C3dCommunicationPlayerWrapper.prototype.container_;


/**
 * Handles a fatal error from O3D by falling back to Flash, if available.
 *
 * @param {talk.media.C3dCommunicationPlayer.FatalErrorEvent} e Event data.
 * @private
 */
talk.media.C3dCommunicationPlayerWrapper.prototype.onFatalO3dError_ =
    function(e) {
  // Dispose the C3D player. It may be in an inconsistent state so don't let
  // an exception stop us.
  try {
    this.eventHandler_.unlisten(this.communicationPlayer_,
        talk.media.C3dCommunicationPlayer.Events.FATAL_ERROR,
        this.onFatalO3dError_);
    // Must remove ourself as the parent so that we don't forward the DISPOSED
    // event.
    this.communicationPlayer_.setParentEventTarget(null);
    this.communicationPlayer_.dispose();
  } catch (except) {
    this.logger_.warning('Ignoring exception during O3D player disposal',
        except);
  }
  this.communicationPlayer_ = null;

  if (!this.callManager_.canUseFlash()) {
    this.callManager_.addToLog(
        'Fatal O3D error and Flash not available. Terminating call.',
        talk.media.CallManager.LogCommentSeverity.ERROR);
    if (this.callType_ != talk.media.CallType.TEST) {
      this.callManager_.endCall(talk.media.CallManager.EndCause.PLAYER_ERROR);
    } else {
      // Test calls bypass the active call system; must access TalkPlugin
      // directly.
      this.callManager_.getTalkPlugin().terminateCall(
          this.participants_[1][0], this.sessionId_,
          talk.media.CallManager.EndCause.PLAYER_ERROR, false);
    }
    return;
  }

  this.callManager_.addToLog('Fatal O3D error; falling back to Flash',
      talk.media.CallManager.LogCommentSeverity.ERROR);
  // Instantiate a Flash player in its place.
  this.communicationPlayer_ = new talk.media.CommunicationPlayer(
      this.callManager_, this.flashVars_, this.swfUrl_);
  this.communicationPlayer_.setContainer(this.container_);
  this.communicationPlayer_.setParentEventTarget(this);
  // Restore the call as a Flash call.
  if (this.callType_ != talk.media.CallType.TEST) {
    this.communicationPlayer_.displayActiveCall(this.participants_,
        this.isMultiUser_);
  } else {
    // Test calls bypass the active call system; must use onNewCall().
    this.communicationPlayer_.onNewCall(
        /** @type{boolean} */(this.isOutgoing_),
        /** @type{string} */(this.sessionId_),
        this.participants_,
        /** @type{talk.media.CallType} */(this.callType_),
        this.isMultiUser_);
  }
};


/**
 * Handles messages from the server, flute, or Gmail actions.
 * Delegates to the real player.
 *
 * @param {string} msg the kind of message to send to the player.
 * @param {Array|string} args the arguments to be sent with the message.
 */
talk.media.C3dCommunicationPlayerWrapper.prototype.sendToPlayer =
    function(msg, args) {
  if (!this.communicationPlayer_) {
    return;
  }
  this.communicationPlayer_.sendToPlayer(msg, args);
};


/**
 * Removes the player (if present). This is public for historical reasons
 * only.
 * Delegates to the real player.
 */
talk.media.C3dCommunicationPlayerWrapper.prototype.removePlayer = function() {
  if (!this.communicationPlayer_) {
    // This gets called _after_ dispose(), so the player may no longer be here.
    // TODO(tschmelcher): Remove this method from the API.
    return;
  }
  this.communicationPlayer_.removePlayer();
};


/**
 * Handles a new call.
 * Delegates to the real player.
 *
 * @param {boolean} isOutgoing If the call is placed by the local user or not.
 * @param {string} sessionId The id of the call session.
 * @param {Array.<Array>} participants The users in the call. Index 0
 *     is the local user.  User array elements are [{string} JID,
 *     {boolean} isLocal, {string} avatarUrl].
 * @param {talk.media.CallType} callType The type of call.
 * @param {boolean} isMultiUser Whether the call is a MUC call.
 */
talk.media.C3dCommunicationPlayerWrapper.prototype.onNewCall = function(
    isOutgoing, sessionId, participants, callType, isMultiUser) {
  this.communicationPlayer_.onNewCall(isOutgoing, sessionId, participants,
      callType, isMultiUser);
  this.isOutgoing_ = isOutgoing;
  this.sessionId_ = sessionId;
  this.participants_ = participants;
  this.callType_ = callType;
  this.isMultiUser_ = isMultiUser;
};


/**
 * Begins displaying the already active call.
 * Delegates to the real player.
 *
 * @param {Array.<Array>} participants The users in the active call.
 * @param {boolean} isMultiUser Whether the call is a MUC call.
 */
talk.media.C3dCommunicationPlayerWrapper.prototype.displayActiveCall = function(
    participants, isMultiUser) {
  var activeCall = this.callManager_.getActiveCall();
  if (!activeCall) {
    this.logger_.warning('displayActiveCall called with no active call');
    return;
  }
  this.communicationPlayer_.displayActiveCall(participants, isMultiUser);
  this.isOutgoing_ = null;
  this.sessionId_ = activeCall.sessionId;
  this.participants_ = participants;
  this.callType_ = activeCall.type;
  this.isMultiUser_ = isMultiUser;
};


/**
 * Handles a jingle signaling or talk plugin message.
 * Delegates to the real player.
 *
 * @param {string} type The kind of msg.
 * @param {string} message The json message to handle.
 */
talk.media.C3dCommunicationPlayerWrapper.prototype.relayCallMessage = function(
    type, message) {
  if (!this.communicationPlayer_) {
    return;
  }
  this.communicationPlayer_.relayCallMessage(type, message);
};


/**
 * Handles changes to microphone mute state of the active call.
 *
 * @param {talk.media.CallManager.MicMuteEvent} e The event.
 */
talk.media.C3dCommunicationPlayerWrapper.prototype.handleMicMuteNotification =
    function(e) {
  if (!this.communicationPlayer_) {
    return;
  }
  this.communicationPlayer_.handleMicMuteNotification(e);
};


/**
 * Shows the avatar for a given jid.
 *
 * @param {string} jid The jid whose avatar to show.
 */
talk.media.C3dCommunicationPlayerWrapper.prototype.showAvatar = function(jid) {
  this.communicationPlayer_.showAvatar(jid);
};


/**
 * Updates the list of participants.
 *
 * @param {Array.<Array>} participants The list of participants in the call.
 *     Index 0 is the local user.  User array elements are [{string} JID,
 *     {boolean} isLocal, {string} avatarUrl].
 */
talk.media.C3dCommunicationPlayerWrapper.prototype.updateParticipants =
    function(participants) {
  this.participants_ = participants;
  this.communicationPlayer_.updateParticipants(participants);
};


/**
 * Returns the UI mode for this player.
 *
 * @return {talk.media.UiMode} The UI mode for this player.
 */
talk.media.C3dCommunicationPlayerWrapper.prototype.getUiMode = function() {
  return this.uiMode_;
};


/**
 * Sets the UI mode for this player.
 *
 * @param {talk.media.UiMode} uiMode The UI mode for this player.
 */
talk.media.C3dCommunicationPlayerWrapper.prototype.setUiMode =
    function(uiMode) {
  this.uiMode_ = uiMode;
};


/**
 * Sets the container.
 *
 * @param {string|Element} container The Element to contain the video pane.
 */
talk.media.C3dCommunicationPlayerWrapper.prototype.setContainer =
    function(container) {
  this.container_ = container;
  this.communicationPlayer_.setContainer(container);
};


/**
 * @protected
 * @override
 */
talk.media.C3dCommunicationPlayerWrapper.prototype.disposeInternal =
    function() {
  this.dispatchEvent(talk.media.CommunicationPlayer.Events.DISPOSED);
  talk.media.C3dCommunicationPlayerWrapper.superClass_.disposeInternal.call(
      this);
  if (goog.isDefAndNotNull(this.communicationPlayer_)) {
    this.communicationPlayer_.dispose();
    this.communicationPlayer_ = null;
  }
};
