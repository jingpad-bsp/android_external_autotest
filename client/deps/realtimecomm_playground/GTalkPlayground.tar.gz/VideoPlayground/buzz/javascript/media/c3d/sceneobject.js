// Copyright 2008 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview Encapsulates a Client3D plugin NPObject for a physical object
 * in the 3D scene.
 *
 * @author tschmelcher@google.com (Tristan Schmelcher)
 */

goog.provide('talk.media.c3d.SceneObject');

goog.require('talk.media.c3d.helpers');
goog.require('talk.media.c3d.Attrs');
goog.require('talk.media.c3d.Dimmable');


/**
 * Encapsulates the details of interacting with an object in the C3D scene.
 *
 * @param {Object} transform The C3D Transform for this object. This is the
 * container in C3D for the vertices, shapes, textures, etc. that make up this
 * object, which we use to manipulate it.
 * @param {Object} pack The C3D Pack object to use.
 * @param {Object} shape The shape for this sceneobject.
 * @extends {talk.media.c3d.Dimmable}
 * @constructor
 */
talk.media.c3d.SceneObject = function(transform, pack, shape) {

  /**
   * The C3D Transform for this object. This is the container in C3D for the
   * vertices, shapes, textures, etc. that make up this object, which we use to
   * manipulate it.
   *
   * @type Object
   * @private
   */
  this.transform_ = transform;

  this.scaleTransform_ = pack['createObject']('Transform');
  this.scaleTransform_['parent'] = this.transform_;
  this.scaleTransform_['addShape'](shape);
  this.alpha_ = this.scaleTransform_['createParam']('alpha', 'o3d.ParamFloat');
  this.alpha_['value'] = 0.0;
};
goog.inherits(talk.media.c3d.SceneObject, talk.media.c3d.Dimmable);


/**
 * The spatial attributes for this object.
 *
 * @type {talk.media.c3d.Attrs}
 * @private
 */
talk.media.c3d.SceneObject.prototype.attrs_;


/**
 * @return {talk.media.c3d.Attrs} This object's spatial attributes.
 */
talk.media.c3d.SceneObject.prototype.getAttrs = function() {
  return this.attrs_;
};


/**
 * Changes this object's spatial attributes.
 *
 * @param {talk.media.c3d.Attrs} attrs The new attributes.
 */
talk.media.c3d.SceneObject.prototype.setAttrs = function(attrs) {
  this.attrs_ = attrs;
  this.scaleTransform_['identity']();
  this.scaleTransform_['scale'](attrs.w, attrs.h, 0);
  this.transform_['identity']();
  this.transform_['translate'](attrs.x, attrs.y, attrs.z);
};


/**
 * Returns this object's transform. Used for creating child objects.
 *
 * @return {Object} The C3D Transform for this object.
 */
talk.media.c3d.SceneObject.prototype.getTransform = function() {
  return this.transform_;
};


/**
 * Sets the alpha (brightness) scaling value for this object.
 *
 * @param {number} value The new value.
 * @override
 */
talk.media.c3d.SceneObject.prototype.setAlpha = function(value) {
  this.alpha_['value'] = value;
};


/**
 * Disposes this object and removes it from the scene graph.
 */
talk.media.c3d.SceneObject.prototype.dispose = function() {
  this.transform_['parent'] = null;
  this.attrs_ = null;
};
