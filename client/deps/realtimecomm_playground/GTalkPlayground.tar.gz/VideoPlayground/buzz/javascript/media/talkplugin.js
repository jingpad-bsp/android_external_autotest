// Copyright 2007 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview Definition of the TalkPlugin class.
 *
 * @author jessan@google.com (Jessan Hutchison-Quillian)
 *
 */

goog.provide('talk.media.TalkPlugin');
goog.provide('talk.media.TalkPlugin.ErrorEvent');
goog.provide('talk.media.TalkPlugin.FluteStateChangedEvent');
goog.provide('talk.media.TalkPlugin.VersionEvent');

goog.require('goog.debug.Logger');
goog.require('goog.events.Event');
goog.require('goog.events.EventHandler');
goog.require('goog.events.EventTarget');
goog.require('goog.Timer');
goog.require('goog.userAgent');
goog.require('talk.media.CallType');
goog.require('talk.media.IdleSignal');
goog.require('talk.media.RendererDetector');
goog.require('talk.media.TalkPluginChannel');
goog.require('talk.media.TalkPluginEvent');

/**
 * Handles communication with the Google Talk Plugin and determines the
 * voice and video capabilities of the client.
 *
 * @constructor
 * @param {string} bareJid our user's bare JID.
 * @param {talk.media.RendererDetector} rendererDetector helper to detect
 *     Client3D or Flash.
 * @param {Object} opt_mfInfo Additional information to pass down to the Google
 * Talk Plugin in the 'mf' message exchange.
 * @extends {goog.events.EventTarget}
 */
talk.media.TalkPlugin = function(bareJid, rendererDetector, opt_mfInfo) {
  goog.events.EventTarget.call(this);

  /**
   * @type {goog.events.EventHandler}
   * @private
   */
  this.eventHandler_ = new goog.events.EventHandler(this);

  /**
   * Our user's bare JID.
   *
   * @type {string}
   * @private
   */
  this.bareJid_ = bareJid;

  /**
   * An object for detecting what renderer to use.
   *
   * @type {talk.media.RendererDetector}
   * @private
   */
  this.rendererDetector_ = rendererDetector;

  /**
   * A map containing information to send to the Google Talk Plugin in the
   * 'mf' message
   * @type {Object}
   * @private
   */
  this.mfInfo_ = opt_mfInfo || {};
};
goog.inherits(talk.media.TalkPlugin, goog.events.EventTarget);


/**
 * The states of flute availability.
 *
 * @enum {number}
 * @private
 */
talk.media.TalkPlugin.FluteState_ = {
  /**
   * Flute state is not yet known and is being determined.
   */
  PENDING: 0,

  /**
   * Flute is available.
   */
  AVAILABLE: 1,

  /**
   * Flute is not available, i.e. the plugin is not installed (or it is but we
   * don't have Flash or Client3D and hence can't make proper use of it).
   */
  NOT_AVAILABLE: 2,

  /**
   * Flute is recovering, i.e. it used to be available but then crashed and now
   * is unavailable. Ideally it will come back up shortly.
   */
  RECOVERING: 3
};

/**
 * Event fired when the flute state changes. May contain idle information.
 * @param {talk.media.IdleSignal} nativeIdleState Idle state.
 * @extends {goog.events.Event}
 * @constructor
 */
talk.media.TalkPlugin.FluteStateChangedEvent = function (nativeIdleState) {
  goog.events.Event.call(this, talk.media.TalkPluginEvent.FLUTESTATE_CHANGED);

  /**
   * Idle signal, one of {none, active, idle}.
   * @type {talk.media.IdleSignal}
   */
  this.nativeIdleState = nativeIdleState;
};
goog.inherits(talk.media.TalkPlugin.FluteStateChangedEvent, goog.events.Event);

/**
 * The video send item in the bitmap of system capabilities sent up by flute.
 * @type {number}
 * @const
 */
talk.media.TalkPlugin.VIDEO_SEND_CAPABILITY = 1 << 3;


/**
 * The video receive item in the bitmap of system capabilities sent up by flute.
 * @type {number}
 * @const
 */
talk.media.TalkPlugin.VIDEO_RECV_CAPABILITY = 1 << 2;


/**
 * The audio send item in the bitmap of system capabilities sent up by flute.
 * @type {number}
 * @const
 */
talk.media.TalkPlugin.AUDIO_SEND_CAPABILITY = 1 << 1;


/**
 * The audio receive item in the bitmap of system capabilities sent up by flute.
 * @type {number}
 * @const
 */
talk.media.TalkPlugin.AUDIO_RECV_CAPABILITY = 1 << 0;

/**
 * The version of the JavaScript code running in the browser. Used by the server
 * to maintain backwards compatibility.
 * @type {number}
 * @const
 */
talk.media.TalkPlugin.JS_VERSION = 1;


/**
 * Cache of the last 'mf' message from flute containing the version.
 * @type {Array}
 * @private
 */
talk.media.TalkPlugin.prototype.versionJson_;


/**
 * Cache of the state object from the last 'fs' message from flute.
 * @type {Array}
 * @private
 */
talk.media.TalkPlugin.prototype.stateJson_;


/**
 * The channel we use to talk to the Google Talk plugin daemon
 * @type {talk.media.TalkPluginChannel}
 * @private
 */
talk.media.TalkPlugin.prototype.pluginChannel_;


/**
 * Whether or not a channel to the plugin has been set up
 * @type {boolean}
 * @private
 */
talk.media.TalkPlugin.prototype.isChannelSetup_;


/**
 * State of flute availability; initially PENDING.
 *
 * @type {talk.media.TalkPlugin.FluteState_}
 * @private
 */
talk.media.TalkPlugin.prototype.fluteState_ =
    talk.media.TalkPlugin.FluteState_.PENDING;


/**
 * Logger.
 * @type {goog.debug.Logger}
 * @private
 */
talk.media.TalkPlugin.prototype.logger_ =
    goog.debug.Logger.getLogger('talk.media.TalkPlugin');


/**
 * Commands supported by the Talk Plugin.
 *
 * TODO(perd): Move the non-event constants in Events here.
 *
 * @enum {string}
 */
talk.media.TalkPlugin.Command = {
  /**
   * Activates the currently selected audio input device.  The full message
   * should be [Command, '', session-id].
   */
  MIC_ON: 'micon',

  /**
   * Deactivates the previously activated audio input device.  The full message
   * should be [Command, '', session-id].
   */
  MIC_OFF: 'micoff',

  /**
   * Plays a sound clip on the currently selected audio output device.  The
   * full message should be [Command, '', session-id, Sound].
   */
  PLAY_SOUND: 'jtone',

  /**
   * Reverts device preferences in Google Talk Plugin to the last saved ones.
   */
  REVERT_DEVICE_PREFS: 'revertdevicestate'
};


/**
 * Sounds supported by the PLAY_SOUND Command.
 *
 * @enum {string}
 */
talk.media.TalkPlugin.Sound = {
  /**
   * A ring tone.
   */
  RING: 'ringback'
};


/**
 * An event indicating the magicflute version we are aware of has changed.
 *
 * @param {Array} json The json message representing the version update.
 * @constructor
 * @extends {goog.events.Event}
 */
talk.media.TalkPlugin.VersionEvent = function(json) {
  goog.events.Event.call(this, talk.media.TalkPluginEvent.VERSION);

  /**
   * @type {Array}
   */
  this.json = json;
};
talk.media.TalkPlugin.VersionEvent.inherits(goog.events.Event);


/**
 * An event indicating the plugin generated an error
 *
 * @param {Array} errorData The json message representing the error.
 * @constructor
 * @extends {goog.events.Event}
 */
talk.media.TalkPlugin.ErrorEvent = function(errorData) {
  goog.events.Event.call(this, talk.media.TalkPluginEvent.ERROR);

  /**
   * @type {Array}
   */
  this.errorData = errorData;
};
talk.media.TalkPlugin.ErrorEvent.inherits(goog.events.Event);


/**
 * Tries to create a channel to talk to the Google Talk plugin daemon via a
 * browser plugin.
 */
talk.media.TalkPlugin.prototype.initialize = function() {
  if (!this.isChannelSetup_) {
    this.pluginChannel_ = this.createPluginChannel(this.bareJid_);
    this.fluteState_ = talk.media.TalkPlugin.FluteState_.PENDING;
    if (this.pluginChannel_.initialize()) {
      this.scheduleBrokenInstallCheck();
      this.setupChannel_();
    } else {
      this.disposeChannel_();
      // Let the server know we have no flute.
      this.fireVersionEvent_();
    }
  } else {
    this.logger_.warning(
        'initialized called after a plugin channel has already been set up');
  }
};


/**
 * Disposes and releases the plugin channel object.
 *
 * @private
 */
talk.media.TalkPlugin.prototype.disposeChannel_ = function() {
  if (this.pluginChannel_) {
    this.pluginChannel_.dispose();
    this.pluginChannel_ = null;
  }
}


/**
 * Starts a call-once timer that checks that we get a response from
 * the googletalkplugin process at startup. If we don't get this message
 * then it is very likely that the installation is broken.
 * (The browser plugin is installed but nothing else)
 *
 * @protected
 */
talk.media.TalkPlugin.prototype.scheduleBrokenInstallCheck = function() {
  this.logger_.info('Scheduling broken-install-check');
  goog.Timer.callOnce(this.checkBrokenInstall, 25000, this);
};


/**
 * Verifies that the install isn't broken. This is called by the
 * broken-install-watchdog timer, calling it elsewhere after the
 * initialization has completed will have no effect.
 *
 * @protected
 */
talk.media.TalkPlugin.prototype.checkBrokenInstall = function() {
  if (this.fluteState_ == talk.media.TalkPlugin.FluteState_.PENDING) {
    this.logger_.severe('talkplugin install seems broken.');
    this.fireVersionEvent_();
  } else {
    this.logger_.info('talkplugin install seem ok; got response from flute.');
  }
};


/**
 * Creates a new TalkPluginChannel instance with the specified bare JID.
 * Override this to inject a mock when testing.
 *
 * @param {string} bareJid The bare JID of the user.
 * @return {talk.media.TalkPluginChannel} A new plugin channel.
 * @protected
 */
talk.media.TalkPlugin.prototype.createPluginChannel = function(bareJid) {
  return new talk.media.TalkPluginChannel(bareJid, this.rendererDetector_, null,
      this.mfInfo_);
};


/**
 * Send a message to the Google Talk Plugin.
 *
 * @param {string} msg The message to be sent to the plugin.
 */
talk.media.TalkPlugin.prototype.sendMsg = function(msg) {
  if (this.isChannelSetup_) {
    this.pluginChannel_.send(msg);
  } else {
    this.logger_.warning(
        'Unable to send message. Channel was not setup. ' + msg);
  }
};


/**
 * Listens to events from the TalkPluginChannel.
 *
 * @private
 */
talk.media.TalkPlugin.prototype.setupChannel_ = function() {
  if (!this.isChannelSetup_) {
    this.pluginChannel_.setParentEventTarget(this);
    this.eventHandler_.listen(this.pluginChannel_,
        talk.media.TalkPluginEvent.MESSAGE,
        this.handleMessage_);
    this.isChannelSetup_ = true;
  }
};


/**
 * Determines if we have a working connection to magicflute.
 *
 * @return {boolean} Whether or not we are connected to magicflute.
 */
talk.media.TalkPlugin.prototype.isConnected = function() {
  return this.isChannelSetup_ &&
      this.fluteState_ == talk.media.TalkPlugin.FluteState_.AVAILABLE;
};


/**
 * Determines if the google talk plugin is installed by checking the
 * availablity of the browser plugin.
 *
 * @return {boolean} Whether or not magicflute is installed.
 */
talk.media.TalkPlugin.prototype.isInstalled = function() {
  return !!this.pluginChannel_;
};


/**
 * Determines if we are in the process of setting up a connection to
 * magicflute.
 *
 * @return {boolean} Whether or not we are connecting to magicflute.
 */
talk.media.TalkPlugin.prototype.isConnecting = function() {
  return this.isChannelSetup_ &&
      this.fluteState_ == talk.media.TalkPlugin.FluteState_.PENDING;
};


/**
 * Returns the bare jid of the local user
 *
 * @return {string} The local user's bare jid
 */
talk.media.TalkPlugin.prototype.getLocalJid = function() {
  return this.bareJid_;
};


/**
 * Determines if we are attempting to re-connect to magicflute.
 *
 * @return {boolean} Whether or not we are re-connecting to magicflute.
 */
talk.media.TalkPlugin.prototype.isRecovering = function() {
  return this.isChannelSetup_ &&
      this.fluteState_ == talk.media.TalkPlugin.FluteState_.RECOVERING;
};


/**
 * Determines if we have a camera installed.
 *
 * @return {boolean} Whether or not we have a camera installed.
 */
talk.media.TalkPlugin.prototype.hasCameraInstalled = function() {
  var versionInfo = this.getFluteVersionInfo();
  var systemInfo;
  if (versionInfo) {
    systemInfo = versionInfo[4];
  } else {
    systemInfo = this.generateSystemInfo();
  }
  if (systemInfo['caps']) {
    return !!(systemInfo['caps'] & talk.media.TalkPlugin.VIDEO_SEND_CAPABILITY);
  }
  return false;
};


/**
 * Determines which renderers are supported by the plugin by looking at the
 * metadata in the flute version message.
 *
 * @param {Array} opt_msg Optional version message to parse.
 * @return {number} Bitwise combination of supported types of renderers.
 */
talk.media.TalkPlugin.prototype.getRenderCapabilities = function(opt_msg) {
  var versionInfo;
  if (opt_msg == undefined) {
    versionInfo = this.getFluteVersionInfo();
  } else {
    versionInfo = opt_msg;
  }
  if (versionInfo) {
    var renderer = versionInfo[4]['renderer'];
    if (renderer) {
      return renderer;
    }
  }
  return 0;
};


/**
 * Determines if the plugin supports rendering with O3D.
 *
 * @return {boolean} Whether or not the plugin can render with O3D.
 */
talk.media.TalkPlugin.prototype.canUseClient3D = function() {
  return !!(this.getRenderCapabilities() &
      talk.media.RendererDetector.RENDER_CLIENT3D_CAPABILITY);
};


/**
 * Determines if the plugin supports rendering with Flash.
 *
 * @return {boolean} Whether or not the plugin can render with client3d.
 */
talk.media.TalkPlugin.prototype.canUseFlash = function() {
  return !!(this.getRenderCapabilities() &
      talk.media.RendererDetector.RENDER_MAGICCAM_CAPABILITY);
};


/**
 * Handles a message from the Google Talk plugin.
 *
 * @param {talk.media.CallEvent} e The event wrapping the
 *     message.
 * @private
 */
talk.media.TalkPlugin.prototype.handleMessage_ = function(e) {
  if (e.msgType == talk.media.TalkPluginEvent.VERSION) {
    this.handleFluteVersionMessage_(e.getParsedMsg());
  } else if (e.msgType == talk.media.TalkPluginEvent.ERROR) {
    this.dispatchEvent(new talk.media.TalkPlugin.ErrorEvent(e.getParsedMsg()));
  } else if (e.msgType == 'termall') {
    this.dispatchEvent(talk.media.TalkPluginEvent.END_CALL);
  } else if (e.msgType == talk.media.TalkPluginEvent.DEAD) {
    this.versionJson_ = null;
    this.stateJson_ = null;
  } else if (e.msgType == 'fs') {
    this.stateJson_ = e.getParsedMsg()[1];
    this.dispatchEvent(new talk.media.TalkPlugin.FluteStateChangedEvent(
        this.getNativeIdleSignal_()));
  }
};


/**
 * Handles a flute version message from the Google Talk plugin.
 *
 * @param {Array} msg The message.
 * @private
 */
talk.media.TalkPlugin.prototype.handleFluteVersionMessage_ = function(msg) {
  // 'nf' versions are used to indicate a SWF that checks the capabilities of
  // the system. It has no actual flute abilities.
  if (!msg[1] || msg[1].indexOf('nf') < 0) {
    this.versionJson_ = msg;
    // Compatibility fix for older plugins not including system info.
    if (!this.versionJson_[4]) {
      this.logger_.warning('System info missing from "mf" msg: ' + msg);
      this.versionJson_[4] = this.generateSystemInfo();
    }

    this.versionJson_[4]['clientver'] = talk.media.TalkPlugin.JS_VERSION;

    // Compatibility fix for older plugins not including render caps. Cannot
    // just use ! because this is an integer and 0 is a legal value.
    if (!goog.isDef(this.versionJson_[4]['renderer'])) {
      this.versionJson_[4]['renderer'] =
          talk.media.RendererDetector.RENDER_MAGICCAM_CAPABILITY;
    }
    // Pass available renderers of browser.
    this.versionJson_[4]['browserRenderer'] =
        this.rendererDetector_.getCapabilities();
    // Pass versions of plugins we care about.
    if (goog.userAgent.flash.HAS_FLASH) {
      this.versionJson_[4]['flashVersion'] = goog.userAgent.flash.VERSION;
    }
    if (goog.isDefAndNotNull(this.rendererDetector_.getClient3DDetector())) {
      this.versionJson_[4]['o3dVersion'] =
          this.rendererDetector_.getClient3DDetector().getVersion();
    }

  }

  this.fireVersionEvent_();
};


/**
 * Builds a VersionEvent using getFluteVersionInfo.
 *
 * @private
 */
talk.media.TalkPlugin.prototype.fireVersionEvent_ = function() {
  var versionInfo = this.getFluteVersionInfo();
  // Version messages with version of 'nf0' are used to indicate that
  // flute is not available.
  if (versionInfo && versionInfo[1] != 'nf0') {
    this.fluteState_ = talk.media.TalkPlugin.FluteState_.AVAILABLE;
  } else {
    if (this.fluteState_ == talk.media.TalkPlugin.FluteState_.AVAILABLE) {
      this.fluteState_ = talk.media.TalkPlugin.FluteState_.RECOVERING;
    } else {
      this.fluteState_ = talk.media.TalkPlugin.FluteState_.NOT_AVAILABLE;
    }
  }
  // We know versionInfo is an Array since we don't pass an opt_serialized to
  // getFluteVersionInfo() above.
  this.dispatchEvent(
      new talk.media.TalkPlugin.VersionEvent( /** @type Array */
          (versionInfo)));
};


/**
 * Returns the name of the OS to use in 'mf' messages.
 *
 * @private
 * @return {string} the OS's name
 */
talk.media.TalkPlugin.prototype.getOsName_ = function() {
  var os = 'other';
  if (goog.userAgent.WINDOWS) {
    os = 'windows';
  } else if (goog.userAgent.MAC) {
    if (goog.userAgent.PLATFORM.indexOf('Intel') != -1) {
      os = 'mac';
    } else {
      os = 'mac-ppc';
    }
  } else if (goog.userAgent.LINUX && this.rendererDetector_.isO3dSupported()) {
    os = 'linux';
  }
  return os;
};


/**
 * Returns the last 'mf' message from flute, or generates a 'nf' message
 * if there is no flute installed or no version message ever sent.
 *
 * @return {Object|string} The last flute version message
 */
talk.media.TalkPlugin.prototype.getFluteVersionInfo =
    function(opt_serialized) {
  /** @type Array */
  var versionInfo;
  if (!this.versionJson_ || this.versionJson_[1] == '') {
    versionInfo = ['mf', 'nf0', '0.0.0', 1, this.generateSystemInfo()];
  } else {
    versionInfo = this.versionJson_.slice();
    // TODO(perd): Include Flash version to let server decide if we're callable.
    if (!(this.rendererDetector_.getCapabilities() &
          this.getRenderCapabilities(versionInfo))) {
      // No render capabilities or not matching capabilities. Consider flute to
      // not be installed.
      versionInfo[1] = 'nf0';
      versionInfo[2] = '0.0.0';
      // Must also add in the os info for the server to consider us invitable.
      versionInfo[4]['os'] = this.getOsName_();
    }
  }
  return opt_serialized ? goog.json.serialize(versionInfo) : versionInfo;
};


/**
 * Returns a stringified version of the results of getFluteVersionInfo
 *
 * @return {string} The last flute version message
 */
talk.media.TalkPlugin.prototype.getFluteVersionInfoStr = function() {
  return goog.json.serialize(/** @type {Object} */(
      this.getFluteVersionInfo()));
};


/**
 * Generates a map of system info. Imitates the map sent up by Flute, but
 * lacks a 'caps' attribute and contains an 'os' attribute.
 *
 * @return {Object} A map describing the capabilities of the system that we
 *     know about.
 * @private
 */
talk.media.TalkPlugin.prototype.generateSystemInfo = function() {
  return {
    'os' : this.getOsName_(),
    'clientver': talk.media.TalkPlugin.JS_VERSION
  };
};


/**
 * Returns the type of the current call on this machine, if any.
 *
 * @return {talk.media.CallType} The type of the current call on this machine.
 */
talk.media.TalkPlugin.prototype.getMachineCallType = function() {
  if (!this.stateJson_) {
    return talk.media.CallType.NONE;
  }

  switch (this.stateJson_['callType']) {
    case 'v':
      return talk.media.CallType.VIDEO;
    case 'a':
      return talk.media.CallType.VOICE;
    default:
      // Not defined when no call.
      return talk.media.CallType.NONE;
  }
};


/**
 * Returns the idle signal value in the internal flute state, or
 * talk.media.IdleSignal.NONE if there's no idle signal to date.
 *
 * @return {talk.media.IdleSignal} idle signal value.
 * @private
 */
talk.media.TalkPlugin.prototype.getNativeIdleSignal_ = function() {
  if (!this.stateJson_) {
    return talk.media.IdleSignal.NONE;
  }

  switch (this.stateJson_['pr']) {
    case 'i':
      return talk.media.IdleSignal.IDLE;
    case 'a':
      return talk.media.IdleSignal.ACTIVE;
    default:
      return talk.media.IdleSignal.NONE;
  }
};


/**
 * Tears down a call in flute.
 *
 * @param {string} jid the remote JID of the call to tear down.
 * @param {string} id the session ID of the call to tear down.
 * @param {talk.media.CallManager.EndCause} cause The reason the call ended
 * @param {boolean} isRemote Whether the remote party terminated the call
 */
talk.media.TalkPlugin.prototype.terminateCall =
    function(jid, id, cause, isRemote) {
  this.sendMsg(goog.json.serialize(
      ['jt', jid, id, cause, isRemote]));
  // Old plugins will ignore this next message, so no need to check API
  // version.
  // TODO(tschmelcher): This is spurious in the C3D case. Move it to
  // CommunicationPlayer.dispose() and axe this function.
  this.sendMsg(goog.json.serialize(
      [talk.media.TalkPluginEvent.STREAM_OFF, jid, id, 0]));
};


/**
 * Sets whether or not to send detailed statistics to the server
 * (the jmidata message).
 *
 * @param {boolean} enable Whether to enable it or not.
 */
talk.media.TalkPlugin.prototype.enableDetailedStats = function(enable) {
  if (this.pluginChannel_) {
    this.pluginChannel_.enableDetailedStats(enable);
  }
};


/**
 * {@inheritDoc}
 */
talk.media.TalkPlugin.prototype.dispose = function() {
  if (!this.getDisposed()) {
    this.eventHandler_.dispose();
    this.eventHandler_ = null;
    if (this.pluginChannel_) {
      this.disposeChannel_();
    }
    talk.media.TalkPlugin.superClass_.dispose.call(this)
  }
};
