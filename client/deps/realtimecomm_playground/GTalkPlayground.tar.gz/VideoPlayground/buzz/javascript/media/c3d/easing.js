// Copyright 2008 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview A bunch of easing classes.
 *
 * @author tschmelcher@google.com (Tristan Schmelcher)
 */

goog.provide('talk.media.c3d.easing');
goog.provide('talk.media.c3d.EasingMethod');
goog.provide('talk.media.c3d.RaisedEaseIn');
goog.provide('talk.media.c3d.RaisedEaseInOut');
goog.provide('talk.media.c3d.RaisedEaseOut');


/**
 * Virtual base class for all easing methods.
 *
 * @constructor
 */
talk.media.c3d.EasingMethod = function() {
};


/**
 * Calculates the easing.
 *
 * @param {number} start The eased parameter's initial value.
 * @param {number} end Its final value.
 * @param {number} fraction The fraction of the tween that we've completed.
 * @return {number} Its new value.
 */
talk.media.c3d.EasingMethod.prototype.doEase =
    goog.abstractMethod;


/**
 * A class for doing in/out easing by raising the fraction to a given power.
 *
 * @param {number} power The value to raise the fraction to. Must be >= 0.
 * > 1 makes it move faster in the middle than at the beginning and end.
 * < 1 does the opposite.
 * == 1 means plain old linear interpolation.
 * @constructor
 * @extends talk.media.c3d.EasingMethod
 */
talk.media.c3d.RaisedEaseInOut =
    function(power) {
  talk.media.c3d.EasingMethod.call(this);

  /**
   * The value to raise the fraction to.
   *
   * @type integer
   * @private
   */
  this.power_ = power;

};
goog.inherits(talk.media.c3d.RaisedEaseInOut,
    talk.media.c3d.EasingMethod);


/**
 * {@inheritDoc}
 */
talk.media.c3d.RaisedEaseInOut.prototype.doEase =
    function(start, end, fraction) {
  fraction *= 2;
  var change = end - start;
  if (fraction < 1) {
    return change/2 * Math.pow(fraction, this.power_) + start;
  } else {
    fraction = 2 - fraction;
    return change/2 * (2 - Math.pow(fraction, this.power_)) + start;
  }
};


/**
 * A class for doing in easing by raising the fraction to a given power.
 *
 * @param {number} power The value to raise the fraction to. Must be >= 0.
 * > 1 makes it move faster at the end than at the beginning.
 * < 1 does the opposite.
 * == 1 means plain old linear interpolation.
 * @constructor
 * @extends talk.media.c3d.EasingMethod
 */
talk.media.c3d.RaisedEaseIn =
    function(power) {
  talk.media.c3d.EasingMethod.call(this);

  /**
   * The value to raise the fraction to.
   *
   * @type integer
   * @private
   */
  this.power_ = power;

};
goog.inherits(talk.media.c3d.RaisedEaseIn,
    talk.media.c3d.EasingMethod);


/**
 * {@inheritDoc}
 */
talk.media.c3d.RaisedEaseIn.prototype.doEase =
    function(start, end, fraction) {
  var change = end - start;
  return change * Math.pow(fraction, this.power_) + start;
};


/**
 * A class for doing out easing by raising the fraction to a given power.
 *
 * @param {number} power The value to raise the fraction to. Must be >= 0.
 * > 1 makes it move faster at the beginning than at the end.
 * < 1 does the opposite.
 * == 1 means plain old linear interpolation.
 * @constructor
 * @extends talk.media.c3d.EasingMethod
 */
talk.media.c3d.RaisedEaseOut =
    function(power) {
  talk.media.c3d.EasingMethod.call(this);

  /**
   * The value to raise the fraction to.
   *
   * @type integer
   * @private
   */
  this.power_ = power;

};
goog.inherits(talk.media.c3d.RaisedEaseOut,
    talk.media.c3d.EasingMethod);


/**
 * {@inheritDoc}
 */
talk.media.c3d.RaisedEaseOut.prototype.doEase =
    function(start, end, fraction) {
  var change = end - start;
  fraction = 1 - fraction;
  return change * (1 - Math.pow(fraction, this.power_)) + start;
};


/**
 * An easing method for very pronounced ease in/out. Functionally identical to
 * Strong.easeInOut in ActionScript.
 *
 * @type talk.media.c3d.RaisedEaseInOut
 * @const
 */
talk.media.c3d.STRONG_EASE_IN_OUT = new talk.media.c3d.RaisedEaseInOut(5);


/**
 * An easing method for slight ease in. Functionally identical to
 * Regular.easeIn in ActionScript.
 *
 * @type talk.media.c3d.RaisedEaseIn
 * @const
 */
talk.media.c3d.REGULAR_EASE_IN = new talk.media.c3d.RaisedEaseIn(2);


/**
 * An easing method for very pronounced ease out. Functionally identical to
 * Strong.easeOut in ActionScript.
 *
 * @type talk.media.c3d.RaisedEaseOut
 * @const
 */
talk.media.c3d.STRONG_EASE_OUT = new talk.media.c3d.RaisedEaseOut(5);
