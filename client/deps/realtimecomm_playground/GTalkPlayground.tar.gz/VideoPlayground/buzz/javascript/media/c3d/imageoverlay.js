// Copyright 2009 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview An ImageOverlay object which is a rendergraph for 2D images
 * on top of other views.
 * Inspired by //depot/googleclient/client3d/samples/fullscreen.html and
 * //depot/googleclient/client3d/samples/o3djs/rendergraph.js.
 *
 * @author geer@google.com (Arthur van der Geer)
 */

goog.provide('talk.media.c3d.ImageOverlay');

goog.require('talk.media.c3d.C3dObject');
goog.require('talk.media.c3d.Image');
goog.require('talk.media.c3d.View');
goog.require('talk.media.c3d.helpers');


/**
 * Creates an ImageOverlay render graph to draw transparent 2d images.
 *
 * @param {talk.media.c3d.O3dBundle} o3dBundle The bundle of global resources
 * for this O3D instance.
 * @param {talk.media.c3d.View} view The view to overlay.
 * @constructor
 */
talk.media.c3d.ImageOverlay = function(o3dBundle, view) {

  /**
   * The bundle of global resources for this O3D instance.
   *
   * @type {talk.media.c3d.O3dBundle}
   * @private
   */
  this.o3dBundle_ = o3dBundle;

  /**
   * The view to overlay.
   *
   * @type {Object}
   * @private
   */
  this.view_ = view;

  /**
   * The material that images will use.
   *
   * @type {Object}
   * @private
   */
  this.material_ = this.o3dBundle_.pack['createObject']('Material');
  // Set the effect and set the drawList and the default.
  this.material_['drawList'] = view.drawList;
  this.material_['effect'] = this.o3dBundle_.effect;
  this.o3dBundle_.effect['createUniformParameters'](this.material_);
  this.material_['getParam']('alpha')['value'] = 1;


  /**
   * A VertexBuffer to tell which coordinates of the texture map to a specific
   * vertex.
   *
   * @type {Object}
   * @private
   */
  this.textureBuffer_ = this.o3dBundle_.pack['createObject']('VertexBuffer');
  var texCoordField = this.textureBuffer_['createField']('FloatField', 2);
  this.textureBuffer_['set']([0, 1, 0, 0, 1, 0, 1, 1]);


  /**
   * A 2d plane for images.
   *
   * @type {Object}
   * @private
   */
  this.shape_ = talk.media.c3d.createPlane(
      this.o3dBundle_.c3dObject.getPlugin(),
      this.o3dBundle_.pack,
      this.material_,
      texCoordField);
};


/**
 * Creates and returns a talk.media.c3d.Image object without a texture set.
 *
 * @param {number} x The horizontal position in plugin client pixels.
 * @param {number} y The vertical position in plugin client pixels.

 * @return {talk.media.c3d.Image} A new Image object.
 */
talk.media.c3d.ImageOverlay.prototype.createUninitializedImage =
    function(x, y) {
  return new talk.media.c3d.Image(
      this.o3dBundle_,
      this.view_.transform,
      this.shape_,
      x,
      y);
};


/**
 * Creates and returns a talk.media.c3d.Image object and loads the texture
 * from a url.
 *
 * @param {number} x The horizontal position in plugin client pixels.
 * @param {number} y The vertical position in plugin client pixels.
 * @param {string} url The url to load the texture from.
 * @param {function()} opt_onSuccess Optional callback for successful load.

 * @return {talk.media.c3d.Image} A new Image object.
 */
talk.media.c3d.ImageOverlay.prototype.createImage = function(x, y, url,
                                                             opt_onSuccess) {
  var image = this.createUninitializedImage(x, y);
  image.loadTexture(url, opt_onSuccess);
  return image;
};


/**
 * Creates and returns a talk.media.c3d.Image object and loads the
 * given texture.
 *
 * @param {number} x The horizontal position in plugin client pixels.
 * @param {number} y The vertical position in plugin client pixels.
 * @param {Object} texture The texture to load.
 * @param {function()} opt_onSuccess Optional callback for successful load.

 * @return {talk.media.c3d.Image} A new Image object.
 */
talk.media.c3d.ImageOverlay.prototype.createImageFromTexture = function(
    x, y, texture, opt_onSuccess) {
  var image = this.createUninitializedImage(x, y);
  image.setTexture(texture, opt_onSuccess);
  return image;
};


/**
 * Creates and returns a talk.media.c3d.Image object containing the given text
 * in a pretty half-transparent message bubble bar thing.
 *
 * @param {string} text The text of the message.
 * @param {number} fontSize The font size for the text.
 * @param {number} outlineRadius The radius for the text outline.
 * @return {talk.media.c3d.Image} A new Image object.
 */
talk.media.c3d.ImageOverlay.prototype.createMessageImage = function(
    text,
    fontSize,
    outlineRadius) {
  var c3d = this.o3dBundle_.c3dObject.getPlugin();

  // The O3D CanvasPaint object for storing text properties.
  var canvasPaint = this.o3dBundle_.pack['createObject']('CanvasPaint');
  canvasPaint['setOutline'](outlineRadius, [0, 0, 0, 1]);  // Opaque black
  canvasPaint['textAlign'] = c3d['o3d']['CanvasPaint']['CENTER'];
  canvasPaint['textSize'] = fontSize;
  canvasPaint['textTypeface'] = 'Arial';
  canvasPaint['color'] = [1, 1, 1, 1];  // Opaque white

  // Get the bounds for rendering the text: [left, top, right, bottom].
  var bounds = canvasPaint['measureText'](text);
  var textWidth = bounds[2] - bounds[0];
  var textHeight = bounds[3] - bounds[1];
  // Make the canvas thicker by 30 pixels.
  var height = textHeight + 30;
  // Ensure height is even.
  if (height % 2 == 1) {
    height++;
  }
  var width = textWidth + 30;
  // Ensure width is even.
  if (width % 2 == 1) {
    width++;
  }

  // The O3D Canvas object for drawing text.
  var canvas = this.o3dBundle_.pack['createObject']('Canvas');
  canvas['setSize'](width, height);

  // Clear the whole canvas to half-transparent black.
  canvas['clear']([0, 0, 0, 0.5]);
  // Now draw the text.
  canvas['drawText'](text,
                     width / 2,
                     height / 2 + textHeight / 2,
                     canvasPaint);

  var texture = this.o3dBundle_.pack['createTexture2D'](width, height,
      c3d['o3d']['Texture']['ARGB8'],  // format
      1,  // mipmap levels
      false);
  canvas['copyToTexture'](texture);

  return this.createImageFromTexture(0, 0, texture);
};


/**
 * Removes the local objects and unregisters o3d plugin callbacks.
 */
talk.media.c3d.ImageOverlay.prototype.dispose = function() {
  this.material_ = null;
  this.shape_ = null;
  this.textureBuffer_ = null;
};
