// Copyright 2008 Google Inc. All Rights Reserved.

/**
 * @fileoverview Detector of Client3D state.
 *
 * @author geer@google.com (Arthur van der Geer)
 */

goog.provide('talk.media.Client3DDetector');

goog.require('goog.debug.Logger');
goog.require('goog.userAgent');
goog.require('talk.media.RendererDetector');

/**
 * Detects whether Client3D is installed or not.
 * At some point we might get the equivalent in {@code goog.userAgent}, just
 * like flash.
 * @constructor
 */
talk.media.Client3DDetector = function() {
};


/**
 * Creates an instance for RendererDetector to be used. The implementation is
 * here to be able to keep all client3d strings safe in a gmail mod.
 * @private
 */
var setupC3dDetector_ = function() {
  if (talk.media.RendererDetector.client3dDetector == null) {
    talk.media.RendererDetector.client3dDetector =
        new talk.media.Client3DDetector();
  }
};

setupC3dDetector_();


/**
 * Cached value of plugin detection.
 * @type {boolean}
 * @private
 */
talk.media.Client3DDetector.hasClient3D_;


/**
 * The plugin version.
 * @type {string}
 * @private
 */
talk.media.Client3DDetector.pluginVersion_;


/**
 * true if we are using the legacy O3D plugin from code.google.com/apis/o3d/,
 * false if we are using GTP's bundled and re-branded one.
 * @type {boolean}
 * @private
 */
talk.media.Client3DDetector.legacyPlugin_;


/**
 * Logger
 * @type goog.debug.Logger
 * @private
 */
talk.media.Client3DDetector.logger_ =
    goog.debug.Logger.getLogger('talk.media.Client3DDetector');


/**
 * Determines if the Client3D plugin is installed.
 * N.B.: Despite being non-static, this accesses static state.
 * @return {boolean} True if Client3D is installed, otherwise false.
 */
talk.media.Client3DDetector.prototype.isInstalled = function() {
  if (!goog.isDef(talk.media.Client3DDetector.hasClient3D_)) {
    talk.media.Client3DDetector.hasClient3D_ = false;
    talk.media.Client3DDetector.legacyPlugin_ = false;
    if (goog.userAgent.IE) {
      /** @preserveTry */
      try {
        var ax = new ActiveXObject('gtpo3d_host.O3DHostControl');
        talk.media.Client3DDetector.hasClient3D_ = true;
        talk.media.Client3DDetector.pluginVersion_ =
            talk.media.Client3DDetector.parseVersion_(ax.description);
      } catch (e) {
        talk.media.Client3DDetector.logger_.info(
            'GTP/O3D ActiveX plugin not available.');
      }
      if (!talk.media.Client3DDetector.hasClient3D_) {
        // Fall back to the generic O3D plugin if present.
        /** @preserveTry */
        try {
          var ax = new ActiveXObject('o3d_host.O3DHostControl');
          talk.media.Client3DDetector.hasClient3D_ = true;
          talk.media.Client3DDetector.legacyPlugin_ = true;
          talk.media.Client3DDetector.pluginVersion_ =
              talk.media.Client3DDetector.parseVersion_(ax.description);
        } catch (e) {
          talk.media.Client3DDetector.logger_.info(
              'O3D ActiveX plugin not available.');
        }
      }
    } else {
      if (goog.global['navigator']) {
        var mimetype = navigator.mimeTypes['application/vnd.gtpo3d.auto'];
        if (mimetype) {
          if (mimetype.enabledPlugin) {
            talk.media.Client3DDetector.hasClient3D_ = true;
            talk.media.Client3DDetector.pluginVersion_ =
                talk.media.Client3DDetector.parseVersion_(
                    mimetype.enabledPlugin.description);
          } else {
            talk.media.Client3DDetector.logger_.info(
                'O3D mimetype not enabled.');
          }
        } else {
          talk.media.Client3DDetector.logger_.info(
              'O3D mimetype not registered.');
        }
        // Fall back to the generic O3D plugin if present.
        if (!talk.media.Client3DDetector.hasClient3D_) {
          mimetype = navigator.mimeTypes['application/vnd.o3d.auto'];
          if (mimetype) {
            if (mimetype.enabledPlugin) {
              talk.media.Client3DDetector.hasClient3D_ = true;
              talk.media.Client3DDetector.legacyPlugin_ = true;
              talk.media.Client3DDetector.pluginVersion_ =
                  talk.media.Client3DDetector.parseVersion_(
                      mimetype.enabledPlugin.description);
            } else {
              talk.media.Client3DDetector.logger_.info(
                  'O3D mimetype not enabled.');
            }
          } else {
            talk.media.Client3DDetector.logger_.info(
                'O3D mimetype not registered.');
          }
        }
      } else {
        talk.media.Client3DDetector.logger_.warning(
            'Global navigator object not defined.');
      }
    }
  }
  return talk.media.Client3DDetector.hasClient3D_;
};


/**
 * Determines if the installed Client3D plugin is the legacy one.
 * N.B.: Despite being non-static, this accesses static state.
 * @return {boolean} true if legacy plugin, false if GTP O3D plugin or if
 * neither installed.
 */
talk.media.Client3DDetector.prototype.isLegacyPlugin = function() {
  if (this.isInstalled()) {
    return talk.media.Client3DDetector.legacyPlugin_;
  }
  return false;
};


/**
 * Parses the plugin description for version info.
 *
 * @param {string} description The plugin description.
 * @return {string} Version in #.#.#.# format.
 * @private
 */
talk.media.Client3DDetector.parseVersion_ = function(description) {
  // TODO(geer): Add a test for (un)supported formats.
  var version = description.match(/\d+(?:\.\d+)+/);
  if (version && version[0]) {
    return version[0];
  }
  return '';
};


/**
 * N.B.: Despite being non-static, this accesses static state.
 * @return {?string} The plugin version if installed, otherwise null.
 */
talk.media.Client3DDetector.prototype.getVersion = function() {
  if (this.isInstalled()) {
    return talk.media.Client3DDetector.pluginVersion_;
  }
  return null;
};
