// Copyright 2010 Google Inc.  All Rights Reserved.

/**
 * @fileoverview Overlays images on a video feed object and handles input
 * events.
 *
 * @author oja@google.com (Fredrik Oja)
 */

goog.provide('talk.media.c3d.FeedHandler');

goog.require('goog.Disposable');
goog.require('goog.debug.Logger');
goog.require('talk.media.c3d.Attrs');
goog.require('talk.media.c3d.Image');
goog.require('talk.media.c3d.ImageOverlay');
goog.require('talk.media.c3d.O3dBundle');
goog.require('talk.media.c3d.View');


/**
 * Overlays images on a video feed object and handles input events.
 *
 * @param {talk.media.c3d.O3dBundle} o3dBundle The global O3D bundle.
 * @param {talk.media.c3d.ShrinkableFeed} feed The object representing
 *     the feed.
 * @constructor
 * @extends {goog.Disposable}
 */
talk.media.c3d.FeedHandler = function(o3dBundle, feed) {
  goog.Disposable.call(this);

  /**
   * The bundle of global resources for this O3D instance.
   *
   * @type {talk.media.c3d.O3dBundle}
   * @protected
   */
  this.o3dBundle = o3dBundle;

  /**
   * The feed to handle.
   *
   * @type {talk.media.c3d.ShrinkableFeed}
   * @protected
   */
  this.feed = feed;

  /**
   * A bound version of onMouseMove, suitable for using as an event callback.
   *
   * @type {Function}
   * @private
   */
  this.boundOnMouseMove_ = goog.bind(this.onMouseMove, this);

  /**
   * A bound version of onMouseUp, suitable for using as an event callback.
   *
   * @type {Function}
   * @private
   */
  this.boundOnMouseUp_ = goog.bind(this.onMouseUp, this);

  /**
   * A bound version of onMouseDown, suitable for using as an event callback.
   *
   * @type {Function}
   * @private
   */
  this.boundOnMouseDown_ = goog.bind(this.onMouseDown, this);
};
goog.inherits(talk.media.c3d.FeedHandler, goog.Disposable);


/**
 * Default color of the border around the feed.
 *
 * @type {Array}
 * @private
 * @const
 */
talk.media.c3d.FeedHandler.DEFAULT_BORDER_COLOR_ = [1, 1, 1, 0.5];


/**
 * Default color of the border around the feed when highlighted.
 *
 * @type {Array}
 * @private
 * @const
 */
talk.media.c3d.FeedHandler.DEFAULT_BORDER_HIGHLIGHT_COLOR_ = [1, 1, 1, 0.9];


/**
 * Default width of the border around the feed.
 *
 * @type {number}
 * @private
 * @const
 */
talk.media.c3d.FeedHandler.DEFAULT_BORDER_WIDTH_ = 2;


/**
 * Used for creating the original border image. The border image will then be
 * scaled to fit the current dimensions of the feed.
 *
 * @type {number}
 * @private
 * @const
 */
talk.media.c3d.FeedHandler.DEFAULT_FEED_WIDTH_ = 160;


/**
 * Used for creating the original border image. The border image will then be
 * scaled to fit the current dimensions of the feed.
 *
 * @type {number}
 * @private
 * @const
 */
talk.media.c3d.FeedHandler.DEFAULT_FEED_HEIGHT_ = 100;


/**
 * Logger.
 *
 * @type {!goog.debug.Logger}
 * @private
 */
talk.media.c3d.FeedHandler.prototype.logger_ =
    goog.debug.Logger.getLogger('talk.media.c3d.FeedHandler');


/**
 * An image showing a border around the feed.
 *
 * @type {talk.media.c3d.Image}
 * @private
 */
talk.media.c3d.FeedHandler.prototype.borderImg_ = null;


/**
 * An image showing a highlight border around the feed.
 *
 * @type {talk.media.c3d.Image}
 * @private
 */
talk.media.c3d.FeedHandler.prototype.borderHighlightImg_ = null;


/**
 * Saved copy of the feeds attributes.
 *
 * @type {talk.media.c3d.Attrs}
 * @protected
 */
talk.media.c3d.FeedHandler.prototype.feedAttrs;


/**
 * The actual video scene.
 *
 * @type {talk.media.c3d.SceneObject}
 * @protected
 */
talk.media.c3d.FeedHandler.prototype.feedObject;


/**
 * Whether the border is visible or not.
 *
 * @type {boolean}
 * @private
 */
talk.media.c3d.FeedHandler.prototype.isBorderVisible_ = false;


/**
 * Whether the border is highlighted or not.
 *
 * @type {boolean}
 * @private
 */
talk.media.c3d.FeedHandler.prototype.isBorderHighlighted_ = false;


/**
 * Initializes images and requests callbacks for event handling.
 *
 * @param {talk.media.c3d.ImageOverlay} opt_imageOverlay Used for holding
 *     images over the feed. If not set, a new ImageOverlay will be created.
 */
talk.media.c3d.FeedHandler.prototype.init = function(opt_imageOverlay) {
  this.feedObject = this.feed.feedObject;
  this.feedAttrs = this.feed.getFeedAttrs();
  if (opt_imageOverlay) {
    this.imageOverlay_ = opt_imageOverlay;
  } else {
    var imageView = new talk.media.c3d.View(
        this.o3dBundle.c3dObject.getPlugin(), this.o3dBundle.pack, 2, true,
        this.o3dBundle, this.feedObject.getTransform());
    this.imageOverlay_ = new talk.media.c3d.ImageOverlay(
        this.o3dBundle, imageView);
  }
  this.createBorderImages_(
      talk.media.c3d.FeedHandler.DEFAULT_FEED_WIDTH_,
      talk.media.c3d.FeedHandler.DEFAULT_FEED_HEIGHT_,
      talk.media.c3d.FeedHandler.DEFAULT_BORDER_WIDTH_,
      talk.media.c3d.FeedHandler.DEFAULT_BORDER_COLOR_,
      talk.media.c3d.FeedHandler.DEFAULT_BORDER_HIGHLIGHT_COLOR_);
  this.borderImg_.setVisible(false);
  this.borderHighlightImg_.setVisible(false);

  this.addMouseEventCallbacks_();
};


/**
 * Add mouse event callbacks.
 *
 * @private
 */
talk.media.c3d.FeedHandler.prototype.addMouseEventCallbacks_ = function() {
  var c3d = this.o3dBundle.c3dObject.getPlugin();
  talk.media.c3d.addEventCallback(c3d, 'mousemove', this.boundOnMouseMove_);
  talk.media.c3d.addEventCallback(c3d, 'mouseup', this.boundOnMouseUp_);
  talk.media.c3d.addEventCallback(c3d, 'mousedown', this.boundOnMouseDown_);
};


/**
 * Handles a global mousemove event.
 *
 * @param {Object} e The event.
 * @protected
 */
talk.media.c3d.FeedHandler.prototype.onMouseMove = function(e) {};


/**
 * Handles a global mouseup event.
 *
 * @param {Object} e The event.
 * @protected
 */
talk.media.c3d.FeedHandler.prototype.onMouseUp = function(e) {};


/**
 * Handles a global mousedown event.
 *
 * @param {Object} e The event.
 * @protected
 */
talk.media.c3d.FeedHandler.prototype.onMouseDown = function(e) {};


/**
 * Creates a border around the video feed with the given color and border width.
 *
 * @param {number} borderWidth The width of the border line.
 * @param {Array} borderColor The color of the border in RGBA format.
 * @param {Array} borderHighlightColor The color of the border in RGBA format.
 */
talk.media.c3d.FeedHandler.prototype.setBorderProperties = function(
    borderWidth, borderColor, borderHighlightColor) {
  this.createBorderImages_(
      talk.media.c3d.FeedHandler.DEFAULT_FEED_WIDTH_,
      talk.media.c3d.FeedHandler.DEFAULT_FEED_HEIGHT_,
      borderWidth, borderColor, borderHighlightColor);
  this.borderImg_.resize(this.feedAttrs.w, this.feedAttrs.h);
  this.borderHighlightImg_.resize(this.feedAttrs.w, this.feedAttrs.h);

  // Draw border if it is set to visible and it's not highlighted.
  this.borderImg_.setVisible(
      this.isBorderVisible_ && !this.isBorderHighlighted_)

  this.borderHighlightImg_.setVisible(this.isBorderHighlighted_);
};


/**
 * Displays a border around the video feed.
 *
 * @param {boolean} visible Whether to display the border or not.
 */
talk.media.c3d.FeedHandler.prototype.setBorderVisible = function(visible) {
  this.borderImg_.setVisible(visible);
  this.isBorderVisible_ = visible;
  if (this.isBorderHighlighted_) {
    // Turn off highlight.
    this.setBorderHighlighted(false);
  }
};


/**
 * Displays a highlighted border around the video feed.
 *
 * @param {boolean} highlighted Whether to highlight the border or not.
 */
talk.media.c3d.FeedHandler.prototype.setBorderHighlighted = function(
    highlighted) {
  this.borderHighlightImg_.setVisible(highlighted);
  if (this.isBorderVisible_) {
    this.borderImg_.setVisible(!highlighted);
  }
  this.isBorderHighlighted_ = highlighted;
};


/**
 * Updates bounds for the current state. This method is called each time the
 * feed changes size. If the border is visible during this call a new image
 * will be created each time. For tweens is is recommended to set the border to
 * not visible during the tween to avoid spending to much time creating new
 * images.
 *
 * @param {talk.media.c3d.Attrs} attrs The new attributes for the feed.
 * @param {boolean} savePosition Whether to save the current position or not.
 */
talk.media.c3d.FeedHandler.prototype.updatePosition = function(attrs,
    savePosition) {
  if (this.feedObject) {
    // Update sizes of border images.
    this.feedAttrs = this.feed.getFeedAttrs();
    this.borderImg_.resize(this.feedAttrs.w, this.feedAttrs.h);
    this.borderHighlightImg_.resize(this.feedAttrs.w, this.feedAttrs.h);
  }
};


/**
 * Creates images for representing a border around this feed.
 *
 * @param {number} width Requested width of the border.
 * @param {number} height Requested height of the border.
 * @param {number} borderWidth Requested width of the border line.
 * @param {Array} borderColor Requested color of the border.
 * @param {Array} borderHighlightColor Requested color of the highlight border.
 * @private
 */
talk.media.c3d.FeedHandler.prototype.createBorderImages_ = function(
    width, height, borderWidth, borderColor, borderHighlightColor) {
  // Create a texture to draw the canvas to.
  var texture = this.createBorderTexture_(width, height, borderWidth,
      borderColor);

  var textureHighlight = this.createBorderTexture_(width, height, borderWidth,
      borderHighlightColor);

  // Create an image from the texture.
  this.borderImg_ = this.imageOverlay_.createImageFromTexture(0, 0, texture);
  this.borderHighlightImg_ = this.imageOverlay_.createImageFromTexture(
      0, 0, textureHighlight);
};


/**
 * Creates a texture for a border that is used for highlighting this feed.
 *
 * @param {number} width Requested width of the border.
 * @param {number} height Requested height of the border.
 * @param {number} borderWidth Requested width of the border line.
 * @param {Array} borderColor Requested color of the border.
 * @return {Object} A texture with a drawn border on it.
 * @private
 */
talk.media.c3d.FeedHandler.prototype.createBorderTexture_ = function(
    width, height, borderWidth, borderColor) {
  var c3d = this.o3dBundle.c3dObject.getPlugin();

  // The O3D CanvasPaint object for storing text properties.
  var canvasPaint = this.o3dBundle.pack['createObject']('CanvasPaint');
  canvasPaint['color'] = borderColor;

  var canvas = this.o3dBundle.pack['createObject']('Canvas');
  canvas['setSize'](width, height);

  // Makes the canvas transparent.
  canvas['clear']([0, 0, 0, 0]);

  // Draw the border as four rectangles. We need to be careful when using
  // transparent colors so that we don't draw the same pixel twice since that
  // will modify the alpha value for that pixel.
  canvas['drawRect'](0, 0, width, borderWidth, canvasPaint);
  canvas['drawRect'](width - borderWidth, borderWidth, width, height,
      canvasPaint);
  canvas['drawRect'](0, borderWidth, borderWidth, height, canvasPaint);
  canvas['drawRect'](borderWidth, height - borderWidth, width - borderWidth,
      height, canvasPaint);

  // Create a texture to draw the canvas to.
  var texture = this.o3dBundle.pack['createTexture2D'](width, height,
      c3d['o3d']['Texture']['ARGB8'],  // format
      1,  // mipmap levels
      false);

  // Draw the canvas into the texture.
  canvas['copyToTexture'](texture);
  return texture;
};


/**
 * Removes all references to C3D objects.
 */
talk.media.c3d.FeedHandler.prototype.disposeC3d = function() {
  // Might not be scriptable during shutdown.
  if (this.o3dBundle.c3dObject.isScriptable()) {
    var c3d = this.o3dBundle.c3dObject.getPlugin();
    talk.media.c3d.removeEventCallback(c3d, 'mousemove',
        this.boundOnMouseMove_);
    talk.media.c3d.removeEventCallback(c3d, 'mouseup',
        this.boundOnMouseUp_);
    talk.media.c3d.removeEventCallback(c3d, 'mousedown',
        this.boundOnMouseDown_);
  }
  if (this.borderImg_) {
    this.borderImg_.disposeC3d();
    this.borderImg_ = null;
  }
  if (this.borderHighlightImg_) {
    this.borderHighlightImg_.disposeC3d();
    this.borderHighlightImg_ = null;
  }
};


/**
 * @override
 * @protected
 */
talk.media.c3d.FeedHandler.prototype.disposeInternal = function() {
  talk.media.c3d.FeedHandler.superClass_.disposeInternal.call(this);
  this.disposeC3d();
};
