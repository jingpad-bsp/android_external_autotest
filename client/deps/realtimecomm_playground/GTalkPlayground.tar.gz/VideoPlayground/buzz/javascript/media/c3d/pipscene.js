// Copyright 2009 Google Inc. All Rights Reserved.

/**
 * @fileoverview Handles the layout for a local and a remote video feed. The
 *     remote is maximized in the available area and the local is shown as a
 *     picture-in-picture.
 *
 * @author geer@google.com (Arthur van der Geer)
 */

goog.provide('talk.media.c3d.PipScene');

goog.require('goog.events.EventHandler');
goog.require('talk.media.c3d.FixedAreaFeed');
goog.require('talk.media.c3d.PipOptions');
goog.require('talk.media.c3d.SceneBase');
goog.require('talk.media.c3d.ShrinkableFeed');
goog.require('talk.media.c3d.StreamEndpoint');


/**
 * @param {talk.media.c3d.O3dBundle} o3dBundle The bundle of global resources
 *     for this O3D instance.
 * @param {talk.media.c3d.PipOptions} pipOptions The options liek position and
 *     size of the PIP.
 * @extends {talk.media.c3d.SceneBase}
 * @constructor
 */
talk.media.c3d.PipScene = function(o3dBundle, pipOptions) {
  talk.media.c3d.SceneBase.call(this, o3dBundle);

  /**
   * The options for the PIP, like relative size and position.
   *
   * @type {talk.media.c3d.PipOptions}
   * @private
   */
  this.pipOptions_ = pipOptions;


  /**
   * EventHandler to simplify installing/removing event listeners.
   *
   * @type goog.events.EventHandler
   * @private
   */
  this.eventHandler_ = new goog.events.EventHandler(this);
};
goog.inherits(talk.media.c3d.PipScene, talk.media.c3d.SceneBase);


/**
 * @override
 * @protected
 */
talk.media.c3d.PipScene.prototype.updatePositions = function() {
  if (this.hasFeed(null)) {
    this.getFeed(null).setArea(this.x_, this.y_, this.width_, this.height_);
  }
  if (this.hasFeed('0')) {
    this.getFeed('0').setArea(this.x_, this.y_, this.width_, this.height_);
  }
};


/**
 * @override
 * @protected
 */
talk.media.c3d.PipScene.prototype.createFeed = function(endpoint) {
  if (endpoint.getStreamId() == null) {
    return this.createLocalFeed_(endpoint);
  } else if (endpoint.getStreamId() == '0') {
    // Shrink the local feed to PIP mode when the remote feed becomes active.
    this.eventHandler_.listen(endpoint,
        talk.media.c3d.StreamEndpoint.Events.TEXTURE_ACTIVATED,
        this.shrinkLocalFeed_);
    return this.createRemoteFeed_(endpoint);
  }
  return null;
};


/**
 * Creates a feed for the local stream that is on top and can be moved around.
 *
 * @param {talk.media.c3d.StreamEndpoint} endpoint The endpoint providing its
 *     texture.
 * @private
 */
talk.media.c3d.PipScene.prototype.createLocalFeed_ = function(endpoint) {
  return new talk.media.c3d.ShrinkableFeed( this.o3dBundle, endpoint,
      0.1, 0, 0, 0, 0, this.pipOptions_);
};


/**
 * Creates a feed that covers the whole area.
 *
 * @param {talk.media.c3d.StreamEndpoint} endpoint The endpoint providing its
 *     texture.
 * @private
 */
talk.media.c3d.PipScene.prototype.createRemoteFeed_ = function(endpoint) {
  return new talk.media.c3d.FixedAreaFeed(
      this.o3dBundle, endpoint, 0.0, 0, 0, 0, 0, true);
};


/**
 * Shrinks the local feed to its PIP mode.
 *
 * @param {talk.media.c3d.StreamEndpoint.TextureActivatedEvent} e The event.
 * @private
 */
talk.media.c3d.PipScene.prototype.shrinkLocalFeed_ = function(e) {
  if (this.hasFeed(null)) {
    (/** @type {talk.media.c3d.ShrinkableFeed} */ this.getFeed(null))
        .shrinkToCorner();
  }
};


/**
 * @override
 * @protected
 */
talk.media.c3d.PipScene.prototype.disposeInternal = function() {
  talk.media.c3d.PipScene.superClass_.disposeInternal.call(this);
  this.eventHandler_.dispose();
  this.eventHandler_ = null;
};
