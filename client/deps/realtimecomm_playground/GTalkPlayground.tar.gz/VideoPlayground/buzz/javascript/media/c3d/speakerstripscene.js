// Copyright 2009 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview Handles the layout of multiple video views in N:N calls in a
 *     strip beneath a main video feed showing the speaker.
 *
 * @author mikaeld@google.com (Mikael Drugge)
 * @author geer@google.com (Arthur van der Geer)
 */

goog.provide('talk.media.c3d.SpeakerStripScene');

goog.require('goog.debug.Logger');
goog.require('goog.events.EventHandler');
goog.require('talk.media.c3d.CursorManager');
goog.require('talk.media.c3d.SceneMouseHandler');
goog.require('talk.media.c3d.StripScene');


/**
 * Creates the SpeakerStripScene.
 *
 * @param {talk.media.c3d.O3dBundle} o3dBundle The bundle of global resources
 *     for this O3D instance.
 * @extends {talk.media.c3d.SceneBase}
 * @constructor
 */
talk.media.c3d.SpeakerStripScene = function(o3dBundle) {
  talk.media.c3d.SceneBase.call(this, o3dBundle);

  /**
   * The embedded scene showing the feeds in a strip.
   *
   * @type {talk.media.c3d.StripScene}
   * @private
   */
  this.strip_ = new talk.media.c3d.StripScene(o3dBundle);

  /**
   * Whether or not to switch the main feed to the one of the speaker.
   *
   * @type {boolean}
   * @private
   */
  this.showSpeaker_ = true;

  /**
   * EventHandler to simplify installing/removing event listeners.
   *
   * @type {goog.events.EventHandler}
   * @private
   */
  this.eventHandler_ = new goog.events.EventHandler(this);

};
goog.inherits(talk.media.c3d.SpeakerStripScene, talk.media.c3d.SceneBase);


/**
 * Logger for debugging.
 *
 * @type {goog.debug.Logger}
 * @private
 */
talk.media.c3d.SpeakerStripScene.logger_ =
    goog.debug.Logger.getLogger('talk.media.c3d.SpeakerStripScene');


/**
 * The feed of the speaker.
 *
 * @type {talk.media.c3d.BaseFeed}
 * @private
 */
talk.media.c3d.SpeakerStripScene.prototype.speaker_;


/**
 * Main feed to show.
 *
 * @type {talk.media.c3d.FixedAreaFeed}
 * @private
 */
talk.media.c3d.SpeakerStripScene.prototype.main_;


/**
 * Available width for main feed.
 *
 * @type {number}
 * @private
 */
talk.media.c3d.SpeakerStripScene.prototype.mainWidth_;


/**
 * Available height for main feed.
 *
 * @type {number}
 * @private
 */
talk.media.c3d.SpeakerStripScene.prototype.mainHeight_;


/**
 * The handler of mouse events for the feeds in the strip scene.
 *
 * @type {talk.media.c3d.SceneMouseHandler}
 * @private
 */
talk.media.c3d.SpeakerStripScene.prototype.stripMouseHandler_;


/**
 * The reference to the mouse cursor that is set to indicate a clickable feed.
 *
 * @type {talk.media.c3d.CursorManager.Registration_}
 * @private
 */
talk.media.c3d.SpeakerStripScene.prototype.click2ViewCursor_;


/**
 * @override
 */
talk.media.c3d.SpeakerStripScene.prototype.addFeed = function(endpoint) {
  this.maybeInitMouseHandler_();

  if (endpoint.getStreamId() != null && endpoint.getStreamId() != '0') {
    this.strip_.addFeed(endpoint);
    if (!this.main_) {
      this.setCurrentSpeaker(endpoint.getStreamId());
    } else {
      // Not changing the main feed, but view changed nonetheless.
      this.streamViewChanged_();
    }
  }
};


/**
 * @override
 */
talk.media.c3d.SpeakerStripScene.prototype.removeFeed = function(streamId) {
  this.strip_.removeFeed(streamId);
  if (this.main_ && this.main_.getEndpoint().getStreamId() == streamId) {
    this.main_.dispose();
    this.main_ = null;
  }
  this.streamViewChanged_();
};


/**
 * @override
 */
talk.media.c3d.SpeakerStripScene.prototype.hasFeed = function(streamId) {
  return this.strip_.hasFeed(streamId);
};


/**
 * @override
 * @protected
 */
talk.media.c3d.SpeakerStripScene.prototype.createFeed = function(endpoint) {
  talk.media.c3d.SpeakerStripScene.logger_.severe(
      'Unexpected call to createFeed.');
  return null;
};


/**
 * @override
 */
talk.media.c3d.SpeakerStripScene.prototype.setArea =
    function(x, y, width, height) {
  talk.media.c3d.SpeakerStripScene.superClass_.setArea.call(
      this, x, y, width, height);
  this.streamViewChanged_();
};


/**
 * @override
 * @protected
 */
talk.media.c3d.SpeakerStripScene.prototype.updatePositions = function() {
  if (this.width_ / this.height_ <= talk.media.c3d.StripScene.FEED_ASPECT) {
    // Letterbox, use horizontal strip.
    var stripHeight = this.strip_.getHeightForWidth(this.width_);
    this.strip_.setArea(this.x_, this.y_ + this.height_ - stripHeight,
        this.width_, stripHeight);
    this.mainWidth_ = this.width_;
    this.mainHeight_ = this.height_ - stripHeight;
  } else {
    // Pillarbox, use vertical strip.
    var stripWidth = this.strip_.getWidthForHeight(this.height_);
    this.strip_.setArea(this.x_ + this.width_ - stripWidth, this.y_,
        stripWidth, this.height_);
    this.mainWidth_ = this.width_ - stripWidth;
    this.mainHeight_ = this.height_;
  }
  if (this.main_) {
    this.main_.setArea(this.x_, this.y_, this.mainWidth_, this.mainHeight_);
  }
};


/**
 * @override
 */
talk.media.c3d.SpeakerStripScene.prototype.setCurrentSpeaker =
    function(streamId) {
  var feed = this.strip_.getFeed(streamId);
  if (feed) {
    this.speaker_ = feed;
    if (this.showSpeaker_) {
      this.setMainFeed_(feed);
    }
  }
};


/**
 * Sets the main feed of the scene. Nothing happens when that feed is already
 * showing.
 *
 * @param {talk.media.c3d.BaseFeed} feed The feed to be shown as the main one.
 * @private
 */
talk.media.c3d.SpeakerStripScene.prototype.setMainFeed_ = function(feed) {
  var endpoint = feed.getEndpoint();
  var previousFeed = this.main_;
  if (previousFeed &&
      previousFeed.getEndpoint().getStreamId() == endpoint.getStreamId()) {
    return;
  }
  this.main_ = new talk.media.c3d.FixedAreaFeed(this.o3dBundle, endpoint,
      0.0, this.x_, this.y_, this.mainWidth_, this.mainHeight_, false);
  if (previousFeed) {
    previousFeed.dispose();
  }
  this.streamViewChanged_();
};


/**
 * Dispatch a {talk.media.c3d.SceneBase.SceneChangedEvent} with the (new) size
 * of all the feeds.
 * @private
 */
talk.media.c3d.SpeakerStripScene.prototype.streamViewChanged_ = function() {
  var views = [];
  var streams = this.strip_.getStreamIds();
  for (var i = 0; i < streams.length; ++i) {
    var feed = this.strip_.getFeed(streams[i]);
    // TODO(geer): Decide how to handle avatar here. An avatar is either an
    // audio participant or a stream that didn't turn on yet.
    views.push([streams[i], feed.getWidth(), feed.getHeight()]);
  }
  if (this.main_) {
    views.push([this.main_.getEndpoint().getStreamId(), this.main_.getWidth(),
        this.main_.getHeight()]);
  }
  this.dispatchEvent(new talk.media.c3d.SceneBase.SceneChangedEvent(views));
};


/**
 * Initializes mouse handling if not done already.
 * @private
 */
talk.media.c3d.SpeakerStripScene.prototype.maybeInitMouseHandler_ = function() {
  if (!goog.isDefAndNotNull(this.stripMouseHandler_)) {
    this.stripMouseHandler_ =
        new talk.media.c3d.SceneMouseHandler(this.o3dBundle, this.strip_);
    this.eventHandler_.listen(this.stripMouseHandler_,
        talk.media.c3d.SceneMouseHandler.Event.MOUSE_OVER, this.onMouseOver_);
    this.eventHandler_.listen(this.stripMouseHandler_,
        talk.media.c3d.SceneMouseHandler.Event.MOUSE_DOWN, this.onMouseDown_);
    this.eventHandler_.listen(this.stripMouseHandler_,
        talk.media.c3d.SceneMouseHandler.Event.MOUSE_UP, this.onMouseUp_);
  }
};


/**
 * Handles the event of a mouse moving over a feed or out of a feed.
 * Switches the main feed if over a feed and not showing the speaker.
 *
 * @param {talk.media.c3d.SceneMouseHandler.MouseOverEvent} e The event.
 * @private
 */
talk.media.c3d.SpeakerStripScene.prototype.onMouseOver_ = function(e) {
  if (e.feed) {
    if (!goog.isDefAndNotNull(this.click2ViewCursor_)) {
      this.click2ViewCursor_ = this.o3dBundle.cursorManager.setCursor(
         'POINTER', 0);
    }
    if (!this.showSpeaker_) {
      this.setMainFeed_(e.feed);
    }
  } else {
    if (goog.isDefAndNotNull(this.click2ViewCursor_)) {
      this.o3dBundle.cursorManager.unsetCursor(this.click2ViewCursor_);
      this.click2ViewCursor_ = null;
    }
  }
};


/**
 * Handles the event of a mouse down. If over a feed the scene switches to
 * showing the feed under the mouse and stops showing the speaker.
 *
 * @param {talk.media.c3d.SceneMouseHandler.MouseDownEvent} e The event.
 * @private
 */
talk.media.c3d.SpeakerStripScene.prototype.onMouseDown_ = function(e) {
  if (e.feed) {
    this.showSpeaker_ = false;
    this.setMainFeed_(e.feed);
  }
};


/**
 * Handles the event of a mouse up. The scene stops showing the feed under the
 * mouse and reverts to showing the speaker again.
 *
 * @param {talk.media.c3d.SceneMouseHandler.MouseUpEvent} e The event.
 * @private
 */
talk.media.c3d.SpeakerStripScene.prototype.onMouseUp_ = function(e) {
  this.showSpeaker_ = true;
  if (this.speaker_) {
    this.setMainFeed_(this.speaker_);
  }
};


/**
 * @override
 */
talk.media.c3d.SpeakerStripScene.prototype.disposeAllFeeds = function() {
  if (this.strip_) {
    this.strip_.disposeAllFeeds();
  }
  if (this.main_) {
    this.main_.dispose();
    this.main_ = null;
  }
  this.speaker_ = null;
};


/**
 * @override
 * @protected
 */
talk.media.c3d.SpeakerStripScene.prototype.disposeInternal = function() {
  talk.media.c3d.SpeakerStripScene.superClass_.disposeInternal.call(this);
  this.eventHandler_.dispose();
  this.eventHandler_ = null;
  if (this.stripMouseHandler_) {
    this.stripMouseHandler_.dispose();
    this.stripMouseHandler_ = null;
  }
  this.strip_.dispose();
  this.strip_ = null;
  this.disposeAllFeeds();
};
