// Copyright 2010 Google Inc. All Rights Reserved.

/**
 * @fileoverview Controls the resolution and framerate of video feeds based on
 * the size of the views displaying them.
 *
 * @author geer@google.com (Arthur van der Geer)
 */

goog.provide('talk.media.ViewQualityControl');

goog.require('goog.debug.Logger');
goog.require('goog.structs.Map');
goog.require('talk.media.CallManager');


/**
 * Creates an object that controls the resolution of video feeds based on the
 * size of the views displaying them.
 *
 * @param {talk.media.CallManager} callManager The object handling communication
 *     with the server.
 * @constructor
 * @extends {goog.Disposable}
 */
talk.media.ViewQualityControl = function(callManager) {
  goog.Disposable.call(this);

  /**
   * The call manager handles communication with the server.
   *
   * @type {talk.media.CallManager}
   * @private
   */
  this.callManager_ = callManager;

};
goog.inherits(talk.media.ViewQualityControl, goog.Disposable);


/**
 * Logger for debugging.
 *
 * @type {goog.debug.Logger}
 * @private
 */
talk.media.ViewQualityControl.logger_ =
    goog.debug.Logger.getLogger('talk.media.ViewQualityControl');


/**
 * Maps the quality for each stream to a fixed resolution and framerate.
 * Restricts the combined set of resolutions to a limited total number of
 * pixels.
 *
 * @param {goog.structs.Map} streamQuality The desired quality of each stream.
 * @private
 */
talk.media.ViewQualityControl.restrictQuality_ = function(streamQuality) {
  // Sort the requested resolutions on descending height.
  var resolutions = streamQuality.getValues();
  resolutions.sort(function(a, b) {
      return b[2] - a[2];
  });

  // For now we cap at wide vga (854x480). This equals max 1 view in vga plus
  // either 2 in qvga or 9 in qqvga.
  // TODO(geer): Move this logic to the server. Note that only the server can
  // decide upon the resolutions because it can take into account all endpoint
  // views. Send actual view dimensions here instead.
  var pixels = 854 * 480;
  for (var i = 0; i < resolutions.length; i++) {
    // Calculate available pixels if the remaining views get qqvga.
    var available = pixels - (resolutions.length - i - 1) * 160 * 100;
    var resolution = resolutions[i];
    if (resolution[2] > 400 && available > 640 * 400) {
      resolution[1] = 640;
      resolution[2] = 400;
      resolution[3] = 30;
      pixels -= 640 * 400;
    } else if (resolution[2] > 200 && available > 320 * 200) {
      resolution[1] = 320;
      resolution[2] = 200;
      resolution[3] = 30;
      pixels -= 320 * 200;
    } else {
      resolution[1] = 160;
      resolution[2] = 100;
      resolution[3] = 30;
    }
  }
};


/**
 * Changes the resolution and framerate of all video feeds to match the sizes
 * of the views.
 *
 * @param {Array.<Array>} views The views and their sizes. The array elements
 *     for each view are [{string} SSRC, {number} width, {number} height].
 */
talk.media.ViewQualityControl.prototype.adjustQualityForViews =
    function(views) {
  var call = this.callManager_.getActiveCall();
  if (!goog.isDefAndNotNull(call) || !goog.isDefAndNotNull(call.ssrcMap)) {
    return;
  }

  // Take the largest view of each ssrc.
  var streamQuality = new goog.structs.Map();
  for (var i = 0; i < views.length; ++i) {
    var v = views[i];
    var other = streamQuality.get(v[0]);
    if (other == undefined || v[2] > other[2]) {
      streamQuality.set(v[0], [v[0], v[1], v[2]]);
    }
  }
  talk.media.ViewQualityControl.restrictQuality_(streamQuality);
  this.requestQuality_(streamQuality);
};


/**
 * Sends a 'view' message to the conference manager in the backend to request
 * the desired quality for each video stream.
 *
 * @param {goog.structs.Map} streamQuality The desired quality of each stream.
 * @private
 */
talk.media.ViewQualityControl.prototype.requestQuality_ =
    function(streamQuality) {
  var call = this.callManager_.getActiveCall();

  var requests = [];
  var nicks = call.ssrcMap.getKeys();
  nicks.sort();  // For ease of debugging.
  for (var i = 0; i < nicks.length; i++) {
    var entry = call.ssrcMap.get(nicks[i]);
    if (entry.videoSsrc) {
      var resolution = streamQuality.get(entry.videoSsrc);
      // Append the video quality for this nick to the view message.
      if (resolution != undefined) {
        requests.push(['selected', nicks[i], entry.videoSsrc, resolution[1],
            resolution[2], resolution[3]]);
      } else {
        talk.media.ViewQualityControl.logger_.severe(
            'No view requested for video SSRC: "' + entry.videoSsrc + '".');
      }
    }
  }
  var remoteJid = call.remoteJids[0]
  var msg = ['view', remoteJid, call.sessionId, requests];

  talk.media.ViewQualityControl.logger_.info('Requesting video view: ' +
      goog.json.serialize(msg));
  this.callManager_.sendJingleMsg(msg);
};


/**
 * @override
 * @protected
 */
talk.media.ViewQualityControl.prototype.disposeInternal = function() {
  talk.media.ViewQualityControl.superClass_.disposeInternal.call(this);
  this.callManager_ = null;
};
