// Copyright 2009 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview Base for classes that handle the layout of video feeds.
 * Provides a mechanism to create and manage a set of feeds and a mechanism to
 * respond to changing layout conditions.
 *
 * @author mikaeld@google.com (Mikael Drugge)
 * @author geer@google.com (Arthur van der Geer)
 */

goog.provide('talk.media.c3d.SceneBase');
goog.provide('talk.media.c3d.SceneBase.SceneChangedEvent');

goog.require('goog.debug.Logger');
goog.require('goog.events.EventTarget');
goog.require('goog.structs.Map');


/**
 * Creates the SceneBase object with functionality common to video scenes.
 *
 * @param {talk.media.c3d.O3dBundle} o3dBundle The bundle of global resources
 *     for this O3D instance.
 * @extends {goog.events.EventTarget}
 * @constructor
 */
talk.media.c3d.SceneBase = function(o3dBundle) {
  goog.events.EventTarget.call(this);

  // TODO(geer): split this class in two, one interface for specialization and
  // one with common implementation for scenes 'owning' feeds.

  /**
   * The container for global O3D handles.
   *
   * @type {talk.media.c3d.O3dBundle}
   * @protected
   */
  this.o3dBundle = o3dBundle;

  /**
   * Map holding the remote user video scene feeds.
   *
   * @type {goog.structs.Map}
   * @private
   */
  this.feeds_ = new goog.structs.Map();
};
goog.inherits(talk.media.c3d.SceneBase, goog.events.EventTarget);


/**
 * Events fired by @code{talk.media.c3d.SceneBase}.
 *
 * @enum {string}
 */
talk.media.c3d.SceneBase.Event = {
  /**
   * Event indicating that the display of feeds changed.
   */
  SCENE_CHANGED: 'sc'
};


/**
 * Event class for {@code talk.media.c3d.SceneBase.Event.SCENE_CHANGED}.
 *
 * @param {Array.<Array>} views The new resolutions of feeds.
 * @constructor
 * @extends {goog.events.Event}
 */
talk.media.c3d.SceneBase.SceneChangedEvent = function(views) {

  /**
   * @type {Array.<Array>} The new resolutions of feeds. Each element is a
   *     triple of [ssrc, width, height]. An ssrc can occur more than once.
   *     Each occurence corresponds to a feed.
   */
  this.views = views;

  goog.events.Event.call(this, talk.media.c3d.SceneBase.Event.SCENE_CHANGED);
};
goog.inherits(talk.media.c3d.SceneBase.SceneChangedEvent, goog.events.Event);


/**
 * Logger for debugging.
 *
 * @type {goog.debug.Logger}
 * @private
 */
talk.media.c3d.SceneBase.logger_ =
    goog.debug.Logger.getLogger('talk.media.c3d.SceneBase');


/**
 * The x-coordinate of the origin (bottom-left corner) for the rectangle to
 * draw in.
 *
 * @type {number}
 * @protected
 */
talk.media.c3d.SceneBase.prototype.x_;


/**
 * The y-coordinate of the origin (bottom-left corner) for the rectangle to
 * draw in.
 *
 * @type {number}
 * @protected
 */
talk.media.c3d.SceneBase.prototype.y_;


/**
 * The width of the rectangle to draw in.
 *
 * @type {number}
 * @protected
 */
talk.media.c3d.SceneBase.prototype.width_;


/**
 * The height of the rectangle to draw in.
 *
 * @type {number}
 * @protected
 */
talk.media.c3d.SceneBase.prototype.height_;


/**
 * Sets the area of the O3D window in which to draw.
 *
 * @param {number} x The x-coord of origin of rect in which to draw.
 * @param {number} y The y-coord of origin of rect in which to draw.
 * @param {number} width Width of rect in which to draw.
 * @param {number} height Height of rect in which to draw.
 */
talk.media.c3d.SceneBase.prototype.setArea = function(x, y, width, height) {
  this.x_ = x;
  this.y_ = y;
  this.width_ = width;
  this.height_ = height;
  this.updatePositions();
};


/**
 * Updates the position of all video feeds on screen, e.g. after having added
 * or removed one or more feeds, or after a resize of the available area.
 *
 * @protected
 */
talk.media.c3d.SceneBase.prototype.updatePositions = goog.abstractMethod;


/**
 * Adds a new video feed to display a stream. Returns null if scene did not
 * create one.
 *
 * @param {talk.media.c3d.StreamEndpoint} endpoint The endpoint providing its
 *     texture.
 */
talk.media.c3d.SceneBase.prototype.addFeed = function(endpoint) {
  var streamId = endpoint.getStreamId();
  if (this.feeds_.containsKey(streamId)) {
    talk.media.c3d.SceneBase.logger_.warning(
        'Attempt to add feed for existing stream ' + streamId);
    return;
  }
  var feed = this.createFeed(endpoint);
  if (feed) {
    this.feeds_.set(streamId, feed);
    this.updatePositions();
    talk.media.c3d.SceneBase.logger_.info('Added feed for stream ' + streamId +
        ', now displaying ' + this.feeds_.getCount() + ' feeds.');
  } else {
    talk.media.c3d.SceneBase.logger_.info('No feed created for stream ' +
        streamId + '.');
  }
};


/**
 * Creates a new video feed to display a stream. Returns null if scene did not
 * create one.
 *
 * @param {talk.media.c3d.StreamEndpoint} endpoint The endpoint providing its
 *     texture.
 * @return {?talk.media.c3d.BaseFeed}
 * @protected
 */
talk.media.c3d.SceneBase.prototype.createFeed = goog.abstractMethod;


/**
 * Removes a video feed.
 *
 * @param {?string} streamId The stream id.
 */
talk.media.c3d.SceneBase.prototype.removeFeed = function(streamId) {
  if (!this.feeds_.containsKey(streamId)) {
    talk.media.c3d.SceneBase.logger_.warning('Attempt to remove feed for ' +
        'non-existing stream ' + streamId);
    return;
  }
  this.removeFeedInternal_(streamId);
  this.updatePositions();
  talk.media.c3d.SceneBase.logger_.info('Removed feed for stream ' + streamId +
      ', now displaying ' + this.feeds_.getCount() + ' feeds.');
};


/**
 * Returns the video feed for the given stream.
 *
 * @param {?string} streamId The stream id.
 * @return {talk.media.c3d.BaseFeed} The video feed.
 */
talk.media.c3d.SceneBase.prototype.getFeed = function(streamId) {
  return /** @type {talk.media.c3d.BaseFeed} */(
      this.feeds_.get(streamId));
};


/**
 * Returns whether there exists a video feed for the given stream.
 *
 * @param {?string} streamId The stream id.
 * @return {boolean} Whether there exists a feed for the given stream.
 */
talk.media.c3d.SceneBase.prototype.hasFeed = function(streamId) {
  return this.feeds_.containsKey(streamId);
};


/**
 * Removes and disposes the video feed corresponding to the given stream.
 *
 * @param {?string} streamId The stream id.
 * @private
 */
talk.media.c3d.SceneBase.prototype.removeFeedInternal_ = function(streamId) {
  var feed = this.feeds_.get(streamId);
  this.feeds_.remove(streamId);
  feed.dispose();
};


/**
 * @return {number}
 */
talk.media.c3d.SceneBase.prototype.getFeedCount = function() {
  return this.feeds_.getCount();
};


/**
 * @return {!Array.<string>}
 */
talk.media.c3d.SceneBase.prototype.getStreamIds = function() {
  return this.feeds_.getKeys();
};


/**
 * Override to respond to changes of active speaker.
 *
 * @param {?string} streamId The stream id of the active speaker.
 */
talk.media.c3d.SceneBase.prototype.setCurrentSpeaker = function(streamId) {
};


/**
 * Disposes all video feeds.
 */
talk.media.c3d.SceneBase.prototype.disposeAllFeeds = function() {
  var streams = this.feeds_.getKeys();
  for (var i = 0; i < streams.length; ++i) {
    this.removeFeedInternal_(streams[i]);
  }
};


/**
 * @override
 * @protected
 */
talk.media.c3d.SceneBase.prototype.disposeInternal = function() {
  talk.media.c3d.SceneBase.superClass_.disposeInternal.call(this);
  this.disposeAllFeeds();
  this.feeds_ = null;
};
