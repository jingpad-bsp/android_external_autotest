// Copyright 2009 Google Inc.  All Rights Reserved.

/**
 * @fileoverview Handling for notifications in C3D area.
 *
 * @author chaitali@google.com (Chaitali Lawande)
 */

goog.provide('talk.media.C3dNotifier');

goog.require('goog.array');
goog.require('goog.debug.Logger');
goog.require('talk.media.c3d.AlphaTween');
goog.require('talk.media.c3d.helpers');
goog.require('talk.media.c3d.tweens');


/**
 * Handles notifications by displaying appropriate messages in the
 * C3D area.
 *
 * @param {talk.media.CallManager} callManager The call manager.
 * @param {Object} pack The C3D Pack object.
 * @param {talk.media.c3d.C3dEngine} c3dEngine A 3D rendering engine.
 * @param {talk.media.c3d.C3dObject} c3dObject A 3D rendering object.
 * @param {talk.media.c3d.ImageOverlay} imageOverlay An image rendering layer.
 * @param {talk.media.c3d.NotificationRenderer} notifRenderer
 *     A notification renderer object.
 * @constructor
 */
talk.media.C3dNotifier = function(callManager, pack, c3dEngine,
    c3dObject, imageOverlay, notifRenderer) {

  this.pack_ = pack;
  this.callManager_ = callManager;
  this.c3dEngine_ = c3dEngine;
  this.c3dObject_ = c3dObject;
  this.imageOverlay_ = imageOverlay;
  this.notifRenderer_ = notifRenderer;

  this.width_ = this.c3dObject_.getWidth();
  this.height_ = this.c3dObject_.getHeight();

  this.logger_.fine('Adding resize listener.');

  /**
   * The list of all notifications currently shown.
   *
   * @type {Array.<talk.media.C3dNotifier.Notification_>}
   * @private
   */
  this.notifications_ = [];

  /**
   * A goog.bind()'ed version of onResize, suitable for using as an event
   * callback.
   *
   * @type {Function}
   * @private
   */
  this.boundOnResize_ = goog.bind(this.onResize, this);

  talk.media.c3d.addEventCallback(this.c3dObject_.getPlugin(), 'resize',
      this.boundOnResize_);
};


/**
 * A Notification containing related information.
 *
 * @private
 * @constructor
 */

talk.media.C3dNotifier.Notification_ = function() {
};


/**
 * Fader ID for callbacks.
 * @type {number}
 */
talk.media.C3dNotifier.Notification_.prototype.faderId;

/**
 * Text for this Notification.
 * @type {string}
 */
talk.media.C3dNotifier.Notification_.prototype.notificationText;

/**
 * Texture for this Notification.
 * @type {talk.media.c3d.Image}
 */
talk.media.C3dNotifier.Notification_.prototype.img;

/**
 * The tween for fading this Notification.
 * @type {talk.media.c3d.AlphaTween}
 */
talk.media.C3dNotifier.Notification_.prototype.imgFader;


/**
 * Delay until fade-out of message starts.
 *
 * @type {number}
 * @private
 */
talk.media.C3dNotifier.FADE_OUT_DELAY_MS_ = 2 * 1000;


/**
 * Logger.
 *
 * @type {!goog.debug.Logger}
 * @private
 */
talk.media.C3dNotifier.prototype.logger_ =
    goog.debug.Logger.getLogger('talk.media.C3dNotifier');


/**
 * The call manager for adding to Flute logs.
 *
 * @type {talk.media.CallManager}
 * @private
 */
talk.media.C3dNotifier.prototype.callManager_;


/**
 * The C3D Pack object.
 *
 * @type Object
 * @private
 */
talk.media.C3dNotifier.prototype.pack_;


/**
 * The 3D rendering engine.
 *
 * @type {talk.media.c3d.C3dEngine}
 * @private
 */
talk.media.C3dNotifier.prototype.c3dEngine_;


/**
 * The 3D rendering object.
 *
 * @type {talk.media.c3d.C3dObject}
 * @private
 */
talk.media.C3dNotifier.prototype.c3dObject_;


/**
 * The width of the video pane.
 *
 * @type {number}
 * @private
 */
talk.media.C3dNotifier.prototype.width_ = 0;


/**
 * The height of the video pane.
 *
 * @type {number}
 * @private
 */
talk.media.C3dNotifier.prototype.height_ = 0;


/**
 * The notification renderer object.
 *
 * @type {talk.media.c3d.NotificationRenderer}
 * @private
 */
talk.media.C3dNotifier.prototype.notifRenderer_ = null;


/**
 * Removes all references to C3D objects.
 */
talk.media.C3dNotifier.prototype.disposeC3d = function() {
  if (!this.c3dEngine_) {
    return;
  }
  if (this.c3dObject_.isScriptable()) {  // Might not be during shutdown
    this.logger_.fine('Removing C3D resize listener.');
    talk.media.c3d.removeEventCallback(this.c3dObject_.getPlugin(), 'resize',
        this.boundOnResize_);
  }
  for (var i = 0; i < this.notifications_.length; ++i) {
      this.notifications_[i].img = null;
      if (this.notifications_[i].imgFader) {
        this.c3dEngine_.unregisterRenderCallback(
            this.notifications_[i].imgFader);
        this.notifications_[i].imgFader = null;
      }
  }
};


/**
 * Handles a resize event of the o3d client.
 *
 * @param {Object} e A C3D event.
 * @protected
 */
talk.media.C3dNotifier.prototype.onResize = function(e) {
  this.width_ = e['width'];
  this.height_ = e['height'];

  for (var i = 0; i < this.notifications_.length; ++i) {
    if (this.notifications_[i].img) {
      var y = this.height_ - this.notifications_[i].img.height();
      this.notifications_[i].img.moveTo(0, y);
    }
  }
};


/**
 * Adds a notification to the list of notifications.
 *
 * @param {string} imgUrl The relative path where the display image is present.
 * @param {string} displayText The text to display for the notification.
 *
 * @return {!talk.media.C3dNotifier.Notification_} The Notification created.
 */
talk.media.C3dNotifier.prototype.addNotification = function(imgUrl,
    displayText) {

  var newNotification = new talk.media.C3dNotifier.Notification_();
  newNotification.notificationText = displayText;
  this.notifications_.push(newNotification);

  this.notifRenderer_.renderTexture(imgUrl, displayText,
      goog.bind(this.onTextRendered_, this, newNotification));

  return newNotification;
};


/**
 * Callback for texture rendering. Sets the image when texture is rendered.
 *
 * @param {talk.media.C3dNotifier.Notification_} newNotification
 *     The Notification to which this texture belongs.
 * @param {Object} texture The texture rendered.
 * @private
 */
talk.media.C3dNotifier.prototype.onTextRendered_ = function(newNotification,
    texture) {

  for (var i = 0; i < this.notifications_.length; ++i) {
    if (this.notifications_[i] == newNotification && texture != null) {
      this.notifications_[i].img =
          this.imageOverlay_.createImageFromTexture(0, 0, texture);
      this.notifications_[i].img.setVisible(false);
    }
  }

};


/**
 * Displays a message for the appropriate notification.
 * The notification is faded out after a while.
 * Currently displays only latest notification received
 * fading out any others present.
 *
 * @param {!talk.media.C3dNotifier.Notification_} notificationInput
 *     The notification to be displayed.
 */
talk.media.C3dNotifier.prototype.showNotification = function(
    notificationInput) {
  if (!this.c3dEngine_) {
    return;
  }

  if (!goog.array.contains(this.notifications_, notificationInput)) {
    return;
  }

  if (!notificationInput.img) {
    return;
  }

  // TODO(chaitali): Add support for displaying multiple notifications.

  for (var i = 0; i < this.notifications_.length; ++i) {
    if (this.notifications_[i] != notificationInput) {
      // finish fading for every other notification
      this.finishNotificationFading_(this.notifications_[i]);
    }
  }

  notificationInput.faderId = goog.Timer.callOnce(
      goog.bind(this.fadeOutNotification_, this, notificationInput),
      talk.media.C3dNotifier.FADE_OUT_DELAY_MS_, this);

  notificationInput.img.setVisible(true);
  notificationInput.img.setAlpha(1);

  this.callManager_.addToLog(notificationInput.notificationText);
};


/**
 * Cancels callback for starting fader and the actual fading process if active.
 *
 * @param {talk.media.C3dNotifier.Notification_} notification The notification
 *     for which to cancel callback.
 * @private
 */
talk.media.C3dNotifier.prototype.finishNotificationFading_ = function(
    notification) {
  if (goog.isDefAndNotNull(notification.faderId)) {
    goog.Timer.clear(notification.faderId);
    notification.imgFader = null;
  }
  if (notification.imgFader) {
    this.c3dEngine_.unregisterRenderCallback(notification.imgFader);
    notification.imgFader = null;
  }
  if (notification.img) {
    notification.img.setVisible(false);
  }
};


/**
 * Starts a process of fading.  Can be aborted
 * via the finishNotificationFading_ function.
 *
 * @param {talk.media.C3dNotifier.Notification_} notification The notification
 *     for which to start fadeout.
 * @private
 */
talk.media.C3dNotifier.prototype.fadeOutNotification_ = function(notification) {
  delete notification.faderId;
  notification.imgFader = new talk.media.c3d.AlphaTween(
      notification.img,
      notification.img.getAlpha(),
      0.0,
      1.0,
      talk.media.c3d.REGULAR_EASE_IN,
      goog.bind(this.finishNotificationFading_, this, notification));
  this.c3dEngine_.registerRenderCallback(notification.imgFader);
};

