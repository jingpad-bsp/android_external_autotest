// Copyright 2009 Google Inc.  All Rights Reserved.

/**
 * @fileoverview Interface for C3D objects with an alpha component.
 *
 * @author perd@google.com (Per Danvind)
 */

goog.provide('talk.media.c3d.Dimmable');

/**
 * Provides an interface for 3D objects with an alpha component for dimming.
 *
 * @constructor
 */
talk.media.c3d.Dimmable = function() {};


/**
 * Sets the alpha component value for the object.  Abstract function, should be
 * overridden.
 *
 * @param {number} a Alpha component value between 0 and 1.
 */
talk.media.c3d.Dimmable.prototype.setAlpha = function(a) {};
