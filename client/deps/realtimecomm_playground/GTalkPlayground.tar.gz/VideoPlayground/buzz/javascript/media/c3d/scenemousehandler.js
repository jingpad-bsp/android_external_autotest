// Copyright 2010 Google Inc. All Rights Reserved.

/**
 * @fileoverview Handles mouse events on the feeds in a scene.
 *
 * @author geer@google.com (Arthur van der Geer)
 */

goog.provide('talk.media.c3d.SceneMouseHandler');
goog.provide('talk.media.c3d.SceneMouseHandler.MouseDownEvent');
goog.provide('talk.media.c3d.SceneMouseHandler.MouseOverEvent');
goog.provide('talk.media.c3d.SceneMouseHandler.MouseUpEvent');

goog.require('goog.events.EventTarget');
goog.require('talk.media.c3d.BaseFeed');
goog.require('talk.media.c3d.O3dBundle');
goog.require('talk.media.c3d.SceneBase');
goog.require('talk.media.c3d.helpers');


/**
 * Creates a handler of mouse events for the feeds in the scene.
 *
 * @param {talk.media.c3d.O3dBundle} o3dBundle The bundle of global resources
 *     for this O3D instance.
 * @param {talk.media.c3d.SceneBase} scene The scene to handle mouse events for.
 * @extends {goog.events.EventTarget}
 * @constructor
 */
talk.media.c3d.SceneMouseHandler = function(o3dBundle, scene) {
  goog.events.EventTarget.call(this);

  /**
   * The container for global O3D handles.
   *
   * @type {talk.media.c3d.O3dBundle}
   * @private
   */
  this.o3dBundle_ = o3dBundle;

  /**
   * The scene to handle mouse events for.
   *
   * @type {talk.media.c3d.SceneBase}
   * @private
   */
  this.scene_ = scene;

  this.boundOnMouseMove_ = goog.bind(this.onMouseMove_, this);
  this.boundOnMouseDown_ = goog.bind(this.onMouseDown_, this);
  this.boundOnMouseUp_ = goog.bind(this.onMouseUp_, this);

  var c3d = o3dBundle.c3dObject.getPlugin();
  talk.media.c3d.addEventCallback(c3d, 'mousemove', this.boundOnMouseMove_);
  talk.media.c3d.addEventCallback(c3d, 'mousedown', this.boundOnMouseDown_);
  talk.media.c3d.addEventCallback(c3d, 'mouseup', this.boundOnMouseUp_);
};
goog.inherits(talk.media.c3d.SceneMouseHandler, goog.events.EventTarget);


/**
 * Events fired by @code{talk.media.c3d.SceneMouseHandler}.
 *
 * @enum {string}
 */
talk.media.c3d.SceneMouseHandler.Event = {
  /**
   * Event indicating that the mouse is (no longer) over a feed.
   */
  MOUSE_OVER: 'mof',

  /**
   * Event indicating that a mouse button went down on a feed.
   */
  MOUSE_DOWN: 'mdf',

  /**
   * Event indicating that a mouse button went up on a feed.
   */
  MOUSE_UP: 'muf'
};


/**
 * Event class for {@code talk.media.c3d.SceneMouseHandler.Event.MOUSE_OVER}.
 *
 * @param {talk.media.c3d.BaseFeed} feed The feed the mouse is over, or null
 *     if mouse is no longer over a feed.
 * @constructor
 * @extends {goog.events.Event}
 */
talk.media.c3d.SceneMouseHandler.MouseOverEvent = function(feed) {

  /**
   * @type {talk.media.c3d.BaseFeed} The feed the mouse is over, or null
   *     if mouse is no longer over a feed.
   */
  this.feed = feed;

  goog.events.Event.call(this,
      talk.media.c3d.SceneMouseHandler.Event.MOUSE_OVER);
};
goog.inherits(talk.media.c3d.SceneMouseHandler.MouseOverEvent,
    goog.events.Event);


/**
 * Event class for {@code talk.media.c3d.SceneMouseHandler.Event.MOUSE_DOWN}.
 *
 * @param {talk.media.c3d.BaseFeed} feed The feed the mouse is over, or null if
 *     mouse is not over a feed.
 * @constructor
 * @extends {goog.events.Event}
 */
talk.media.c3d.SceneMouseHandler.MouseDownEvent = function(feed) {

  /**
   * @type {talk.media.c3d.BaseFeed} The feed the mouse is over, or null if
   *     mouse is not over a feed.
   */
  this.feed = feed;

  goog.events.Event.call(this,
      talk.media.c3d.SceneMouseHandler.Event.MOUSE_DOWN);
};
goog.inherits(talk.media.c3d.SceneMouseHandler.MouseDownEvent,
    goog.events.Event);


/**
 * Event class for {@code talk.media.c3d.SceneMouseHandler.Event.MOUSE_UP}.
 *
 * @param {talk.media.c3d.BaseFeed} feed The feed the mouse is over, or null if
 *     mouse is not over a feed.
 * @constructor
 * @extends {goog.events.Event}
 */
talk.media.c3d.SceneMouseHandler.MouseUpEvent = function(feed) {

  /**
   * @type {talk.media.c3d.BaseFeed} The feed the mouse is over, or null
   *     if mouse is not over a feed.
   */
  this.feed = feed;

  goog.events.Event.call(this,
      talk.media.c3d.SceneMouseHandler.Event.MOUSE_UP);
};
goog.inherits(talk.media.c3d.SceneMouseHandler.MouseUpEvent,
    goog.events.Event);


/**
 * Helper function to find the feed the mouse is over. Returns null if mouse is
 * not over a feed.
 *
 * @param {number} x The horizontal position.
 * @param {number} y The vertical position.
 * @return {talk.media.c3d.BaseFeed} The feed at the position or null if none.
 * @private
 */
talk.media.c3d.SceneMouseHandler.prototype.getFeedAtPos_ = function(x, y) {
  var streamIds = this.scene_.getStreamIds();
  for (var i = 0; i < streamIds.length; ++i) {
    var feed = this.scene_.getFeed(streamIds[i]);
    var attrs = feed.getAttrs();
    if (attrs.x <= x && x < attrs.x + attrs.w &&
        attrs.y <= y && y < attrs.y + attrs.h) {
      return feed;
    }
  }
  return null;
};


/**
 * Handles a mousemove event and dispatches a MouseOverEvent with the feed the
 * mouse is over.
 *
 * @param {Object} e The o3d.Event with mouse position.
 * @private
 */
talk.media.c3d.SceneMouseHandler.prototype.onMouseMove_ = function(e) {
  // TODO(geer): Add button info to events.
  var feed = this.getFeedAtPos_(e['x'], e['y']);
  this.dispatchEvent(new talk.media.c3d.SceneMouseHandler.MouseOverEvent(feed));
};


/**
 * Handles a mousedown event and dispatches a MouseDownEvent with the feed the
 * mouse is over.
 *
 * @param {Object} e The o3d.Event with mouse position.
 * @private
 */
talk.media.c3d.SceneMouseHandler.prototype.onMouseDown_ = function(e) {
  var feed = this.getFeedAtPos_(e['x'], e['y']);
  this.dispatchEvent(new talk.media.c3d.SceneMouseHandler.MouseDownEvent(feed));
};


/**
 * Handles a mouseup event and dispatches a MouseUpEvent with the feed the
 * mouse is over.
 *
 * @param {Object} e The o3d.Event with mouse position.
 * @private
 */
talk.media.c3d.SceneMouseHandler.prototype.onMouseUp_ = function(e) {
  var feed = this.getFeedAtPos_(e['x'], e['y']);
  this.dispatchEvent(new talk.media.c3d.SceneMouseHandler.MouseUpEvent(feed));
};


/**
 * @override
 * @protected
 */
talk.media.c3d.SceneMouseHandler.prototype.disposeInternal = function() {
  talk.media.c3d.SceneMouseHandler.superClass_.disposeInternal.call(this);
  // Might not be scriptable during shutdown.
  if (this.o3dBundle_.c3dObject.isScriptable()) {
    var c3d = this.o3dBundle_.c3dObject.getPlugin();
    talk.media.c3d.removeEventCallback(c3d, 'mousemove',
        this.boundOnMouseMove_);
    talk.media.c3d.removeEventCallback(c3d, 'mousedown',
        this.boundOnMouseDown_);
    talk.media.c3d.removeEventCallback(c3d, 'mouseup', this.boundOnMouseUp_);
  }
};
