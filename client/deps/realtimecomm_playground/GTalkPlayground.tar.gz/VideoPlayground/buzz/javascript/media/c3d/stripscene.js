// Copyright 2009 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview Handles the layout of multiple video views in N:N calls in a
 *     horizontal strip.
 *
 * @author mikaeld@google.com (Mikael Drugge)
 * @author geer@google.com (Arthur van der Geer)
 */

goog.provide('talk.media.c3d.StripScene');

goog.require('talk.media.c3d.LabeledFeed');
goog.require('talk.media.c3d.SceneBase');


/**
 * Creates the StripScene.
 *
 * @param {talk.media.c3d.O3dBundle} o3dBundle The bundle of global resources
 *     for this O3D instance.
 * @extends {talk.media.c3d.SceneBase}
 * @constructor
 */
talk.media.c3d.StripScene = function(o3dBundle) {
  talk.media.c3d.SceneBase.call(this, o3dBundle);
};
goog.inherits(talk.media.c3d.StripScene, talk.media.c3d.SceneBase);


/**
 * The default number of user feeds to fit on screen initially.
 *
 * @type {number}
 * @const
 * @private
 */
talk.media.c3d.StripScene.USER_FEEDS_ = 5;


/**
 * For each feed we allocate screen real estate with a 16:10 aspect ratio.
 * If the feed is not 16:10 then the sizing logic in FixedAreaFeed will either
 * pillarbox or letterbox it within its available area.
 *
 * @type {number}
 * @const
 */
talk.media.c3d.StripScene.FEED_ASPECT = 1.6;


/**
 * @override
 * @protected
 */
talk.media.c3d.StripScene.prototype.createFeed = function(endpoint) {
  return new talk.media.c3d.LabeledFeed(
        this.o3dBundle, endpoint, 0.2, 0, 0, 0, 0);
};


/**
 * @override
 * @protected
 */
talk.media.c3d.StripScene.prototype.updatePositions = function() {
  var count = this.getFeedCount();

  var scale = 0.92;  // For spacing in between the video feeds.
  var spacing = (1 - scale) / 2;

  if (this.width_ / this.height_ >= talk.media.c3d.StripScene.FEED_ASPECT) {
    // Arrange feeds horizontally.
    var width = this.width_ /
        Math.max(talk.media.c3d.StripScene.USER_FEEDS_, count);
    var height = width / talk.media.c3d.StripScene.FEED_ASPECT;
    if (height > this.height_) {
      // If we make our feeds take up the available horizontal space then
      // they'll be too high. Must instead limit to the available vertical
      // space and leave some horizontal space unused.
      height = this.height_;
      width = height * talk.media.c3d.StripScene.FEED_ASPECT;
    }
    // Loop through all video feeds and (re)position them centered.
    var streams = this.getStreamIds();
    var middle = this.x_ + this.width_ / 2 - streams.length * width / 2;
    for (var i = 0; i < streams.length; ++i) {
      var feed = this.getFeed(streams[i]);
      feed.setArea(middle + (i * width) + spacing * width,
                   this.y_ + spacing * height,
                   width * scale,
                   height * scale);
    }
  } else {
    // Vertical strip.
    var height = this.height_ /
        Math.max(talk.media.c3d.StripScene.USER_FEEDS_, count);
    var width = height * talk.media.c3d.StripScene.FEED_ASPECT;
    if (width > this.width_) {
      // If we make our feeds take up the available vertical space then they'll
      // be too wide. Must instead limit to the available horizontal space and
      // leave some vertical space unused.
      width = this.width_;
      height = width / talk.media.c3d.StripScene.FEED_ASPECT;
    }
    // Loop through all video feeds and (re)position them top aligned.
    var streams = this.getStreamIds();
    for (var i = 0; i < streams.length; ++i) {
      var feed = this.getFeed(streams[i]);
      feed.setArea(this.x_ + spacing * width,
                   this.y_ + (i * height) + spacing * height,
                   width * scale,
                   height * scale);
    }
  }
};


/**
 * Return the height of this strip for a given available width.
 *
 * @param {number} width The available horizontal space.
 * @return {number} The matching height.
 */
talk.media.c3d.StripScene.prototype.getHeightForWidth = function(width) {
  var feedWidth = width /
      Math.max(talk.media.c3d.StripScene.USER_FEEDS_, this.getFeedCount());
  return feedWidth / talk.media.c3d.StripScene.FEED_ASPECT;
};


/**
 * Return the width of this strip for a given available height.
 *
 * @param {number} height The available vertical space.
 * @return {number} The matching width.
 */
talk.media.c3d.StripScene.prototype.getWidthForHeight = function(height) {
  var feedHeight = height /
      Math.max(talk.media.c3d.StripScene.USER_FEEDS_, this.getFeedCount());
  return feedHeight * talk.media.c3d.StripScene.FEED_ASPECT;
};
