// Copyright 2009 Google Inc.
// All Rights Reserved.

/*
 * @fileoverview Defines the VideoChatDialog class.
 *
 * @author jessan@google.com (Jessan Hutchison-Quillian)
 */

goog.provide('talk.media.VideoChatDialog');

goog.require('goog.debug.Logger');
goog.require('goog.events');
goog.require('goog.events.EventHandler');
goog.require('goog.ui.Dialog');
goog.require('goog.Disposable');
goog.require('talk.media.CommunicationPlayer');
goog.require('talk.media.SwitchMediaUiEvent');
goog.require('talk.media.UiMode');

/**
 * A modal dialog for displaying video chat.
 *
 * @param {talk.media.CommunicationPlayer|
 *     talk.media.C3dCommunicationPlayerWrapper} player The video player to
 *     embed.
 * @param {talk.media.CallManager} callManager A manager with an active call.
 * @param {string} opt_class See goog.ui.Dialog
 * @param {boolean} opt_useIframeMask See goog.ui.Dialog
 * @param {goog.dom.DomHelper} opt_domHelper See goog.ui.Dialog
 * @extends {goog.Disposable}
 * @constructor
 */
talk.media.VideoChatDialog = function(player, callManager, opt_class,
                                      opt_useIframeMask, opt_domHelper) {
  goog.Disposable.call(this);

  /**
   * @type {talk.media.CommunicationPlayer|
   *     talk.media.C3dCommunicationPlayerWrapper}
   * @private
   */
  this.player_ = player;

  /**
   * @type {talk.media.CallManager}
   * @private
   */
  this.callManager_ = callManager;

  // TODO(jessan): Shared event handler with parent
  /**
   * Event handler.
   * @private
   */
  this.videoChatDialogEventHandler_ = new goog.events.EventHandler(this);

  /**
   * @type {goog.ui.Dialog}
   * @private
   */
  this.dialog_ = new goog.ui.Dialog(opt_class, opt_useIframeMask,
      opt_domHelper);
  this.dialog_.setDraggable(true);
  this.dialog_.setModal(false);
  // We use an empty button set for the dialog, we'll add the control buttons
  // ourselves.
  this.dialog_.setButtonSet(new goog.ui.Dialog.ButtonSet());
  this.dialog_.setDraggable(true);

  /**
   * The button to click on to get back to small video mode.
   * @type {Element}
   */
  this.popInButton_ = this.createAndInsertPopInButton(this.dialog_);

  this.dialog_.setVisible(true);

  player.setContainer(this.dialog_.getContentElement());
  player.setUiMode(talk.media.UiMode.BIG);

  // We do this last to get the UI faster to the user.
  this.setUpEventListeners_();
};
goog.inherits(talk.media.VideoChatDialog, goog.Disposable);


/**
 * @type {goog.debug.Logger}
 * @private
 */
talk.media.VideoChatDialog.prototype.logger_ =
    goog.debug.Logger.getLogger('talk.media.VideoChatDialog');


/**
 * Creates the pop-in button and inserts it into the dialog title bar.
 * @param {goog.ui.Dialog} dialog The dialog to insert into.
 * @return {Element} The newly created button.
 */
talk.media.VideoChatDialog.prototype.createAndInsertPopInButton =
    function(dialog) {
  var domHelper = dialog.getDomHelper();
  var popInButton = domHelper.createDom('div', {
    'class': goog.getCssName('CSS_VIDEO_CHAT_DIALOG_TITLE_POP_IN')}
  );
  domHelper.appendChild(dialog.getTitleElement(), popInButton);
  return popInButton;
};


/**
 * Inserts a toolbar below the player.
 * @param {Element} toolbar The toolbar to insert.
 */
talk.media.VideoChatDialog.prototype.insertToolbar = function(toolbar) {
  this.dialog_.getDomHelper().appendChild(this.dialog_.getButtonElement(),
      toolbar);
};


/**
 * Set up all event listeners on this widget.
 */
talk.media.VideoChatDialog.prototype.setUpEventListeners_ = function() {
  // Listen for hover events on the title bar buttons.
  var closeElement = this.dialog_.getTitleCloseElement();
  this.videoChatDialogEventHandler_.listen(closeElement,
      goog.events.EventType.MOUSEOVER, function(e) {
    goog.dom.classes.add(e.target,
        goog.getCssName('CSS_VIDEO_CHAT_DIALOG_CLOSE_HOVER'))
  });
  this.videoChatDialogEventHandler_.listen(closeElement,
      goog.events.EventType.MOUSEOUT, function(e) {
    goog.dom.classes.remove(e.target,
        goog.getCssName('CSS_VIDEO_CHAT_DIALOG_CLOSE_HOVER'))
  });
  this.videoChatDialogEventHandler_.listen(this.dialog_,
      goog.ui.Dialog.EventType.AFTER_HIDE, this.onDialogClosing_);

  this.videoChatDialogEventHandler_.listen(this.popInButton_,
      goog.events.EventType.MOUSEOVER, function(e) {
    goog.dom.classes.add(e.target,
        goog.getCssName('CSS_VIDEO_CHAT_DIALOG_TITLE_POP_IN_HOVER'))
  });
  this.videoChatDialogEventHandler_.listen(this.popInButton_,
      goog.events.EventType.MOUSEOUT, function(e) {
    goog.dom.classes.remove(e.target,
        goog.getCssName('CSS_VIDEO_CHAT_DIALOG_TITLE_POP_IN_HOVER'))
  });
  this.videoChatDialogEventHandler_.listen(this.popInButton_,
      goog.events.EventType.CLICK, this.onPopIn_);
  this.videoChatDialogEventHandler_.listen(this.player_,
      talk.media.CommunicationPlayer.Events.DISPOSED, this.dispose);
};


/**
 * Handles the dialog being popped in
 *
 * @param {goog.events.Event} e The pop in click.
 */
talk.media.VideoChatDialog.prototype.onPopIn_ = function(e) {
  this.player_.dispatchEvent(
      new talk.media.SwitchMediaUiEvent(talk.media.UiMode.NORMAL));
  this.dispose();
};


/**
 * Handles the dialog being closed, either by the call end or by pop in.
 *
 * @param {goog.events.Event} e the AFTER_DISMISS event.
 */
talk.media.VideoChatDialog.prototype.onDialogClosing_ = function(e) {
  this.callManager_.endCall();
  this.dispose();
};


/** @override */
talk.media.VideoChatDialog.prototype.disposeInternal = function() {
  this.videoChatDialogEventHandler_.removeAll();
  this.videoChatDialogEventHandler_.dispose();

  this.player_.dispose();
  this.dialog_.dispose();
};
