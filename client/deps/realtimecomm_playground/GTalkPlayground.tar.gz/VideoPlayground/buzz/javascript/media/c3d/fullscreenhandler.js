// Copyright 2010 Google Inc. All Rights Reserved.

/**
 * @fileoverview A handler of O3D fullscreen mode and UI widgets to switch mode.
 *
 * @author geer@google.com (Arthur van der Geer)
 */

goog.provide('talk.media.c3d.FullscreenHandler');

goog.require('goog.Disposable');
goog.require('goog.debug.Logger');
goog.require('talk.media.c3d.C3dEngine');
goog.require('talk.media.c3d.C3dObject');
goog.require('talk.media.c3d.CursorManager');
goog.require('talk.media.c3d.FullscreenNotice');
goog.require('talk.media.c3d.Image');
goog.require('talk.media.c3d.ImageFader');
goog.require('talk.media.c3d.ImageOverlay');
goog.require('talk.media.c3d.O3dBundle');
goog.require('talk.media.c3d.View');
goog.require('talk.media.c3d.helpers');


/**
 * Creates a handler of O3D fullscreen mode and UI widgets to switch mode.
 *
 * @param {talk.media.c3d.O3dBundle} o3dBundle The collection of global O3D
 *     handles.
 * @param {talk.media.c3d.ImageOverlay} imageOverlay The layer for images.
 * @param {string} locale The user's locale to use for notifications.
 * @constructor
 * @extends {goog.Disposable}
 */
talk.media.c3d.FullscreenHandler = function(o3dBundle, imageOverlay, locale) {
  goog.Disposable.call(this);

  /**
   * The collection of global O3D handles.
   *
   * @type {talk.media.c3d.O3dBundle}
   * @private
   */
  this.o3dBundle_ = o3dBundle;


  /**
   * The C3D render graph to draw transparent 2d images.
   *
   * @type {talk.media.c3d.ImageOverlay}
   * @private
   */
  this.imageOverlay_ = imageOverlay;


  /**
   * The user's locale to use for notifications.
   *
   * @type {string}
   * @private
   */
  this.locale_ = locale;


  /**
   * A goog.bind()'ed version of onResize_, suitable for using as an event
   * callback.
   *
   * @type {Function}
   * @private
   */
  this.boundOnResize_ = goog.bind(this.onResize_, this);


  /**
   * A goog.bind()'ed version of onMouseMove_, suitable for using as an event
   * callback.
   *
   * @type {Function}
   * @private
   */
  this.boundOnMouseMove_ = goog.bind(this.onMouseMove_, this);


  /**
   * A goog.bind()'ed version of onClick_, suitable for using as an event
   * callback.
   *
   * @type {Function}
   * @private
   */
  this.boundOnClick_ = goog.bind(this.onClick_, this);
};
goog.inherits(talk.media.c3d.FullscreenHandler, goog.Disposable);


/**
 * Our logger.
 *
 * @type {goog.debug.Logger}
 * @private
 */
talk.media.c3d.FullscreenHandler.prototype.logger_ =
    goog.debug.Logger.getLogger('talk.media.c3d.FullscreenHandler');


/**
 * A button image to enter fullscreen mode.
 *
 * @type {talk.media.c3d.Image}
 * @private
 */
talk.media.c3d.FullscreenHandler.prototype.enterFullscreenImg_;


/**
 * A button image to leave fullscreen mode.
 *
 * @type {talk.media.c3d.Image}
 * @private
 */
talk.media.c3d.FullscreenHandler.prototype.exitFullscreenImg_;


/**
 * A button image to enter fullscreen mode when hovering over button.
 *
 * @type {talk.media.c3d.Image}
 * @private
 */
talk.media.c3d.FullscreenHandler.prototype.rolloverFullscreenImg_;


/**
 * The button image to show for the current state.
 *
 * @type {talk.media.c3d.Image}
 * @private
 */
talk.media.c3d.FullscreenHandler.prototype.fullscreenImg_;


/**
 * A tween to hide the images by fading.
 *
 * @type {talk.media.c3d.AlphaTween}
 * @private
 */
talk.media.c3d.FullscreenHandler.prototype.imgHider_;


/**
 * Opaque reference to the fullscreen image's cursor setting.
 *
 * @type {talk.media.c3d.CursorManager.Registration_}
 * @private
 */
talk.media.c3d.FullscreenHandler.prototype.cursorRef_;


/**
 * Reference to the hidden cursor state.
 *
 * @type {talk.media.c3d.CursorManager.Registration_}
 * @private
 */
talk.media.c3d.FullscreenHandler.prototype.noCursorRef_;


/**
 * The fullscreen notification image.
 *
 * @type {talk.media.c3d.Image}
 * @private
 */
talk.media.c3d.FullscreenHandler.prototype.fullscreenMsg_;


/**
 * The object showing and fading out the fullscreen notification image.
 *
 * @type {talk.media.c3d.ImageFader}
 * @private
 */
talk.media.c3d.FullscreenHandler.prototype.fullscreenMsgFader_;


/**
 * Initializes images and event handlers.
 * Adds a clickable area in the upper left corner of the video area.
 */
talk.media.c3d.FullscreenHandler.prototype.init = function() {
  var c3d = this.o3dBundle_.c3dObject.getPlugin();

  // Add resize handler to re-position everything upon resize.
  talk.media.c3d.addEventCallback(c3d, 'resize', this.boundOnResize_);

  this.fullscreenMsg_ = talk.media.c3d.FullscreenNotice.createFullscreenNotice(
      this.o3dBundle_, this.imageOverlay_, this.locale_);
  this.fullscreenMsgFader_ = new talk.media.c3d.ImageFader(
      this.o3dBundle_, this.fullscreenMsg_);
  this.fullscreenMsgFader_.hide();
  try {
    this.enterFullscreenImg_ = this.imageOverlay_.createImage(
        10, 10, 'images/enter_fullscreen.png', goog.bind(function() {
      // Link image to fullscreen mode.
      c3d['client']['setFullscreenClickRegion'](
          this.enterFullscreenImg_.x(),
          this.enterFullscreenImg_.y(),
          this.enterFullscreenImg_.width(),
          this.enterFullscreenImg_.height(),
          c3d['o3d']['Renderer']['DISPLAY_MODE_DEFAULT']);
      // Add mousemove handler to change mouse pointer over image.
      talk.media.c3d.addEventCallback(c3d, 'mousemove', this.boundOnMouseMove_);
      this.showControl();
    }, this, c3d));
  } catch (e) {
    // Not defined, old version of o3d plugin.
    this.logger_.warning('Full screen not available ("' + e.name + '", "' +
                         e.message + '")');
  }
  this.fullscreenImg_ = this.enterFullscreenImg_;

  this.exitFullscreenImg_ = this.imageOverlay_.createImage(10, 10,
      'images/exit_fullscreen.png', goog.bind(function() {
        this.exitFullscreenImg_.resize(
            this.exitFullscreenImg_.textureWidth() * 2,
            this.exitFullscreenImg_.textureHeight() * 2);
      }, this));
  this.exitFullscreenImg_.setVisible(false);

  this.rolloverFullscreenImg_ = this.imageOverlay_.createImage(10, 10,
      'images/fullscreen_rollover.png');
  this.rolloverFullscreenImg_.setVisible(false);
};


/**
 * Changes the button image.
 *
 * @param {talk.media.c3d.Image} image The image to use.
 * @private
 */
talk.media.c3d.FullscreenHandler.prototype.setImage_ = function(image) {
  if (this.fullscreenImg_ == image) {
    return;
  }
  var previous = this.fullscreenImg_;
  this.fullscreenImg_ = image;
  if (previous.isVisible()) {
    this.fullscreenImg_.setVisible(true);
    previous.setVisible(false);
  }
};


/**
 * Handles a resize event of the o3d client.
 *
 * @param {Object} e The event.
 * @private
 */
talk.media.c3d.FullscreenHandler.prototype.onResize_ = function(e) {
  var c3d = this.o3dBundle_.c3dObject.getPlugin();

  if (this.enterFullscreenImg_) {
    if (e['fullscreen']) {
      // Position and show the fullscreen message, if loaded.
      if (goog.isDefAndNotNull(this.fullscreenMsg_.width())) {
        this.fullscreenMsg_.moveTo(
            (this.o3dBundle_.width - this.fullscreenMsg_.width()) / 2,
            this.fullscreenMsg_.height() / 2);
        this.fullscreenMsgFader_.show(4000, 1);
      }
      this.setImage_(this.exitFullscreenImg_);
      // Add click handler to respond to mouse clicks on image, now that the
      // o3d click region has done its job.
      talk.media.c3d.addEventCallback(c3d, 'click', this.boundOnClick_);
    } else {
      // Hide the fullscreen message if not faded-out yet.
      this.fullscreenMsgFader_.hide();
      this.setImage_(this.enterFullscreenImg_);
      talk.media.c3d.removeEventCallback(c3d, 'click', this.boundOnClick_);
    }
  }
};


/**
 * Handles a mousemove event of the o3d client.
 *
 * @param {Object} e The event.
 * @private
 */
talk.media.c3d.FullscreenHandler.prototype.onMouseMove_ = function(e) {
  if (this.isOverControl(e['x'], e['y'])) {
    if (this.fullscreenImg_ == this.enterFullscreenImg_) {
      this.setImage_(this.rolloverFullscreenImg_);
    }
    if (!this.cursorRef_) {
      this.cursorRef_ = this.o3dBundle_.cursorManager.setCursor('POINTER', 0);
    }
  } else {
    if (this.fullscreenImg_ == this.rolloverFullscreenImg_) {
      this.setImage_(this.enterFullscreenImg_);
    }
    if (this.cursorRef_) {
      this.o3dBundle_.cursorManager.unsetCursor(this.cursorRef_);
      this.cursorRef_ = null;
    }
  }
};


/**
 * Handles a click event of the o3d client.
 *
 * @param {Object} e The event.
 * @private
 */
talk.media.c3d.FullscreenHandler.prototype.onClick_ = function(e) {
  var c3d = this.o3dBundle_.c3dObject.getPlugin();
  if (c3d['client']['fullscreen'] && this.isOverControl(e['x'], e['y'])) {
    c3d['client']['cancelFullscreenDisplay']();
  }
};


/**
 * Shows the fullscreen icon.
 */
talk.media.c3d.FullscreenHandler.prototype.showControl = function() {
  this.cancelHideTween_();
  if (this.fullscreenImg_) {
    this.fullscreenImg_.setVisible(true);
    this.fullscreenImg_.setAlpha(1);
  }
  if (this.noCursorRef_) {
    this.o3dBundle_.cursorManager.unsetCursor(this.noCursorRef_);
    this.noCursorRef_ = null;
  }
};


/**
 * Hides the fullscreen icon.
 */
talk.media.c3d.FullscreenHandler.prototype.hideControl = function() {
  if (this.fullscreenImg_ && this.fullscreenImg_.isVisible()) {
    this.imgHider_ = new talk.media.c3d.AlphaTween(this.fullscreenImg_,
        this.fullscreenImg_.getAlpha(), 0, 0.4,
        talk.media.c3d.REGULAR_EASE_IN,
        goog.bind(this.finishHideControl_, this));
    this.o3dBundle_.c3dEngine.registerRenderCallback(this.imgHider_);
  }
};


/**
 * Cancels and removes the tween for hiding.
 * @private
 */
talk.media.c3d.FullscreenHandler.prototype.cancelHideTween_ = function() {
  if (this.imgHider_) {
    this.o3dBundle_.c3dEngine.unregisterRenderCallback(this.imgHider_);
    this.imgHider_ = null;
  }
};


/**
 * Finalizes the hiding of the control. Cancels and removes the tween.
 * @private
 */
talk.media.c3d.FullscreenHandler.prototype.finishHideControl_ = function() {
  this.cancelHideTween_();
  this.fullscreenImg_.setVisible(false);

  // Hide the mouse cursor if in fullscreen.
  if (this.o3dBundle_.c3dObject.isScriptable()) {
    var c3d = this.o3dBundle_.c3dObject.getPlugin();
    if (c3d['client']['fullscreen'] && !this.noCursorRef_) {
      this.noCursorRef_ = this.o3dBundle_.cursorManager.setCursor('NONE', -1);
    }
  }
};


/**
 * Checks if a mouse position is over the control.
 *
 * @param {number} x The horizontal position.
 * @param {number} y The vertical position.
 * @return {boolean} Whether or not the position is over a control.
 */
talk.media.c3d.FullscreenHandler.prototype.isOverControl = function(x, y) {
  return this.fullscreenImg_ != null &&
      this.fullscreenImg_.isVisible() &&
      this.fullscreenImg_.hitTest(x, y);
};


/**
 * @override
 * @protected
 */
talk.media.c3d.FullscreenHandler.prototype.disposeInternal = function() {
  // Might not be during shutdown.
  if (this.o3dBundle_.c3dObject.isScriptable()) {
    var c3d = this.o3dBundle_.c3dObject.getPlugin();
    talk.media.c3d.removeEventCallback(c3d, 'resize', this.boundOnResize_);
    talk.media.c3d.removeEventCallback(c3d, 'mousemove',
                                       this.boundOnMouseMove_);
    talk.media.c3d.removeEventCallback(c3d, 'click', this.boundOnClick_);
    if (c3d['client']['fullscreen']) {
      c3d['client']['cancelFullscreenDisplay']();
    }
    c3d['client']['clearFullscreenClickRegion']();
  }
  this.enterFullscreenImg_.disposeC3d();
  this.enterFullscreenImg_ = null;
  this.exitFullscreenImg_.disposeC3d();
  this.exitFullscreenImg_ = null;
  this.rolloverFullscreenImg_.disposeC3d();
  this.rolloverFullscreenImg_ = null;
  this.fullscreenImg_ = null;
  this.fullscreenMsg_.disposeC3d();
  this.fullscreenMsg_ = null;
  if (this.fullscreenMsgFader_) {
    this.fullscreenMsgFader_.dispose();
    this.fullscreenMsgFader_ = null;
  }
  this.imageOverlay_ = null;
  this.o3dBundle_ = null;
  talk.media.c3d.FullscreenHandler.superClass_.disposeInternal.call(this);
};
