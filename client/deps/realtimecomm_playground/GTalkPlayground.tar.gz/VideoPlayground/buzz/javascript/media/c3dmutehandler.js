// Copyright 2009 Google Inc.  All Rights Reserved.

/**
 * @fileoverview Handling for mute indications in C3D area.
 *
 * @author perd@google.com (Per Danvind)
 */

goog.provide('talk.media.C3dMuteHandler');

goog.require('goog.Disposable');
goog.require('goog.debug.Logger');
goog.require('goog.events.BrowserEvent');
goog.require('goog.events.EventTarget');
goog.require('talk.media.CallManager');
goog.require('talk.media.c3d.AlphaTween');
goog.require('talk.media.c3d.C3dEngine');
goog.require('talk.media.c3d.C3dObject');
goog.require('talk.media.c3d.ImageOverlay');
goog.require('talk.media.c3d.easing');
goog.require('talk.media.c3d.helpers');

/**
 * Handles microphone mute notifications by displaying appropriate icons in the
 * C3D area.
 *
 * @extends {goog.Disposable}
 * @constructor
 */
talk.media.C3dMuteHandler = function() {
  goog.Disposable.call(this);

  /**
   * A goog.bind()'ed version of onResize, suitable for using as an event
   * callback.
   *
   * @type {Function}
   * @private
   */
  this.boundOnResize_ = goog.bind(this.onResize, this);
};
goog.inherits(talk.media.C3dMuteHandler, goog.Disposable);


/**
 * Delay until fade-out of unmuted icon starts.
 *
 * @type {number}
 * @private
 */
talk.media.C3dMuteHandler.FADE_OUT_DELAY_MS_ = 2 * 1000;


/**
 * Logger.
 *
 * @type {!goog.debug.Logger}
 * @private
 */
talk.media.C3dMuteHandler.prototype.logger_ =
    goog.debug.Logger.getLogger('talk.media.C3dMuteHandler');


/**
 * Whether mute handling is enabled or not, initially disabled.
 *
 * @type {boolean}
 * @private
 */
talk.media.C3dMuteHandler.prototype.enabled_ = false;


/**
 * Whether C3D system is available or not.
 *
 * @type {boolean}
 * @private
 */
talk.media.C3dMuteHandler.prototype.c3dAvailable_ = false;


/**
 * The call manager providing the microphone mute state.
 *
 * @type {talk.media.CallManager}
 * @private
 */
talk.media.C3dMuteHandler.prototype.callManager_ = null;


/**
 * The width of the video pane.
 *
 * @type {number}
 * @private
 */
talk.media.C3dMuteHandler.prototype.width_ = 0;


/**
 * The height of the video pane.
 *
 * @type {number}
 * @private
 */
talk.media.C3dMuteHandler.prototype.height_ = 0;


/**
 * An icon indicating that the microphone is muted.
 *
 * @type {talk.media.c3d.Image}
 * @private
 */
talk.media.C3dMuteHandler.prototype.mutedImg_;


/**
 * An icon indicating that the microphone is unmuted.
 *
 * @type {talk.media.c3d.Image}
 * @private
 */
talk.media.C3dMuteHandler.prototype.unmutedImg_;


/**
 * The ID for the unmuted indicator fading callback.
 *
 * @type {?number}
 * @private
 */
talk.media.C3dMuteHandler.prototype.unmutedImgFaderId_;


/**
 * A tween handling the unmuted icon fading.
 *
 * @type {talk.media.c3d.AlphaTween}
 * @private
 */
talk.media.C3dMuteHandler.prototype.unmutedImgFader_;


/**
 * Initializes mute indication icons and enables mute handling.
 *
 * @param {talk.media.CallManager} callManager The call manager.
 * @param {talk.media.c3d.C3dEngine} c3dEngine A 3D rendering engine.
 * @param {talk.media.c3d.C3dObject} c3dObject A 3D rendering object.
 * @param {talk.media.c3d.ImageOverlay} imageOverlay An image rendering layer.
 */
talk.media.C3dMuteHandler.prototype.init = function(callManager, c3dEngine,
    c3dObject, imageOverlay) {
  if (this.c3dAvailable_) {
    this.logger_.warning('Already initialized, this is probably unintended.');
    return;
  }
  this.c3dAvailable_ = true;
  this.callManager_ = callManager;
  this.c3dEngine_ = c3dEngine;
  this.c3dObject_ = c3dObject;
  this.width_ = this.c3dObject_.getWidth();
  this.height_ = this.c3dObject_.getHeight();

  this.addMuteIndicator_(imageOverlay);

  this.logger_.fine('Adding resize listener.');
  talk.media.c3d.addEventCallback(this.c3dObject_.getPlugin(), 'resize',
      this.boundOnResize_);
  this.initInternal(true);
};


/**
 * Removes all references to C3D objects.
 */
talk.media.C3dMuteHandler.prototype.disposeC3d = function() {
  if (!this.c3dAvailable_) {
    return;
  }
  if (this.c3dObject_.isScriptable()) {  // Might not be during shutdown
    this.logger_.fine('Removing C3D resize listener.');
    talk.media.c3d.removeEventCallback(this.c3dObject_.getPlugin(), 'resize',
        this.boundOnResize_);
  }
  if (this.c3dObject_.isSceneScriptable()) {  // Might not be during shutdown
    this.hideMuteIndication_();
  }
  this.mutedImg_ = null;
  this.unmutedImg_ = null;
  this.c3dAvailable_ = false;
};


/**
 * @param {boolean} enable Whether to be initially enabled or disabled.
 * @protected
 */
talk.media.C3dMuteHandler.prototype.initInternal = function(enable) {
  this.setEnabled(enable);
};


/**
 * Handles a resize event of the o3d client.
 *
 * @param {Object} e A C3D event.
 * @protected
 */
talk.media.C3dMuteHandler.prototype.onResize = function(e) {
  this.width_ = e['width'];
  this.height_ = e['height'];

  if (this.mutedImg_) {
    this.mutedImg_.moveImageWithEdgeWrapping(-2, 2, this.width_, this.height_);
  }
  if (this.unmutedImg_) {
    this.unmutedImg_.moveImageWithEdgeWrapping(-2, 2, this.width_,
        this.height_);
  }
};


/**
 * @return {talk.media.CallManager} The CallManager or null if not initialized.
 * @protected
 */
talk.media.C3dMuteHandler.prototype.getCallManager = function() {
  return this.callManager_;
};


/**
 * Adds an icon in the upper right corner of the video area for indicating if
 * the microphone is muted.
 *
 * @param {talk.media.c3d.ImageOverlay} imageOverlay Layer to hold mute icons.
 * @private
 */
talk.media.C3dMuteHandler.prototype.addMuteIndicator_ = function(imageOverlay) {
  this.mutedImg_ = imageOverlay.createImage(0, 0,
      'images/mic_fullscreen_muted.png',
      goog.bind(function() {
            this.imageLoaded_(this.mutedImg_, -2, 2);
          }, this));
  this.unmutedImg_ = imageOverlay.createImage(0, 0,
      'images/mic_fullscreen.png',
      goog.bind(function() {
            this.imageLoaded_(this.unmutedImg_, -2, 2);
          }, this));

  this.hideMuteIndication_();
};


/**
 * Displays an icon to indicate whether the microphone is muted or unmuted.
 * If unmuted the icon is faded out after a while.
 *
 * @param {boolean} muted Whether mic is muted or not.
 * @private
 */
talk.media.C3dMuteHandler.prototype.showMuteIndication_ = function(muted) {
  if (!this.c3dAvailable_) {
    return;
  }

  if (muted) {
    this.finishUnmutedImgFading_();
    this.mutedImg_.setVisible(true);
  } else {
    this.unmutedImgFaderId_ = goog.Timer.callOnce(this.fadeOutUnmutedImg_,
        talk.media.C3dMuteHandler.FADE_OUT_DELAY_MS_, this);
    this.mutedImg_.setVisible(false);
    this.unmutedImg_.setVisible(true);
    this.unmutedImg_.setAlpha(1);
  }
};


/**
 * Hides mute indication icons.
 *
 * @private
 */
talk.media.C3dMuteHandler.prototype.hideMuteIndication_ = function() {
  if (!this.c3dAvailable_) {
    return;
  }
  this.finishUnmutedImgFading_();
  this.mutedImg_.setVisible(false);
};


/**
 * Starts a process of fading out the unmuted indicator icon.  Can be aborted
 * via the finishUnmutedImgFading_ function.
 *
 * @private
 */
talk.media.C3dMuteHandler.prototype.fadeOutUnmutedImg_ = function() {
  this.unmutedImgFaderId_ = null;
  this.unmutedImgFader_ = new talk.media.c3d.AlphaTween(
      this.unmutedImg_,
      this.unmutedImg_.getAlpha(),
      0.0,
      1.0,
      talk.media.c3d.REGULAR_EASE_IN,
      goog.bind(this.finishUnmutedImgFading_, this));
  this.c3dEngine_.registerRenderCallback(this.unmutedImgFader_);
};


/**
 * Cancels callback for starting fader and the actual fading process if active.
 *
 * @private
 */
talk.media.C3dMuteHandler.prototype.finishUnmutedImgFading_ = function() {
  if (this.unmutedImgFaderId_) {
    goog.Timer.clear(this.unmutedImgFaderId_);
    this.unmutedImgFaderId_ = null;
  }
  if (this.unmutedImgFader_) {
    this.c3dEngine_.unregisterRenderCallback(this.unmutedImgFader_);
    this.unmutedImgFader_ = null;
  }
  this.unmutedImg_.setVisible(false);
};


/**
 * Callback when an image has completed loading. Moves image to the given
 * initial position.
 *
 * @param {talk.media.c3d.Image} image The image to move.
 * @param {number} x The new horizontal position.
 * @param {number} y The new vertical position.
 * @private
 */
talk.media.C3dMuteHandler.prototype.imageLoaded_ =
    function(image, x, y) {
  image.moveImageWithEdgeWrapping(x, y, this.width_, this.height_);
};


/**
 * Handles changes to microphone mute state of the active call.
 *
 * @param {talk.media.CallManager.MicMuteEvent} e The event.
 */
talk.media.C3dMuteHandler.prototype.handleMicMuteNotification = function(e) {
  if (this.enabled_) {
    this.showMuteIndication_(e.muted);
  } else {
    this.logger_.fine('Ignoring mic mute notification - disabled.');
  }
};


/**
 * Enables or disables the mute handling.  When enabled, mute indications for
 * the current mute state and subsequent mute notifications are shown.  When
 * disabled, mute indications are removed and subsequent mute notifications are
 * not processed.
 *
 * @param {boolean} enabled Whether to enable or disable the mute handling.
 * @protected
 */
talk.media.C3dMuteHandler.prototype.setEnabled = function(enabled) {
  if (this.enabled_ == enabled) {
    return;
  }
  this.enabled_ = enabled;
  if (this.enabled_) {
    this.showMuteIndication_(this.callManager_.getMicrophoneMute());
  } else {
    this.hideMuteIndication_();
  }
};


/**
 * Returns whether mute handling is enabled or disabled.
 *
 * @return {boolean} Whether mute handling is enabled or not.
 */
talk.media.C3dMuteHandler.prototype.isEnabled = function() {
  return this.enabled_;
};


/**
 * @override
 * @protected
 */
talk.media.C3dMuteHandler.prototype.disposeInternal = function() {
  talk.media.C3dMuteHandler.superClass_.disposeInternal.call(this);
  this.disposeC3d();
};
