// Copyright 2010 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview A helper function to create the fullscreen notice image.
 *
 * @author tschmelcher@google.com (Tristan Schmelcher)
 */

goog.provide('talk.media.c3d.FullscreenNotice');

goog.require('goog.debug.Logger');
goog.require('talk.media.c3d.helpers');


/**
 * Our logger.
 *
 * @type {goog.debug.Logger}
 * @private
 */
talk.media.c3d.FullscreenNotice.logger_ =
    goog.debug.Logger.getLogger('talk.media.c3d.FullscreenNotice');


/**
 * The set of locales for which we have a localized image.
 *
 * @type {Object}
 * @private
 */
talk.media.c3d.FullscreenNotice.AvailableLocales_ = {
  'ar': 1,
  'bg': 1,
  'bn': 1,
  'ca': 1,
  'cs': 1,
  'da': 1,
  'de': 1,
  'el': 1,
  'en': 1,
  'en-GB': 1,
  'es': 1,
  'es-419': 1,
  'et': 1,
  'fa': 1,
  'fi': 1,
  'fil': 1,
  'fr': 1,
  'gu': 1,
  'hi': 1,
  'hr': 1,
  'hu': 1,
  'id': 1,
  'is': 1,
  'it': 1,
  'iw': 1,
  'ja': 1,
  'kn': 1,
  'ko': 1,
  'lt': 1,
  'lv': 1,
  'ml': 1,
  'mr': 1,
  'ms': 1,
  'nl': 1,
  'no': 1,
  'pl': 1,
  'pt-BR': 1,
  'pt-PT': 1,
  'ro': 1,
  'ru': 1,
  'sk': 1,
  'sl': 1,
  'sr': 1,
  'sv': 1,
  'ta': 1,
  'te': 1,
  'th': 1,
  'tr': 1,
  'uk': 1,
  'ur': 1,
  'vi': 1,
  'zh-CN': 1,
  'zh-TW': 1
};


/**
 * The amount by which the black background bar is thicker than the message
 * itself.
 *
 * @type {number}
 * @private
 * @const
 */
talk.media.c3d.FullscreenNotice.VERTICAL_MARGIN_ = 30;


/**
 * Renders the loaded message texture to the image with a pretty
 * half-transparent black background with rounded corners.
 *
 * @param {talk.media.c3d.O3dBundle} o3dBundle The bundle of global resources
 * for this O3D instance.
 * @param {talk.media.c3d.Image} image The target image.
 * @param {Object} sourceTexture The O3D texture object with the message in it.
 * @private
 */
talk.media.c3d.FullscreenNotice.renderNotice_ =
    function(o3dBundle, image, sourceTexture) {
  // Compute dimensions for the overall texture.
  // Make the canvas thicker by 30 pixels.
  var height = sourceTexture['height'] +
      talk.media.c3d.FullscreenNotice.VERTICAL_MARGIN_;
  // Ensure height is even.
  if (height % 2 == 1) {
    height++;
  }
  // Make the canvas wider by enough pixels for a half-circle at each end.
  var width = sourceTexture['width'] + height;
  // Radius of the half-circles that we will put at each end.
  var circleRadius = height / 2;
  // Ensure width is even.
  if (width % 2 == 1) {
    width++;
  }

  var canvas = o3dBundle.pack['createObject']('Canvas');
  canvas['setSize'](width, height);

  // Makes the canvas transparent.
  canvas['clear']([0, 0, 0, 0]);

  // Draw the main rectangle for the background.
  var backgroundPaint = o3dBundle.pack['createObject']('CanvasPaint');
  backgroundPaint['color'] = [0, 0, 0, 0.5];  // Half-transparent black
  canvas['drawRect'](circleRadius,
                     0,
                     width - circleRadius,
                     height,
                     backgroundPaint);

  // Draw the half-circles at each end.

  // Right side.
  talk.media.c3d.rasterizeSolidQuarterCircle(
      canvas,
      backgroundPaint,
      width - circleRadius,
      circleRadius,
      circleRadius,
      1);
  talk.media.c3d.rasterizeSolidQuarterCircle(
      canvas,
      backgroundPaint,
      width - circleRadius,
      circleRadius,
      circleRadius,
      2);
  // Left side.
  talk.media.c3d.rasterizeSolidQuarterCircle(
      canvas,
      backgroundPaint,
      circleRadius,
      circleRadius,
      circleRadius,
      3);
  talk.media.c3d.rasterizeSolidQuarterCircle(
      canvas,
      backgroundPaint,
      circleRadius,
      circleRadius,
      circleRadius,
      4);

  // Now copy the message texture on top of the main rectangle.
  canvas['drawBitmap'](
      sourceTexture,
      circleRadius,
      height - talk.media.c3d.FullscreenNotice.VERTICAL_MARGIN_ / 2);

  // Now copy the canvas content out to a texture.
  var c3d = o3dBundle.c3dObject.getPlugin();
  var targetTexture = o3dBundle.pack['createTexture2D'](width, height,
      c3d['o3d']['Texture']['ARGB8'],  // format
      1,  // mipmap levels
      false);
  canvas['copyToTexture'](targetTexture);

  // Finally initialize the image.
  image.setTexture(targetTexture);
};


/**
 * Creates an Image object containing the fullscreen notice message ("Press Esc
 * to exit full screen mode").
 *
 * @param {talk.media.c3d.O3dBundle} o3dBundle The bundle of global resources
 * for this O3D instance.
 * @param {talk.media.c3d.ImageOverlay} imageOverlay The image plane to place
 * the message on.
 * @param {string} locale The current user's locale.
 * @return {talk.media.c3d.Image} The image (not yet initialized).
 */
talk.media.c3d.FullscreenNotice.createFullscreenNotice =
    function(o3dBundle, imageOverlay, locale) {
  var image = imageOverlay.createUninitializedImage(0, 0);
  // Our images all use '-' for the locale separator, so convert any
  // underscores.
  locale = locale.replace(/_/g, '-');
  if (!talk.media.c3d.FullscreenNotice.AvailableLocales_[locale]) {
    // Not translated in this locale. Probably someone is testing out an
    // unsupported language. Fall back to English.
    locale = 'en';
  }
  var url = 'images/fullscreen_notice_' + locale + '.png';
  var request = o3dBundle.pack['createFileRequest']('TEXTURE');
  request['open']('GET', url, true);
  request['onreadystatechange'] = function() {
    if (request['done']) {
      if (request['success']) {
        talk.media.c3d.FullscreenNotice.renderNotice_(
            o3dBundle, image, request['texture']);
      } else {
        var msg = request['error'];
        if (!msg) {
          msg = 'Unknown error';
        }
        talk.media.c3d.FullscreenNotice.logger_.severe(
            'Texture failed to load, url="' + url + '", msg="' + msg + '"');
      }
      o3dBundle.pack['removeObject'](request);
    }
  };
  request['send']();
  return image;
};
