// Copyright 2009 Google Inc.  All Rights Reserved.

/**
 * @fileoverview Handles mouse input for the PIP(Picture In Picture) element.
 * The PIP element is movable by dragging and minimizable by pressing the
 * minimize icon.
 *
 * @author oja@google.com (Fredrik Oja)
 */

goog.provide('talk.media.c3d.PipHandler');

goog.require('goog.debug.Logger');
goog.require('talk.media.c3d.Attrs');
goog.require('talk.media.c3d.AttrsTween');
goog.require('talk.media.c3d.C3dEngine');
goog.require('talk.media.c3d.FeedHandler');
goog.require('talk.media.c3d.Image');
goog.require('talk.media.c3d.ImageOverlay');
goog.require('talk.media.c3d.O3dBundle');


/**
 * Handles input events for the PIP video object.
 *
 * @param {talk.media.c3d.O3dBundle} o3dBundle The global O3D bundle.
 * @param {talk.media.c3d.ShrinkableFeed} feed The object representing
 *     the PIP feed.
 * @constructor
 * @extends {talk.media.c3d.FeedHandler}
 */
talk.media.c3d.PipHandler = function(o3dBundle, feed) {
  talk.media.c3d.FeedHandler.call(this, o3dBundle, feed);
};
goog.inherits(talk.media.c3d.PipHandler, talk.media.c3d.FeedHandler);


/**
 * Width of border around the PIP.
 *
 * @type {number}
 * @private
 * @const
 */
talk.media.c3d.PipHandler.PIP_BORDER_WIDTH_ = 2;


/**
 * Treshold width for when to double the size of the icons.
 *
 * @type {number}
 * @private
 * @const
 */
talk.media.c3d.PipHandler.RESIZE_THRESHOLD_WIDTH_ = 320;


/**
 * Treshold height for when to double the size of the icons.
 *
 * @type {number}
 * @private
 * @const
 */
talk.media.c3d.PipHandler.RESIZE_THRESHOLD_HEIGHT_ = 200;


/**
 * Duration of the minimize and maximize animations, in seconds.
 *
 * @type {number}
 * @private
 * @const
 */
talk.media.c3d.PipHandler.MINMAX_DURATION_ = 0.6;


/**
 * Duration of the snap to corner animation, in seconds.
 *
 * @type {number}
 * @private
 * @const
 */
talk.media.c3d.PipHandler.SNAP_DURATION_ = 0.3;


/**
 * Logger.
 *
 * @type {!goog.debug.Logger}
 * @private
 */
talk.media.c3d.PipHandler.prototype.logger_ =
    goog.debug.Logger.getLogger('talk.media.c3d.PipHandler');


/**
 * A clickable icon for minimizing the pip.
 *
 * @type {talk.media.c3d.Image}
 * @private
 */
talk.media.c3d.PipHandler.prototype.minimizeImg_;


/**
 * A rollover version of the minimize icon.
 *
 * @type {talk.media.c3d.Image}
 * @private
 */
talk.media.c3d.PipHandler.prototype.minimizeRolloverImg_;


/**
 * A clickable icon for maximizing the pip.
 *
 * @type {talk.media.c3d.Image}
 * @private
 */
talk.media.c3d.PipHandler.prototype.maximizeImg_;


/**
 * A rollover version of the maximize icon.
 *
 * @type {talk.media.c3d.Image}
 * @private
 */
talk.media.c3d.PipHandler.prototype.maximizeRolloverImg_;


/**
 * An image showing a four way arrow highlighting that the pip is movable.
 *
 * @type {talk.media.c3d.Image}
 * @private
 */
talk.media.c3d.PipHandler.prototype.fourwayArrowImg_;


/**
 * Saved copy of PIP objects attributes before being minimized.
 *
 * @type {talk.media.c3d.Attrs}
 * @private
 */
talk.media.c3d.PipHandler.prototype.savedAttrs_;


/**
 * Tween that handles shrinking and growing animations.
 *
 * @type {talk.media.c3d.AttrsTween}
 * @private
 */
talk.media.c3d.PipHandler.prototype.tween_;


/**
 * Whether we are currently minimized.
 *
 * @type {boolean}
 * @private
 */
talk.media.c3d.PipHandler.prototype.isMinimized_ = false;


/**
 * Whether we are currently being dragged.
 *
 * @type {boolean}
 * @private
 */
talk.media.c3d.PipHandler.prototype.isDragging_ = false;


/**
 * Whether we are currently highlighted.
 *
 * @type {boolean}
 * @private
 */
talk.media.c3d.PipHandler.prototype.isHighlighted_ = false;


/**
 * Whether highlighting the PIP is enabled.
 *
 * @type {boolean}
 * @private
 */
talk.media.c3d.PipHandler.prototype.isHighlightEnabled_ = false;


/**
 * Current global mouse x coordinate.
 *
 * @type {number}
 * @private
 */
talk.media.c3d.PipHandler.prototype.mouseX_ = 0;


/**
 * Current global mouse y coordinate.
 *
 * @type {number}
 * @private
 */
talk.media.c3d.PipHandler.prototype.mouseY_ = 0;


/**
 * Opaque reference to our current cursor setting, if any.
 *
 * @type {talk.media.c3d.CursorManager.Registration_}
 * @private
 */
talk.media.c3d.PipHandler.prototype.cursorRef_;


/**
 * @override
 * @protected
 */
talk.media.c3d.PipHandler.prototype.init = function(opt_imageOverlay) {
  talk.media.c3d.PipHandler.superClass_.init.call(this, opt_imageOverlay);
  this.createImages_(this.imageOverlay_);
  this.setBorderVisible(true);
  this.setHighlightEnabled_(true);
  this.feedAttrs = this.feed.getFeedAttrs();
};


/**
 * Updates bounds for the current state.
 *
 * @param {talk.media.c3d.Attrs} attrs The new attributes for the PIP.
 * @param {boolean} savePosition Whether to save the current position or not.
 * @override
 */
talk.media.c3d.PipHandler.prototype.updatePosition = function(attrs,
    savePosition) {
  talk.media.c3d.PipHandler.superClass_.updatePosition.call(
      this, attrs, savePosition);
  if (this.feedObject) {
    if (savePosition) {
      this.resizeImages_(attrs.w, attrs.h);
    }
    if (this.isMinimized_ && savePosition) {
      // We have been resized while minimized. Update the minimized bounds and
      // also store our new width and height for when being unminimized.
      var newAttrs = new talk.media.c3d.Attrs(this.feed.getX() +
          this.feed.getWidth() - (this.maximizeImg_.width() +
              talk.media.c3d.PipHandler.PIP_BORDER_WIDTH_),
          this.feed.getY() + this.feed.getHeight() -
          (this.maximizeImg_.height() +
              talk.media.c3d.PipHandler.PIP_BORDER_WIDTH_), 0,
          this.maximizeImg_.width(),
          this.maximizeImg_.height(), 1);
      this.savedAttrs_.x = this.savedAttrs_.x + attrs.x - this.savedAttrs_.w;
      this.savedAttrs_.y = this.savedAttrs_.y + attrs.y - this.savedAttrs_.h;
      this.savedAttrs_.w = attrs.w;
      this.savedAttrs_.h = attrs.h;
      this.feedObject.setAttrs(newAttrs);
      this.feedAttrs = this.feed.getFeedAttrs();
    }
    if (this.isMinimized_) {
      this.maximizeImg_.moveImageWithEdgeWrapping(0, 0, this.feedAttrs.w,
          this.feedAttrs.h);
      this.maximizeRolloverImg_.moveImageWithEdgeWrapping(0, 0,
          this.feedAttrs.w, this.feedAttrs.h);
    } else {
      this.minimizeImg_.moveImageWithEdgeWrapping(-2, 2, this.feedAttrs.w,
          this.feedAttrs.h);
      this.minimizeRolloverImg_.moveImageWithEdgeWrapping(-2, 2,
          this.feedAttrs.w, this.feedAttrs.h);
      this.fourwayArrowImg_.moveImageWithEdgeWrapping(
          this.feedAttrs.w / 2 - this.fourwayArrowImg_.width() / 2,
          this.feedAttrs.h / 2 - this.fourwayArrowImg_.height() / 2,
          this.feedAttrs.w, this.feedAttrs.h);
    }
    this.updateUI_();
  }
};


/**
 * Updates UI for the current state.
 * @private
 */
talk.media.c3d.PipHandler.prototype.updateUI_ = function() {
  var insidePip = this.isInsidePip_(this.mouseX_, this.mouseY_);
  var showMin = insidePip && !this.isMinimized_;
  var showMax = this.isMinimized_;
  var hoverMin = false;
  var hoverMax = false;
  if (insidePip) {
    var pos = this.translateToPipPoint_([this.mouseX_, this.mouseY_, 0]);
    hoverMin = this.minimizeImg_.hitTest(pos[0], pos[1]);
    hoverMax = this.maximizeImg_.hitTest(pos[0], pos[1]);
  }
  this.setHighlighted_(insidePip);
  this.minimizeImg_.setVisible(showMin && !hoverMin);
  this.minimizeRolloverImg_.setVisible(showMin && hoverMin);
  this.maximizeImg_.setVisible(showMax && !hoverMax);
  this.maximizeRolloverImg_.setVisible(showMax && hoverMax);
};


/**
 * Adapts sizes of icons to the current size of the feed.
 *
 * @param {number} feedWidth The current width in pixels of the feed.
 * @param {number} feedHeight The current height in pixels of the feed.
 * @private
 */
talk.media.c3d.PipHandler.prototype.resizeImages_ = function(feedWidth,
    feedHeight) {
  // Decide if we need to double the size of images.
  this.resizeImage_(this.minimizeImg_);
  this.resizeImage_(this.minimizeRolloverImg_);
  this.resizeImage_(this.maximizeImg_);
  this.resizeImage_(this.maximizeRolloverImg_);
  this.resizeImage_(this.fourwayArrowImg_);
};


/**
 * Resizes the image based on the current size of the PIP.
 *
 * @param {talk.media.c3d.Image} image The image to resize.
 * @private
 */
talk.media.c3d.PipHandler.prototype.resizeImage_ = function(image) {
  var scale = this.feedAttrs.w <
      talk.media.c3d.PipHandler.RESIZE_THRESHOLD_WIDTH_ ||
      this.feedAttrs.h < talk.media.c3d.PipHandler.RESIZE_THRESHOLD_HEIGHT_ ?
      1 : 2;
  image.resize(image.textureWidth() * scale, image.textureHeight() * scale);
};


/**
 * Creates icons used for the minimize and maximize buttons.
 *
 * @param {talk.media.c3d.ImageOverlay} imageOverlay The overlay to display the
 *     images.
 * @private
 */
talk.media.c3d.PipHandler.prototype.createImages_ = function(imageOverlay) {
  this.minimizeImg_ = this.createImage_(imageOverlay, 'images/minimize.png',
      -talk.media.c3d.PipHandler.PIP_BORDER_WIDTH_,
      talk.media.c3d.PipHandler.PIP_BORDER_WIDTH_);
  this.minimizeRolloverImg_ = this.createImage_(imageOverlay,
      'images/minimize_rollover.png',
      -talk.media.c3d.PipHandler.PIP_BORDER_WIDTH_,
      talk.media.c3d.PipHandler.PIP_BORDER_WIDTH_);
  this.maximizeImg_ = this.createImage_(imageOverlay, 'images/maximize.png',
      -talk.media.c3d.PipHandler.PIP_BORDER_WIDTH_,
      -talk.media.c3d.PipHandler.PIP_BORDER_WIDTH_);
  this.maximizeRolloverImg_ = this.createImage_(imageOverlay,
      'images/maximize_rollover.png',
      -talk.media.c3d.PipHandler.PIP_BORDER_WIDTH_,
      -talk.media.c3d.PipHandler.PIP_BORDER_WIDTH_);
  this.fourwayArrowImg_ = this.createCenterImage_(imageOverlay,
      'images/fourway_arrow.png');

  // Make the image a bit transparent.
  this.fourwayArrowImg_.setAlpha(0.9);
};


/**
 * Creates an icon based on the given image URL.
 *
 * @param {talk.media.c3d.ImageOverlay} imageOverlay The overlay to display the
 *     image.
 * @param {string} url The url of the image.
 * @param {number} x The initial x coordinate for this image.
 * @param {number} y The initial y coordinate for this image.
 * @return {talk.media.c3d.Image} A new Image object.
 * @private
 */
talk.media.c3d.PipHandler.prototype.createImage_ = function(imageOverlay, url,
    x, y) {
  var image = imageOverlay.createImage(0, 0, url, goog.bind(function() {
    this.imageLoaded_(image, x, y);
  }, this));
  return image;
};


/**
 * Moves image to the given initial position. Called when an image has
 * completed loading.
 *
 * @param {talk.media.c3d.Image} image The image that loaded.
 * @param {number} x The new horizontal position.
 * @param {number} y The new vertical position.
 * @private
 */
talk.media.c3d.PipHandler.prototype.imageLoaded_ = function(image, x, y) {
  this.resizeImage_(image);
  image.moveImageWithEdgeWrapping(x, y, this.feedAttrs.w, this.feedAttrs.h);
  image.setVisible(false);
};


/**
 * Creates an image to display at the center of the pip.
 *
 * @param {talk.media.c3d.ImageOverlay} imageOverlay The overlay to display the
 *     image.
 * @param {string} url The url of the image.
 * @return {talk.media.c3d.Image} A new Image object.
 * @private
 */
talk.media.c3d.PipHandler.prototype.createCenterImage_ = function(imageOverlay,
    url) {
  var image = imageOverlay.createImage(0, 0, url, goog.bind(function() {
            this.centerImage_(image);
          }, this));
  return image;
};


/**
 * Moves image to the center of the pip.
 *
 * @param {talk.media.c3d.Image} image The image to move.
 * @private
 */
talk.media.c3d.PipHandler.prototype.centerImage_ = function(image) {
  this.resizeImage_(image);
  image.moveImageWithEdgeWrapping(this.feedAttrs.w / 2 - image.width() / 2,
                                  this.feedAttrs.h / 2 - image.height() / 2,
                                  this.feedAttrs.w, this.feedAttrs.h);
  image.setVisible(false);
};


/**
 * Toggles the minimized state for the PIP and initiates a tween to move it to
 * the new location.
 *
 * @param {boolean} minimized Whether the PIP is minimized.
 * @private
 */
talk.media.c3d.PipHandler.prototype.setMinimized_ = function(minimized) {
  this.isMinimized_ = minimized;
  this.setBorderVisible(!minimized);
  var newAttrs;
  if (minimized) {
    this.minimizeImg_.setVisible(false);
    this.minimizeRolloverImg_.setVisible(false);
    this.fourwayArrowImg_.setVisible(false);
    this.savedAttrs_ = this.feedAttrs;
    newAttrs = new talk.media.c3d.Attrs(this.feed.getX() +
        this.feed.getWidth() - (this.maximizeImg_.width() +
            talk.media.c3d.PipHandler.PIP_BORDER_WIDTH_),
        this.feed.getY() + this.feed.getHeight() -
        (this.maximizeImg_.height() +
            talk.media.c3d.PipHandler.PIP_BORDER_WIDTH_), 0,
        this.maximizeImg_.width(),
        this.maximizeImg_.height(), 1);
  } else {
    this.maximizeImg_.setVisible(false);
    this.maximizeRolloverImg_.setVisible(false);
    newAttrs = this.savedAttrs_;

    // In case we have been resized while in minimized mode we need to make
    // sure we doesn't end up outside our parent area.
    this.checkBoundaries_(newAttrs);
  }
  this.tween_ = new talk.media.c3d.AttrsTween(
      this.feedObject,
      this.feedAttrs,
      newAttrs,
      talk.media.c3d.PipHandler.MINMAX_DURATION_,
      talk.media.c3d.STRONG_EASE_IN_OUT,
      goog.bind(this.onTweenCompleted, this)
      );
  this.o3dBundle.c3dEngine.registerRenderCallback(this.tween_);
};


/**
 * Checks if this coordinate is inside the PIP.
 *
 * @param {number} x The client global x coordinate.
 * @param {number} y The client global y coordinate.
 * @return {boolean} Wether this point is inside the pip.
 * @private
 */
talk.media.c3d.PipHandler.prototype.isInsidePip_ = function(x, y) {
  return (x >= this.feedAttrs.x &&
      x <= this.feedAttrs.x + this.feedAttrs.w &&
      y >= this.feedAttrs.y && y <= this.feedAttrs.y + this.feedAttrs.h);
};


/**
 * Checks if this x position is inside the client area.
 *
 * @param {number} x The client global x coordinate.
 * @return {boolean} Whether this x position is inside the client area.
 * @private
 */
talk.media.c3d.PipHandler.prototype.clientHitTestX_ = function(x) {
  return x >= 0 && x <= this.o3dBundle.width;
};


/**
 * Checks if this y position is inside the client area.
 *
 * @param {number} y The client global y coordinate.
 * @return {boolean} Wether this y position is inside the client area.
 * @private
 */
talk.media.c3d.PipHandler.prototype.clientHitTestY_ = function(y) {
  return y >= 0 && y <= this.o3dBundle.height;
};


/**
 * Translates world vector to pip local.
 *
 * @param {Array.<number>} vector The world vector to be translated.
 * @return {Array.<number>} The translated vector.
 * @private
 */
talk.media.c3d.PipHandler.prototype.translateToPipPoint_ = function(vector) {
  var inverseMatrix = talk.media.c3d.inverse4(
      this.feedObject.getTransform()['localMatrix']);
  return talk.media.c3d.transformPoint(inverseMatrix, vector);
};


/**
 * Checks given attributes and makes sure that they are within our parent's
 * bounds. If not the check will fail and the attributes will be adjusted to
 * the closest valid bounds.
 *
 * @param {talk.media.c3d.Attrs} attrs The attributes to be checked.
 * @return {boolean} Whether the attributes are within our parent's bounds.
 * @private
 */
talk.media.c3d.PipHandler.prototype.checkBoundaries_ = function(attrs) {
  var result = true;
  if (attrs.x < 0) {
    attrs.x = 0;
    result = false;
  } else if (attrs.x + attrs.w > this.feed.getX() +
      this.feed.getWidth()) {
    attrs.x = this.feed.getWidth() - attrs.w;
    result = false;
  }
  if (attrs.y < 0) {
    attrs.y = 0;
    result = false;
  } else if (attrs.y + attrs.h > this.feed.getY() +
      this.feed.getHeight()) {
    attrs.y = this.feed.getHeight() - attrs.h;
    result = false;
  }
  return result;
};


/**
 * Updates the PIP to match the new state.
 *
 * @protected
 */
talk.media.c3d.PipHandler.prototype.onTweenCompleted = function() {
  this.tween_ = null;
  this.updatePosition(this.feed.getFeedAttrs(), false);
};


/**
 * @override
 * @protected
 */
talk.media.c3d.PipHandler.prototype.onMouseMove = function(e) {
  if (this.tween_) {
    // Just ignore mouse move if we are in a tween.
    return;
  }
  if (this.isDragging_) {
    var x = e['x'];
    var y = e['y'];
    var dx = x - this.mouseX_;
    var dy = y - this.mouseY_;
    var attrs = this.feedAttrs;

    // Simulates Flash behaviour when dragging outside the client area.
    if (this.clientHitTestX_(x)) {
      // Allow move only if inside the x range.
      attrs.x += dx;
    }
    if (this.clientHitTestY_(y)) {
      // Allow move only if inside the y range.
      attrs.y += dy;
    }
    this.mouseX_ = x;
    this.mouseY_ = y;
    this.checkBoundaries_(attrs);
    this.feedObject.setAttrs(attrs);
  } else {
    this.mouseX_ = e['x'];
    this.mouseY_ = e['y'];
    this.updateUI_();
  }
};


/**
 * @override
 * @protected
 */
talk.media.c3d.PipHandler.prototype.onMouseUp = function(e) {
  this.mouseX_ = e['x'];
  this.mouseY_ = e['y'];
  if (this.isDragging_) {
    // Finalize dragging by snapping to one of the corners.
    this.isDragging_ = false;
    this.feed.moveToCorner(this.getNearestCorner_(),
        talk.media.c3d.PipHandler.SNAP_DURATION_,
        talk.media.c3d.STRONG_EASE_OUT);
  }
  if (this.isInsidePip_(e['x'], e['y'])) {
    // Mouse released inside PIP, check if any icon was hit.
    var vec = [e['x'], e['y'], 0];
    vec = this.translateToPipPoint_(vec);
    if (this.isMinimized_) {
      if (this.maximizeImg_.hitTest(vec[0], vec[1])) {
        this.setMinimized_(false);
      }
    } else {
      if (this.minimizeImg_.hitTest(vec[0], vec[1])) {
        this.setMinimized_(true);
      }
    }
    this.changeCursor_('POINTER', 0);  // In case we were dragging.
  } else {
    this.unsetCursor_();
  }
};


/**
 * @override
 * @protected
 */
talk.media.c3d.PipHandler.prototype.onMouseDown = function(e) {
  if (!this.isMinimized_ && this.isInsidePip_(e['x'], e['y'])) {
    // Mouse pressed inside PIP, initiate dragging.
    this.isDragging_ = true;
    this.mouseX_ = e['x'];
    this.mouseY_ = e['y'];
    // Priority for the grab icon is higher than pointer, because even when over
    // other clickable things we still want to see the grab icon.
    this.changeCursor_('MOVE', 1);
  }
};


/**
 * Enables or disables highlighting of the PIP.
 *
 * @param {boolean} enabled Whether to enable highlightning.
 * @private
 */
talk.media.c3d.PipHandler.prototype.setHighlightEnabled_ = function(enabled) {
  if (this.isHighlighted_) {
    this.setHighlighted_(enabled);
  }
  this.isHighlightEnabled_ = enabled;
};


/**
 * Highlights the feed by drawing a border around it. Also shows the fourway
 * arrow and switches cursor to indicate that the PIP can be moved.
 *
 * @param {boolean} highlighted Whether to turn on or off highlighting.
 * @private
 */
talk.media.c3d.PipHandler.prototype.setHighlighted_ = function(highlighted) {
  if (!this.isHighlightEnabled_ || highlighted == this.isHighlighted_) {
    // Either highlighting is not enabled or we are already in the requested
    // state, just return.
    return;
  }
  if (highlighted) {
    this.changeCursor_('POINTER', 0);
  } else {
    this.unsetCursor_();
  }
  if (!this.isMinimized_) {
    this.fourwayArrowImg_.setVisible(highlighted);
    this.setBorderHighlighted(highlighted);
  }
  this.isHighlighted_ = highlighted;
};


/**
 * Changes our cursor style to the given one.
 *
 * @param {string} styleName New cursor style.
 * @param {number} priority Priority for this style request.
 * @private
 */
talk.media.c3d.PipHandler.prototype.changeCursor_ = function(
    styleName,
    priority) {
  if (goog.isDefAndNotNull(this.cursorRef_)) {
    this.o3dBundle.cursorManager.unsetCursor(this.cursorRef_);
  }
  this.cursorRef_ = this.o3dBundle.cursorManager.setCursor(
    styleName,
    priority);
};


/**
 * Unsets our cursor style.
 * @private
 */
talk.media.c3d.PipHandler.prototype.unsetCursor_ = function() {
  if (goog.isDefAndNotNull(this.cursorRef_)) {
    this.o3dBundle.cursorManager.unsetCursor(this.cursorRef_);
    this.cursorRef_ = null;
  }
};


/**
 * Returns the corner that is closest to the feed.
 * @return {talk.media.c3d.PipOptions.Corner}
 * @private
 */
talk.media.c3d.PipHandler.prototype.getNearestCorner_ = function() {
  var left = (this.feedAttrs.x + this.feedAttrs.w / 2 <
              this.o3dBundle.width / 2);
  var top = (this.feedAttrs.y + this.feedAttrs.h / 2 <
             this.o3dBundle.height / 2);
  if (left) {
    if (top) {
      return talk.media.c3d.PipOptions.Corner.TOP_LEFT;
    } else {
      return talk.media.c3d.PipOptions.Corner.BOTTOM_LEFT;
    }
  } else {
    if (top) {
      return talk.media.c3d.PipOptions.Corner.TOP_RIGHT;
    } else {
      return talk.media.c3d.PipOptions.Corner.BOTTOM_RIGHT;
    }
  }
};


/**
 * Removes all references to C3D objects.
 *
 * @override
 */
talk.media.c3d.PipHandler.prototype.disposeC3d = function() {
  talk.media.c3d.PipHandler.superClass_.disposeC3d.call(this);
  if (this.minimizeImg_) {
    this.minimizeImg_.disposeC3d();
    this.minimizeImg_ = null;
  }
  if (this.minimizeRolloverImg_) {
    this.minimizeRolloverImg_.disposeC3d();
    this.minimizeRolloverImg_ = null;
  }
  if (this.maximizeImg_) {
    this.maximizeImg_.disposeC3d();
    this.maximizeImg_ = null;
  }
  if (this.maximizeRolloverImg_) {
    this.maximizeRolloverImg_.disposeC3d();
    this.maximizeRolloverImg_ = null;
  }
  if (this.fourwayArrowImg_) {
    this.fourwayArrowImg_.disposeC3d();
    this.fourwayArrowImg_ = null;
  }
};
