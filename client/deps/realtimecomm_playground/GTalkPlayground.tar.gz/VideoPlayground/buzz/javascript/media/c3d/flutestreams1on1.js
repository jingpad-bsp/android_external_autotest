// Copyright 2010 Google Inc. All Rights Reserved.

/**
 * @fileoverview A handler of flute video streams for a 2-way call between a
 * local and a remote participant.
 *
 * @author geer@google.com (Arthur van der Geer)
 */

goog.provide('talk.media.c3d.FluteStreams1on1');

goog.require('talk.media.c3d.FluteStreams');


/**
 * Creates a flute stream handler for regular one on one calls.
 *
 * @param {talk.media.CallManager} callManager The manager for voice/video
 *     calls, used to communicate with flute.
 * @param {talk.media.c3d.O3dBundle} o3dBundle The shared O3D objects to use.
 * @constructor
 * @extends {talk.media.c3d.FluteStreams}
 */
talk.media.c3d.FluteStreams1on1 = function(callManager, o3dBundle) {
  talk.media.c3d.FluteStreams.call(this, callManager, o3dBundle, true);
};
goog.inherits(talk.media.c3d.FluteStreams1on1, talk.media.c3d.FluteStreams);


/**
 * @override
 */
talk.media.c3d.FluteStreams1on1.prototype.initSession =
    function(sessionId, senderJid, callType) {
  talk.media.c3d.FluteStreams1on1.superClass_.initSession.call(
      this, sessionId, senderJid, callType);

  // Add endpoint for remote participant.
  this.createStreamEndpoint('0', false);
};
