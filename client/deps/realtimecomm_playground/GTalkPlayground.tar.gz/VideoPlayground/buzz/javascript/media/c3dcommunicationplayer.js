// Copyright 2008 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview A Client3D UI object handling real time communication.
 *
 * @author tschmelcher@google.com (Tristan Schmelcher)
 */

goog.provide('talk.media.C3dCommunicationPlayer');
goog.provide('talk.media.C3dCommunicationPlayer.FatalErrorEvent');

goog.require('goog.Timer');
goog.require('goog.events');
goog.require('goog.events.EventHandler');
goog.require('goog.style');
goog.require('talk.media.C3dMuteHandler');
goog.require('talk.media.C3dNotifier');
goog.require('talk.media.CallManager');
goog.require('talk.media.CallManager.Call');
goog.require('talk.media.CallType');
goog.require('talk.media.CommunicationPlayer');  // for constants
goog.require('talk.media.PlayerOptions');
goog.require('talk.media.ViewQualityControl');
goog.require('talk.media.c3d.C3dEngine');
goog.require('talk.media.c3d.C3dEventTarget');
goog.require('talk.media.c3d.C3dObject');
goog.require('talk.media.c3d.CursorManager');
goog.require('talk.media.c3d.FluteStreams');
goog.require('talk.media.c3d.FluteStreams1on1');
goog.require('talk.media.c3d.FullscreenHandler');
goog.require('talk.media.c3d.ImageOverlay');
goog.require('talk.media.c3d.NotificationRenderer');
goog.require('talk.media.c3d.O3dBundle');
goog.require('talk.media.c3d.PipScene');
goog.require('talk.media.c3d.SpeakerStripScene');
goog.require('talk.media.c3d.StreamEndpoint');
goog.require('talk.media.c3d.View');
goog.require('talk.media.c3d.helpers');


/**
 * Creates a player that displays real time communication (voice/video calls)
 * via Client3D. Based on CommunicationPlayer and NativeCommunicationPlayer.
 *
 * <p>Ordinary browser events like 'keypress' originating from the Client3D
 * plugin can be subscribed to by listening to this player.
 *
 * @param {talk.media.CallManager} callManager The manager for voice/video
 *     calls.
 * @param {talk.media.PlayerOptions} options Options for player features.
 * @param {boolean} opt_multiView Whether to enable multiple video views.
 * @param {talk.media.C3dMuteHandler} opt_muteHandler A handler for mute
 *     indications.
 * @param {boolean} opt_enableNotifications Whether to enable notifications.
 * @constructor
 * @extends goog.events.EventTarget
 */
talk.media.C3dCommunicationPlayer = function(callManager, options,
    opt_multiView, opt_muteHandler, opt_enableNotifications) {
  goog.events.EventTarget.call(this);

  /**
   * The container for our global O3D handles that will be shared across
   * multiple classes.
   *
   * @type {talk.media.c3d.O3dBundle}
   * @private
   */
  this.o3dBundle_ = new talk.media.c3d.O3dBundle();

  this.o3dBundle_.c3dObject = new talk.media.c3d.C3dObject();
  this.o3dBundle_.c3dEngine = new talk.media.c3d.C3dEngine();
  this.o3dBundle_.cursorManager =
      new talk.media.c3d.CursorManager(this.o3dBundle_);


  /**
   * A wrapper to convert C3D events to closure events and allow ordinary
   * closure event listening.
   *
   * @type {!talk.media.c3d.C3dEventTarget}
   */
  this.c3dEventTarget_ = new talk.media.c3d.C3dEventTarget();
  this.c3dEventTarget_.setParentEventTarget(this);


  /**
   * The call manager handles communication with the server and the
   * TalkPlugin.
   *
   * @type talk.media.CallManager
   * @private
   */
  this.callManager_ = callManager;


  /**
   * The mute handler for mute state indication icons.
   *
   * @type {talk.media.C3dMuteHandler}
   * @private
   */
  this.muteHandler_ = opt_muteHandler || null;


  /**
   * The flag to enable/disable notifications in O3D..
   *
   * @type {boolean}
   * @private
   */

  this.enableNotifications_ = opt_enableNotifications || false;


  /**
   * EventHandler to simplify installing/removing event listeners.
   *
   * @type goog.events.EventHandler
   * @private
   */
  this.eventHandler_ = new goog.events.EventHandler(this);

  this.eventHandler_.listen(this.callManager_,
      talk.media.CallManager.Event.SHOW_VIDEO, this.handleShowVideo_);


  /**
   * Collection of options for player features.
   *
   * @type {talk.media.PlayerOptions}
   * @private
   */
  this.playerOptions_ = options;


  // TODO(geer): Pass an opt_scene to use.
  var scene;
  var streams;
  if (opt_multiView) {
    streams = new talk.media.c3d.FluteStreams(callManager, this.o3dBundle_,
        this.playerOptions_.getPip().getVisible());
    scene = new talk.media.c3d.SpeakerStripScene(this.o3dBundle_);
  } else {
    streams = new talk.media.c3d.FluteStreams1on1(callManager, this.o3dBundle_);
    scene = new talk.media.c3d.PipScene(this.o3dBundle_,
        this.playerOptions_.getPip());
  }
  /**
   * Our scene showing our stream endpoints.
   *
   * @type {talk.media.c3d.SceneBase}
   * @private
   */
  this.scene_ = scene;

  this.eventHandler_.listen(this.scene_,
      talk.media.c3d.SceneBase.Event.SCENE_CHANGED, this.handleSceneChanged_);


  /**
   * The controller of video stream quality based on the size of the views
   * displaying them.
   *
   * @type {talk.media.ViewQualityControl}
   * @private
   */
  this.viewQualityControl_ = new talk.media.ViewQualityControl(callManager);


  /**
   * The handler for video streams from flute.
   *
   * @type {talk.media.c3d.FluteStreams}
   * @private
   */
  this.streams_ = streams;

  this.eventHandler_.listen(this.streams_,
      talk.media.c3d.FluteStreams.Event.NEW_ENDPOINT, this.handleNewEndpoint_);
  this.eventHandler_.listen(this.streams_,
      talk.media.c3d.FluteStreams.Event.REMOVED_ENDPOINT,
      this.handleRemovedEndpoint_);


  /**
   * A goog.bind()'ed version of onResize_, suitable for using as an event
   * callback.
   *
   * @type Function
   * @private
   */
  this.boundOnResize_ = goog.bind(this.onResize_, this);


  /**
   * A goog.bind()'ed version of onMouseMove_, suitable for using as an event
   * callback.
   *
   * @type Function
   * @private
   */
  this.boundOnMouseMove_ = goog.bind(this.onMouseMove_, this);
};
goog.inherits(talk.media.C3dCommunicationPlayer, goog.events.EventTarget);


/**
 * List of events that we dispatch.
 *
 * @enum {string}
 */
talk.media.C3dCommunicationPlayer.Events = {

  /**
   * Denotes a fatal error that prevents playback.
   */
  FATAL_ERROR : 'c3dcp-error'
};


/**
 * Event class for the
 * {@code talk.media.C3dCommunicationPlayer.Events.FATAL_PLAYER_ERROR} event.
 *
 * @constructor
 * @extends {goog.events.Event}
 */
talk.media.C3dCommunicationPlayer.FatalErrorEvent = function() {
  goog.events.Event.call(this,
      talk.media.C3dCommunicationPlayer.Events.FATAL_ERROR);
};
goog.inherits(talk.media.C3dCommunicationPlayer.FatalErrorEvent,
    goog.events.Event);


/**
 * The string constant for our effect code, Cg version.
 *
 * @type {string}
 * @const
 * @private
 */
talk.media.C3dCommunicationPlayer.EFFECT_STRING_CG_ =
    // The texture sampler is used to access the texture bitmap in the
    // pixel shader.
    'sampler texSampler0;' +
    'float4x4 worldViewProj : WORLDVIEWPROJECTION;' +
    // Alpha scaling value for doing fade-in.
    'float alpha;' +
    // Input parameters for our vertex shader
    'struct a2v {' +
      'float4 pos : POSITION;' +
      'float2 tex : TEXCOORD0;' + // Texture coordinates
    '};' +
    // Input parameters for our pixel shader
    'struct v2f {' +
      'float4 pos : POSITION;' +
      'float2 tex : TEXCOORD0;' + // Texture coordinates
    '};' +
    // Our vertex shader transforms the vertices to the proper screen-relative
    // position.
    'v2f vsMain(a2v IN) {' +
      'v2f OUT;' +
      'OUT.pos = mul(IN.pos, worldViewProj);' +
      'OUT.tex = IN.tex;' +
      'return OUT;' +
    '}' +
    // Given the texture coordinates, our pixel shader grabs the corresponding
    // color from the texture, changing the brightness to the desired level.
    'float4 psMain(v2f IN) : COLOR {' +
      // The "alpha" component in the input is not for brightness, it's for
      // transparency, but we don't have that enabled so it's unused (but
      // Cg language rules still require a float4 everywhere). To change the
      // brightness, we just multiply the RGB components by our scaling factor.
      // This code actually says to multiply the fourth alpha component too, but
      // the effect compiler must be smart enough to optimize this case because
      // this is actually MORE performant than only multiplying the RGB
      // components (by about 7%, measured as fps in SwiftShader).
      'return tex2D(texSampler0, IN.tex) * alpha;' +
    '}\n' +
    '// #o3d VertexShaderEntryPoint vsMain\n' +
    '// #o3d PixelShaderEntryPoint psMain\n' +
    '// #o3d MatrixLoadOrder RowMajor\n';

/**
 * The string constant for our effect code, GLSL version.
 *
 * @type {string}
 * @const
 * @private
 */
talk.media.C3dCommunicationPlayer.EFFECT_STRING_GLSL_ =
    'uniform mat4 worldViewProjection;\n' +
    // Input parameters for our vertex shader
    'attribute vec4 position;\n' +
    'attribute vec2 texcoords0;\n' +
    // Interpolant
    'varying vec2 uvs;\n' +
    // Our vertex shader transforms the vertices to the proper screen-relative
    // position.
    'void main() {\n' +
    '  gl_Position = worldViewProjection * position;\n' +
    '  uvs = texcoords0;\n' +
    '}\n' +
    '// #o3d SplitMarker\n' +
    '// #o3d MatrixLoadOrder RowMajor\n' +
    // The texture sampler is used to access the texture bitmap in the
    // pixel shader.
    'uniform sampler2D texSampler0;\n' +
    // Alpha scaling value for doing fade-in.
    'uniform float alpha;\n' +
    // Interpolant
    'varying vec2 uvs;\n' +
    // Given the texture coordinates, our pixel shader grabs the corresponding
    // color from the texture, changing the brightness to the desired level.
    'void main() {\n' +
      // The "alpha" component in the input is not for brightness, it's for
      // transparency, but we don't have that enabled so it's unused (but
      // GLSL language rules still require a float4 everywhere). To change the
      // brightness, we just multiply the RGB components by our scaling factor.
    '  gl_FragColor = texture2D(texSampler0, uvs) * alpha;\n' +
    '}\n';


/**
 * The amount of time (in ms) to wait before retrying the initialize step of
 * player creation. We continue to retry until MAX_INITIALIZE_WAIT_.
 *
 * @type {number}
 * @const
 * @private
 */
talk.media.C3dCommunicationPlayer.RETRY_INITIALIZE_WAIT_ = 2 * 1000;


/**
 * The maximum amount of time in total(in ms) to wait for O3D to
 * initialize.
 *
 * @type {number}
 * @const
 * @private
 */
talk.media.C3dCommunicationPlayer.MAX_INITIALIZE_WAIT_ = 20 * 1000;


/**
 * The time to show the controls on mousemove.
 *
 * @type {number}
 * @const
 * @private
 */
talk.media.C3dCommunicationPlayer.SHOW_CONTROLS_ON_MOUSEMOVE_MS_ = 2.5 * 1000;


/**
 * Our logger.
 *
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.logger_ =
    goog.debug.Logger.getLogger('talk.media.C3dCommunicationPlayer');


/**
 * Count of the number of errors we've gotten from O3D.
 *
 * @type number
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.errorCount_ = 0;


/**
 * The JID we're calling.
 *
 * @type string
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.senderJid_;


/**
 * The ID of the call being displayed.
 *
 * @type string
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.sessionId_;


/**
 * The type of call we're displaying.
 *
 * @type talk.media.CallType
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.callType_;


/**
 * Transparent view for overlaying icons on top of video contents.
 *
 * @type {talk.media.c3d.View}
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.transparencyView_;


/**
 * A handler of O3D fullscreen mode and UI widgets to switch mode.
 *
 * @type {talk.media.c3d.FullscreenHandler}
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.fullscreenHandler_;


/**
 * The ID of the timer that hides the controls and the cursor on timeout.
 *
 * @type {?number}
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.hideTimerId_;


/**
 * The C3D render graph to draw transparent 2d images.
 *
 * @type {talk.media.c3d.ImageOverlay}
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.imageOverlay_;


/**
 * The C3D notifier to handle notifications.
 *
 * @type {talk.media.C3dNotifier}
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.notifier_;


/**
 * The amount of time the player has been waiting to initialize.
 *
 * @type {number}
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.initializeWait_ = 0;


/**
 * The Element to contain the video pane.
 *
 * @type {string|Element}
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.container_;


/**
 * Reference to the client's horizontal cursor position.
 *
 * @type {number}
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.lastMouseX_ = 0;


/**
 * Reference to the client's vertical cursor position.
 *
 * @type {number}
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.lastMouseY_ = 0;


/**
 * Returns whether or not this call is in the accepted state or not.
 *
 * @return {boolean}
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.isAccepted_ = function() {
  return goog.isDefAndNotNull(this.callManager_) &&
      goog.isDefAndNotNull(this.callManager_.getActiveCall()) &&
      this.callManager_.getActiveCall().state ==
      talk.media.CallManager.Call.State.ACTIVE_CALL;
};


/**
 * Updates C3D's perspective matrix to match the dimensions of its window pane.
 *
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.updatePerspective_ =
    function() {
  if (!this.o3dBundle_.view || !this.o3dBundle_.drawContext) {
    return;
  }
  // Set up our orthographic projection matrix. This selects the dimensions of
  // the rectangular prism of 3D space to render (which renders with no 3D
  // perspective--i.e., as if we're infinitely far away and with infinite zoom).
  // It needs to have the same aspect ratio as the Client3D pane or else the
  // scene will get stretched when drawn to the screen.
  var client = this.o3dBundle_.c3dObject.getPlugin()['client'];
  // Save width and height for fast lookups when laying-out feeds.
  this.o3dBundle_.width = client['width'];
  this.o3dBundle_.height = client['height'];
  // Reset the projection to match client area. Origin is at the top-left.

  this.o3dBundle_.drawContext['projection'] =
      talk.media.c3d.createOrthographicMatrix(0 + 0.5,
          this.o3dBundle_.width + 0.5,
          this.o3dBundle_.height + 0.5,
          0 + 0.5,
          0.001,
          1000);

  this.scene_.setArea(0, 0, this.o3dBundle_.width, this.o3dBundle_.height);
};


/**
 * Initializes our scene in C3D.
 *
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.initPlayer_ = function() {
  var success = false;
  try {
    var initialErrorCount = this.errorCount_;

    var c3d = this.o3dBundle_.c3dObject.getPlugin();

    if (!c3d) {
      // Plugin was removed from DOM before we had a chance to initialize it.
      // This is odd, so log it.
      this.logger_.warning('O3D missing from DOM during initPlayer_');
      return;
    }

    if (!this.o3dBundle_.c3dObject.isScriptable() ||
        (c3d['client']['rendererInitStatus'] ==
            c3d['o3d']['Renderer']['UNINITIALIZED'])) {
      // Plugin hasn't loaded yet.
      if (this.initializeWait_ <
          talk.media.C3dCommunicationPlayer.MAX_INITIALIZE_WAIT_) {

        // Wait and retry.
        goog.Timer.callOnce(this.initPlayer_,
            talk.media.C3dCommunicationPlayer.RETRY_INITIALIZE_WAIT_, this);
        this.initializeWait_ +=
            talk.media.C3dCommunicationPlayer.RETRY_INITIALIZE_WAIT_;

        this.logger_.info('O3D not loaded yet, retrying in ' +
            talk.media.C3dCommunicationPlayer.RETRY_INITIALIZE_WAIT_ + ' ms');
        return;
      } else {
        // We will catch this below and unload the player.
        throw new Error('Hit max retries for initializing O3D, quitting.');
      }
    }

    c3d['client']['setErrorCallback'](goog.bind(this.handleC3dError_, this));

    this.o3dBundle_.c3dEngine.setC3d(this.o3dBundle_.c3dObject);
    this.c3dEventTarget_.setC3d(this.o3dBundle_.c3dObject);

    // Add resize handler to re-position everything upon resize.
    talk.media.c3d.addEventCallback(c3d, 'resize', this.boundOnResize_);

    // Add mousemove handler to handle idle state.
    talk.media.c3d.addEventCallback(c3d, 'mousemove', this.boundOnMouseMove_);

    // Create a pack to manage our resources/assets
    this.o3dBundle_.pack = c3d['client']['createPack']();

    // Set up a global draw context which will be used by all views.
    this.o3dBundle_.drawContext = this.o3dBundle_.pack['createObject'](
        'DrawContext');
    this.o3dBundle_.drawContext['view'] = talk.media.c3d.createLookAtMatrix(
        [0, 0, 50],  // eye
        [0, 0, 0],  // target
        [0, 1, 0]);  // up

    var priority = 0;

    // Setup our render graph.
    this.o3dBundle_.view = new talk.media.c3d.View(c3d, this.o3dBundle_.pack,
        priority, false, this.o3dBundle_);

    // Again for transparent objects.
    this.transparencyView_ =
        new talk.media.c3d.View(c3d, this.o3dBundle_.pack, priority++, true,
            this.o3dBundle_);

    // Create the effect to use for 3D objects.
    this.o3dBundle_.effect = this.o3dBundle_.pack['createObject']('Effect');
    var effectString;
    if (c3d['client']['clientInfo']['glsl']) {
      // o3d expects GLSL shaders.
      effectString = talk.media.C3dCommunicationPlayer.EFFECT_STRING_GLSL_;
    } else {
      // o3d expects Cg shaders.
      effectString = talk.media.C3dCommunicationPlayer.EFFECT_STRING_CG_;
    }
    this.o3dBundle_.effect['loadFromFXString'](effectString);

    this.streams_.initSession(this.sessionId_, this.senderJid_, this.callType_);

    // Set up the dimensions of our camera's frustum.
    this.updatePerspective_();

    // Add a 2d view on top for images like full screen button.
    this.imageOverlay_ = new talk.media.c3d.ImageOverlay(
        this.o3dBundle_,
        this.transparencyView_);

    if (this.enableNotifications_) {
      var notifRenderer = new talk.media.c3d.NotificationRenderer(
          this.o3dBundle_.pack,
          this.o3dBundle_.c3dObject.getPlugin(),
          this.o3dBundle_.c3dObject.getWidth(),
          50);
      this.notifier_ = new talk.media.C3dNotifier(this.callManager_,
          this.o3dBundle_.pack, this.o3dBundle_.c3dEngine,
          this.o3dBundle_.c3dObject, this.imageOverlay_, notifRenderer);
    }

    if (this.callType_ == talk.media.CallType.VIDEO && this.isAccepted_()) {
      this.setCallAccepted_();
    }

    if (this.errorCount_ == initialErrorCount) {
      // No errors during initialization.
      success = true;
    }
  } catch (e) {
    this.callManager_.addToLog('Exception during O3D initialization',
        talk.media.CallManager.LogCommentSeverity.ERROR, e);
  }
  if (!success) {
    // Either there was an error callback or an exception. In either case,
    // fallback to Flash for safety (since it could be that O3D is unusable on
    // this machine for some reason).
    this.dispatchEvent(new talk.media.C3dCommunicationPlayer.FatalErrorEvent());
  }
};


/**
 * Handles changes to microphone mute state of the active call.
 *
 * @param {talk.media.CallManager.MicMuteEvent} e The event.
 */
talk.media.C3dCommunicationPlayer.prototype.handleMicMuteNotification =
    function(e) {
  if (this.muteHandler_) {
    this.muteHandler_.handleMicMuteNotification(e);
  }

  if (this.notifier_) {
    if (e.muted) {
      this.callManager_.addToLog('Mic Mute show');
      this.notifier_.showNotification(this.micMuteNotification_);
    } else {
      this.callManager_.addToLog('Mic Unmute show');
      this.notifier_.showNotification(this.micUnmuteNotification_);
    }
  }
};


/**
 * Handles a resize event of the o3d client.
 *
 * @param {Object} e The event.
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.onResize_ = function(e) {
  this.updatePerspective_();

  // Invalidate last known position.
  this.lastMouseX_ = 0;
  this.lastMouseY_ = 0;
  this.showControls_();
};


/**
 * Handles a mousemove event of the o3d client.
 *
 * @param {Object} e The event.
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.onMouseMove_ = function(e) {
  this.lastMouseX_ = e['x'];
  this.lastMouseY_ = e['y'];
  this.showControls_();
};


/**
 * Handles logging of errors from Client3D.
 *
 * @param {string} msg The error message.
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.handleC3dError_ = function(msg) {
  if (msg.substring(0, 16) == 'Texture with id ' &&
      msg.substring(msg.length - 10) == ' not found') {
    // This error is benign. It occurs after we delete a texture and before
    // flute has stopped updating it.
    // TODO(tschmelcher): Find a way to make this error not happen in the first
    // place.
    return;
  }
  // Anything else is a real error though.
  ++this.errorCount_;
  this.callManager_.addToLog('Error from O3D: ' + msg,
      talk.media.CallManager.LogCommentSeverity.ERROR);
};


/**
 * Initializes the mute handler with the C3D objects.
 *
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.initMuteHandler_ = function() {
  if (this.muteHandler_) {
    this.muteHandler_.init(this.callManager_, this.o3dBundle_.c3dEngine,
        this.o3dBundle_.c3dObject, this.imageOverlay_);
  }
};


/**
 * Initializes the notifier with the C3D objects and adds notifications.
 *
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.initNotifier_ = function() {
  if (this.notifier_) {

    this.micMuteNotification_ = this.notifier_.addNotification(
        'images/mic_fullscreen_muted.png',
        'Your mic is now Off!');

    this.micUnmuteNotification_ = this.notifier_.addNotification(
        'images/mic_fullscreen.png',
        'Your mic is now On!');
  }
};


/**
 * Handles messages from the server, flute, or Gmail actions.
 *
 * @param {string} msg the kind of message to send to the player.
 * @param {Array|string} args the arguments to be sent with the message.
 */
talk.media.C3dCommunicationPlayer.prototype.sendToPlayer =
    function(msg, args) {
  var argsArray = args;
  if (typeof args == 'string') {
    argsArray = goog.json.parse(args);
  }
  switch (msg) {
    case talk.media.CommunicationPlayer.SendMsg.UI_COMMAND:
      if (argsArray[0] == 'a') {
        // TODO(tschmelcher): Refactor callmanager to do this.
        var message = ['ja', this.senderJid_, this.sessionId_];
        this.callManager_.sendJingleMsg(message);
        this.callManager_.sendFluteMsg(goog.json.serialize(message));
        if (this.callType_ == talk.media.CallType.VIDEO) {
          this.setCallAccepted_();
        }
      }
      break;
    case talk.media.CommunicationPlayer.SendMsg.JINGLE:
      if (argsArray[0] == 'ja') {
        if (this.callType_ == talk.media.CallType.VIDEO) {
          this.setCallAccepted_();
        }
      }
      break;
    case talk.media.CommunicationPlayer.SendMsg.PLUGIN_DATA:
      // Listening for TalkPlugin messages here and not directly to events
      // through callmanager because if in a tearoff client, these messages are
      // passed to the player directly through a proxy.
      this.streams_.handleTalkPluginMessage(/** @type {Array} */ (argsArray));
      break;
    default:
      this.logger_.warning('sendToPlayer(): unhandled message type: ' + msg);
  }
};


/**
 * Shows the avatar for a given jid.
 *
 * @param {string} jid The jid whose avatar to show.
 */
talk.media.C3dCommunicationPlayer.prototype.showAvatar = function(jid) {
  // TODO(geer): Find out if this is still needed for n:n audio calls.
  this.streams_.showAvatar(jid);
};


/**
 * Handles a request to show a video stream.
 *
 * @param {talk.media.CallManager.ShowVideoEvent} e The event.
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.handleShowVideo_ = function(e) {
  // TODO(geer): Change listening to SPEAKER_CHANGED event.
  if (e.sessionId == this.sessionId_) {
    this.scene_.setCurrentSpeaker(e.ssrc);
  }
};


/**
 * Handles a new endpoint by adding it to the scene.
 *
 * @param {talk.media.c3d.FluteStreams.NewEndpointEvent} e The event.
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.handleNewEndpoint_ = function(e) {
  if (!this.scene_.hasFeed(e.endpoint.getStreamId())) {
    this.scene_.addFeed(e.endpoint);
  }
};


/**
 * Handles a removed endpoint by removing it from the scene.
 *
 * @param {talk.media.c3d.FluteStreams.RemovedEndpointEvent} e The event.
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.handleRemovedEndpoint_ =
    function(e) {
  if (this.scene_.hasFeed(e.endpoint.getStreamId())) {
    this.scene_.removeFeed(e.endpoint.getStreamId());
  }
};


/**
 * Removes the C3D player (if present). This is public for historical reasons
 * only.
 */
talk.media.C3dCommunicationPlayer.prototype.removePlayer = function() {
  this.o3dBundle_.c3dEngine.unregisterAllRenderCallbacks();
  this.o3dBundle_.c3dEngine.setC3d(null);
  this.c3dEventTarget_.setC3d(null);
  this.streams_.disposeSession();
  this.scene_.disposeAllFeeds();
  if (this.fullscreenHandler_) {
    this.fullscreenHandler_.dispose();
    this.fullscreenHandler_ = null;
  }
  if (this.imageOverlay_) {
    this.imageOverlay_.dispose();
  }
  this.imageOverlay_ = null;
  if (this.muteHandler_) {
    this.muteHandler_.disposeC3d();
  }
  if (this.notifier_) {
    this.notifier_.disposeC3d();
  }
  this.o3dBundle_.pack = null;
  this.o3dBundle_.view = null;
  this.o3dBundle_.effect = null;
  this.transparencyView_ = null;
  // Might not be during shutdown.
  if (this.o3dBundle_.c3dObject.isScriptable()) {
    var c3d = this.o3dBundle_.c3dObject.getPlugin();
    talk.media.c3d.removeEventCallback(c3d, 'resize', this.boundOnResize_);
    talk.media.c3d.removeEventCallback(c3d, 'mousemove',
                                       this.boundOnMouseMove_);
    c3d['client']['clearErrorCallback']();
  }
  this.o3dBundle_.c3dObject.removeHTML();
};


/**
 * Creates the C3D player (must not already be present).
 *
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.createPlayer_ = function() {
  this.o3dBundle_.c3dObject.writeHTML(this.container_);
  // All other set-up work must be deferred because the plugin loads
  // asynchronously.
  goog.Timer.callOnce(this.initPlayer_, 0, this);
};


/**
 * Begins displaying the call with the given parameters.
 *
 * @param {string} sessionId The id of the call session.
 * @param {Array.<Array>} participants The users in the call.
 * @param {talk.media.CallType} callType The type of call.
 * @param {boolean} isMultiUser Whether the call is a MUC call.
 */
talk.media.C3dCommunicationPlayer.prototype.displayCall_ = function(
    sessionId, participants, callType, isMultiUser) {
  this.updateParticipants(participants);
  this.senderJid_ = participants[1][0];
  this.sessionId_ = sessionId;
  this.callType_ = callType;
  this.removePlayer();
  if (this.callType_ != talk.media.CallType.VIDEO &&
      this.callType_ != talk.media.CallType.TEST) {
    // Voice calls only have a player UI if they are multi-user calls.
    if (isMultiUser) {
      this.createPlayer_();
    }
  } else {
    this.createPlayer_();
  }
};


/**
 * Handles a new call.
 *
 * @param {boolean} isOutgoing If the call is placed by the local user or not.
 * @param {string} sessionId The id of the call session.
 * @param {Array.<Array>} participants The users in the call. Index 0
 *     is the local user.  User array elements are [{string} JID,
 *     {boolean} isLocal, {string} avatarUrl].
 * @param {talk.media.CallType} callType The type of call.
 * @param {boolean} isMultiUser Whether the call is a MUC call.
 */
talk.media.C3dCommunicationPlayer.prototype.onNewCall = function(isOutgoing,
    sessionId, participants, callType, isMultiUser) {
  // Copied from NativeCommunicationPlayer
  if (isOutgoing) {
    // For historical reasons, we have to send the 'jn' for outgoing calls.
    // Further, we can't safely send it right away because CallManager was
    // designed for the Flash version and assumes that there is a delay.
    // TODO(tschmelcher): Refactor callmanager to send the initiate.
    if (this.callType_ != talk.media.CallType.TEST) {
      goog.Timer.callOnce(this.sendInitiate_, 0, this);
    } else {
      // Test calls are an exception. CallManager is not involved and the jn
      // _must_ be sent immediately or else the micon will arrive first and be
      // ignored.
      this.sendInitiate_();
    }
  }

  this.displayCall_(sessionId, participants, callType, isMultiUser);
};


/**
 * Sends a jingle initiate.
 *
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.sendInitiate_ = function() {
  // Send a Jingle initiate to both the server and the plugin.
  var typeString;
  switch (this.callType_) {
    case talk.media.CallType.TEST:
      typeString = 't';
      break;
    case talk.media.CallType.VIDEO:
      typeString = 'v';
      break;
    default:
      typeString = 'a';
      break;
  }
  var message = ['jn', this.senderJid_, this.sessionId_, typeString];
  if (this.callType_ != talk.media.CallType.TEST) {
    this.callManager_.sendJingleMsg(message);
  }
  // We are the initiator, append 's'.
  message.push('s');
  this.callManager_.sendFluteMsg(goog.json.serialize(message));
};


/**
 * Begins displaying the already active call.
 *
 * @param {Array.<Array>} participants The users in the active call.
 * @param {boolean} isMultiUser Whether the call is a MUC call.
 */
talk.media.C3dCommunicationPlayer.prototype.displayActiveCall = function(
    participants, isMultiUser) {
  var activeCall = this.callManager_.getActiveCall();
  if (!activeCall) {
    this.logger_.warning('displayActiveCall called with no active call');
    return;
  }

  this.displayCall_(activeCall.sessionId, participants, activeCall.type,
      isMultiUser);
};


/**
 * Handles a jingle signaling or talk plugin message.
 *
 * @param {string} type The kind of msg.
 * @param {string} message The json message to handle.
 */
talk.media.C3dCommunicationPlayer.prototype.relayCallMessage = function(
    type, message) {
  this.sendToPlayer(type, message);
};


/**
 * Updates the list of participants.
 *
 * @param {Array.<Array>} participants The list of participants in the call.
 *     Index 0 is the local user.  User array elements are [{string} JID,
 *     {boolean} isLocal, {string} avatarUrl].
 */
talk.media.C3dCommunicationPlayer.prototype.updateParticipants = function(
    participants) {
  this.logger_.info('updateParticipants : ' + participants);
  this.streams_.updateParticipants(participants);
};


/**
 * Sets the container.
 * @param {string|Element} container The Element to contain the video pane.
 */
talk.media.C3dCommunicationPlayer.prototype.setContainer = function(container) {
  this.container_ = container;
};


/**
 * Shows the controls.
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.showControls_ = function() {
  this.clearHideTimer_();
  if (this.fullscreenHandler_) {
    this.fullscreenHandler_.showControl();
  }
  if (this.playerOptions_.getAutoHideControls()) {
    this.hideTimerId_ = goog.Timer.callOnce(this.hideControls_,
        talk.media.C3dCommunicationPlayer.SHOW_CONTROLS_ON_MOUSEMOVE_MS_, this);
  }
};


/**
 * Hides the controls.
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.hideControls_ = function() {
  this.clearHideTimer_();
  if (this.fullscreenHandler_) {
    // Don't hide any controls if mouse is idling over a control.
    if (!this.fullscreenHandler_.isOverControl(this.lastMouseX_,
        this.lastMouseY_)) {
      this.fullscreenHandler_.hideControl();
    }
  }
};


/**
 * Clears the timer for hiding the controls.
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.clearHideTimer_ = function() {
  if (this.hideTimerId_) {
    goog.Timer.clear(this.hideTimerId_);
    this.hideTimerId_ = null;
  }
};


/**
 * Prepare the UI that remote streams can start coming in now that the call has
 * been established.
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.setCallAccepted_ = function() {
  // Start streams that have not yet started.
  this.streams_.requestAll();

  if (this.playerOptions_.getIncludeFullscreen()) {
    this.fullscreenHandler_ = new talk.media.c3d.FullscreenHandler(
        this.o3dBundle_, this.imageOverlay_, this.playerOptions_.getLocale());
    this.fullscreenHandler_.init();
  }
  this.initMuteHandler_();
  this.initNotifier_();
  this.showControls_();
};


/**
 * Handles a change in the scene by passing the new view sizes to the object
 * controlling the quality of the viewed streams.
 *
 * @param {talk.media.c3d.SceneBase.SceneChangedEvent} e The event with the
 *     view sizes.
 * @private
 */
talk.media.C3dCommunicationPlayer.prototype.handleSceneChanged_ = function(e) {
  this.viewQualityControl_.adjustQualityForViews(e.views);
};


/**
 * @override
 * @protected
 */
talk.media.C3dCommunicationPlayer.prototype.disposeInternal = function() {
  this.dispatchEvent(talk.media.CommunicationPlayer.Events.DISPOSED);
  talk.media.C3dCommunicationPlayer.superClass_.disposeInternal.call(this);
  this.clearHideTimer_();
  this.removePlayer();
  if (this.muteHandler_) {
    this.muteHandler_.dispose();
  }
  this.eventHandler_.dispose();
  this.eventHandler_ = null;
  this.callManager_ = null;
  this.c3dEventTarget_.dispose();
  this.viewQualityControl_.dispose();
  this.viewQualityControl_ = null;
  this.scene_.dispose();
  this.scene_ = null;
  this.streams_.dispose();
  this.streams_ = null;
};
