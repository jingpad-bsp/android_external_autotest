// Copyright 2009 Google Inc. All Rights Reserved.

/**
 * @fileoverview A basic render graph setup.
 * See also o3djs.rendergraph.ViewInfo in o3djs/rendergraph.js.
 *
 * @author geer@google.com (Arthur van der Geer)
 */

goog.provide('talk.media.c3d.View');


/**
 * Creates a basic render graph setup to draw opaque and transparent objects.
 *
 * @param {Object} c3d The C3D Plugin instance.
 * @param {Object} pack The C3D Pack object to use.
 * @param {number} priority The base priority for created objects.
 * @param {boolean} transparent Use a transparent clear buffer or not.
 * @param {talk.media.c3d.O3dBundle} o3dBundle The bundle of global resources
 *     for this O3D instance.
 * @param {Object} opt_parentTransform Parent transform to this view. If not
 *     set the client's root transform is used.
 * @constructor
 */
talk.media.c3d.View = function(c3d, pack, priority, transparent, o3dBundle,
    opt_parentTransform) {
  // Create a root transform to help administering.
  this.transform = pack['createObject']('Transform');
  if (opt_parentTransform) {
    this.transform['parent'] = opt_parentTransform;
  }

  // Create Viewport.
  this.viewport_ = pack['createObject']('Viewport');
  this.viewport_['priority'] = priority;
  this.viewport_['parent'] = c3d['client']['renderGraphRoot'];

  // Create a ClearBuffer.
  this.clearBuffer_ = pack['createObject']('ClearBuffer');
  if (transparent) {
    // Create a clear buffer with clearing the color turned off since that would
    // erase the rendered (3d) parts.
    this.clearBuffer_['clearColor'] = [0.5, 0.5, 0.5, 1.0];
    this.clearBuffer_['clearColorFlag'] = false;
  } else {
    this.clearBuffer_['clearColor'] = [0.0, 0.0, 0.0, 0.0];
  }
  this.clearBuffer_['priority'] = priority++;
  this.clearBuffer_['parent'] = this.viewport_;

  // Create DrawList.
  this.drawList = pack['createObject']('DrawList');

  // Create TreeTraversal and parent it to the root.
  this.treeTraversal_ = pack['createObject']('TreeTraversal');
  this.treeTraversal_['priority'] = priority++;
  this.treeTraversal_['parent'] = this.viewport_;

  // Create a StateSet.
  this.stateSet_ = pack['createObject']('StateSet');
  this.stateSet_['priority'] = priority++;
  this.stateSet_['parent'] = this.viewport_;
  if (transparent) {
    // Create a State so everything on the zOrderedDrawPass below is assumed
    // to need alpha blending with the typical settings.
    this.state_ = pack['createObject']('State');
    this.stateSet_['state'] = this.state_;
    this.state_['getStateParam']('AlphaBlendEnable')['value'] = true;
    this.state_['getStateParam']('SourceBlendFunction')['value'] =
        c3d['o3d']['State']['BLENDFUNC_SOURCE_ALPHA'];
    this.state_['getStateParam']('DestinationBlendFunction')['value'] =
        c3d['o3d']['State']['BLENDFUNC_INVERSE_SOURCE_ALPHA'];
    this.state_['getStateParam']('AlphaTestEnable')['value'] = true;
    this.state_['getStateParam']('AlphaComparisonFunction')['value'] =
        c3d['o3d']['State']['CMP_GREATER'];
    this.state_['getStateParam']('ColorWriteEnable')['value'] = 7;
    this.state_['getStateParam']('ZWriteEnable')['value'] = false;
  }

  // Create a DrawPass.
  this.drawPass_ = pack['createObject']('DrawPass');
  this.drawPass_['drawList'] = this.drawList;
  this.drawPass_['parent'] = this.stateSet_;
  if (transparent) {
    // Use zOrdered shapes.
    this.drawPass_['sortMethod'] = c3d['o3d']['DrawList']['BY_Z_ORDER'];
  }

  // Register the DrawPass and DrawContext with the TreeTraversal.
  this.treeTraversal_['registerDrawList'](this.drawList, o3dBundle.drawContext,
      true);
  this.treeTraversal_['transform'] = this.transform;
};


/**
 * The C3D ClearBuffer object.
 *
 * @type {Object}
 * @private
 */
talk.media.c3d.View.prototype.clearBuffer_;


/**
 * The C3D DrawList.
 *
 * @type Object
 */
talk.media.c3d.View.prototype.drawList;


/**
 * The C3D DrawPass.
 *
 * @type Object
 * @private
 */
talk.media.c3d.View.prototype.drawPass_;


/**
 * The C3D State.
 *
 * @type Object
 * @private
 */
talk.media.c3d.View.prototype.state_;


/**
 * The C3D StateSet.
 *
 * @type Object
 * @private
 */
talk.media.c3d.View.prototype.stateSet_;


/**
 * The C3D Transform object.
 *
 * @type Object
 */
talk.media.c3d.View.prototype.transform;


/**
 * The C3D TreeTraversal object.
 *
 * @type Object
 * @private
 */
talk.media.c3d.View.prototype.treeTraversal_;


/**
 * The C3D Viewport object.
 *
 * @type Object
 * @private
 */
talk.media.c3d.View.prototype.viewport_;
