// Copyright 2009 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview A C3D endpoint to which we can render a stream in flute and
 * from which we can create a visual feed object in C3D.
 *
 * @author tschmelcher@google.com (Tristan Schmelcher)
 */

goog.provide('talk.media.c3d.StreamEndpoint');
goog.provide('talk.media.c3d.StreamEndpoint.AspectChangedEvent');
goog.provide('talk.media.c3d.StreamEndpoint.AvatarEvent');
goog.provide('talk.media.c3d.StreamEndpoint.SendStreamOffEvent');
goog.provide('talk.media.c3d.StreamEndpoint.SendStreamOnEvent');
goog.provide('talk.media.c3d.StreamEndpoint.TextureActivatedEvent');

goog.require('goog.debug.Logger');
goog.require('goog.events.Event');
goog.require('goog.events.EventTarget');
goog.require('goog.Timer');
goog.require('talk.media.c3d.helpers');


/**
 * A C3D endpoint to which we can render a stream in flute and from which we can
 * create a visual feed object in C3D.
 *
 * @param {?string} ssrc The SSRC id of the stream, null for local.
 * @param {string} jid The jid that this endpoint is representing.
 * @param {string} avatarUrl The URL of the avatar image.
 * @param {Object} material The C3D Material object.
 * @param {Object} texBuffer The C3D VertexBuffer object for the texture
 * coordinates.
 * @param {Object} texCoordField The C3D Field object pointing to the data in
 * the texBuffer.
 * @param {Object} texSampler The C3D Sampler object that connects to the
 * texture.
 * @param {boolean} mirror Whether or not to mirror the stream when displaying.
 * @param {Object} pack The C3D Pack object that this communication player is
 * using.
 * @param {talk.media.c3d.C3dObject} c3dObject The C3D plugin instance that this
 * communication player is using.
 * @constructor
 * @extends {goog.events.EventTarget}
 */
talk.media.c3d.StreamEndpoint = function(ssrc, jid, avatarUrl, material,
    texBuffer, texCoordField, texSampler, mirror, pack, c3dObject) {
  goog.events.EventTarget.call(this);

  /**
   * The SSRC of the stream, or null for local stream.
   *
   * @type {?string}
   * @private
   */
  this.ssrc_ = ssrc;


  /**
   * The jid that this endpoint is representing.
   *
   * @type {string}
   * @private
   */
  this.jid_ = jid;


  /**
   * The URL of the avatar image.
   *
   * @type {string}
   * @private
   */
  this.avatarUrl_ = avatarUrl;
  // TODO(geer): Add a Participant object for attributes like jid and avatarUrl.


  /**
   * The C3D Material object.
   *
   * @type Object
   * @const
   */
  this.material = material;


  /**
   * The C3D Field object pointing to the data in the texBuffer.
   *
   * @type Object
   * @const
   */
  this.texCoordField = texCoordField;


  /**
   * The C3D VertexBuffer object for the texture coordinates.
   *
   * @type Object
   * @private
   * @const
   */
  this.texBuffer_ = texBuffer;


  /**
   * The C3D Sampler object that connects to the currently active texture.
   *
   * @type Object
   * @private
   * @const
   */
  this.texSampler_ = texSampler;


  /**
   * Whether or not to mirror the stream when displaying.
   *
   * @type boolean
   * @private
   * @const
   */
  this.mirror_ = mirror;


  /**
   * The C3D Pack object that this communication player is using.
   *
   * @type Object
   * @private
   * @const
   */
  this.pack_ = pack;


  /**
   * The C3D plugin instance that this communication player is using.
   *
   * @type talk.media.c3d.C3dObject
   * @private
   * @const
   */
  this.c3dObject_ = c3dObject;


  /**
   * List of all textures that we currently care about. This
   * list includes both the currently active texture and also any pending
   * requests that we are waiting to get a streamready for. The elements are
   * talk.media.c3d.StreamEndpoint.Mapping_ objects.
   *
   * @type Array
   * @private
   * @const
   */
  this.mappings_ = [];
};
goog.inherits(talk.media.c3d.StreamEndpoint,
    goog.events.EventTarget);


/**
 * The initial width for dynamic video textures when the width of the stream
 * isn't known.
 *
 * @type {number}
 * @const
 * @private
 */
talk.media.c3d.StreamEndpoint.DEFAULT_TEXTURE_WIDTH_ = 1024;


/**
 * The initial height for dynamic video textures when the height of the stream
 * isn't known.
 *
 * @type {number}
 * @const
 * @private
 */
talk.media.c3d.StreamEndpoint.DEFAULT_TEXTURE_HEIGHT_ = 512;


/**
 * The amount of time to wait after a resolution decrease before resizing the
 * texture to match, in milliseconds.
 *
 * @type {number}
 * @const
 * @private
 */
talk.media.c3d.StreamEndpoint.RESIZE_TIMEOUT_ = 5000;


/**
 * Events fired by StreamEndpoint objects.
 *
 * @enum {string}
 */
talk.media.c3d.StreamEndpoint.Events = {
  /**
   * Event indicating that a 'streamon' message should be sent to flute.
   */
  SEND_STREAM_ON : 'on',

  /**
   * Event indicating that a 'streamoff' message should be sent to flute.
   */
  SEND_STREAM_OFF : 'off',

  /**
   * Event indicating that the aspect ratio of this stream has changed.
   */
  ASPECT_CHANGED : 'aspect',

  /**
   * Event indicating that value of isAvatar() has changed.
   */
  AVATAR : 'avatar',

  /**
   * Event indicating that rendering started on the stream's texture.
   */
  TEXTURE_ACTIVATED : 'ta'
};


/**
 * Event indicating that a 'streamon' message should be sent to flute.
 *
 * @param {talk.media.c3d.StreamEndpoint} endpoint The
 * endpoint generating this event.
 * @param {number} textureId The ID of the texture.
 * @param {?string} stream The SSRC of the stream, or null for local stream.
 * @param {number} textureWidth The width of the texture.
 * @param {number} textureHeight The height of the texture.
 * @constructor
 * @extends goog.events.Event
 */
talk.media.c3d.StreamEndpoint.SendStreamOnEvent =
    function(endpoint, textureId, stream, textureWidth, textureHeight) {
  goog.events.Event.call(this,
      talk.media.c3d.StreamEndpoint.Events.SEND_STREAM_ON);

  /**
   * The endpoint generating this event.
   *
   * @type {talk.media.c3d.StreamEndpoint}
   */
  this.endpoint = endpoint;


  /**
   * The ID of the texture.
   *
   * @type {number}
   */
  this.textureId = textureId;


  /**
   * The SSRC of the stream, or null for local stream.
   *
   * @type {?string}
   */
  this.stream = stream;


  /**
   * The width of the texture.
   *
   * @type {number}
   */
  this.textureWidth = textureWidth;


  /**
   * The height of the texture.
   *
   * @type {number}
   */
  this.textureHeight = textureHeight;

};
goog.inherits(
    talk.media.c3d.StreamEndpoint.SendStreamOnEvent,
    goog.events.Event);


/**
 * Event indicating that a 'streamoff' message should be sent to flute.
 *
 * @param {talk.media.c3d.StreamEndpoint} endpoint The
 * endpoint generating this event.
 * @param {number} textureId The ID of the texture.
 * @constructor
 * @extends goog.events.Event
 */
talk.media.c3d.StreamEndpoint.SendStreamOffEvent =
    function(endpoint, textureId) {
  goog.events.Event.call(this,
      talk.media.c3d.StreamEndpoint.Events.SEND_STREAM_OFF);

  /**
   * The endpoint generating this event.
   *
   * @type talk.media.c3d.StreamEndpoint
   */
  this.endpoint = endpoint;


  /**
   * The ID of the texture.
   *
   * @type number
   */
  this.textureId = textureId;

};
goog.inherits(
    talk.media.c3d.StreamEndpoint.SendStreamOffEvent,
    goog.events.Event);


/**
 * Event indicating that the aspect ratio of this stream has changed.
 *
 * @param {talk.media.c3d.StreamEndpoint} endpoint The
 * endpoint generating this event.
 * @constructor
 * @extends goog.events.Event
 */
talk.media.c3d.StreamEndpoint.AspectChangedEvent =
    function(endpoint) {
  goog.events.Event.call(this,
      talk.media.c3d.StreamEndpoint.Events.ASPECT_CHANGED);

  /**
   * The endpoint generating this event. The new aspect ratio can be retrieved
   * via endpoint.getAspect().
   *
   * @type talk.media.c3d.StreamEndpoint
   */
  this.endpoint = endpoint;

};
goog.inherits(
    talk.media.c3d.StreamEndpoint.AspectChangedEvent,
    goog.events.Event);


/**
 * Event indicating that value of isAvatar() has changed.
 *
 * @param {talk.media.c3d.StreamEndpoint} endpoint The
 * endpoint generating this event.
 * @constructor
 * @extends goog.events.Event
 */
talk.media.c3d.StreamEndpoint.AvatarEvent =
    function(endpoint) {
  goog.events.Event.call(this,
      talk.media.c3d.StreamEndpoint.Events.AVATAR);

  /**
   * The endpoint generating this event.
   *
   * @type talk.media.c3d.StreamEndpoint
   */
  this.endpoint = endpoint;

};
goog.inherits(
    talk.media.c3d.StreamEndpoint.AvatarEvent,
    goog.events.Event);


/**
 * Event indicating that the texture became active; something started rendering
 * the texture.
 *
 * @param {talk.media.c3d.StreamEndpoint} endpoint The endpoint generating this
 *     event.
 * @constructor
 * @extends goog.events.Event
 */
talk.media.c3d.StreamEndpoint.TextureActivatedEvent = function(endpoint) {
  goog.events.Event.call(this,
      talk.media.c3d.StreamEndpoint.Events.TEXTURE_ACTIVATED);

  /**
   * The endpoint generating this event.
   *
   * @type talk.media.c3d.StreamEndpoint
   */
  this.endpoint = endpoint;

};
goog.inherits(
    talk.media.c3d.StreamEndpoint.TextureActivatedEvent,
    goog.events.Event);


/**
 * A simple data structure for the texture and the requested stream attributes.
 *
 * @param {Object} texture The C3D Texture2D object.
 * @constructor
 * @private
 */
talk.media.c3d.StreamEndpoint.Mapping_ = function(texture) {

  /**
   * The C3D Texture2D object.
   *
   * @type {Object}
   * @const
   */
  this.texture = texture;


  /**
   * The id of the texture object. We have to cache this because we can't
   * retrieve it anymore in the !isSceneScriptable() case.
   *
   * @type {number}
   * @const
   */
  this.textureId = texture['clientId'];
};


/**
 * The width of the video being written to this mapping's texture, if any.
 *
 * @type {number}
 */
talk.media.c3d.StreamEndpoint.Mapping_.prototype.width;


/**
 * The height of the video being written to this mapping's texture, if any.
 *
 * @type {number}
 */
talk.media.c3d.StreamEndpoint.Mapping_.prototype.height;


/**
 * Our logger.
 *
 * @private
 */
talk.media.c3d.StreamEndpoint.prototype.logger_ =
    goog.debug.Logger.getLogger('talk.media.c3d.StreamEndpoint');


/**
 * Whether or not the texture is on (i.e., rendering something). If true then
 * this.mappings_ will be non-empty and the first element is the active mapping.
 *
 * @type {boolean}
 * @private
 */
talk.media.c3d.StreamEndpoint.prototype.isOn_ = false;


/**
 * Whether or not the texture is displaying an avatar. If true this isOn() will
 * be true but mappings_ will be empty and isRequestedOn() will be false.
 *
 * @type {boolean}
 * @private
 */
talk.media.c3d.StreamEndpoint.prototype.isAvatar_ = false;


/**
 * Timer for resizing after resolution decreases.
 *
 * @type {number?}
 * @private
 */
talk.media.c3d.StreamEndpoint.prototype.resizeTimer_;


/**
 * Width to resize to.
 *
 * @type {number?}
 * @private
 */
talk.media.c3d.StreamEndpoint.prototype.resizeWidth_;


/**
 * Height to resize to.
 *
 * @type {number?}
 * @private
 */
talk.media.c3d.StreamEndpoint.prototype.resizeHeight_;


/**
 * Current aspect ratio.
 *
 * @type {number}
 * @private
 */
talk.media.c3d.StreamEndpoint.prototype.aspect_;


/**
 * The O3D FileRequest object for loading an avatar texture.
 *
 * @type {?Object}
 * @private
 */
talk.media.c3d.StreamEndpoint.prototype.fileRequest_;


/**
 * The O3D Texture object with the avatar image.
 *
 * @type {?Object}
 * @private
 */
talk.media.c3d.StreamEndpoint.prototype.avatarTexture_;


/**
 * Whether to show an avatar when texture becomes available.
 *
 * @type {boolean}
 * @private
 */
talk.media.c3d.StreamEndpoint.prototype.needAvatar_;

/**
 * @return {boolean} Whether or not the texture is on.
 */
talk.media.c3d.StreamEndpoint.prototype.isOn = function() {
  return this.isOn_;
};


/**
 * @return {boolean} Whether or not the texture is displaying an avatar.
 */
talk.media.c3d.StreamEndpoint.prototype.isAvatar = function() {
  return this.isAvatar_;
};


/**
 * @return {boolean} Whether or not the texture is turning on or is
 *     currently on.
 */
talk.media.c3d.StreamEndpoint.prototype.isRequestedOn = function() {
  return this.mappings_.length > 0;
};


/**
 * @return {?string} The identifier for the stream that is rendered to this
 *     endpoint. null means the local stream.
 */
talk.media.c3d.StreamEndpoint.prototype.getStreamId = function() {
  return this.ssrc_;
};


/**
 * @return {string} The jid that this endpoint is representing.
 */
talk.media.c3d.StreamEndpoint.prototype.getJid = function() {
  return this.jid_;
};


/**
 * Requests a new avatar for this endpoint.
 */
talk.media.c3d.StreamEndpoint.prototype.requestAvatar = function() {
  this.needAvatar_ = true;  // State that an avatar is pending.
  var url = this.avatarUrl_;
  this.logger_.info('Texture requested for url="' + url + '"');

  if (this.avatarTexture_) {
    this.logger_.info('Reusing existing texture.');
    this.onAvatarReady_(this.avatarTexture_);
  }
  if (this.fileRequest_) {
    this.logger_.warning('Earlier texture request not yet done.');
    return;
  }
  this.fileRequest_ = this.pack_['createFileRequest']('TEXTURE');
  this.fileRequest_['open']('GET', url, true);
  this.fileRequest_['onreadystatechange'] = goog.bind(function() {
      if (this.fileRequest_['done']) {
        if (this.fileRequest_['success']) {
          this.onAvatarReady_(this.fileRequest_['texture']);
        } else {
          var msg = this.fileRequest_['error'];
          if (!msg) {
            msg = 'Unknown error';
          }
          this.logger_.severe('Texture failed to load, url="' + url +
                             '", msg="' + msg + '"');
          // TODO(geer): Add fallback to default avatar image.
        }
        this.pack_['removeObject'](this.fileRequest_);
        this.fileRequest_ = null;
      }
  }, this);
  this.fileRequest_.send();
};


/**
 * Handles the avatar texture being ready for display.
 *
 * @param {Object} texture The C3D Texture2D object.
 * @private
 */
talk.media.c3d.StreamEndpoint.prototype.onAvatarReady_ = function(texture) {
  // NOTE: This call keeps pending stream requests to be able to respond to a
  // delayed streamready message.
  this.avatarTexture_ = texture;
  if (!this.needAvatar_) {
    this.logger_.info('Avatar texture ready but not needed anymore.');
    return;
  }
  this.needAvatar_ = false;
  this.activateTexture_(texture,
                        [0, 1, 0, 0, 1, 0, 1, 1],
                        texture['width'] / texture['height']);
  if (!this.isAvatar_) {
    this.isAvatar_ = true;
    this.dispatchEvent(new talk.media.c3d.StreamEndpoint.AvatarEvent(this));
  }
};


/**
 * Requests a new stream for this endpoint.
 *
 * @param {number} opt_width Optional texture width. Must be power of two.
 * @param {number} opt_height Optional texture height. Must be power of two.
 */
talk.media.c3d.StreamEndpoint.prototype.requestStream =
    function(opt_width, opt_height) {
  if (this.isRequestedOn()) {
    return;
  }
  // Make a new texture.
  // If no texture dimensions are given, set them to the maximum that we
  // expect to support (which for 640x480 gives 1024x512). There is no penalty
  // for overestimating except a bit of temporary CPU usage.
  var width = opt_width ||
      talk.media.c3d.StreamEndpoint.DEFAULT_TEXTURE_WIDTH_;
  var height = opt_height ||
      talk.media.c3d.StreamEndpoint.DEFAULT_TEXTURE_HEIGHT_;
  this.queueStream_(width, height);
  this.cancelResize_();
};


/**
 * Creates and queues a mapping for a given texture size.
 *
 * @param {number} width Width to use for the texture. Must be power of two.
 * @param {number} height Height to use for the texture. Must be power of two.
 * @private
 */
talk.media.c3d.StreamEndpoint.prototype.queueStream_ =
    function(width, height) {
  var texture = this.pack_['createTexture2D'](
      width, height,  // width and height
      this.c3dObject_.getPlugin()['o3d']['Texture']['ARGB8'],  // format
      1,  // mipmap levels
      false);  // enable render surfaces
  var mapping = new talk.media.c3d.StreamEndpoint.Mapping_(texture);
  this.mappings_.push(mapping);
  this.dispatchEvent(
      new talk.media.c3d.StreamEndpoint.SendStreamOnEvent(
          this,
          mapping.textureId,
          this.ssrc_,
          width,
          height));
};


/**
 * Clears any and all streams for this endpoint.
 */
talk.media.c3d.StreamEndpoint.prototype.clearStream =
    function() {
  // Dequeue all streams.
  this.dequeueStreams_(this.mappings_.length);
  // Record that it's now off.
  this.isOn_ = false;
  delete this.aspect_;
  this.cancelResize_();
};


/**
 * Dequeues the "count" oldest mappings, telling flute to stop updating them.
 *
 * @param {number} count The number of mappings to dequeue.
 * @private
 */
talk.media.c3d.StreamEndpoint.prototype.dequeueStreams_ =
    function(count) {
  while (count > 0) {
    var mapping = this.mappings_.shift();
    this.dispatchEvent(new talk.media.c3d.StreamEndpoint
        .SendStreamOffEvent(this, mapping.textureId));
    if (this.c3dObject_.isSceneScriptable()) {  // Might not be during shutdown
      this.pack_['removeObject'](mapping.texture);
    }
    count--;
  }
};


/**
 * Handles a streamready event from flute for one of this endpoint's textures.
 *
 * @param {number} textureId The ID of the texture.
 * @param {?string} stream The stream being written to it.
 * @param {number} width The width of the stream source.
 * @param {number} height The height of the stream source.
 * @param {number} opt_renderedWidth The width of the stream as written into the
 * texture.
 * @param {number} opt_renderedHeight The height of the stream as written into
 * the texture.
 * @param {number} opt_pixelWidth The width of pixels for this stream as written
 * into the texture, in abstract units.
 * @param {number} opt_pixelHeight The height of pixels for this stream as
 * written into the texture, in abstract units.
 */
talk.media.c3d.StreamEndpoint.prototype.handleStreamReady =
    function(textureId, stream, width, height, opt_renderedWidth,
             opt_renderedHeight, opt_pixelWidth, opt_pixelHeight) {
  // TODO(geer): Remove stream param.
  if (stream != this.ssrc_) {
    this.logger_.severe('Wrong ssrc in streamready for this endpoint.');
    return;
  }
  // These were not sent in old streamready formats.
  var renderedWidth = opt_renderedWidth || width;
  var renderedHeight = opt_renderedHeight || height;
  var pixelWidth = opt_pixelWidth || 1;
  var pixelHeight = opt_pixelHeight || 1;
  for (var i = 0; i < this.mappings_.length; ++i) {
    if (this.mappings_[i].textureId == textureId) {
      // Found it.
      // Only the first mapping in the list is ever active, so this one is
      // active if it's first in the list and this endpoint is active.
      var isActive = (i == 0) && this.isOn_ && !this.isAvatar();
      // Start displaying this texture.
      if (!isActive) {
        this.needAvatar_ = false;  // Cancel any pending avatar.
        var texture = this.mappings_[i].texture;
        var texCoords = talk.media.c3d.computeTextureCoords(
            renderedWidth,
            renderedHeight,
            texture['width'],
            texture['height'],
            this.mirror_);
        var aspect = renderedWidth * pixelWidth /
            (renderedHeight * pixelHeight);
        this.activateTexture_(texture, texCoords, aspect);
        // Texture is now active and locked to these dimensions. Record them.
        this.mappings_[i].width = renderedWidth;
        this.mappings_[i].height = renderedHeight;
        if (this.isAvatar_) {
          this.isAvatar_ = false;
          this.dispatchEvent(new talk.media.c3d.StreamEndpoint.AvatarEvent(
              this));
        }
      }
      // If this is the texture we wanted then check if we have the size right.
      if (i == this.mappings_.length - 1) {
        // Cancel any pending resize event.
        this.cancelResize_();
        // Compute the ideal texture sizes for this video stream size.
        var texWidth = talk.media.c3d.powerOfTwoCeiling(width);
        var texHeight = talk.media.c3d.powerOfTwoCeiling(height);
        if (!isActive) {
          // It's possible that the texture size we chose isn't the best size
          // for this stream (i.e., smallest size that can fit the full
          // resolution). Resize if so.
          if (texWidth != this.mappings_[i].texture['width'] ||
              texHeight != this.mappings_[i].texture['height']) {
            this.queueStream_(texWidth, texHeight);
          }
        } else if (width > this.mappings_[i].width &&
                   height > this.mappings_[i].height) {
          // Resolution increase. Resize immediately.
          this.queueStream_(texWidth, texHeight);
        } else if (width != this.mappings_[i].width ||
                   height != this.mappings_[i].height) {
          // Resolution decrease (or mixed inc/dec, but that's unlikely). This
          // can often happen due to temporary packet loss that will subside, so
          // we only want to resize if this new resolution persists.
          this.resizeWidth_ = texWidth;
          this.resizeHeight_ = texHeight;
          this.resizeTimer_ = goog.Timer.callOnce(
              this.onResizeTimerElapsed_,
              talk.media.c3d.StreamEndpoint.RESIZE_TIMEOUT_,
              this);
        }
      }
      // All older mappings are now obsolete. Get rid of them.
      // (The older mappings here represent textures/resolutions that we
      // were previously using. Now that this new configuration has become
      // ready, the old textures are defunct.)
      this.dequeueStreams_(i);
      break;
    }
  }
};


/**
 * Handles a streamfailed event from flute for one of this endpoint's textures.
 *
 * @param {number} textureId The ID of the texture.
 */
talk.media.c3d.StreamEndpoint.prototype.handleStreamFailed =
    function(textureId) {
  this.requestAvatar();
};


/**
 * Actually displays the given texture's stream for this stream endpoint.
 *
 * @param {Object} texture The C3D Texture2D object.
 * @param {Array} texCoords An 8-element number array giving the x-y coordinates
 * of each corner of the texture.
 * @param {number} aspect The aspect ratio at which to render the image (can be
 * different from the aspect in pixels so as to effectively apply a scale).
 * @private
 */
talk.media.c3d.StreamEndpoint.prototype.activateTexture_ =
    function(texture, texCoords, aspect) {
  var wasOn = this.isOn_;
  this.isOn_ = true;
  if (this.aspect_ != aspect) {
    // New aspect.
    this.aspect_ = aspect;
    this.dispatchEvent(new talk.media.c3d.StreamEndpoint.
        AspectChangedEvent(this));
  }
  this.texSampler_['texture'] = texture;
  this.texBuffer_['set'](texCoords);
  if (!wasOn) {
    this.dispatchEvent(new talk.media.c3d.StreamEndpoint.TextureActivatedEvent(
        this));
  }
};


/**
 * Handles the resize timer elapsing by performing the pending resize.
 *
 * @private
 */
talk.media.c3d.StreamEndpoint.prototype.onResizeTimerElapsed_ = function() {
  this.queueStream_(/** @type {number} */(this.resizeWidth_),
                    /** @type {number} */(this.resizeHeight_));
  this.resizeTimer_ = null;
  this.resizeWidth_ = null;
  this.resizeHeight_ = null;
};


/**
 * Cancels any pending resize event.
 *
 * @private
 */
talk.media.c3d.StreamEndpoint.prototype.cancelResize_ =
    function() {
  goog.Timer.clear(this.resizeTimer_);
  this.resizeTimer_ = null;
  this.resizeWidth_ = null;
  this.resizeHeight_ = null;
};


/**
 * Retrieves the current aspect ratio, if any.
 *
 * @return {number} The current aspect ratio.
 */
talk.media.c3d.StreamEndpoint.prototype.getAspect =
    function() {
  return this.aspect_;
};


/**
 * @override
 * @protected
 */
talk.media.c3d.StreamEndpoint.prototype.disposeInternal = function() {
  // Undo any mappings in flute.
  this.clearStream();
  if (this.avatarTexture_ && this.c3dObject_.isSceneScriptable()) {
    this.pack_['removeObject'](this.avatarTexture_);
    this.avatarTexture_ = null;
  }
};
