// Copyright 2009 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview Concrete feed class that positions the feed within a fixed
 * rectangle of screen space, starting out with it filling the space as with
 * FixedAreaFeed, but with the added capability to later shrink it into the
 * corner of that area.
 *
 * @author tschmelcher@google.com (Tristan Schmelcher)
 */

goog.provide('talk.media.c3d.ShrinkableFeed');

goog.require('talk.media.c3d.AttrsTween');
goog.require('talk.media.c3d.FixedAreaFeed');
goog.require('talk.media.c3d.PipHandler');
goog.require('talk.media.c3d.PipOptions');
goog.require('talk.media.c3d.easing');


/**
 * Concrete feed class that positions the feed within a fixed rectangle of
 * screen space, starting out with it filling the space as with FixedAreaFeed,
 * but with the added capability to later shrink it into the corner of that
 * area (called the PIP state, for picture-in-picture).
 *
 * @param {talk.media.c3d.O3dBundle} o3dBundle The bundle of global resources
 * for this O3D instance.
 * @param {talk.media.c3d.StreamEndpoint} endpoint The StreamEndpoint that
 * provides the video/avatar for this feed.
 * @param {number} depth The depth at which to display this feed.
 * @param {number} x The x-coordinate of the origin.
 * @param {number} y The y-coordinate of the origin.
 * @param {number} width The width of the rectangle to draw in.
 * @param {number} height The height of the rectangle to draw in.
 * @param {talk.media.c3d.PipOptions} pipOptions The options for PIP state, like
 * relative size and corner to shrink to.
 * @extends {talk.media.c3d.FixedAreaFeed}
 * @constructor
 */
talk.media.c3d.ShrinkableFeed = function(o3dBundle, endpoint, depth,
    x, y, width, height, pipOptions) {
  talk.media.c3d.FixedAreaFeed.call(this, o3dBundle, endpoint, depth,
      x, y, width, height, true);

  /**
   * Size of the feed when in the PIP state, expressed as the ratio of each
   * dimension to the size of that dimension when in the initial state.
   *
   * @type {number}
   * @private
   * @const
   */
  this.sizeRatio_ = pipOptions.getSize();


  /**
   * The corner to shrink to.
   *
   * @type {talk.media.c3d.PipOptions.Corner}
   * @private
   * @const
   */
  this.corner_ = pipOptions.getCorner();


   /**
   * Handles move and minimize / maximize of the pip object.
   *
   * @type {talk.media.c3d.PipHandler}
   * @private
   */
  this.pipHandler_ = new talk.media.c3d.PipHandler(o3dBundle, this);
};
goog.inherits(talk.media.c3d.ShrinkableFeed, talk.media.c3d.FixedAreaFeed);


/**
 * Offset of the PIP.
 *
 * @type {number}
 * @private
 * @const
 */
talk.media.c3d.ShrinkableFeed.OFFSET_ = 3;


/**
 * Duration of the shrink animation, in seconds.
 *
 * @type {number}
 * @private
 * @const
 */
talk.media.c3d.ShrinkableFeed.SHRINK_DURATION_ = 0.8;


/**
 * Whether or not we have shrunk yet (or started shrinking).
 *
 * @type {boolean}
 * @private
 */
talk.media.c3d.ShrinkableFeed.prototype.hasShrunk_ = false;


/**
 * Whether or not the PipHandler has been initialized.
 *
 * @type {boolean}
 * @private
 */
talk.media.c3d.ShrinkableFeed.prototype.pipHandlerInitialized_ = false;


/**
 * Our current spatial tween, if any.
 *
 * @type {?talk.media.c3d.AttrsTween}
 * @private
 */
talk.media.c3d.ShrinkableFeed.prototype.tween_;


/**
 * Shrinks the feed to the corner of the available area in a fancy wooshing
 * movement.
 */
talk.media.c3d.ShrinkableFeed.prototype.shrinkToCorner = function() {
  if (this.hasShrunk_) {
    return;
  }
  // C3dCommunicationPlayer calls shrinkToCorner() from an avatar ready handler,
  // but its handler executes before ours so the feed object may not be created
  // yet. Hence we need to call reposition() to handle any possible position
  // changes now.
  this.reposition();
  this.hasShrunk_ = true;
  if (!this.feedObject) {
    // Feed is not on yet. Hence the feed object has not yet been created
    // because we don't know the aspect ratio yet. Skip the tween. The feed
    // will simply appear in the PIP position once it's ready.
    return;
  }
  // Now do the tween.
  this.moveToCorner(this.corner_,
      talk.media.c3d.ShrinkableFeed.SHRINK_DURATION_,
      talk.media.c3d.STRONG_EASE_IN_OUT);
};


/**
 * Moves the feed with a tween to the corner.
 *
 * @param {talk.media.c3d.PipOptions.Corner} corner The corner to move to.
 * @param {number} duration The duration of the tween.
 * @param {talk.media.c3d.EasingMethod} easeMethod The easing method to use.
 */
talk.media.c3d.ShrinkableFeed.prototype.moveToCorner =
    function(corner, duration, easeMethod) {
  this.corner_ = corner;
  var currentAttrs = this.feedObject.getAttrs();
  // Compute the PIP-attrs without calling reposition, b/c we don't actually
  // want to move it there yet.
  var pipAttrs = this.getAttrs();
  this.fillAttributes(pipAttrs, this.getEndpoint().getAspect());
  // Do the tween.
  // TODO(tschmelcher): O3D has animations support that can probably replace
  // this.
  this.tween_ = new talk.media.c3d.AttrsTween(
      this.feedObject,
      currentAttrs,
      pipAttrs,
      duration,
      easeMethod,
      goog.bind(this.onTweenDone_, this));
  this.o3dBundle.c3dEngine.registerRenderCallback(this.tween_);
};


/**
 * Callback for when the shrink animation completes.
 *
 * @private
 */
talk.media.c3d.ShrinkableFeed.prototype.onTweenDone_ = function() {
  this.tween_ = null;
  this.initPipHandler_();
  this.pipHandler_.updatePosition(this.getFeedAttrs(), true);
};


/**
 * Initializes the PIP handler.
 *
 * @private
 */
talk.media.c3d.ShrinkableFeed.prototype.initPipHandler_ = function() {
  if (this.feedObject && this.hasShrunk_ && !this.pipHandlerInitialized_) {
    this.pipHandler_.init();
    this.pipHandlerInitialized_ = true;
  }
};


/**
 * @override
 * @protected
 */
talk.media.c3d.ShrinkableFeed.prototype.fillAttributes =
    function(attrs, aspect) {
  talk.media.c3d.ShrinkableFeed.superClass_.fillAttributes.call(this, attrs,
      aspect);
  if (this.hasShrunk_) {
    // Overwrite the full-area attributes with values adjusted for PIP display.
    // Based on getPipAttributes() from
    // //flash/actionscript/com/google/talk/session/VideoCallWindowManager.as.
    var w = attrs.w * this.sizeRatio_;
    var h = attrs.h * this.sizeRatio_;

    if (this.corner_ == talk.media.c3d.PipOptions.Corner.BOTTOM_RIGHT ||
        this.corner_ == talk.media.c3d.PipOptions.Corner.TOP_RIGHT) {
      // Right.
      attrs.x = this.x + this.width - w - talk.media.c3d.ShrinkableFeed.OFFSET_;
    } else {
      // Left.
      attrs.x = this.x + talk.media.c3d.ShrinkableFeed.OFFSET_;
    }
    if (this.corner_ == talk.media.c3d.PipOptions.Corner.BOTTOM_LEFT ||
        this.corner_ == talk.media.c3d.PipOptions.Corner.BOTTOM_RIGHT) {
      // Bottom.
      attrs.y = this.y + this.height - h -
          talk.media.c3d.ShrinkableFeed.OFFSET_;
    } else {
      // Top.
      attrs.y = this.y + talk.media.c3d.ShrinkableFeed.OFFSET_;
    }
    attrs.w = w;
    attrs.h = h;
  }
};


/**
 * @override
 * @protected
 */
talk.media.c3d.ShrinkableFeed.prototype.updatePosition = function(attrs) {
  if (!this.tween_) {
    talk.media.c3d.ShrinkableFeed.superClass_.updatePosition.call(this, attrs);
    // Maybe the tween was not used to get to pip mode. Make sure the handler
    // is initialized.
    this.initPipHandler_();
    this.pipHandler_.updatePosition(attrs, true);
    return;
  }
  // Else we are in the middle of doing the shrink-to-corner animation to our
  // previous destination. We must cancel it and start a replacement animation
  // for the new destination. Note that this will not be completely smooth
  // because the replacement tween will do its own ease-in from rest, but this
  // should be rare so that's acceptable.
  var remaining = this.tween_.getRemaining();
  var easeMethod = this.tween_.getEaseMethod();
  this.o3dBundle.c3dEngine.unregisterRenderCallback(this.tween_);
  this.tween_ = new talk.media.c3d.AttrsTween(
      this.feedObject,
      this.feedObject.getAttrs(),
      attrs,
      remaining,
      easeMethod,
      goog.bind(this.onTweenDone_, this));
  this.o3dBundle.c3dEngine.registerRenderCallback(this.tween_);
};


/**
 * @override
 * @protected
 */
talk.media.c3d.ShrinkableFeed.prototype.disposeInternal = function() {
  talk.media.c3d.ShrinkableFeed.superClass_.disposeInternal.call(this);
  if (this.pipHandler_) {
    this.pipHandler_.dispose();
  }
};
