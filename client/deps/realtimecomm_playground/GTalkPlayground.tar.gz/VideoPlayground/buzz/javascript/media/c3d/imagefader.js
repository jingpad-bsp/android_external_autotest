// Copyright 2010 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview Class to manage images that need to appear and fade-out.
 * @author tschmelcher@google.com (Tristan Schmelcher)
 */

goog.provide('talk.media.c3d.ImageFader');

goog.require('goog.Disposable');
goog.require('goog.Timer');
goog.require('talk.media.c3d.easing');
goog.require('talk.media.c3d.AlphaTween');


/**
 * Creates an object to manage an image that need to appear and fade-out.
 *
 * @param {talk.media.c3d.O3dBundle} o3dBundle The bundle of global resources
 *     for this O3D instance.
 * @param {talk.media.c3d.Image} image The image to manage.
 * @constructor
 * @extends {goog.Disposable}
 */
talk.media.c3d.ImageFader = function(o3dBundle, image) {

  /**
   * The bundle of global resources for this O3D instance.
   *
   * @type {talk.media.c3d.O3dBundle}
   * @private
   */
  this.o3dBundle_ = o3dBundle;


  /**
   * The image to manage.
   *
   * @type {talk.media.c3d.Image}
   * @private
   */
  this.image_ = image;

};
goog.inherits(talk.media.c3d.ImageFader, goog.Disposable);


/**
 * A tween to hide the image by fading.
 *
 * @type {talk.media.c3d.AlphaTween}
 * @private
 */
talk.media.c3d.ImageFader.prototype.imageFader_;


/**
 * The ID of the timer for how long we show the image.
 *
 * @type {number}
 * @private
 */
talk.media.c3d.ImageFader.prototype.showTimerId_;


/**
 * Duration of the next fade-out animation (in seconds).
 *
 * @type {number}
 * @private
 */
talk.media.c3d.ImageFader.prototype.fadeDurationSec_;


/**
 * Returns the image that this object is managing. It's alpha property must
 * not be altered.
 *
 * @return {talk.media.c3d.Image} The image that this object is managing.
 */
talk.media.c3d.ImageFader.prototype.getImage = function() {
  return this.image_;
};


/**
 * Immediately show the image, cancelling any pending or in-progress animations.
 *
 * @param {number} showDurationMs duration to show the image (in milliseconds)
 * @param {number} fadeDurationSec duration of the fade-out animation (in
 * seconds)
 */
talk.media.c3d.ImageFader.prototype.show = function(showDurationMs,
                                                    fadeDurationSec) {
  // Cancel anything in progress.
  this.cancelAnimations_();
  // Display the image.
  this.image_.setAlpha(1);
  this.image_.setVisible(true);
  // Start timer for when to fade it out.
  this.showTimerId_ = goog.Timer.callOnce(this.onShowTimerElapsed_,
                                          showDurationMs,
                                          this);
  // Save this for later.
  this.fadeDurationSec_ = fadeDurationSec;
};


/**
 * Immediately hide the image, cancelling any pending or in-progress animations.
 *
 * @private
 */
talk.media.c3d.ImageFader.prototype.hide = function() {
  // Cancel anything in progress.
  this.cancelAnimations_();
  // Hide the image.
  this.image_.setVisible(false);
};


/**
 * Called when the showDuration is over to start the fade-out.
 *
 * @private
 */
talk.media.c3d.ImageFader.prototype.onShowTimerElapsed_ = function() {
  delete this.showTimerId_;
  this.imageFader_ = new talk.media.c3d.AlphaTween(this.image_,
      this.image_.getAlpha(), 0, this.fadeDurationSec_,
      talk.media.c3d.REGULAR_EASE_IN,
      goog.bind(this.onImageFaderDone_, this));
  this.o3dBundle_.c3dEngine.registerRenderCallback(this.imageFader_);
};


/**
 * Called when the fadeDuration is over and the fade-out is complete.
 *
 * @private
 */
talk.media.c3d.ImageFader.prototype.onImageFaderDone_ = function() {
  delete this.imageFader_;
  this.image_.setVisible(false);
};


/**
 * Cancels and removes any pending or in-progress animations.
 *
 * @private
 */
talk.media.c3d.ImageFader.prototype.cancelAnimations_ = function() {
  if (this.showTimerId_) {
    goog.Timer.clear(this.showTimerId_);
    delete this.showTimerId_;
  }
  if (this.imageFader_) {
    this.o3dBundle_.c3dEngine.unregisterRenderCallback(this.imageFader_);
    delete this.imageFader_;
  }
};


/**
 * @override
 * @protected
 */
talk.media.c3d.ImageFader.prototype.disposeInternal = function() {
  talk.media.c3d.ImageFader.superClass_.disposeInternal.call(this);
  this.cancelAnimations_();
  // Does NOT dispose the image, since we do not consider this class to own it.
};
