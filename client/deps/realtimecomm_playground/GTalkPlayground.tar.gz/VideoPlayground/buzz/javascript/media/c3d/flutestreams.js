// Copyright 2008 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview A handler of flute video streams.
 *
 * @author tschmelcher@google.com (Tristan Schmelcher)
 * @author geer@google.com (Arthur van der Geer)
 */

goog.provide('talk.media.c3d.FluteStreams');
goog.provide('talk.media.c3d.FluteStreams.NewEndpointEvent');
goog.provide('talk.media.c3d.FluteStreams.RemovedEndpointEvent');

goog.require('goog.debug.Trace');
goog.require('goog.events');
goog.require('goog.events.EventHandler');
goog.require('talk.media.CallManager');
goog.require('talk.media.CallManager.Call');
goog.require('talk.media.CallType');
goog.require('talk.media.c3d.C3dObject');
goog.require('talk.media.c3d.O3dBundle');
goog.require('talk.media.c3d.StreamEndpoint');


/**
 * Creates a handler of flute video streams.
 *
 * @param {talk.media.CallManager} callManager The manager for voice/video
 *     calls, used to communicate with flute.
 * @param {talk.media.c3d.O3dBundle} o3dBundle The shared O3D objects to use.
 * @param {boolean} includeLocal Whether to include the local feed.
 * @constructor
 * @extends goog.events.EventTarget
 */
talk.media.c3d.FluteStreams = function(callManager, o3dBundle, includeLocal) {
  goog.events.EventTarget.call(this);

  /**
   * Whether to include a stream from the local camera or not.
   *
   * @type {boolean}
   * @private
   */
  this.includeLocal_ = includeLocal;


  /**
   * A trace of how long it takes us to start video from the time that we
   * are created.
   *
   * @type {?number}
   * @private
   */
  this.videoStartTrace_ = goog.debug.Trace.startTracer(
      'communicationPlayer.start');


  /**
   * The container for our global O3D handles that will be shared across
   * multiple classes.
   *
   * @type {talk.media.c3d.O3dBundle}
   * @private
   */
  this.o3dBundle_ = o3dBundle;


  /**
   * The call manager handles communication with the TalkPlugin.
   *
   * @type talk.media.CallManager
   * @private
   */
  this.callManager_ = callManager;


  /**
   * EventHandler to simplify installing/removing event listeners.
   *
   * @type goog.events.EventHandler
   * @private
   */
  this.eventHandler_ = new goog.events.EventHandler(this);

  this.eventHandler_.listen(this.callManager_,
      talk.media.CallManager.Event.ADD_VIDEO, this.handleAddVideo_);
  this.eventHandler_.listen(this.callManager_,
      talk.media.CallManager.Event.REMOVE_VIDEO, this.handleRemoveVideo_);


  /**
   * A list of all our stream endpoints.
   *
   * @type {Array.<talk.media.c3d.StreamEndpoint>}
   * @private
   */
  this.streamEndpoints_ = [];
};
goog.inherits(talk.media.c3d.FluteStreams, goog.events.EventTarget);


/**
 * Events fired by @code{talk.media.c3d.FluteStreams}.
 *
 * @enum {string}
 */
talk.media.c3d.FluteStreams.Event = {
  /**
   * Event indicating that a new endpoint has been added for a flute stream.
   */
  NEW_ENDPOINT : 'nep',

  /**
   * Event indicating that an endpoint is being removed.
   */
  REMOVED_ENDPOINT : 'rep'
};


/**
 * Event class for {@code talk.media.c3d.FluteStreams.Event.NEW_ENDPOINT}.
 *
 * @param {talk.media.c3d.StreamEndpoint} endpoint The newly created endpoint
 *     for rendering a stream.
 * @constructor
 * @extends {goog.events.Event}
 */
talk.media.c3d.FluteStreams.NewEndpointEvent = function(endpoint) {

  /**
   * @type {talk.media.c3d.StreamEndpoint} The endpoint for the new stream.
   */
  this.endpoint = endpoint;

  goog.events.Event.call(this, talk.media.c3d.FluteStreams.Event.NEW_ENDPOINT);
};
goog.inherits(talk.media.c3d.FluteStreams.NewEndpointEvent, goog.events.Event);


/**
 * Event class for {@code talk.media.c3d.FluteStreams.Event.REMOVED_ENDPOINT}.
 *
 * @param {talk.media.c3d.StreamEndpoint} endpoint The removed stream endpoint.
 * @constructor
 * @extends {goog.events.Event}
 */
talk.media.c3d.FluteStreams.RemovedEndpointEvent = function(endpoint) {

  /**
   * @type {talk.media.c3d.StreamEndpoint} The removed endpoint.
   */
  this.endpoint = endpoint;

  goog.events.Event.call(this,
      talk.media.c3d.FluteStreams.Event.REMOVED_ENDPOINT);
};
goog.inherits(talk.media.c3d.FluteStreams.RemovedEndpointEvent,
    goog.events.Event);


/**
 * Our logger.
 *
 * @private
 */
talk.media.c3d.FluteStreams.prototype.logger_ =
    goog.debug.Logger.getLogger('talk.media.c3d.FluteStreams');


/**
 * The JID we're calling.
 *
 * @type {?string}
 * @private
 */
talk.media.c3d.FluteStreams.prototype.senderJid_;


/**
 * The ID of the call session of the flute video streams.
 *
 * @type {?string}
 * @private
 */
talk.media.c3d.FluteStreams.prototype.sessionId_;


/**
 * The message queue address for our O3D instance.
 *
 * @type {string}
 * @private
 */
talk.media.c3d.FluteStreams.prototype.c3dAddress_;


/**
 * The list of participants in the call.
 * Index 0 is the local user.  User array elements are [{string} JID,
 * {boolean} isLocal, {string} avatarUrl].
 *
 * @type {Array.<Array>}
 * @private
 */
talk.media.c3d.FluteStreams.prototype.participants_;


/**
 * Makes a new stream endpoint for sending a video stream from flute to C3D.
 *
 * @param {?string} streamId The identifier for the video stream: SSRC or '0'
 *     for remote or null for local.
 * @param {boolean} mirror Whether or not to mirror this stream when displayed.
 * @return {?talk.media.c3d.StreamEndpoint} A new stream
 *     endpoint.
 * @protected
 */
talk.media.c3d.FluteStreams.prototype.createStreamEndpoint = function(
    streamId, mirror) {
  // Get participant info.
  // TODO(geer): Add a participant class.
  var participant;
  if (streamId == null) {
    participant = this.participants_[0];
  } else if (streamId == '0') {
    participant = this.participants_[1];
  } else {
    // Lookup ssrc to get the jid and find the participant.
    var call = this.callManager_.getActiveCall();
    if (goog.isDefAndNotNull(call)) {
      var jid = call.getJidForVideoSsrc(streamId);
      for (var i = 0; i < this.participants_.length; ++i) {
        if (this.participants_[i][0] == jid) {
          participant = this.participants_[i];
          break;
        }
      }
    }
  }
  if (!participant) {
    this.logger_.severe('No participant for streamId \'' + streamId + '\'');
    return null;
  }

  var material = this.o3dBundle_.pack['createObject']('Material');

  // Set the material's drawList
  material['drawList'] = this.o3dBundle_.view.drawList;

  // Apply our effect to this material. The effect tells the 3D hardware
  // which shader to use.
  material['effect'] = this.o3dBundle_.effect;

  // This will create our quadColor parameter on the material.
  this.o3dBundle_.effect['createUniformParameters'](material);

  // Create a Sampler object for this texture.
  var texSampler = this.o3dBundle_.pack['createObject']('Sampler');
  // (Creating and setting the texture that it samples will be the
  // StreamEndpoint's job.)

  // Set this as the material's sampler.
  material['getParam']('texSampler0')['value'] = texSampler;

  // Create a VertexBuffer to tell which coordinates of the texture maps to a
  // specific vertex.
  var texBuffer = this.o3dBundle_.pack['createObject']('VertexBuffer');
  var texCoordField = texBuffer['createField']('FloatField', 2);
  // Setting the actual values will be the StreamEndpoint's job, but we have to
  // initialize it to something or else C3D complains.
  texBuffer['set'](talk.media.c3d.computeTextureCoords(1, 1, 1, 1, false));

  var endpoint = new talk.media.c3d.StreamEndpoint(streamId,
      participant[0], // jid
      participant[2], // url
      material,
      texBuffer,
      texCoordField,
      texSampler,
      mirror,
      this.o3dBundle_.pack,
      this.o3dBundle_.c3dObject);

  this.eventHandler_.listen(endpoint,
      talk.media.c3d.StreamEndpoint.Events.SEND_STREAM_ON,
      this.sendStreamOn_);
  this.eventHandler_.listen(endpoint,
      talk.media.c3d.StreamEndpoint.Events.SEND_STREAM_OFF,
      this.sendStreamOff_);

  this.streamEndpoints_.push(endpoint);

  this.dispatchEvent(
      new talk.media.c3d.FluteStreams.NewEndpointEvent(endpoint));

  return endpoint;
};


/**
 * Gets the stream endpoint for a given stream id.
 *
 * @param {string} id The id of the stream: SSRC, '0' or null.
 * @return {?talk.media.c3d.StreamEndpoint} The endpoint or null if not found.
 * @private
 */
talk.media.c3d.FluteStreams.prototype.getEndpointForStreamId_ = function(id) {
  for (var i = 0; i < this.streamEndpoints_.length; ++i) {
    var endpoint = this.streamEndpoints_[i];
    if (endpoint.getStreamId() == id) {
      return endpoint;
    }
  }
  return null;
};


/**
 * Initializes the flute streams for a new session.
 *
 * @param {string} sessionId The id of the call session to connect streams with.
 * @param {string} senderJid The jid to communicate to flute with.
 * @param {talk.media.CallType} callType The type of call.
 */
talk.media.c3d.FluteStreams.prototype.initSession =
    function(sessionId, senderJid, callType) {
  this.sessionId_ = sessionId;
  // TODO(geer): Refactor the dependency on this jid. And why is the sender
  // needed to get the message delivered?
  this.senderJid_ = senderJid;

  var showVideo = (callType == talk.media.CallType.VIDEO ||
                   callType == talk.media.CallType.TEST);

  var c3d = this.o3dBundle_.c3dObject.getPlugin();

  // Have to cache this because we need it during the !isSceneScriptable()
  // shutdown path and it won't be correct if we read it then.
  this.c3dAddress_ = c3d['client']['getMessageQueueAddress']();

  // Create local.
  if (this.includeLocal_) {
    var local = this.createStreamEndpoint(null, true);
    if (showVideo) {
      local.requestStream();
    } else {
      local.requestAvatar();
    }
  }

  if (!showVideo) {
    this.stopTracer_();
  }
};


/**
 * Removes the flute streams of the current session.
 */
talk.media.c3d.FluteStreams.prototype.disposeSession = function() {
  this.disposeStreams_();
  this.sessionId_ = null;
  this.senderJid_ = null;
  delete this.c3dAddress_;
};


/**
 * Handles messages from the TalkPlugin.
 *
 * @param {Array} msg The flute message.
 */
talk.media.c3d.FluteStreams.prototype.handleTalkPluginMessage = function(msg) {
  switch (msg[0]) {
    case 'streamready':
      this.logger_.info('streamready message from plugin');
      this.stopTracer_();
      // Ignore messages for stream id's that are not ours, and
      // dispatch to the proper stream endpoint.
      var stream = msg[5];
      var endpoint = this.getEndpointForStreamId_(stream);
      if (endpoint) {
        var textureId = msg[4];
        var width = msg[6];
        var height = msg[7];
        var opt_renderedWidth = msg[8];
        var opt_renderedHeight = msg[9];
        var opt_pixelWidth = msg[10];
        var opt_pixelHeight = msg[11];
        endpoint.handleStreamReady(textureId, stream, width, height,
            opt_renderedWidth, opt_renderedHeight, opt_pixelWidth,
            opt_pixelHeight);
      } else {
        this.logger_.info('No endpoint found for stream: ' + stream);
      }
      break;
    case 'streamfailed':
      this.logger_.info('streamfailed message from plugin');
      this.stopTracer_();
      // Dispatch to the proper stream endpoint.
      var stream = msg[5];
      var endpoint = this.getEndpointForStreamId_(stream);
      if (endpoint) {
        var textureId = msg[4];
        endpoint.handleStreamFailed(textureId);
      } else {
        this.logger_.info('No endpoint found for stream: ' + stream);
      }
      break;
  }
};


/**
 * Shows the avatar for a given jid.
 *
 * @param {string} jid The jid whose avatar to show.
 */
talk.media.c3d.FluteStreams.prototype.showAvatar = function(jid) {
  // TODO(geer): Find out of this is still needed for n:n audio calls.
  for (var i = 0; i < this.streamEndpoints_.length; ++i) {
    var endpoint = this.streamEndpoints_[i];
    if (endpoint.getJid() == jid) {
      endpoint.requestAvatar();
      break;
    }
  }
};


/**
 * Handles a request to add a video stream.
 *
 * @param {talk.media.CallManager.AddVideoEvent} e The event.
 * @private
 */
talk.media.c3d.FluteStreams.prototype.handleAddVideo_ = function(e) {
  if (e.sessionId == this.sessionId_) {
    if (!this.getEndpointForStreamId_(e.ssrc)) {
      var endpoint = this.createStreamEndpoint(e.ssrc, false);
      endpoint.requestStream();
    }
  }
};


/**
 * Handles a request to remove a video stream.
 *
 * @param {talk.media.CallManager.RemoveVideoEvent} e The event.
 * @private
 */
talk.media.c3d.FluteStreams.prototype.handleRemoveVideo_ = function(e) {
  if (e.sessionId == this.sessionId_) {
    for (var i = 0; i < this.streamEndpoints_.length; ++i) {
      var endpoint = this.streamEndpoints_[i];
      if (endpoint.getStreamId() == e.ssrc) {
        this.dispatchEvent(
            new talk.media.c3d.FluteStreams.RemovedEndpointEvent(endpoint));
        endpoint.dispose();
        this.streamEndpoints_.splice(i, 1);
        break;
      }
    }
  }
};


/**
 * Handles a request from a StreamEndpoint for us to send a 'streamon'.
 *
 * @param {talk.media.c3d.StreamEndpoint.SendStreamOnEvent} e The event.
 * @private
 */
talk.media.c3d.FluteStreams.prototype.sendStreamOn_ = function(e) {
  var c3d = this.o3dBundle_.c3dObject.getPlugin();
  this.callManager_.sendFluteMsg(goog.json.serialize(
      ['streamon', this.senderJid_, this.sessionId_, this.c3dAddress_,
          e.textureId, e.stream, e.textureWidth, e.textureHeight]));
};


/**
 * Handles a request from a StreamEndpoint for us to send a 'streamoff'.
 *
 * @param {talk.media.c3d.StreamEndpoint.SendStreamOffEvent} e The event.
 * @private
 */
talk.media.c3d.FluteStreams.prototype.sendStreamOff_ = function(e) {
  var c3d = this.o3dBundle_.c3dObject.getPlugin();
  this.callManager_.sendFluteMsg(goog.json.serialize(
      ['streamoff', this.senderJid_, this.sessionId_, this.c3dAddress_,
          e.textureId]));
};


/**
 * Tears down the stream rendering mappings that we currently have registered
 * with flute.
 *
 * @private
 */
talk.media.c3d.FluteStreams.prototype.disposeStreams_ = function() {
  for (var i = 0; i < this.streamEndpoints_.length; ++i) {
    this.streamEndpoints_[i].dispose();
  }
  this.streamEndpoints_.splice(0, this.streamEndpoints_.length);
};


/**
 * @private
 */
talk.media.c3d.FluteStreams.prototype.stopTracer_ = function() {
  if (this.videoStartTrace_ != null) {
    goog.debug.Trace.stopTracer(this.videoStartTrace_, 0);
    delete this.videoStartTrace_;
    this.logger_.info(goog.debug.Trace.getFormattedTrace());
  }
};


/**
 * Updates the list of participants.
 *
 * @param {Array.<Array>} participants The list of participants in the call.
 *     Index 0 is the local user.  User array elements are [{string} JID,
 *     {boolean} isLocal, {string} avatarUrl].
 */
talk.media.c3d.FluteStreams.prototype.updateParticipants = function(
    participants) {
  this.logger_.info('updateParticipants : ' + participants);
  this.participants_ = participants;
};


/**
 * Request all the streams that have not yet been requested.
 */
talk.media.c3d.FluteStreams.prototype.requestAll = function() {
  // Start streams that have not yet started.
  for (var i = 0; i < this.streamEndpoints_.length; ++i) {
    var endpoint = this.streamEndpoints_[i];
    if (!endpoint.isRequestedOn()) {
      endpoint.requestStream();
    }
  }
};


/**
 * @override
 * @protected
 */
talk.media.c3d.FluteStreams.prototype.disposeInternal = function() {
  talk.media.c3d.FluteStreams.superClass_.disposeInternal.call(this);
  this.disposeStreams_();
  this.eventHandler_.dispose();
  this.eventHandler_ = null;
  this.callManager_ = null;
};
