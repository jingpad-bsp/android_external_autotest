// Copyright 2008 Google Inc. All Rights Reserved.

/**
 * @fileoverview Detector of what renderer to use: flash or client3d.
 *
 * @author geer@google.com (Arthur van der Geer)
 */

goog.provide('talk.media.RendererDetector');

goog.require('goog.debug.Logger');
goog.require('talk.media.FlashDetector');

/**
 * Detects what kind of renderer to use: flash or client3D.
 * @param {boolean} opt_supportClient3D Use Client3D instead of Flash if
 *     possible, default true.
 * @constructor
 */
talk.media.RendererDetector = function(opt_supportClient3D) {
  this.flash_ = new talk.media.FlashDetector();
  this.supportClient3D_ = (opt_supportClient3D == null) ? true :
      opt_supportClient3D;
};


/**
 * The flash rendering bitmask in the bitmap of rendering capabilities
 * communicated with flute.
 * @type {number}
 */
talk.media.RendererDetector.RENDER_MAGICCAM_CAPABILITY = 1 << 0;


/**
 * The client3d rendering bitmask in the bitmap of rendering capabilities
 * communicated with flute.
 * @type {number}
 */
talk.media.RendererDetector.RENDER_CLIENT3D_CAPABILITY = 1 << 1;


/**
 * Logger
 * @type goog.debug.Logger
 * @private
 */
talk.media.RendererDetector.logger_ =
    goog.debug.Logger.getLogger('talk.media.RendererDetector');


/**
 * Our Client3DDetector.
 * TODO(btlee): Set type to "talk.media.Client3DDetector" when released
 *     for Client3D.
 * @type {Object}
 * @private
 */
talk.media.RendererDetector.prototype.client3dDetector_;


/**
 * @return {talk.media.FlashDetector} The object used to detect Flash and check
 *     its version.
 */
talk.media.RendererDetector.prototype.getFlashDetector = function() {
  return this.flash_;
};


/**
 * Global variable holding the C3D detector iff there is one.
 * TODO(btlee): Set type to "talk.media.Client3DDetector" when released
 *     for Client3D.
 * @type {Object}
 */
talk.media.RendererDetector.client3dDetector = null;


/**
 * Returns whether or not O3D mode is supported (e.g., the user is in the
 * lab). Does not imply anything about whether O3D is installed.
 * @return {boolean}
 */
talk.media.RendererDetector.prototype.isO3dSupported = function() {
  return this.supportClient3D_ && !!this.getClient3DDetector();
}


/**
 * Returns a Client3dDetector iff one could be created at JS load time;
 * otherwise, the variable it returns will be null.
 * TODO(btlee): Set return type to "talk.media.Client3DDetector" when released
 *     for Client3D.
 * @return {Object} The object to detect Client3D.
 */
talk.media.RendererDetector.prototype.getClient3DDetector = function() {
  // We need to load the global Client3DDetector into a property to get around
  // bugs in Gmail's pop-out design. In pop-out, this is called from the context
  // of the pop-out window, which has a separate set of global variable values,
  // so the global talk.media.RendererDetector.client3dDetector isn't set.
  // By loading the reference into a property it will be saved by the first
  // invocation of this function in the main window at initialization time and
  // will thus be available when this is later called from pop-out.
  // For some reason this is only an issue in jsmode=OPTIMIZED.
  if (!goog.isDefAndNotNull(this.client3dDetector_)) {
    this.client3dDetector_ = talk.media.RendererDetector.client3dDetector;
  }
  return this.client3dDetector_;
};


/**
 * Determines which of Flash and Client3D is installed and available.
 *
 * @return {number} The available renderers combined with OR.
 */
talk.media.RendererDetector.prototype.getCapabilities = function() {
  var caps = 0;
  if (this.isO3dSupported() && this.getClient3DDetector().isInstalled()) {
    caps |= talk.media.RendererDetector.RENDER_CLIENT3D_CAPABILITY;
  }
  if (this.getFlashDetector().hasFlashInstalled() &&
      this.getFlashDetector().hasRequiredFlashVersion()) {
    caps |= talk.media.RendererDetector.RENDER_MAGICCAM_CAPABILITY;
  }
  return caps;
};
