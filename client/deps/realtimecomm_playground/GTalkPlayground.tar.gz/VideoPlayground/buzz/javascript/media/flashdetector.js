// Copyright 2008 Google Inc. All Rights Reserved.

/**
 * @fileoverview Detector of Flash state using {@code goog.userAgent.flash}.
 *
 * @author perd@google.com (Per Danvind)
 */

goog.provide('talk.media.FlashDetector');

goog.require('goog.debug.Logger');
goog.require('goog.userAgent.flash');

/**
 * Wrapper of the static stuff in {@code goog.userAgent.flash} to facilitate
 * mocking in tests.
 * @constructor
 */
talk.media.FlashDetector = function() {
};


/**
 * Required Flash version on Linux.
 * @type string
 */
talk.media.FlashDetector.REQUIRED_VERSION_LINUX = '9.0.0';


/**
 * Required Flash version on Mac.
 * @type string
 */
talk.media.FlashDetector.REQUIRED_VERSION_MAC = '8.0.0';


/**
 * Required Flash version on Windows.
 * @type string
 */
talk.media.FlashDetector.REQUIRED_VERSION_WIN = '8.0.0';


/**
 * Logger
 * @type goog.debug.Logger
 * @private
 */
talk.media.FlashDetector.logger_ =
    goog.debug.Logger.getLogger('talk.media.FlashDetector');


/**
 * Determines if Flash is installed.
 * @return {boolean} True if Flash is installed, otherwise false
 */
talk.media.FlashDetector.prototype.hasFlashInstalled = function() {
  return goog.userAgent.flash.HAS_FLASH;
};


/**
 * Determines if the required version of Flash is installed.
 * @return {boolean} True if required version or newer, otherwise false
 */
talk.media.FlashDetector.prototype.hasRequiredFlashVersion = function() {
  if (goog.userAgent.LINUX) {
    return goog.userAgent.flash.isVersion(
        talk.media.FlashDetector.REQUIRED_VERSION_LINUX);
  } else if (goog.userAgent.MAC) {
    return goog.userAgent.flash.isVersion(
        talk.media.FlashDetector.REQUIRED_VERSION_MAC);
  } else if (goog.userAgent.WINDOWS) {
    return goog.userAgent.flash.isVersion(
        talk.media.FlashDetector.REQUIRED_VERSION_WIN);
  } else {
    talk.media.FlashDetector.logger_.
        warning('Unknown platform, neither linux, mac or windows');
    return false;
  }
};
