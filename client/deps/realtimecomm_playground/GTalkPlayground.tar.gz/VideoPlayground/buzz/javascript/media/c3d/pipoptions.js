// Copyright 2010 Google Inc. All Rights Reserved.

/**
 * @fileoverview Options for the PIP, like its position and size and whether to
 * show it or not.
 * @author geer@google.com (Arthur van der Geer)
 */

goog.provide('talk.media.c3d.PipOptions');
goog.provide('talk.media.c3d.PipOptions.Corner');


/**
 * Constructs an object to get and set options for the PIP view.
 * @constructor
 */
talk.media.c3d.PipOptions = function() {

  /**
   * The corner position of the PIP.
   *
   * @type {talk.media.c3d.PipOptions.Corner}
   * @private
   */
  this.corner_ = talk.media.c3d.PipOptions.DEFAULT_CORNER_;


  /**
   * The size of the PIP, as a fraction of the main feed's size.
   *
   * @type {number}
   * @private
   */
  this.size_ = talk.media.c3d.PipOptions.DEFAULT_SIZE_;


  /**
   * Whether the PIP should be visible or not.
   *
   * @type {boolean}
   * @private
   */
  this.visible_ = true;


};


/**
 * Identifies the corners of the player area.
 *
 * @enum {number}
 */
talk.media.c3d.PipOptions.Corner = {
    BOTTOM_LEFT : 0,
    BOTTOM_RIGHT : 1,
    TOP_RIGHT : 2,
    TOP_LEFT : 3
};


/**
 * Default corner of the PIP.
 *
 * @type {talk.media.c3d.PipOptions.Corner}
 * @const
 * @private
 */
talk.media.c3d.PipOptions.DEFAULT_CORNER_ =
    talk.media.c3d.PipOptions.Corner.BOTTOM_RIGHT;


/**
 * Default size of the PIP, as a fraction of the main feed's size.
 *
 * @type {number}
 * @const
 * @private
 */
talk.media.c3d.PipOptions.DEFAULT_SIZE_ = 1 / 3;


/**
 * Returns the corner position of the PIP.
 *
 * @returns {talk.media.c3d.PipOptions.Corner}
 */
talk.media.c3d.PipOptions.prototype.getCorner = function() {
  return this.corner_;
};


/**
 * Sets the corner position of the PIP.
 *
 * @param {talk.media.c3d.PipOptions.Corner} corner The corner position.
 */
talk.media.c3d.PipOptions.prototype.setCorner = function(corner) {
  this.corner_ = corner;
};


/**
 * Returns the size of the PIP, as a fraction of the main feed's size.
 *
 * @returns {number} The relative size of the pip.
 */
talk.media.c3d.PipOptions.prototype.getSize = function() {
  return this.size_;
};


/**
 * Sets the size of the PIP, as a fraction of the main feed's size.
 *
 * @param {number} size The relative size of the pip.
 */
talk.media.c3d.PipOptions.prototype.setSize = function(size) {
  this.size_ = size;
};


/**
 * Returns whether the PIP should be visible or not.
 *
 * @returns {boolean} The visibiity.
 */
talk.media.c3d.PipOptions.prototype.getVisible = function() {
  return this.visible_;
};


/**
 * Sets whether the PIP should be visible or not.
 *
 * @param {boolean} visible The visibiity of the pip.
 */
talk.media.c3d.PipOptions.prototype.setVisible = function(visible) {
  this.visible_ = visible;
};
