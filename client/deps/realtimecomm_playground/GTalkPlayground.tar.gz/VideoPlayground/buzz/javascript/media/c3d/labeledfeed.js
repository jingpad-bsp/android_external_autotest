// Copyright 2009 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview Concrete feed class showing a label with an identifier.
 * @author geer@google.com (Arthur van der Geer)
 */

goog.provide('talk.media.c3d.LabeledFeed');

goog.require('goog.Timer');
goog.require('goog.debug.Logger');
goog.require('talk.media.c3d.AlphaTween');
goog.require('talk.media.c3d.FixedAreaFeed');
goog.require('talk.media.c3d.Image');
goog.require('talk.media.c3d.helpers');


/**
 * Concrete feed class that shows a label with an identifier.
 *
 * @param {talk.media.c3d.O3dBundle} o3dBundle The bundle of global resources
 *     for this O3D instance.
 * @param {talk.media.c3d.StreamEndpoint} endpoint The StreamEndpoint that
 *     provides the video/avatar for this feed.
 * @param {number} depth The depth at which to display this feed.
 * @param {number} x The x-coordinate of the origin.
 * @param {number} y The y-coordinate of the origin.
 * @param {number} width The width of the rectangle to draw in.
 * @param {number} height The height of the rectangle to draw in.
 * @extends {talk.media.c3d.FixedAreaFeed}
 * @constructor
 */
talk.media.c3d.LabeledFeed = function(o3dBundle, endpoint, depth,
    x, y, width, height) {

  /**
   * A goog.bind()'ed version of onMouseMove_, suitable for using as an event
   * callback.
   *
   * @type {!Function}
   * @private
   */
  this.boundOnMouseMove_ = goog.bind(this.onMouseMove_, this);


  talk.media.c3d.FixedAreaFeed.call(this, o3dBundle, endpoint, depth,
      x, y, width, height, true);
};
goog.inherits(talk.media.c3d.LabeledFeed, talk.media.c3d.FixedAreaFeed);


/**
 * The time to show the label when feed appeared.
 *
 * @type {number}
 * @const
 * @private
 */
talk.media.c3d.LabeledFeed.SHOW_ON_START_MS_ = 7 * 1000;


/**
 * The time to show the label when mouse hovered over the feed.
 *
 * @type {number}
 * @const
 * @private
 */
talk.media.c3d.LabeledFeed.SHOW_ON_MOUSE_MS_ = 3 * 1000;


/**
 * The ID of the timer that hides the label on timeout.
 *
 * @type {?number}
 * @private
 */
talk.media.c3d.LabeledFeed.prototype.hideTimerId_;


/**
 * A tween to hide the label by fading.
 *
 * @type {talk.media.c3d.AlphaTween}
 * @private
 */
talk.media.c3d.LabeledFeed.prototype.labelHider_;


/**
 * The label to show on the feed.
 *
 * @type {talk.media.c3d.Image}
 * @private
 */
talk.media.c3d.LabeledFeed.prototype.label_ = null;


/**
 * Our logger.
 *
 * @type {goog.debug.Logger}
 * @private
 */
talk.media.c3d.LabeledFeed.prototype.logger_ =
    goog.debug.Logger.getLogger('talk.media.c3d.LabeledFeed');


/**
 * @override
 * @protected
 */
talk.media.c3d.LabeledFeed.prototype.createFeedObject = function() {
  var feedObject =
      talk.media.c3d.LabeledFeed.superClass_.createFeedObject.call(this);

  this.createLocalView_(feedObject);

  var text = this.getEndpoint().getJid().split('@', 1)[0];
  this.label_ = this.createLabelImage_(text);

  var c3d = this.o3dBundle.c3dObject.getPlugin();
  talk.media.c3d.addEventCallback(c3d, 'mousemove', this.boundOnMouseMove_);

  this.showLabel(talk.media.c3d.LabeledFeed.SHOW_ON_START_MS_);

  return feedObject;
};


/**
 * @override
 * @protected
 */
talk.media.c3d.LabeledFeed.prototype.updatePosition = function(attrs) {
  talk.media.c3d.LabeledFeed.superClass_.updatePosition.call(this, attrs);
  this.label_.moveTo((attrs.w - this.label_.width()) / 2,
                     attrs.h - this.label_.height() * 1.5);
};


/**
 * Setup a view for displaying images on top of the video feed.
 *
 * @param {talk.media.c3d.SceneObject} feedObject The object displaying the
 *     feed.
 * @private
 */
talk.media.c3d.LabeledFeed.prototype.createLocalView_ = function(feedObject) {
  var c3d = this.o3dBundle.c3dObject.getPlugin();

  this.imageView_ = new talk.media.c3d.View(c3d, this.o3dBundle.pack, 2, true,
      this.o3dBundle, feedObject.getTransform());

  this.imageOverlay_ = new talk.media.c3d.ImageOverlay(this.o3dBundle,
      this.imageView_);
};


/**
 * Create an image in the local view with the text rendered on it.
 *
 * @param {string} text The text to render on the image.
 * @return {talk.media.c3d.Image} Image with the text.
 * @private
 */
talk.media.c3d.LabeledFeed.prototype.createLabelImage_ = function(text) {
  return this.imageOverlay_.createMessageImage(text, 12, 1);
};


/**
 * Shows the label for a specified amount of time. After that the label will
 * fade out.
 *
 * @param {number} interval The number of milliseconds to show the label.
 */
talk.media.c3d.LabeledFeed.prototype.showLabel = function(interval) {
  this.cancelHideTween_();
  if (!this.label_) {
    this.logger_.warning('No label to show.');
    return;
  }

  this.label_.setVisible(true);
  this.label_.setAlpha(1);

  this.clearHideTimer_();
  this.hideTimerId_ = goog.Timer.callOnce(this.hideLabel, interval, this);
};


/**
 * Hides the label.
 */
talk.media.c3d.LabeledFeed.prototype.hideLabel = function() {
  this.clearHideTimer_();
  if (this.label_) {
    this.labelHider_ = new talk.media.c3d.AlphaTween(this.label_,
        this.label_.getAlpha(), 0, 1, talk.media.c3d.REGULAR_EASE_IN,
        goog.bind(this.finishHideLabel_, this));
    this.o3dBundle.c3dEngine.registerRenderCallback(this.labelHider_);
  }
};


/**
 * Cancels and removes the tween for hiding.
 * @private
 */
talk.media.c3d.LabeledFeed.prototype.cancelHideTween_ = function() {
  if (this.labelHider_) {
    this.o3dBundle.c3dEngine.unregisterRenderCallback(this.labelHider_);
    this.labelHider_ = null;
  }
};


/**
 * Finalizes the hiding of the label. Cancels and removes the tween.
 * @private
 */
talk.media.c3d.LabeledFeed.prototype.finishHideLabel_ = function() {
  this.cancelHideTween_();
  this.label_.setVisible(false);
};


/**
 * Clears the timer for hiding the label.
 * @private
 */
talk.media.c3d.LabeledFeed.prototype.clearHideTimer_ = function() {
  if (this.hideTimerId_) {
    goog.Timer.clear(this.hideTimerId_);
    this.hideTimerId_ = null;
  }
};


/**
 * Responds to mousemove events by showing the label.
 *
 * @param {Object} e The O3D Plugin event object which is generic for all types
 *     of O3D events.
 * @private
 */
talk.media.c3d.LabeledFeed.prototype.onMouseMove_ = function(e) {
  if (this.hitTest(e.x, e.y)) {
    this.showLabel(talk.media.c3d.LabeledFeed.SHOW_ON_MOUSE_MS_);
  }
};


/**
 * Returns whether the position is inside the feed area.
 *
 * @param {number} x Horizontal position.
 * @param {number} y Vertical position.
 * @return {boolean} True iff inside.
 */
talk.media.c3d.LabeledFeed.prototype.hitTest = function(x, y) {
  return x >= this.x && x <= this.x + this.width &&
         y >= this.y && y <= this.y + this.height;
};


/**
 * @override
 * @protected
 */
talk.media.c3d.LabeledFeed.prototype.disposeInternal = function() {
  talk.media.c3d.LabeledFeed.superClass_.disposeInternal.call(this);

  this.clearHideTimer_();
  if (this.o3dBundle.c3dObject.isScriptable()) {
    var c3d = this.o3dBundle.c3dObject.getPlugin();
    talk.media.c3d.removeEventCallback(c3d, 'mousemove',
        this.boundOnMouseMove_);
  }
  if (this.label_) {
    this.label_.disposeC3d();
    this.label_ = null;
  }
};
