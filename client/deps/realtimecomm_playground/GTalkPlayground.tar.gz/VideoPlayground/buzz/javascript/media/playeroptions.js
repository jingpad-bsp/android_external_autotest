// Copyright 2010 Google Inc. All Rights Reserved.

/**
 * @fileoverview Options for C3dCommunicationPlayer, like options for the PIP
 * and automatically hiding controls on idle or not.
 * @author geer@google.com (Arthur van der Geer)
 */

goog.provide('talk.media.PlayerOptions');

goog.require('talk.media.c3d.PipOptions');


/**
 * Constructs an object to get and set options for the player.
 *
 * @param {string} locale The locale to use for messages.
 * @constructor
 */
talk.media.PlayerOptions = function(locale) {

  /**
   * The options for the PIP.
   *
   * @type {talk.media.c3d.PipOptions}
   * @private
   */
  this.pipOptions_ = new talk.media.c3d.PipOptions();


  /**
   * Whether controls should be hidden automatically on idle mouse or not.
   *
   * @type {boolean}
   * @private
   */
  this.autoHideControls_ = true;


  /**
   * Whether fullscreen mode should be included or not.
   *
   * @type {boolean}
   * @private
   */
  this.includeFullscreen_ = true;


  /**
   * The locale to use for messages.
   *
   * @type {string}
   * @private
   */
  this.locale_ = locale;

};


/**
 * Returns the options for the PIP.
 *
 * @returns {talk.media.c3d.PipOptions}
 */
talk.media.PlayerOptions.prototype.getPip = function() {
  return this.pipOptions_;
};


/**
 * Returns whether controls should be hidden automatically on idle mouse or not.
 *
 * @returns {boolean} True iff constrols should hide automatically.
 */
talk.media.PlayerOptions.prototype.getAutoHideControls = function() {
  return this.autoHideControls_;;
};


/**
 * Sets whether controls should be hidden automatically on idle mouse or not.
 *
 * @param {boolean} autoHide True iff constrols should hide automatically.
 */
talk.media.PlayerOptions.prototype.setAutoHideControls = function(autoHide) {
  this.autoHideControls_ = autoHide;
};


/**
 * Returns whether fullscreen mode should be included or not.
 *
 * @returns {boolean} True iff fullscreen should be included.
 */
talk.media.PlayerOptions.prototype.getIncludeFullscreen = function() {
  return this.includeFullscreen_;
};


/**
 * Sets whether fullscreen mode should be included or not.
 *
 * @param {boolean} include True iff fullscreen should be included.
 */
talk.media.PlayerOptions.prototype.setIncludeFullscreen = function(include) {
  this.includeFullscreen_ = include;
};


/**
 * Returns the locale to use for messages.
 *
 * @returns {string} The locale to use for messages.
 */
talk.media.PlayerOptions.prototype.getLocale = function() {
  return this.locale_;
};


/**
 * Sets the locale to use for messages.
 *
 * @param {string} locale The locale to use for messages.
 */
talk.media.PlayerOptions.prototype.setLocale = function(locale) {
  this.locale_ = locale;
};
