// Copyright 2009 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview A simple container for global O3D handles, factories, etc. for
 * handy access.
 *
 * @author tschmelcher@google.com (Tristan Schmelcher)
 */

goog.provide('talk.media.c3d.O3dBundle');


/**
 * A simple container for global O3D handles, factories, etc. for handy access.
 * Many different classes require these, so having a container for them
 * simplifies things by reducing the number of fields and constructor arguments
 * in other classes.
 *
 * @constructor
 */
talk.media.c3d.O3dBundle = function() {
};


/**
 * A simple object encapsulating the O3D plugin instance.
 *
 * @type {talk.media.c3d.C3dObject}
 */
talk.media.c3d.O3dBundle.prototype.c3dObject;


/**
 * The engine for managing real-time scene logic.
 *
 * @type {talk.media.c3d.C3dEngine}
 */
talk.media.c3d.O3dBundle.prototype.c3dEngine;


/**
 * Manager for sharing access to the cursor.
 *
 * @type {talk.media.c3d.CursorManager}
 */
talk.media.c3d.O3dBundle.prototype.cursorManager;


/**
 * The C3D DrawContext object.
 *
 * @type Object
 */
talk.media.c3d.O3dBundle.prototype.drawContext;


/**
 * The O3D Pack object.
 *
 * @type {Object}
 */
talk.media.c3d.O3dBundle.prototype.pack;


/**
 * The O3D View object.
 *
 * @type {Object}
 */
talk.media.c3d.O3dBundle.prototype.view;


/**
 * Cached value of O3D display pane's width, for faster lay-out logic.
 *
 * @type {number}
 */
talk.media.c3d.O3dBundle.prototype.width;


/**
 * Cached value of O3D display pane's height, for faster lay-out logic.
 *
 * @type {number}
 */
talk.media.c3d.O3dBundle.prototype.height;


/**
 * The O3D Effect object, specifying the shader to use.
 *
 * @type {Object}
 */
talk.media.c3d.O3dBundle.prototype.effect;
