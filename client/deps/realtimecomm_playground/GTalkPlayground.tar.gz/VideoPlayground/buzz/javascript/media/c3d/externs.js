// Copyright 2009 Google Inc. All Rights Reserved.

/**
 * @fileoverview External properties for O3D Plugin objects.
 * @author geer@google.com (Arthur van der Geer)
 */

// The Element type originates from the reference to the embedded plugin object.
Element.prototype.o3d;

var o3d = {};

/** @constructor */
o3d.Canvas = function() {};
o3d.Canvas.prototype.copyToTexture = function(texture) {};
o3d.Canvas.prototype.drawText = function(text, x, y, paint) {};

/** @constructor */
o3d.CanvasPaint = function() {};
o3d.CanvasPaint.CENTER;
o3d.CanvasPaint.prototype.setOutline = function(radius, color) {};

/** @constructor */
o3d.Material = function() {};
o3d.Material.effect;

/** @constructor */
o3d.Pack = function() {};
o3d.Pack.prototype.createObject = function(typeName) {};
o3d.Pack.prototype.createTexture2D =
    function(width, height, format, levels, enableRenderSurfaces) {};

/** @constructor */
o3d.Texture = function() {};
o3d.Texture.ARGB8;
