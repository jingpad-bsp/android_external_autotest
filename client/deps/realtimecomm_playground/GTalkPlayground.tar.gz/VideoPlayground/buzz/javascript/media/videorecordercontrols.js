// Copyright 2008 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview Control buttons for talk.media.VideoRecorder.
 * talk.media.VideoRecorderControls is a goog.ui.Component with buttons for
 * Record, Stop, Replay, and Delete. Also includes status buttons for Recording
 * and Replaying. There may be one or two buttons visible at a time. Which
 * button or pair is visible is controlled by calling one of the show[name]
 * functions.
 *
 * @author kmd@google.com (Krista Davis)
 */
goog.provide('talk.media.VideoRecorderControls');

goog.require('goog.dom');
goog.require('goog.dom.classes');
goog.require('goog.structs.Set');
goog.require('goog.ui.Button');
goog.require('goog.ui.Component');
goog.require('goog.ui.ImagelessButtonRenderer');

/**
 * Component for the control buttons for the VideoRecorder.
 * @param {goog.dom.DomHelper} opt_domHelper Optional DOM helper.
 * @constructor
 * @extends {goog.ui.Component}
 */
talk.media.VideoRecorderControls = function(opt_domHelper) {
  goog.ui.Component.call(this, opt_domHelper);
  /**
   * @type goog.ui.ImagelessButtonRenderer
   * @private
   */
  this.renderer_ = goog.ui.ImagelessButtonRenderer.getInstance();
};
talk.media.VideoRecorderControls.inherits(goog.ui.Component);


/** @desc Button to begin recording webcam data. */
talk.media.VideoRecorderControls.MSG_RECORD = goog.getMsg('Start Recording');


/** @desc Button to cancel recording webcam data. */
talk.media.VideoRecorderControls.MSG_CANCEL = goog.getMsg('Cancel');


/**
 * @desc Button to stop either recording webcam data, or stop replaying
 * previously recorded webcam data.
 */
talk.media.VideoRecorderControls.MSG_STOP = goog.getMsg('Stop');


/** @desc Button to begin playback of previously recorded webcam data. */
talk.media.VideoRecorderControls.MSG_REPLAY = goog.getMsg('Replay');


/** @desc Button to save the current webcam data. */
talk.media.VideoRecorderControls.MSG_SAVE = goog.getMsg('Save');


/**
 * @desc Button to delete previously recorded webcam data and start over
 * again.
 */
talk.media.VideoRecorderControls.MSG_START_OVER = goog.getMsg('Start Over');


/**
 * Button identifiers.
 * @enum {string}
 */
talk.media.VideoRecorderControls.ButtonId = {
  RECORD: 'record',
  STOP: 'stop',
  REPLAY: 'replay',
  SAVE: 'save',
  START_OVER: 'restart',
  CANCEL: 'cancel'
};

/**
 * Control states which define visible buttons.
 * @enum {goog.structs.Set}
 */
talk.media.VideoRecorderControls.State = {
  START: new goog.structs.Set(
    [talk.media.VideoRecorderControls.ButtonId.RECORD,
     talk.media.VideoRecorderControls.ButtonId.CANCEL]),
  RECORDING: new goog.structs.Set(
    [talk.media.VideoRecorderControls.ButtonId.STOP,
     talk.media.VideoRecorderControls.ButtonId.START_OVER,
     talk.media.VideoRecorderControls.ButtonId.CANCEL]),
  HAVE_RECORDED: new goog.structs.Set(
    [talk.media.VideoRecorderControls.ButtonId.REPLAY,
     talk.media.VideoRecorderControls.ButtonId.SAVE,
     talk.media.VideoRecorderControls.ButtonId.START_OVER,
     talk.media.VideoRecorderControls.ButtonId.CANCEL]),
  REPLAYING: new goog.structs.Set(
    [talk.media.VideoRecorderControls.ButtonId.STOP,
     talk.media.VideoRecorderControls.ButtonId.SAVE,
     talk.media.VideoRecorderControls.ButtonId.START_OVER,
     talk.media.VideoRecorderControls.ButtonId.CANCEL])
};


/**
 * {@inheritDoc}
 */
talk.media.VideoRecorderControls.prototype.enterDocument = function() {
  talk.media.VideoRecorderControls.superClass_.enterDocument.call(this);

  /**
   * Object holding all button references.
   * @type Object
   * @private
   */
  this.buttons_ = {};

  this.createButton_(talk.media.VideoRecorderControls.MSG_RECORD,
      talk.media.VideoRecorderControls.ButtonId.RECORD,
      [goog.getCssName('CSS_VIDEO_RECORDER_CONTROLS_LEFT')]);

  this.createButton_(talk.media.VideoRecorderControls.MSG_STOP,
      talk.media.VideoRecorderControls.ButtonId.STOP,
      [goog.getCssName('CSS_VIDEO_RECORDER_CONTROLS_LEFT'),
        goog.getCssName('goog-imageless-button-collapse-right')]);

  this.createButton_(talk.media.VideoRecorderControls.MSG_REPLAY,
      talk.media.VideoRecorderControls.ButtonId.REPLAY,
      [goog.getCssName('CSS_VIDEO_RECORDER_CONTROLS_LEFT'),
        goog.getCssName('goog-imageless-button-collapse-right')]);

  this.createButton_(talk.media.VideoRecorderControls.MSG_SAVE,
      talk.media.VideoRecorderControls.ButtonId.SAVE,
      [goog.getCssName('CSS_VIDEO_RECORDER_CONTROLS_LEFT'),
        goog.getCssName('goog-imageless-button-collapse-right'),
        goog.getCssName('goog-imageless-button-collapse-left')]);

  this.createButton_(talk.media.VideoRecorderControls.MSG_START_OVER,
      talk.media.VideoRecorderControls.ButtonId.START_OVER,
      [goog.getCssName('CSS_VIDEO_RECORDER_CONTROLS_LEFT'),
        goog.getCssName('goog-imageless-button-collapse-left')]);

  this.createButton_(talk.media.VideoRecorderControls.MSG_CANCEL,
      talk.media.VideoRecorderControls.ButtonId.CANCEL,
      [goog.getCssName('CSS_VIDEO_RECORDER_CONTROLS_RIGHT')]);

  this.setState(talk.media.VideoRecorderControls.State.START);
};

/**
 * Creates a new button with the given text and CSS classes. Appends it to this
 * component. Button is hidden when created.
 * @param {string} text The text content of the new button
 * @param {talk.media.VideoRecorderControls.ButtonId} value The button id
 * @param {Array.<string>} css The CSS classes
 * @return {goog.ui.Button} The new button
 * @private
 */
talk.media.VideoRecorderControls.prototype.createButton_ = function(text, value,
      css) {
  var button = new goog.ui.Button(text, this.renderer_, this.dom_);
  for (var i = 0; i < css.length; i++) {
    button.addClassName(css[i]);
  }
  button.setVisible(false);

  button.setValue(value);
  button.render(this.getElement());

  this.addChild(button);
  this.buttons_[value] = button;
  return button;
};


/**
 * Enables or disables all the control buttons.
 * @param {boolean} enabled true to enable, false to disable.
 */
talk.media.VideoRecorderControls.prototype.setEnabled = function(enabled) {
  for (var id in this.buttons_) {
    this.buttons_[id].setEnabled(enabled);
  }
};


/**
 * Sets the active (visible) controls.
 *
 * @param {talk.media.VideoRecorderControls.State} buttonState
     The state of the buttons
 */
talk.media.VideoRecorderControls.prototype.setState = function(buttonState) {
  for (var id in this.buttons_) {
    this.buttons_[id].setVisible(buttonState.contains(id));
  }
};
