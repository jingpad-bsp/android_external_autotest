// Copyright 2008 Google Inc.
// All Rights Reserved.

/**
 * @fileoverview A few miscellaneous helper functions.
 *
 * @author tschmelcher@google.com (Tristan Schmelcher)
 */

goog.provide('talk.media.c3d.helpers');


/**
 * Helper function to compute the texture coordinates array for a texture of a
 * given width/height which is embedded in the top-left of a texture buffer with
 * another (potentially larger) width/height, optionally mirroring it. This can
 * then be used as the TEXCOORD vertex stream to display precisely that portion
 * of the texture buffer.
 *
 * @param {number} embWidth The width of the embedded texture.
 * @param {number} embHeight The height of the embedded texture.
 * @param {number} bufWidth The width of the texture buffer.
 * @param {number} bufHeight The height of the texture buffer.
 * @param {boolean} mirror Whether to mirror the texture or not.
 * @return {Array} The texture coordinates array.
 */
talk.media.c3d.computeTextureCoords = function(embWidth, embHeight, bufWidth,
    bufHeight, mirror) {
  var w = embWidth / bufWidth;
  var h = embHeight / bufHeight;
  // Our texture coordinates are in pairs of floats
  if (mirror) {
    return [
      w, 0,  // top-left
      w, h,  // bottom-left
      0, h,  // bottom-right
      0, 0   // top-right
    ];
  } else {
    return [
      0, 0,  // top-left
      0, h,  // bottom-left
      w, h,  // bottom-right
      w, 0   // top-right
    ];
  }
};


/**
 * Computes a 4-by-4 orthographic projection matrix given the coordinates of the
 * planes defining the axis-aligned, box-shaped viewing volume.  The matrix
 * generated sends that box to the unit box.  Note that although left and right
 * are x coordinates and bottom and top are y coordinates, near and far
 * are not z coordinates, but rather they are distances along the negative
 * z-axis.  We assume a unit box extending from -1 to 1 in the x and y
 * dimensions and from 0 to 1 in the z dimension.
 *
 * Copied from CLIENT3DJS.math.matrix4.orthographic() in client3d-math.js.
 *
 * @param {number} left The x coordinate of the left plane of the box.
 * @param {number} right The x coordinate of the right plane of the box.
 * @param {number} bottom The y coordinate of the bottom plane of the box.
 * @param {number} top The y coordinate of the right plane of the box.
 * @param {number} near The negative z coordinate of the near plane of the box.
 * @param {number} far The negative z coordinate of the far plane of the box.
 * @return {Array} The orthographic projection matrix as an array of arrays.
 */
talk.media.c3d.createOrthographicMatrix =
    function(left, right, bottom, top, near, far) {
  return [
    [2 / (right - left), 0, 0, 0],
    [0, 2 / (top - bottom), 0, 0],
    [0, 0, 1 / (near - far), 0],
    [(left + right) / (left - right),
     (bottom + top) / (bottom - top),
     near / (near - far), 1]
  ];
};


/**
 * Divides a vector by its Euclidean length and returns the quotient.
 *
 * Copied from CLIENT3DJS.math.normalize() in client3d-math.js.
 *
 * @param {Array} a The vector, as a 3-value array.
 * @return {Array} The normalized vector.
 */
talk.media.c3d.normalize = function(a) {
  var r = [];
  var n = 0.0;
  var aLength = a.length;
  for (var i = 0; i < aLength; ++i)
    n += a[i] * a[i];
  n = Math.sqrt(n);
  for (var i = 0; i < aLength; ++i)
    r[i] = a[i] / n;
  return r;
};


/**
 * Subtracts two vectors.
 *
 * Copied from CLIENT3DJS.math.subVector() in client3d-math.js.
 *
 * @param {Array} a Operand vector.
 * @param {Array} b Operand vector.
 * @return {Array} The difference of a and b.
 */
talk.media.c3d.subVector = function(a, b) {
  var r = [];
  var aLength = a.length;
  for (var i = 0; i < aLength; ++i)
    r[i] = a[i] - b[i];
  return r;
};


/**
 * Computes the cross product of two vectors; assumes both vectors have
 * three entries.
 *
 * Copied from CLIENT3DJS.math.cross() in client3d-math.js.
 *
 * @param {Array} a Operand vector.
 * @param {Array} b Operand vector.
 * @return {Array} The vector a cross b.
 */
talk.media.c3d.cross = function(a, b) {
  return [a[1] * b[2] - a[2] * b[1],
          a[2] * b[0] - a[0] * b[2],
          a[0] * b[1] - a[1] * b[0]];
};


/**
 * Computes the inverse of a 4-by-4 matrix.
 *
 * Copied from CLIENT3DJS.math.inverse4 in client3d-math.js.
 *
 * @param {Array} m The matrix.
 * @return {Array} The inverse of m.
 */
talk.media.c3d.inverse4 = function(m) {
  var tmp_0 = m[2][2] * m[3][3];
  var tmp_1 = m[3][2] * m[2][3];
  var tmp_2 = m[1][2] * m[3][3];
  var tmp_3 = m[3][2] * m[1][3];
  var tmp_4 = m[1][2] * m[2][3];
  var tmp_5 = m[2][2] * m[1][3];
  var tmp_6 = m[0][2] * m[3][3];
  var tmp_7 = m[3][2] * m[0][3];
  var tmp_8 = m[0][2] * m[2][3];
  var tmp_9 = m[2][2] * m[0][3];
  var tmp_10 = m[0][2] * m[1][3];
  var tmp_11 = m[1][2] * m[0][3];
  var tmp_12 = m[2][0] * m[3][1];
  var tmp_13 = m[3][0] * m[2][1];
  var tmp_14 = m[1][0] * m[3][1];
  var tmp_15 = m[3][0] * m[1][1];
  var tmp_16 = m[1][0] * m[2][1];
  var tmp_17 = m[2][0] * m[1][1];
  var tmp_18 = m[0][0] * m[3][1];
  var tmp_19 = m[3][0] * m[0][1];
  var tmp_20 = m[0][0] * m[2][1];
  var tmp_21 = m[2][0] * m[0][1];
  var tmp_22 = m[0][0] * m[1][1];
  var tmp_23 = m[1][0] * m[0][1];

  var t0 = (tmp_0 * m[1][1] + tmp_3 * m[2][1] + tmp_4 * m[3][1]) -
      (tmp_1 * m[1][1] + tmp_2 * m[2][1] + tmp_5 * m[3][1]);
  var t1 = (tmp_1 * m[0][1] + tmp_6 * m[2][1] + tmp_9 * m[3][1]) -
      (tmp_0 * m[0][1] + tmp_7 * m[2][1] + tmp_8 * m[3][1]);
  var t2 = (tmp_2 * m[0][1] + tmp_7 * m[1][1] + tmp_10 * m[3][1]) -
      (tmp_3 * m[0][1] + tmp_6 * m[1][1] + tmp_11 * m[3][1]);
  var t3 = (tmp_5 * m[0][1] + tmp_8 * m[1][1] + tmp_11 * m[2][1]) -
      (tmp_4 * m[0][1] + tmp_9 * m[1][1] + tmp_10 * m[2][1]);

  var d = 1.0 / (m[0][0] * t0 + m[1][0] * t1 + m[2][0] * t2 + m[3][0] * t3);

  return [[d * t0, d * t1, d * t2, d * t3],
      [d * ((tmp_1 * m[1][0] + tmp_2 * m[2][0] + tmp_5 * m[3][0]) -
          (tmp_0 * m[1][0] + tmp_3 * m[2][0] + tmp_4 * m[3][0])),
       d * ((tmp_0 * m[0][0] + tmp_7 * m[2][0] + tmp_8 * m[3][0]) -
          (tmp_1 * m[0][0] + tmp_6 * m[2][0] + tmp_9 * m[3][0])),
       d * ((tmp_3 * m[0][0] + tmp_6 * m[1][0] + tmp_11 * m[3][0]) -
          (tmp_2 * m[0][0] + tmp_7 * m[1][0] + tmp_10 * m[3][0])),
       d * ((tmp_4 * m[0][0] + tmp_9 * m[1][0] + tmp_10 * m[2][0]) -
          (tmp_5 * m[0][0] + tmp_8 * m[1][0] + tmp_11 * m[2][0]))],
      [d * ((tmp_12 * m[1][3] + tmp_15 * m[2][3] + tmp_16 * m[3][3]) -
          (tmp_13 * m[1][3] + tmp_14 * m[2][3] + tmp_17 * m[3][3])),
       d * ((tmp_13 * m[0][3] + tmp_18 * m[2][3] + tmp_21 * m[3][3]) -
          (tmp_12 * m[0][3] + tmp_19 * m[2][3] + tmp_20 * m[3][3])),
       d * ((tmp_14 * m[0][3] + tmp_19 * m[1][3] + tmp_22 * m[3][3]) -
          (tmp_15 * m[0][3] + tmp_18 * m[1][3] + tmp_23 * m[3][3])),
       d * ((tmp_17 * m[0][3] + tmp_20 * m[1][3] + tmp_23 * m[2][3]) -
          (tmp_16 * m[0][3] + tmp_21 * m[1][3] + tmp_22 * m[2][3]))],
      [d * ((tmp_14 * m[2][2] + tmp_17 * m[3][2] + tmp_13 * m[1][2]) -
          (tmp_16 * m[3][2] + tmp_12 * m[1][2] + tmp_15 * m[2][2])),
       d * ((tmp_20 * m[3][2] + tmp_12 * m[0][2] + tmp_19 * m[2][2]) -
          (tmp_18 * m[2][2] + tmp_21 * m[3][2] + tmp_13 * m[0][2])),
       d * ((tmp_18 * m[1][2] + tmp_23 * m[3][2] + tmp_15 * m[0][2]) -
          (tmp_22 * m[3][2] + tmp_14 * m[0][2] + tmp_19 * m[1][2])),
       d * ((tmp_22 * m[2][2] + tmp_16 * m[0][2] + tmp_21 * m[1][2]) -
          (tmp_20 * m[1][2] + tmp_23 * m[2][2] + tmp_17 * m[0][2]))]];
};


/**
 * Computes a 4-by-4 look-at transformation.  The transformation generated is
 * an orthogonal rotation matrix with translation component.  The translation
 * component sends the eye to the origin.  The rotation component sends the
 * vector pointing from the eye to the target to a vector pointing in the
 * negative z direction, and also sends the up vector into the upper half of
 * the yz plane.
 *
 * Copied from CLIENT3DJS.math.matrix4.lookAt() in client3d-math.js.
 *
 * @param {Array} eye The position of the eye, as a 3-value array.
 * @param {Array} target The position meant to be viewed, as a 3-value array.
 * @param {Array} up A vector pointing up, as a 3-value array.
 * @return {Array} The look-at matrix.
 */
talk.media.c3d.createLookAtMatrix = function(eye, target, up) {
  var vz = talk.media.c3d.normalize(
      talk.media.c3d.subVector(eye, target).slice(0, 3)).concat(0);
  var vx = talk.media.c3d.normalize(
      talk.media.c3d.cross(up, vz)).concat(0);
  var vy = talk.media.c3d.cross(vz, vx).concat(0);

  return talk.media.c3d.inverse4([vx, vy, vz, eye.concat(1)]);
};


/**
 * Creates a 4-by-4 matrix which scales in each dimension by an amount given by
 * the corresponding entry in the given vector; assumes the vector has three
 * entries.
 *
 * Copied from CLIENT3DJS.math.matrix4.scaling in client3d-math.js.
 *
 * @param {Array} v A vector of three entries specifying the factor by which to
 * scale in each dimension.
 * @return {Array} The scaling matrix.
 */
talk.media.c3d.scaling = function(v) {
  return [
    [v[0], 0, 0, 0],
    [0, v[1], 0, 0],
    [0, 0, v[2], 0],
    [0, 0, 0, 1]
  ];
};


/**
 * Modifies the given 4-by-4 matrix by translation by the given vector v.
 *
 * Copied from CLIENT3DJS.math.matrix4.translate in client3d-math.js.
 *
 * @param {Array} m The matrix.
 * @param {Array} v The vector by which to translate.
 * @return {Array} m once modified.
 */
talk.media.c3d.translate = function(m, v) {
  var v0 = v[0];
  var v1 = v[1];
  var v2 = v[2];
  var m0 = m[0];
  var m1 = m[1];
  var m2 = m[2];
  var m3 = m[3];
  var m00 = m0[0];
  var m01 = m0[1];
  var m02 = m0[2];
  var m03 = m0[3];
  var m10 = m1[0];
  var m11 = m1[1];
  var m12 = m1[2];
  var m13 = m1[3];
  var m20 = m2[0];
  var m21 = m2[1];
  var m22 = m2[2];
  var m23 = m2[3];
  var m30 = m3[0];
  var m31 = m3[1];
  var m32 = m3[2];
  var m33 = m3[3];

  m0.splice(0, 3, m00 + m03 * v0, m01 + m03 * v1, m02 + m03 * v2);
  m1.splice(0, 3, m10 + m13 * v0, m11 + m13 * v1, m12 + m13 * v2);
  m2.splice(0, 3, m20 + m23 * v0, m21 + m23 * v1, m22 + m23 * v2);
  m3.splice(0, 3, m30 + m33 * v0, m31 + m33 * v1, m32 + m33 * v2);

  return m;
};


/**
 * Takes a 4-by-4 matrix and a vector with 3 entries,
 * interprets the vector as a point, transforms that point by the matrix, and
 * returns the result as a vector with 3 entries.
 *
 * @param {Array} m The matrix.
 * @param {Array} v The point.
 * @return {Array} The transformed point.
 */
talk.media.c3d.transformPoint = function(m, v) {
  var v0 = v[0];
  var v1 = v[1];
  var v2 = v[2];
  var m0 = m[0];
  var m1 = m[1];
  var m2 = m[2];
  var m3 = m[3];

  var d = v0 * m0[3] + v1 * m1[3] + v2 * m2[3] + m3[3];
  return [(v0 * m0[0] + v1 * m1[0] + v2 * m2[0] + m3[0]) / d,
          (v0 * m0[1] + v1 * m1[1] + v2 * m2[1] + m3[1]) / d,
          (v0 * m0[2] + v1 * m1[2] + v2 * m2[2] + m3[2]) / d];
};


/**
  * Creates an XY plane.
  * See also o3djs.primitives.createPlane() in o3djs.primitives.js.
  * @param {Object} c3d The C3D Plugin instance.
  * @param {Object} pack The C3D Pack object to use.
  * @param {Object} material The C3D Material object to use.
  * @param {Object} textureCoordField The C3D Field on the texture VertexBuffer
  *                 for storing the texture coordinates.
  * @return {Object} A C3D Shape object.
  */
talk.media.c3d.createPlane = function(c3d, pack, material, textureCoordField) {
  // First, create a 'shape' and 'primitive' to store the quad.
  var shape = pack['createObject']('Shape');
  var primitive = pack['createObject']('Primitive');
  primitive['owner'] = shape;

  // Set its material
  primitive['material'] = material;

  // The quad is made of 2 triangles.
  primitive['numberPrimitives'] = 2;
  primitive['primitiveType'] = c3d['o3d']['Primitive']['TRIANGLELIST'];
  primitive['numberVertices'] = 4;
  primitive['createDrawElement'](pack, null);

  // These next few lines take our javascript arrays and load them into some
  // 'buffers' where the 3D hardware can find them. We have to do this because
  // the 3D hardware can't 'see' javascript data until it is in a buffer.
  // Create a javascript array that gives the coordinates of each of the
  // vertices.
  // Also note that by default, triangles with vertices given anticlockwise
  // are culled, so we have to orient our triangles properly.
  // i.e., vertices should be given in a clockwise fashion in the index
  // buffer.
  var vertexBuffer = pack['createObject']('VertexBuffer');
  var positionField = vertexBuffer['createField']('FloatField', 3);
  vertexBuffer['set']([
    0, 0, 0,
    0, 1, 0,
    1, 1, 0,
    1, 0, 0
  ]);

  // Our index array defines the order of the vertices we want to draw.
  // Here we tell the renderer to draw the vertices in the order we gave them.
  // ie. Vertex 0, then Vertex 1, etc.
  var indexBuffer = pack['createObject']('IndexBuffer');
  indexBuffer['set']([0, 1, 2, 0, 2, 3]);

  // Now we associate these 'buffers' of data with our primitive so that it can
  // access the data.
  var streamBank = pack['createObject']('StreamBank');
  primitive['streamBank'] = streamBank;

  streamBank['setVertexStream'](c3d['o3d']['Stream']['POSITION'], 0,
                                positionField, 0);

  streamBank['setVertexStream'](c3d['o3d']['Stream']['TEXCOORD'], 0,
                                textureCoordField, 0);
  primitive['indexBuffer'] = indexBuffer;

  return shape;
};


/**
 * Function to add event listeners on the o3d plugin object.
 * See also o3djs.event.addEventListener() in o3djs/event.js.
 *
 * @param {Object} c3d The C3D Plugin instance.
 * @param {string} type The type of event.
 * @param {Object} handler The call back function.
 */
talk.media.c3d.addEventCallback = function(c3d, type, handler) {
  // Get the registry of o3d plugin callbacks.
  c3d['eventCallbackMap'] = c3d['eventCallbackMap'] || [];
  var callbacks = c3d['eventCallbackMap'][type];
  if (!callbacks || callbacks.length == 0) {
    // Initialize a new list and register one function to call them all.
    callbacks = c3d['eventCallbackMap'][type] = [];
    c3d['client']['setEventCallback'](type, goog.bind(function(event) {
      for (var i in callbacks) {
        callbacks[i](event);
      }
    }, callbacks));
  } else {
    // Check if the handler is already here.
    for (var i in callbacks) {
      if (callbacks[i] == handler) {
        return;
      }
    }
  }
  callbacks.push(handler);
};


/**
 * Function to remove event listeners from the o3d plugin object.
 * See also o3djs.event.removeEventListener() in o3djs/event.js.
 *
 * @param {Object} c3d The C3D Plugin instance.
 * @param {string} type The type of event.
 * @param {Object} handler The call back function.
 */
talk.media.c3d.removeEventCallback = function(c3d, type, handler) {
  if (!c3d['eventCallbackMap']) {
    return;
  }
  var callbacks = c3d['eventCallbackMap'][type];
  if (!callbacks) {
    return;
  }
  for (var i in callbacks) {
    if (callbacks[i] == handler) {
      if (callbacks.length == 1) {
        c3d['client']['clearEventCallback'](type);
      }
      callbacks.splice(i, 1);
      return;
    }
  }
};


/**
 * Returns the lowest non-negative power of two that is not less than val; i.e.,
 * rounds up to the next power of two.
 *
 * Optimized implementation that runs in O(log(log(n)). Based on
 * http://en.wikipedia.org/wiki/Power_of_two#Algorithm_to_find_the_next-highest_power_of_two
 * but generalized to work with any integer width.
 *
 * @param {number} val The number to round.
 * @return {number} The rounded number.
 */
talk.media.c3d.powerOfTwoCeiling = function(val) {
  if (val <= 0) {
    return 0;
  }
  val--;
  var shift = 1;
  while (((val + 1) & val) != 0) {
    val |= val >> shift;
    shift <<= 1;
  }
  return val + 1;
};


/**
 * Draws a solid quarter circle on the given canvas.
 *
 * @param {Object} canvas The O3D Canvas to draw on.
 * @param {Object} canvasPaint The O3D CanvasPaint object with the drawing
 * context.
 * @param {number} x Integer x-coordinate for the circle's center.
 * @param {number} y Integer y-coordinate for the circle's center.
 * @param {number} radius Radius of the circle. Must be >= 0.5.
 * @param {number} quadrant Quadrant to draw (1-4).
 */
talk.media.c3d.rasterizeSolidQuarterCircle =
    function(canvas, canvasPaint, x, y, radius, quadrant) {
  // The Canvas only gives us a drawRect method, so we have to draw the circle
  // as a series of rectangles. We do this by subdividing the circle into
  // lines with thickness of 1 pixel and with a possibly non-integer length (O3D
  // is smart enough to scale down the alpha component of fractional pixels).
  // This method results in some visible artifacting at the edges if the
  // adjacent lines are parallel to the tangent, so for best results we use
  // horizontal lines for half of the quarter-circle and vertical lines for the
  // other half.

  if (radius < 0.5) {
    // Our line-based drawing method can't handle a radius under half a pixel,
    // because the sqrt() in the loop would give NaN. Draw nothing instead.
    return;
  }

  // Size of the largest integer square that fits inside the quarter circle.
  // The horizontal lines will fill in this square while the vertical lines will
  // stop outside its boundary (we cannot simply fill it in twice because that
  // would change the alpha).
  var squareSize = Math.floor(Math.sqrt(radius * radius / 2));

  var xmult = (quadrant == 1 || quadrant == 2) ? 1 : -1;
  var ymult = (quadrant == 2 || quadrant == 3) ? 1 : -1;

  for (var i = 0; i <= squareSize; i++) {
    // The 1-pixel-width line has edges at i and i + 1, so we compute its length
    // using the middle, i.e. i + 0.5.
    var lineCenter = i + 0.5;
    var lineLength = Math.sqrt(radius * radius - lineCenter * lineCenter);
    // Vertical line.
    canvas['drawRect'](x + i * xmult,
                       y + squareSize * ymult,
                       x + (i + 1) * xmult,
                       y + lineLength * ymult,
                       canvasPaint);
    if (i != squareSize) {  // Final iteration is for just a single dot
      // Horizontal line.
      canvas['drawRect'](x,
                         y + i * ymult,
                         x + lineLength * xmult,
                         y + (i + 1) * ymult,
                         canvasPaint);
    }
  }
};
