This directory holds example test files that can be registered with Piglit
with ``add_glsl_parser_test()``. For a decription of the the test's
behavior and file format, see the docstrings in file glsl_parser_test.py.
